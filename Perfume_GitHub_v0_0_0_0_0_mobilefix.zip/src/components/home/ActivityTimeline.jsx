import { useState, useMemo } from "react";
// useState is used in both ActivityCard and ActivityTimeline
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Pin, Archive, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import { useNumberEncryption } from "@/lib/useNumberEncryption";
import { useContentEncryption } from "@/lib/useContentEncryption";

const ACTIVITY_COLORS = {
   review: "border-l-rose-500",
   purchase: "border-l-amber-500",
   favorite: "border-l-amber-800",
   wear: "border-l-cyan-500",
   blog: "border-l-orange-500",
   glossary: "border-l-emerald-500",
   goal: "border-l-violet-500",
   budget: "border-l-green-500",
   quote: "border-l-sky-500",
   wish: "border-l-red-400",
   schedule: "border-l-amber-400",
   reminder: "border-l-amber-600",
 };

// Turn raw snake_case values (e.g. "daily_lifestyle", "in_progress") into clean
// spaced, capitalised labels so they never show with underscores in the feed.
const humanize = (v) =>
  String(v || "").replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()).trim();

// Renders text with emojis in their own span to force emoji color presentation on all platforms
function TextWithEmoji({ text, className }) {
  if (!text) return null;
  const parts = text.split(/(\p{Emoji_Presentation}|\p{Extended_Pictographic})/gu);
  return (
    <span className={className}>
      {parts.map((part, i) =>
        /(\p{Emoji_Presentation}|\p{Extended_Pictographic})/u.test(part)
          ? <span key={i} style={{ color: "initial", fontFamily: "initial", WebkitTextFillColor: "initial" }}>{part}</span>
          : part
      )}
    </span>
  );
}

function GoldDivider({ label }) {
  return (
    <div className="flex items-center gap-2 py-2">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-emerald-700/60 to-emerald-600/40" />
      {label && <span className="text-[10px] font-body text-emerald-700 dark:text-emerald-500 font-semibold uppercase tracking-wider px-1">{label}</span>}
      <div className="flex-1 h-px bg-gradient-to-l from-transparent via-emerald-700/60 to-emerald-600/40" />
    </div>
  );
}

function ActivityCard({ activity, isPinned, isArchived, onPin, onArchive, onDelete, navigate, names, profiles, isAr }) {
  const isGlossary = activity.type === "glossary";
  const glossaryColor = "#10b981";
  const personColor = isGlossary
    ? glossaryColor
    : activity.person === "person2"
      ? (profiles?.person2?.color || "#8b5cf6")
      : (profiles?.person1?.color || "#10b981");

  // Border on right for Arabic, left for English
  const borderStyle = isAr
    ? { borderRightColor: personColor, borderRightWidth: 2, borderRightStyle: "solid" }
    : { borderLeftColor: personColor, borderLeftWidth: 2, borderLeftStyle: "solid" };

  const [expanded, setExpanded] = useState(false);

  return (
    <div
      className={`flex items-stretch transition-colors ${activity.clickPath ? "cursor-pointer hover:bg-primary/5" : "cursor-default"}`}
      style={{ borderRadius: 0, ...borderStyle }}
      onClick={() => activity.clickPath && navigate(activity.clickPath, { state: { from: "activities" } })}
    >
      {/* Text content */}
      <div className={`flex-1 px-3 py-4 min-w-0 ${isAr ? "text-right" : "text-left"}`}>
        {activity.type === "glossary" ? (
          <div className="flex items-baseline gap-2 flex-wrap">
            <span className="text-sm font-body font-normal" style={{ color: "#b8960c", fontFamily: "'Playfair Display', serif" }}>{activity.title}</span>
            {activity.subtitle && <span className="text-xs text-emerald-600 dark:text-emerald-400 font-body" dir="rtl">{activity.subtitle}</span>}
          </div>
        ) : (
          <>
            <p className="text-sm font-body font-medium"><TextWithEmoji text={activity.title} /></p>
            <p className="text-xs text-muted-foreground font-body">{activity.subtitle}</p>
          </>
        )}
        {activity.rating ? (
          <p className="text-xs font-body mt-0.5" style={{ color: "var(--brand)", letterSpacing: "1px" }}>{"■".repeat(Math.round(activity.rating))}{"□".repeat(Math.max(0, 5 - Math.round(activity.rating)))}</p>
        ) : null}
      </div>

      {/* Right strip — diamond always visible, icons shown when expanded */}
      <div
        className="flex flex-col items-center justify-center gap-1 px-1.5 border-l border-border/30"
        onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); }}
      >
        {expanded && (
          <>
            <button
              onClick={(e) => { e.stopPropagation(); onArchive(activity.id); setExpanded(false); }}
              className={`p-1 transition-colors ${isArchived ? "text-amber-500" : "text-muted-foreground hover:text-foreground"}`}
              title={isArchived ? "Unarchive" : "Archive"}
            >
              <Archive className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={(e) => { e.stopPropagation(); onPin(activity.id); setExpanded(false); }}
              className={`p-1 transition-colors ${isPinned ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}
              title={isPinned ? "Unpin" : "Pin"}
            >
              <Pin className="w-3.5 h-3.5" fill={isPinned ? "currentColor" : "none"} />
            </button>

          </>
        )}

        {/* Diamond — always visible, click to toggle */}
        {isGlossary ? (
          <div style={{ width: 10, height: 10, background: "#10b981", flexShrink: 0, cursor: "pointer" }} />
        ) : (
          <div style={{ width: 10, height: 10, background: expanded ? personColor : "transparent", border: `1.5px solid ${personColor}`, flexShrink: 0, cursor: "pointer" }} />
        )}
      </div>
    </div>
  );
}

export default function ActivityTimeline({ filters, sortOrder }) {
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();
  const { isAr } = useLang();
  const { decryptFields, userId } = useNumberEncryption();
  const { decryptFields: decryptContent, userId: contentUserId } = useContentEncryption();
  const [currentPage, setCurrentPage] = useState(1);
  const ITEMS_PER_PAGE = 50;

  const [pinnedIds, setPinnedIds] = useState(() => {
    const saved = localStorage.getItem("pinnedActivities");
    return saved ? JSON.parse(saved) : [];
  });

  const [archivedIds, setArchivedIds] = useState(() => {
    const saved = localStorage.getItem("archivedActivities");
    return saved ? JSON.parse(saved) : [];
  });

  const [showArchived, setShowArchived] = useState(false);

  const STALE = 1000 * 60 * 5; // 5 minutes

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
    staleTime: STALE,
  });

  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
    staleTime: STALE,
  });

  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-created_date"),
    staleTime: STALE,
  });

  const { data: wearSchedules = [] } = useQuery({
    queryKey: ["wear-schedules"],
    queryFn: () => apphost.entities.WearSchedule.list("scheduled_date"),
    staleTime: STALE,
  });

  const { data: blogPosts = [] } = useQuery({
    queryKey: ["blog-posts", contentUserId],
    queryFn: async () => {
      const raw = await apphost.entities.BlogPost.list("-created_date");
      if (!contentUserId) return raw;
      return Promise.all(raw.map(async (bp) => {
        try {
          const dec = await decryptContent(bp, ['title']);
          return dec;
        } catch { return bp; }
      }));
    },
    staleTime: STALE,
    enabled: !!contentUserId,
  });

  const { data: glossaryTerms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
    staleTime: STALE,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => apphost.entities.Goal.list("-created_date"),
    staleTime: STALE,
  });

  const { data: budgetIncomes = [] } = useQuery({
    queryKey: ["budget-incomes"],
    queryFn: () => apphost.entities.BudgetIncome.list("-created_date"),
    staleTime: STALE,
  });

  const { data: budgetExpenses = [] } = useQuery({
    queryKey: ["budget-expenses"],
    queryFn: () => apphost.entities.BudgetExpense.list("-created_date"),
    staleTime: STALE,
  });

  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-created_date"),
    staleTime: STALE,
  });

  const { data: allQuotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("name"),
    staleTime: STALE,
  });

  const { data: shopProducts = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: STALE,
  });

  const { data: wishlists = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-created_date"),
    staleTime: STALE,
  });

  const allActivities = useMemo(() => {
    const all = [];
    const f = filters || { reviews: true, purchases: false, favorites: true, wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true, budgetEntries: true, quotesActivity: true, wishes: false };

    const tr = (en, ar) => isAr ? ar : en;

    if (f.reviews) {
      userPerfumes.forEach((up) => {
        if (up.rating || up.impression) {
          all.push({ type: "review", id: `rev-${up.id}`, title: tr(`Reviewed ${up.perfume_name}`, `تقييم ${up.perfume_name}`), subtitle: tr(`by ${up.brand_name}`, `${up.brand_name}`), rating: up.rating, person: up.person, clickPath: `/perfume?id=${up.perfume_id}`, date: new Date(up.created_date) });
        }
      });
    }
    if (f.wishes) {
      wishlists.forEach((w) => {
        if (w.perfume_id) {
          all.push({ type: "wish", id: `wish-${w.id}`, title: tr(`Added to wishlist`, `أُضيف للأمنيات`), subtitle: `${w.perfume_name || ""} ${w.brand_name || ""}`, person: w.person, clickPath: `/perfume?id=${w.perfume_id}`, date: new Date(w.added_date || w.created_date) });
        }
      });
    }
    if (f.purchases) {
      purchaseRecords.forEach((pr) => {
        all.push({ type: "purchase", id: `pur-${pr.id}`, title: tr(`Purchased ${pr.type === "sample" ? "sample" : "bottle"}`, `شراء ${pr.type === "sample" ? "عينة" : "زجاجة"}`), subtitle: `${pr.perfume_name} ${pr.ml}ml`, person: pr.person, clickPath: `/perfume?id=${pr.perfume_id}`, date: new Date(pr.purchase_date || pr.created_date) });
      });
    }
    if (f.favorites) {
      userPerfumes.forEach((up) => {
        if (up.list === "favorite") {
          all.push({ type: "favorite", id: `fav-${up.id}`, title: tr(`Added to favorites`, `أُضيف للمفضلة`), subtitle: `${up.perfume_name} ${up.brand_name}`, person: up.person, clickPath: `/perfume?id=${up.perfume_id}`, date: new Date(up.created_date) });
        }
      });
    }
    if (f.wearLogs) {
      wearLogs.forEach((wl) => {
        all.push({ type: "wear", id: `wear-${wl.id}`, title: tr(`Wore ${wl.perfume_name}`, `تم ارتداء ${wl.perfume_name}`), subtitle: `${wl.brand_name}`, person: wl.person, clickPath: `/perfume?id=${wl.perfume_id}`, date: new Date(wl.date || wl.created_date) });
      });
      // جدولة الارتداء: مدخل عند الإنشاء + تذكير في يوم الجدولة
      const todayStr = new Date().toISOString().slice(0, 10);
      wearSchedules.forEach((s) => {
        // مدخل الإنشاء (متى أُنشئت الجدولة)
        all.push({ type: "schedule", id: `sched-${s.id}`, title: tr(`Scheduled ${s.perfume_name}`, `جُدول ارتداء ${s.perfume_name}`), subtitle: `${s.brand_name || ""} ${s.scheduled_date}`, person: s.person, clickPath: `/perfume?id=${s.perfume_id}`, date: new Date(s.created_date) });
        // تذكير في يوم الجدولة (إذا كان اليوم هو يوم الارتداء ولم يُنفّذ بعد)
        if (s.is_active && s.scheduled_date === todayStr && s.last_done_date !== todayStr) {
          all.push({ type: "reminder", id: `remind-${s.id}`, title: tr(`Wear today: ${s.perfume_name}`, `ارتدِ اليوم: ${s.perfume_name}`), subtitle: `${s.brand_name || ""}${s.note ? ` ${s.note}` : ""}`, person: s.person, clickPath: `/perfume?id=${s.perfume_id}`, date: new Date(s.scheduled_date + "T08:00:00") });
        }
      });
    }
    if (f.blogEntries) {
      blogPosts.forEach((bp) => {
        all.push({ type: "blog", id: `blog-${bp.id}`, title: bp.title, subtitle: tr(`${humanize(bp.entry_type)} entry`, `مدخل ${humanize(bp.entry_type)}`), person: bp.person, clickPath: `/blog?id=${bp.id}`, date: new Date(bp.created_date) });
      });
    }

    if (f.glossaryEntries !== false) {
      glossaryTerms.forEach((gt) => {
        all.push({ type: "glossary", id: `gl-${gt.id}`, title: isAr ? (gt.term_ar || gt.term_en) : gt.term_en, subtitle: isAr ? gt.term_en : (gt.term_ar || ""), person: null, clickPath: `/glossary-term?id=${gt.id}`, date: new Date(gt.created_date) });
      });
    }

    if (f.goals !== false) {
      goals.forEach((g) => {
        all.push({ type: "goal", id: `goal-${g.id}`, title: g.title, subtitle: `${humanize(g.category) || ""} ${g.status ? humanize(g.status) : tr("Pending", "قيد الانتظار")}`, person: g.person === "both" ? null : g.person, clickPath: `/goals`, date: new Date(g.created_date) });
      });
    }

    if (f.quotesActivity !== false) {
      userQuotes.forEach((uq) => {
        const quote = allQuotes.find((q) => String(q.id) === String(uq.quote_id));
        const reactionLabel = uq.reaction === "like" ? "❤️" : uq.reaction === "dislike" ? "💔" : uq.reaction === "wtf" ? "😱" : "💬";
        const isNew = !uq.reaction || uq.reaction === "none";
        const title = isNew ? tr(`Added quote`, `أُضيفت اقتباس`) : tr(`Reacted ${reactionLabel} to quote`, `تفاعل ${reactionLabel} مع اقتباس`);
        const subtitle = quote ? (isAr ? quote.text_ar : quote.text_en || "").slice(0, 60) + ((isAr ? quote.text_ar : quote.text_en)?.length > 60 ? "…" : "") : "";
        all.push({ type: "quote", id: `uq-${uq.id}`, title, subtitle, person: null, clickPath: `/quotes`, date: new Date(uq.created_date) });
      });
    }

    if (f.budgetEntries !== false) {
      budgetIncomes.forEach((inc) => {
        all.push({ type: "budget", id: `inc-${inc.id}`, title: tr(`Income: ${inc.type}`, `دخل: ${inc.type}`), subtitle: `${inc.amount} ${inc.date || ""}`, person: inc.person === "family" ? null : inc.person, clickPath: `/budget`, date: new Date(inc.date || inc.created_date) });
      });
      budgetExpenses.forEach((exp) => {
        all.push({ type: "budget", id: `exp-${exp.id}`, title: tr(`Expense: ${exp.category}`, `مصروف: ${exp.category}`), subtitle: `${exp.amount} ${exp.description || ""}`, person: exp.person === "family" ? null : exp.person, clickPath: `/budget`, date: new Date(exp.date || exp.created_date) });
      });
    }

    if (f.purchases) {
      shopProducts.forEach((sp) => {
        if (sp.cost && sp.purchase_date) {
          all.push({ type: "purchase", id: `shop-${sp.id}`, title: tr(`Purchased ${sp.name}`, `شراء ${sp.name}`), subtitle: `${sp.brand_name || tr("Unknown", "غير معروف")} ${sp.cost} ${sp.recurring ? tr("(Recurring)", "(متكرر)") : ""}`, person: sp.person, clickPath: `/shop-product?id=${sp.id}`, date: new Date(sp.purchase_date) });
        }
      });
    }

    const sort = sortOrder || "newest";
    if (sort === "alpha_asc") {
      all.sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    } else if (sort === "alpha_desc") {
      all.sort((a, b) => (b.title || "").localeCompare(a.title || ""));
    } else {
      all.sort((a, b) => sort === "newest" ? b.date - a.date : a.date - b.date);
    }
    return all;
  }, [userPerfumes, purchaseRecords, wearLogs, blogPosts, glossaryTerms, goals, budgetIncomes, budgetExpenses, userQuotes, allQuotes, wishlists, filters, sortOrder, isAr]);

  const pinned = allActivities.filter((a) => pinnedIds.includes(a.id) && !archivedIds.includes(a.id));
  const active = allActivities.filter((a) => !pinnedIds.includes(a.id) && !archivedIds.includes(a.id));
  const archived = allActivities.filter((a) => archivedIds.includes(a.id));
  
  const totalPages = Math.ceil(active.length / ITEMS_PER_PAGE);
  const paginatedActive = active.slice((currentPage - 1) * ITEMS_PER_PAGE, currentPage * ITEMS_PER_PAGE);

  const togglePin = (id) => {
    let newPinned = [...pinnedIds];
    if (newPinned.includes(id)) {
      newPinned = newPinned.filter((pid) => pid !== id);
    } else {
      if (newPinned.length >= 20) newPinned.shift();
      newPinned.push(id);
    }
    setPinnedIds(newPinned);
    localStorage.setItem("pinnedActivities", JSON.stringify(newPinned));
  };

  const toggleArchive = (id) => {
    let newArchived = [...archivedIds];
    if (newArchived.includes(id)) {
      newArchived = newArchived.filter((aid) => aid !== id);
    } else {
      newArchived.push(id);
      // If pinned, unpin when archiving
      if (pinnedIds.includes(id)) {
        const newPinned = pinnedIds.filter((pid) => pid !== id);
        setPinnedIds(newPinned);
        localStorage.setItem("pinnedActivities", JSON.stringify(newPinned));
      }
    }
    setArchivedIds(newArchived);
    localStorage.setItem("archivedActivities", JSON.stringify(newArchived));
  };

  if (allActivities.length === 0) return null;

  return (
    <div className="space-y-0">
      {/* Pinned Section */}
      {pinned.length > 0 && (
        <>
          <GoldDivider label="Pinned" />
          <div className="space-y-5">
            {pinned.map((activity) => (
              <ActivityCard key={activity.id} activity={activity} isPinned={true} isArchived={false} onPin={togglePin} onArchive={toggleArchive} navigate={navigate} names={names} profiles={profiles} isAr={isAr} />
            ))}
          </div>
        </>
      )}

      {/* Activities Section */}
       {active.length > 0 && (
         <>
           <GoldDivider label={pinned.length > 0 ? "Activities" : undefined} />
           <div className="space-y-5">
             {paginatedActive.map((activity) => (
               <ActivityCard key={activity.id} activity={activity} isPinned={false} isArchived={false} onPin={togglePin} onArchive={toggleArchive} navigate={navigate} names={names} profiles={profiles} isAr={isAr} />
             ))}
           </div>

           {/* Pagination */}
           {totalPages > 1 && (
             <div className="flex items-center justify-center gap-2 py-4 mt-4 border-t border-border/30">
               <button
                 onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                 disabled={currentPage === 1}
                 className=" rounded-none text-xs font-body disabled:opacity-40 transition-colors"
               >
                 {isAr ? "→ السابق" : "← Prev"}
               </button>
               <span className="text-xs font-body text-muted-foreground">
                 {currentPage} / {totalPages}
               </span>
               <button
                 onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                 disabled={currentPage === totalPages}
                 className=" rounded-none text-xs font-body disabled:opacity-40 transition-colors"
               >
                 {isAr ? "التالي ←" : "Next →"}
               </button>
             </div>
           )}
         </>
       )}

      {/* Archived Section */}
      {archived.length > 0 && (
        <>
          <GoldDivider label="Archived" />
          <button
            onClick={() => setShowArchived(!showArchived)}
            className="w-full flex items-center justify-center gap-1.5 py-2 text-xs font-body text-muted-foreground hover:text-foreground transition-colors"
          >
            {showArchived ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            {showArchived ? "Hide Archived" : `Show Archived Activities (${archived.length})`}
          </button>
          {showArchived && (
            <div className="space-y-5 opacity-60">
              {archived.map((activity) => (
                <ActivityCard key={activity.id} activity={activity} isPinned={false} isArchived={true} onPin={togglePin} onArchive={toggleArchive} navigate={navigate} names={names} profiles={profiles} isAr={isAr} />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}