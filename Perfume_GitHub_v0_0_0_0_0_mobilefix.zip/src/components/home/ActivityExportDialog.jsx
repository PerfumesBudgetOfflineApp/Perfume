import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, FileText, Image, FileImage } from "lucide-react";
import { format, subDays, subWeeks, subMonths, subYears } from "date-fns";
import { openHtmlReport, saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";
const PERIOD_OPTIONS = [
  { value: "day", label: "Today" },
  { value: "week", label: "This Week" },
  { value: "month", label: "This Month" },
  { value: "year", label: "This Year" },
  { value: "all", label: "All Time" },
];

const TYPE_OPTIONS = [
  { key: "reviews", label: "📝 Reviews" },
  { key: "purchases", label: "🛍 Purchases" },
  { key: "favorites", label: "🤎 Favorites" },
  { key: "wearLogs", label: "💧 Wear Logs" },
  { key: "blogEntries", label: "📖 Blog Entries" },
  { key: "glossaryEntries", label: "📚 Glossary" },
  { key: "goals", label: "🎯 Goals / Tasks" },
  { key: "budgetEntries", label: "💰 Budget Entries" },
  { key: "quotesActivity", label: "💬 Quotes" },
];

const FORMAT_OPTIONS = [
  { value: "txt", label: "Text (.txt)", icon: FileText },
  { value: "pdf", label: "PDF (.pdf)", icon: FileImage },
  { value: "image", label: "Image (.png)", icon: Image },
];

const TYPE_MAP = {
  review: "reviews", purchase: "purchases", favorite: "favorites",
  wear: "wearLogs", blog: "blogEntries", glossary: "glossaryEntries", goal: "goals",
  budget: "budgetEntries", quote: "quotesActivity",
};

const LABEL_MAP = {
  review: "Reviews", purchase: "Purchases", favorite: "Favorites",
  wear: "Wear Logs", blog: "Blog Entries", glossary: "Glossary Terms", goal: "Goals / Tasks",
  budget: "Budget Entries", quote: "Quotes",
};

function getStartDate(period) {
  const now = new Date();
  if (period === "day") return subDays(now, 1);
  if (period === "week") return subWeeks(now, 1);
  if (period === "month") return subMonths(now, 1);
  if (period === "year") return subYears(now, 1);
  return null;
}

export default function ActivityExportDialog({ open, onOpenChange, activities }) {
  const [period, setPeriod] = useState("month");
  const [exportFormat, setExportFormat] = useState("txt");
  const [selectedTypes, setSelectedTypes] = useState({
    reviews: true, purchases: true, favorites: true,
    wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true,
    budgetEntries: true, quotesActivity: true,
  });
  const [exporting, setExporting] = useState(false);
  const previewRef = useRef(null);

  const toggleType = (key) => setSelectedTypes((s) => ({ ...s, [key]: !s[key] }));

  const getFiltered = () => {
    const startDate = getStartDate(period);
    return activities.filter((a) => {
      const typeKey = TYPE_MAP[a.type];
      if (!selectedTypes[typeKey]) return false;
      if (startDate && a.date < startDate) return false;
      return true;
    });
  };

  const buildLines = async (filtered) => {
    const periodLabel = PERIOD_OPTIONS.find((p) => p.value === period)?.label || period;
    const lines = [];
    lines.push(`Activity Report — ${periodLabel}`);
    lines.push(`Generated: ${format(new Date(), "yyyy-MM-dd HH:mm")}`);
    lines.push(`Total: ${filtered.length} activities`);
    lines.push("=".repeat(50));
    lines.push("");
    const grouped = {};
    filtered.forEach((a) => {
      if (!grouped[a.type]) grouped[a.type] = [];
      grouped[a.type].push(a);
    });
    Object.entries(grouped).forEach(([type, items]) => {
      lines.push(`── ${LABEL_MAP[type] || type} (${items.length})`);
      items.forEach((a) => {
        const dateStr = a.date ? format(new Date(a.date), "yyyy-MM-dd") : "";
        lines.push(`  • ${a.title}${a.subtitle ? " — " + a.subtitle : ""}${dateStr ? " (" + dateStr + ")" : ""}`);
      });
      lines.push("");
    });
    return lines;
  };

  const exportTxt = async (filtered) => {
    const lines = buildLines(filtered);
    const blob = new Blob([lines.join("\n")], { type: "text/plain;charset=utf-8" });
    await downloadBlob(blob, `activity-report-${period}-${format(new Date(), "yyyyMMdd")}.txt`);
  };

  const exportPdf = async (filtered) => {
    const periodLabel = PERIOD_OPTIONS.find((p) => p.value === period)?.label || period;

    // Group by type
    const grouped = {};
    filtered.forEach((a) => {
      if (!grouped[a.type]) grouped[a.type] = [];
      grouped[a.type].push(a);
    });

    const sectionsHtml = Object.entries(grouped).map(([type, items]) => {
      const rows = items.map((a) => {
        const dateStr = a.date ? format(new Date(a.date), "yyyy-MM-dd") : "";
        return `<div style="padding:5px 0 5px 12px; border-bottom:1px solid #f0ede6; font-size:12px; color:#333;">
          <span style="color:#16a34a;">•</span> 
          <strong>${a.title}</strong>
          ${a.emoji ? `<span style="font-size:14px;"> ${a.emoji}</span>` : ""}
          ${a.ratingStars ? `<span style="color:#f59e0b; font-size:11px;"> ${a.ratingStars}</span>` : ""}
          ${a.subtitle ? `<span style="color:#888;"> — ${a.subtitle}</span>` : ""}
          ${dateStr ? `<span style="color:#aaa; font-size:10px;"> (${dateStr})</span>` : ""}
        </div>`;
      }).join("");

      return `
        <div style="margin-bottom:18px;">
          <div style="background:#fdf6e3; border-left:3px solid #c8962a; padding:6px 10px; font-weight:bold; font-size:13px; color:#7a5c1e; margin-bottom:4px;">
            ${LABEL_MAP[type] || type} <span style="font-weight:normal; color:#aaa;">(${items.length})</span>
          </div>
          ${rows}
        </div>`;
    }).join("");

    const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8"/>
  <title>تقرير النشاط Activity Report</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700&display=swap');
    * { box-sizing: border-box; }
    body {
      font-family: 'Cairo', 'Arial', 'Segoe UI', Tahoma, sans-serif;
      direction: rtl;
      margin: 0;
      padding: 32px 40px;
      background: #fff;
      color: #222;
    }
    h1 { font-size: 22px; color: #7a5c1e; margin:0 0 4px; }
    .meta { font-size: 11px; color: #aaa; margin-bottom: 20px; }
    hr { border: none; border-top: 1px solid #e8d9b0; margin: 16px 0; }
    @media print {
      body { padding: 20px 28px; }
    }
  </style>
</head>
<body>
  <h1>Activity Report — ${periodLabel}</h1>
  <div class="meta">
    Generated: ${format(new Date(), "yyyy-MM-dd HH:mm")} &nbsp;|&nbsp; Total: ${filtered.length} activities
  </div>
  <hr/>
  ${sectionsHtml}
</body>
</html>`;

    await openHtmlReport(html);
  };

  const exportImage = async (filtered) => {
    const periodLabel = PERIOD_OPTIONS.find((p) => p.value === period)?.label || period;

    // Group by type
    const grouped = {};
    filtered.forEach((a) => {
      if (!grouped[a.type]) grouped[a.type] = [];
      grouped[a.type].push(a);
    });

    // Canvas dimensions — wide landscape card
    const W = 1200;
    const PADDING = 56;
    const colGap = 32;
    const cols = 2;
    const colW = (W - PADDING * 2 - colGap) / cols;

    // We'll measure height dynamically
    const canvas = document.createElement("canvas");
    canvas.width = W;
    const ctx = canvas.getContext("2d");

    const drawCard = (ctx, totalH) => {
      // White background
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, W, totalH);

      // Subtle top accent bar
      ctx.fillStyle = "#16a34a";
      ctx.fillRect(0, 0, W, 6);

      // Header area
      ctx.fillStyle = "#f9fafb";
      ctx.fillRect(0, 6, W, 80);

      // Title
      ctx.font = "bold 28px 'Georgia', serif";
      ctx.fillStyle = "#111827";
      ctx.textAlign = "left";
      ctx.fillText("Activity Report", PADDING, 52);

      // Period pill
      const pillText = periodLabel;
      ctx.font = "13px 'Arial', sans-serif";
      const pillW = ctx.measureText(pillText).width + 24;
      ctx.fillStyle = "#dcfce7";
      roundRect(ctx, W - PADDING - pillW, 28, pillW, 26, 13);
      ctx.fillStyle = "#16a34a";
      ctx.font = "bold 13px 'Arial', sans-serif";
      ctx.textAlign = "right";
      ctx.fillText(pillText, W - PADDING - 12, 46);

      // Date & count
      ctx.font = "12px 'Arial', sans-serif";
      ctx.fillStyle = "#9ca3af";
      ctx.textAlign = "left";
      ctx.fillText(`${format(new Date(), "dd MMM yyyy")}  ·  ${filtered.length} activities`, PADDING, 74);

      // Divider
      ctx.strokeStyle = "#e5e7eb";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(PADDING, 90);
      ctx.lineTo(W - PADDING, 90);
      ctx.stroke();

      return 110; // content starts at y=110
    };

    // First pass: measure total height
    let leftH = 110, rightH = 110;
    const types = Object.keys(grouped);
    types.forEach((type, idx) => {
      const items = grouped[type];
      const isLeft = idx % 2 === 0;
      const sectionH = 36 + items.length * 36 + 16;
      if (isLeft) leftH += sectionH;
      else rightH += sectionH;
    });
    const totalH = Math.max(leftH, rightH) + PADDING;

    canvas.height = totalH;

    // Draw background and header
    let contentY = drawCard(ctx, totalH);

    // Bottom accent bar
    ctx.fillStyle = "#16a34a";
    ctx.fillRect(0, totalH - 6, W, 6);

    // Draw sections in two columns
    let leftY = contentY;
    let rightY = contentY;

    types.forEach((type, idx) => {
      const items = grouped[type];
      const isLeft = idx % 2 === 0;
      const x = isLeft ? PADDING : PADDING + colW + colGap;
      let y = isLeft ? leftY : rightY;

      // Section header
      const headerLabel = LABEL_MAP[type] || type;
      ctx.fillStyle = "#f3f4f6";
      roundRect(ctx, x, y, colW, 28, 6);
      ctx.fillStyle = "#374151";
      ctx.font = "bold 13px 'Arial', sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`${headerLabel}  (${items.length})`, x + 12, y + 19);
      y += 36;

      // Items
      items.forEach((a) => {
        const dateStr = a.date ? format(new Date(a.date), "MMM d") : "";

        // Item row bg on hover-like alternating
        ctx.fillStyle = "#fafafa";
        roundRect(ctx, x, y, colW, 30, 5);

        // Dot
        ctx.fillStyle = "#d1d5db";
        ctx.beginPath();
        ctx.arc(x + 14, y + 15, 3, 0, Math.PI * 2);
        ctx.fill();

        // Title
        ctx.font = "13px 'Arial', sans-serif";
        ctx.fillStyle = "#111827";
        ctx.textAlign = "left";
        const titleMaxW = colW - 130;
        let titleText = a.title;
        while (ctx.measureText(titleText).width > titleMaxW && titleText.length > 10) {
          titleText = titleText.slice(0, -1);
        }
        if (titleText !== a.title) titleText += "…";
        ctx.fillText(titleText, x + 26, y + 19);

        // Emoji for reviews
        if (a.emoji) {
          ctx.font = "14px 'Segoe UI Emoji', 'Apple Color Emoji', sans-serif";
          ctx.fillText(a.emoji, x + 26 + ctx.measureText(titleText.replace(/…$/, "")).width + 6, y + 19);
        }

        // Rating stars
        if (a.ratingStars) {
          ctx.font = "11px 'Arial', sans-serif";
          ctx.fillStyle = "#f59e0b";
          ctx.textAlign = "right";
          ctx.fillText(a.ratingStars, x + colW - 60, y + 19);
        }

        // Date
        ctx.font = "11px 'Arial', sans-serif";
        ctx.fillStyle = "#9ca3af";
        ctx.textAlign = "right";
        ctx.fillText(dateStr, x + colW - 8, y + 19);

        y += 36;
      });

      y += 16;
      if (isLeft) leftY = y;
      else rightY = y;
    });

    // Column separator line
    ctx.strokeStyle = "#e5e7eb";
    ctx.lineWidth = 1;
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(PADDING + colW + colGap / 2, 110);
    ctx.lineTo(PADDING + colW + colGap / 2, totalH - 20);
    ctx.stroke();
    ctx.setLineDash([]);

    await saveCanvasAsImage(canvas, `activity-report-${period}-${format(new Date(), "yyyyMMdd")}.png`);
  };

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
    ctx.fill();
  }

  const handleExport = async () => {
    const filtered = getFiltered();
    if (filtered.length === 0) {
      alert("No activities match the selected filters.");
      return;
    }
    setExporting(true);
    try {
      if (exportFormat === "txt") exportTxt(filtered);
      else if (exportFormat === "pdf") exportPdf(filtered);
      else if (exportFormat === "image") await exportImage(filtered);
    } finally {
      setExporting(false);
    }
  };

  const previewCount = getFiltered().length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">تصدير تقرير النشاط Export Activity Report</DialogTitle>
          <DialogDescription>
            Choose time period, format, and activity types to export
          </DialogDescription>
        </DialogHeader>
          <ExportOptionsBar />

        <div className="space-y-4">
          {/* Period */}
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">الفترة الزمنية Time Period</p>
            <div className="grid grid-cols-3 gap-1.5">
              {PERIOD_OPTIONS.map(({ value, label }) => (
                <button key={value} onClick={() => setPeriod(value)}
                  className={`py-2 rounded-none text-xs font-body font-medium transition-all ${period === value ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Format */}
          <div className="space-y-2">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">صيغة التصدير Export Format</p>
            <div className="grid grid-cols-3 gap-1.5">
              {FORMAT_OPTIONS.map(({ value, label, icon: Icon }) => (
                <button key={value} onClick={() => setExportFormat(value)}
                  className={`flex flex-col items-center gap-1 py-2.5 rounded-none text-[10px] font-body font-medium transition-all ${exportFormat === value ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                  <Icon className="w-4 h-4" />
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Types */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">تضمين Include</p>
              <button
                onClick={() => {
                  const allOn = TYPE_OPTIONS.every((t) => selectedTypes[t.key]);
                  const next = {};
                  TYPE_OPTIONS.forEach((t) => (next[t.key] = !allOn));
                  setSelectedTypes(next);
                }}
                className="text-[10px] text-primary font-body underline"
              >
                {TYPE_OPTIONS.every((t) => selectedTypes[t.key]) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="space-y-1.5">
              {TYPE_OPTIONS.map(({ key, label }) => (
                <button key={key} onClick={() => toggleType(key)} className="w-full flex items-center gap-2 text-xs font-body">
                  <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors flex-shrink-0 ${selectedTypes[key] ? "bg-primary border-primary" : "border-border"}`}>
                    {selectedTypes[key] && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={selectedTypes[key] ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Preview count */}
          <p className="text-xs text-muted-foreground font-body text-center">
            {previewCount} activities will be exported
          </p>

          <Button className="w-full h-10 rounded-none font-body gap-2" onClick={handleExport} disabled={previewCount === 0 || exporting}>
            <Download className="w-4 h-4" />
            {exporting ? "Exporting..." : `Export as ${exportFormat.toUpperCase()}`}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}