import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Link } from "react-router-dom";
import { Heart, ThumbsUp, ThumbsDown, RotateCw } from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import BookmarkButton from "@/components/shared/BookmarkButton";

/**
 * RandomQuote — اقتباس عشوائي على Goals/Home.
 * يعرض اللغتين دائماً، بلا تصنيف، بخلفية مختلفة وبلا إطارات، وبخمسة أزرار
 * تفاعل بلا إطارات: مفضّل · إعجاب · عدم إعجاب · مذهول 😱 · إبعاد (cast away).
 * الإبعاد يُخفي الاقتباس من الدوران ويسجّله reaction="castaway".
 */
export default function RandomQuote({ linkTo }) {
  const { isAr } = useLang();
  const [currentQuote, setCurrentQuote] = useState(null);
  const qc = useQueryClient();

  const { data: quotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("-created_date"),
  });

  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-updated_date"),
  });

  const userQuoteMap = useMemo(() => {
    const m = {};
    for (const uq of userQuotes) m[String(uq.quote_id)] = uq;
    return m;
  }, [userQuotes]);

  const reactionMutation = useMutation({
    mutationFn: async ({ quoteId, reaction }) => {
      const existing = userQuoteMap[String(quoteId)];
      const quote = quotes.find((q) => String(q.id) === String(quoteId));
      if (existing) {
        return apphost.entities.UserQuote.update(existing.id, {
          reaction, text_enar: quote?.text_enar, category: quote?.category,
        });
      }
      return apphost.entities.UserQuote.create({
        quote_id: quoteId, text_enar: quote?.text_enar, category: quote?.category, reaction,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const pickNewQuote = (excludeId = null) => {
    const ex = excludeId != null ? String(excludeId) : null;
    const withText = quotes.filter(
      (q) => (q.text_enar || q.text_en || q.text_ar || q.text) &&
        userQuoteMap[String(q.id)]?.reaction !== "castaway" &&
        String(q.id) !== ex
    );
    const pool = withText.length > 0 ? withText : quotes.filter((q) => String(q.id) !== ex);
    if (pool.length > 0) setCurrentQuote(pool[Math.floor(Math.random() * pool.length)]);
  };

  useEffect(() => {
    pickNewQuote();
     
  }, [quotes.length]);

  useEffect(() => {
    const handle = () => pickNewQuote();
    window.addEventListener("refreshQuote", handle);
    return () => window.removeEventListener("refreshQuote", handle);
     
  }, [quotes.length]);

  if (!currentQuote) return null;

  const userReaction = userQuoteMap[String(currentQuote.id)]?.reaction || "none";
  const react = (reaction) => {
    const newReaction = userReaction === reaction ? "none" : reaction;
    reactionMutation.mutate({ quoteId: currentQuote.id, reaction: newReaction });
    if (newReaction === "castaway") {
      const castId = currentQuote.id;
      setTimeout(() => pickNewQuote(castId), 0);
    }
  };

  // اللغتان دائماً: نفضّل المدمج، وإلا نعرض الإنجليزي والعربي معاً.
  const enar = currentQuote.text_enar || "";
  const en = currentQuote.text_en || currentQuote.text || "";
  const ar = currentQuote.text_ar || "";

  const RBtn = ({ active, activeColor, title, onClick, children }) => (
    <button
      type="button"
      onClick={onClick}
      title={title}
      aria-label={title}
      className={`flex items-center justify-center w-8 h-8 bg-transparent transition-all ${
        active ? activeColor : "text-muted-foreground/55 hover:text-foreground"
      }`}
    >
      {children}
    </button>
  );

  return (
    <div className="px-1 py-2 space-y-3">
      {/* Bilingual quote — always both languages */}
      {enar ? (
        <p className="text-sm font-body font-medium leading-relaxed" dir="auto" style={{ unicodeBidi: "plaintext" }}>{enar}</p>
      ) : (
        <div className="space-y-1">
          {en && <p className="text-sm font-body font-medium leading-relaxed" dir="ltr">{en}</p>}
          {ar && <p className="text-sm font-body font-medium leading-relaxed" dir="rtl">{ar}</p>}
        </div>
      )}

      {currentQuote.author && (
        <p className="text-xs text-muted-foreground font-body" dir="auto" style={{ unicodeBidi: "plaintext" }}>— {currentQuote.author}</p>
      )}

      {currentQuote.category && (
        <span className="inline-block text-[10px] font-body text-amber-700 dark:text-amber-300" dir="auto" style={{ unicodeBidi: "plaintext" }}>
          {currentQuote.category}
        </span>
      )}

      <div className="flex items-center gap-2 justify-between pt-1 flex-wrap-reverse">
        <div className="flex gap-2 items-center">
          {linkTo && (
            <Link to={linkTo} className="text-primary text-[10px] font-body hover:underline whitespace-nowrap">
              {isAr ? "كل الاقتباسات" : "Read all quotes"}
            </Link>
          )}
          <button type="button" onClick={pickNewQuote}
            className="p-1.5 text-muted-foreground/60 hover:text-primary transition-colors"
            title={isAr ? "اقتباس آخر" : "Next quote"}>
            <RotateCw className="w-4 h-4" />
          </button>
        </div>
        {/* Five reactions, borderless */}
        <div className="flex gap-1 items-center">
          <RBtn active={userReaction === "favorite"} activeColor="text-rose-500" title={isAr ? "مفضّل" : "Favourite"} onClick={() => react("favorite")}>
            <Heart className={`w-4 h-4 ${userReaction === "favorite" ? "fill-current" : ""}`} />
          </RBtn>
          <RBtn active={userReaction === "like"} activeColor="text-emerald-600" title={isAr ? "إعجاب" : "Like"} onClick={() => react("like")}>
            <ThumbsUp className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "dislike"} activeColor="text-slate-500" title={isAr ? "عدم إعجاب" : "Dislike"} onClick={() => react("dislike")}>
            <ThumbsDown className="w-4 h-4" />
          </RBtn>
          <RBtn active={userReaction === "wtf"} activeColor="opacity-100" title={isAr ? "مذهل/غريب" : "Astonishing"} onClick={() => react("wtf")}>
            <span className={`text-base leading-none ${userReaction === "wtf" ? "opacity-100" : "opacity-60"}`}>😱</span>
          </RBtn>
          <BookmarkButton size={32} descriptor={{
            item_type: "quote", item_id: String(currentQuote.id),
            title_en: currentQuote.text_en || currentQuote.text || currentQuote.text_enar || "",
            title_ar: currentQuote.text_ar || "",
            subtitle: currentQuote.category || "", path: linkTo || "/quotes",
          }} />
          <RBtn active={userReaction === "castaway"} activeColor="text-amber-600" title={isAr ? "إبعاد" : "Cast away"} onClick={() => react("castaway")}>
            <EraserIcon className="w-4 h-4" strokeWidth={2} />
          </RBtn>
        </div>
      </div>
    </div>
  );
}
