import { useState, useMemo, useEffect, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Search, X, Droplets, Building2, User, Sparkles, BookOpen, GraduationCap, Quote as QuoteIcon } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * GlobalSearch — one search box on the Home page that searches across the
 * whole app: perfumes, brands, perfumers, notes, stories, glossary terms and
 * quotes. Results are grouped by type and navigate to the right page.
 *
 * Bilingual: every entity is matched on its English AND Arabic fields.
 */
const STALE = 1000 * 60 * 5;

export default function GlobalSearch() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const boxRef = useRef(null);

  // كل البيانات تُجلب مرة وتُفلتر محلياً (أوفلاين) — لكن فقط عند الكتابة في
  // البحث، حتى لا تُحمَّل الـ130 ألف عند مجرّد فتح الصفحة الرئيسية.
  const wantData = !!q.trim();
  const { data: perfumes = [] } = useQuery({ queryKey: ["perfumes"], queryFn: () => apphost.entities.Perfume.list("-created_date"), staleTime: STALE, enabled: wantData });
  const { data: brands = [] } = useQuery({ queryKey: ["brands"], queryFn: () => apphost.entities.PerfumeBrand.list("name"), staleTime: STALE, enabled: wantData });
  const { data: perfumers = [] } = useQuery({ queryKey: ["perfumers-all"], queryFn: () => apphost.entities.Perfumer.list("name"), staleTime: STALE, enabled: wantData });
  const { data: notes = [] } = useQuery({ queryKey: ["notes-all-for-tagsearch"], queryFn: () => apphost.entities.PerfumeNote.list("name"), staleTime: STALE, enabled: wantData });
  const { data: glossary = [] } = useQuery({ queryKey: ["glossary-all"], queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"), staleTime: STALE, enabled: wantData });
  const { data: quotes = [] } = useQuery({ queryKey: ["quotes"], queryFn: () => apphost.entities.Quote.list("-created_date"), staleTime: STALE, enabled: wantData });

  // إغلاق القائمة عند النقر خارجها
  useEffect(() => {
    const onClick = (e) => { if (boxRef.current && !boxRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  const results = useMemo(() => {
    const s = q.trim();
    if (!s) return [];
    const ql = s.toLowerCase();
    const hit = (...vals) => vals.some((v) => v && (String(v).toLowerCase().includes(ql) || String(v).includes(s)));
    const out = [];

    perfumes.filter((p) => hit(p.name, p.name_en, p.name_ar, p.brand_name, p.brand_name_ar)).slice(0, 6)
      .forEach((p) => out.push({ type: "perfume", id: p.id, title: p.name_en || p.name || p.name_ar, sub: p.brand_name || "", path: `/perfume?id=${p.id}` }));

    brands.filter((b) => hit(b.name, b.name_en, b.name_ar, b.country)).slice(0, 5)
      .forEach((b) => out.push({ type: "brand", id: b.id, title: b.name || b.name_ar, sub: b.country || "", path: `/brand?id=${b.id}` }));

    perfumers.filter((p) => hit(p.name, p.name_ar, p.nationality)).slice(0, 5)
      .forEach((p) => out.push({ type: "perfumer", id: p.id, title: p.name || p.name_ar, sub: p.nationality || "", path: `/perfumer?id=${p.id}` }));

    notes.filter((n) => hit(n.name, n.name_ar, n.category)).slice(0, 5)
      .forEach((n) => out.push({ type: "note", id: n.id, title: n.name || n.name_ar, sub: n.category || "", path: `/note?id=${n.id}` }));

    glossary.filter((t) => hit(t.term_en, t.term_ar, t.meaning, t.meaning_ar, t.tags)).slice(0, 5)
      .forEach((t) => out.push({ type: t.entry_type === "story" ? "story" : "term", id: t.id, title: isAr ? (t.term_ar || t.term_en) : t.term_en, sub: t.entry_type === "story" ? (isAr ? "قصة" : "Story") : (isAr ? "مصطلح" : "Term"), path: `/glossary-term?id=${t.id}` }));

    quotes.filter((qt) => !qt.hidden && hit(qt.text_en, qt.text_ar, qt.text_enar, qt.quoteauthor, qt.author)).slice(0, 5)
      .forEach((qt) => out.push({ type: "quote", id: qt.id, title: (qt.text_en || qt.text_ar || qt.text_enar || "").slice(0, 50), sub: qt.quoteauthor || qt.author || "", path: `/quotes` }));

    return out;
  }, [q, perfumes, brands, perfumers, notes, glossary, quotes, isAr]);

  const ICONS = {
    perfume: <Droplets className="w-4 h-4 text-cyan-500" />,
    brand: <Building2 className="w-4 h-4 text-amber-600" />,
    perfumer: <User className="w-4 h-4 text-violet-500" />,
    note: <Sparkles className="w-4 h-4 text-emerald-500" />,
    story: <BookOpen className="w-4 h-4 text-orange-500" />,
    term: <GraduationCap className="w-4 h-4 text-teal-600" />,
    quote: <QuoteIcon className="w-4 h-4 text-sky-500" />,
  };

  const go = (path) => { setOpen(false); setQ(""); navigate(path); };

  return (
    <div ref={boxRef} className="relative">
      <div className="flex items-center gap-2 px-3 h-11 bg-white border border-transparent" style={{ borderRadius: 0 }}>
        <Search className="w-4 h-4 text-muted-foreground flex-shrink-0" />
        <input
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => q.trim() && setOpen(true)}
          placeholder={isAr ? "ابحث" : "Search"}
          dir={isAr ? "rtl" : "ltr"}
          className="flex-1 bg-transparent outline-none text-sm font-body placeholder:text-muted-foreground"
        />
        {q && (
          <button onClick={() => { setQ(""); setOpen(false); }} className="text-muted-foreground hover:text-foreground">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {open && q.trim() && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-none shadow-xl z-40 max-h-[60vh] overflow-y-auto">
          {results.length === 0 ? (
            <p className="text-center text-xs text-muted-foreground font-body py-6">{isAr ? "لا نتائج" : "No results"}</p>
          ) : (
            results.map((r) => (
              <button
                key={`${r.type}-${r.id}`}
                onClick={() => go(r.path)}
                className="w-full flex items-center gap-3 px-3 py-2.5 hover:bg-secondary text-left border-b border-border/30 last:border-b-0 transition-colors"
              >
                <span className="flex-shrink-0">{ICONS[r.type]}</span>
                <span className="flex-1 min-w-0">
                  <span className="block text-sm font-body font-medium truncate">{r.title}</span>
                  {r.sub && <span className="block text-[11px] text-muted-foreground truncate">{r.sub}</span>}
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
