import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Trash2, Edit2 } from "lucide-react";
import { toast } from "sonner";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function BrandServiceManager() {
  const [open, setOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [formData, setFormData] = useState({ name: "", category: "brand", notes: "" });
  const qc = useQueryClient();

  // Create a custom entity for storing brands and services
  // We'll use a flexible approach with a custom entity
  const { data: items = [] } = useQuery({
    queryKey: ["brands-services"],
    queryFn: async () => {
      try {
        // Try to fetch from a custom entity if it exists
        return await apphost.entities.BrandService?.list() || [];
      } catch {
        return [];
      }
    },
  });

  const createMutation = useMutation({
    mutationFn: (data) => {
      return apphost.entities.BrandService?.create(data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["brands-services"] });
      setFormData({ name: "", category: "brand", notes: "" });
      setOpen(false);
      toast.success("أُضيف العنصر");
    },
    onError: () => {
      toast.error("تعذّرت إضافة العنصر");
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => {
      return apphost.entities.BrandService?.update(editingId, data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["brands-services"] });
      setFormData({ name: "", category: "brand", notes: "" });
      setEditingId(null);
      setOpen(false);
      toast.success("حُدّث العنصر");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.BrandService?.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["brands-services"] });
      toast.success("حُذف العنصر");
    },
  });

  const handleSave = () => {
    if (!formData.name.trim()) {
      toast.error("الاسم مطلوب");
      return;
    }
    if (editingId) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const handleEdit = (item) => {
    setFormData({ name: item.name, category: item.category, notes: item.notes || "" });
    setEditingId(item.id);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingId(null);
    setFormData({ name: "", category: "brand", notes: "" });
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-heading font-semibold">🏷️ Items & Services</h2>
        <Button
          size="sm"
          variant="outline"
          className="h-8 rounded-none gap-1 text-xs"
          onClick={() => {
            setEditingId(null);
            setFormData({ name: "", category: "brand", notes: "" });
            setOpen(true);
          }}
        >
          Add Item
        </Button>
      </div>

      {items.length === 0 ? (
        <p className="text-xs text-muted-foreground font-body py-4">لا عناصر بعد No items yet.</p>
      ) : (
        <div className="space-y-2">
          {items.map((item) => (
            <div key={item.id} className="flex items-center justify-between bg-secondary/40 rounded-none p-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-body font-bold rounded-none text-primary">
                    {item.category === "brand" ? "Brand" : "Service"}
                  </span>
                  <p className="text-xs font-body font-medium">{item.name}</p>
                </div>
                {item.notes && <p className="text-[10px] text-muted-foreground mt-1">{item.notes}</p>}
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <button
                  onClick={() => handleEdit(item)}
                  className="p-1 rounded hover:bg-accent transition-colors text-muted-foreground hover:text-foreground"
                >
                  <Edit2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => {
                    if (confirm("Delete this item")) {
                      deleteMutation.mutate(item.id);
                    }
                  }}
                  className="p-1 rounded hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading">{editingId ? "Edit" : "Add"} Item</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">النوع Type</label>
              <Select value={formData.category} onValueChange={(v) => setFormData({ ...formData, category: v })}>
                <SelectTrigger className="rounded-none h-10 mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="brand">البراند Brand</SelectItem>
                  <SelectItem value="service">الخدمة Service</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Input
              placeholder="الاسم Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="rounded-none h-10"
            />
            <Input
              placeholder="ملاحظات اختياري Notes (optional)"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="rounded-none h-10"
            />
            <Button className="w-full rounded-none h-10" onClick={handleSave} disabled={createMutation.isPending || updateMutation.isPending}>
              {editingId ? "Update" : "Add"} Item
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}