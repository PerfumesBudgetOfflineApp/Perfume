import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Download } from "lucide-react";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";

const TRANSLATIONS = {
  en: {
    title: "📊 Advanced Report Export",
    selectOptions: "Select Report Options",
    includeIncome: "Include Income",
    includeExpenses: "Include Expenses",
    includePurchases: "Include Perfume Purchases",
    includeObligations: "Include Obligations",
    includeRecurring: "Include Recurring Expenses",
    includeAssets: "Include Assets",
    includeSummary: "Include Summary",
    format: "Export Format",
    csv: "CSV - Spreadsheet",
    json: "JSON - Data",
    pdf: "PDF - Report",
    excel: "Excel - Formatted",
    png: "PNG - Image",
    export: "Export",
    exporting: "Exporting...",
    selectAtLeast: "Select at least one option",
  },
  ar: {
    title: "📊 تصدير التقرير المتقدم",
    selectOptions: "اختر خيارات التقرير",
    includeIncome: "تضمين الدخل",
    includeExpenses: "تضمين المصاريف",
    includePurchases: "تضمين مشتريات العطور",
    includeObligations: "تضمين الالتزامات",
    includeRecurring: "تضمين المصاريف الدورية",
    includeAssets: "تضمين الأصول",
    includeSummary: "تضمين الملخص",
    format: "صيغة التصدير",
    csv: "CSV جدول",
    json: "JSON بيانات",
    pdf: "PDF تقرير",
    excel: "Excel منسق",
    png: "PNG صورة",
    export: "تصدير",
    exporting: "جارٍ التصدير...",
    selectAtLeast: "اختر خيار واحد على الأقل",
  }
};

export default function AdvancedBudgetExport({
  open,
  onOpenChange,
  data,
  isAr,
  currency,
  names,
  selectedPerson,
  selectedMonth,
}) {
  const t = TRANSLATIONS[isAr ? "ar" : "en"];
  const [exporting, setExporting] = useState(false);
  const [format, setFormat] = useState("pdf");
  const [options, setOptions] = useState({
    income: true,
    expenses: true,
    purchases: true,
    obligations: true,
    recurring: true,
    assets: false,
    summary: true,
  });

  const personLabel =
    selectedPerson === "person1"
      ? names.person1 || "A"
      : selectedPerson === "person2"
      ? names.person2 || "B"
      : selectedPerson === "together"
      ? (isAr ? "الكل معاً" : "All Together")
      : (isAr ? "عائلة" : "Family");

  const toggleOption = (key) => {
    setOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const hasSelectedOptions = Object.values(options).some(v => v);

  const exportToJSON = async () => {
    if (!hasSelectedOptions) return;
    setExporting(true);
    try {
      const reportData = {
        metadata: {
          generated: new Date().toISOString(),
          person: personLabel,
          month: selectedMonth,
          currency,
        },
        ...(options.income && { incomes: data.incomes || [] }),
        ...(options.expenses && { expenses: data.expenses || [] }),
        ...(options.purchases && { purchases: data.purchases || [] }),
        ...(options.obligations && { obligations: data.obligations || [] }),
        ...(options.recurring && { recurring: data.recurring || [] }),
        ...(options.assets && { assets: data.assets || [] }),
        ...(options.summary && {
          summary: {
            totalIncome: data.totalIncome,
            totalExpenses: data.totalExpense,
            totalPurchases: data.totalPurchases,
            totalObligations: data.totalObligations,
            totalRecurring: data.totalRecurring,
            balance: data.balance,
          }
        }),
      };

      const jsonString = JSON.stringify(reportData, null, 2);
      const blob = new Blob([jsonString], { type: "application/json;charset=utf-8;" });
      await downloadBlob(blob, `budget_${personLabel}_${selectedMonth}.json`);
      setExporting(false);
    } catch (error) {
      console.error("JSON export failed:", error);
      setExporting(false);
    }
  };

  const exportToCSV = async () => {
    if (!hasSelectedOptions) return;
    setExporting(true);
    try {
      const rows = [];
      rows.push([(isAr ? "التقرير المالي" : "Financial Report"), selectedMonth]);
      rows.push([(isAr ? "الشخص" : "Person"), personLabel]);
      rows.push([(isAr ? "العملة" : "Currency"), currency]);
      rows.push([]);

      if (options.income && data.incomes?.length > 0) {
        rows.push([(isAr ? "الدخل" : "INCOME")]);
        rows.push([(isAr ? "البيان" : "Description"), (isAr ? "النوع" : "Type"), (isAr ? "التاريخ" : "Date"), (isAr ? "المبلغ" : "Amount")]);
        data.incomes.forEach(inc => {
          rows.push([inc.description || inc.type, inc.type, inc.date, inc.amount]);
        });
        rows.push([(isAr ? "إجمالي الدخل" : "Total Income"), "", "", data.totalIncome]);
        rows.push([]);
      }

      if (options.expenses && data.expenses?.length > 0) {
        rows.push([(isAr ? "المصاريف" : "EXPENSES")]);
        rows.push([(isAr ? "البيان" : "Description"), (isAr ? "الفئة" : "Category"), (isAr ? "التاريخ" : "Date"), (isAr ? "المبلغ" : "Amount")]);
        data.expenses.forEach(exp => {
          rows.push([exp.description || exp.category, exp.category, exp.date, exp.amount]);
        });
        rows.push([(isAr ? "إجمالي المصاريف" : "Total Expenses"), "", "", data.totalExpense]);
        rows.push([]);
      }

      if (options.purchases && data.purchases?.length > 0) {
        rows.push([(isAr ? "مشتريات العطور" : "PERFUME PURCHASES")]);
        rows.push([(isAr ? "الاسم" : "Name"), (isAr ? "البراند" : "Brand"), (isAr ? "التاريخ" : "Date"), (isAr ? "التكلفة" : "Cost")]);
        data.purchases.forEach(p => {
          rows.push([p.perfume_name, p.brand_name, p.purchase_date, p.cost]);
        });
        rows.push([(isAr ? "إجمالي المشتريات" : "Total Purchases"), "", "", data.totalPurchases]);
        rows.push([]);
      }

      if (options.obligations && data.obligations?.length > 0) {
        rows.push([(isAr ? "الالتزامات" : "OBLIGATIONS")]);
        rows.push([(isAr ? "العنوان" : "Title"), (isAr ? "القسط" : "Payment"), (isAr ? "المتبقي" : "Remaining"), (isAr ? "حتى" : "Until")]);
        data.obligations.forEach(obl => {
          const remaining = obl.total_amount - obl.paid_amount;
          rows.push([obl.title, obl.monthly_payment, remaining, obl.end_date]);
        });
        rows.push([(isAr ? "إجمالي الالتزامات" : "Total Obligations"), "", "", data.totalObligations]);
        rows.push([]);
      }

      if (options.summary) {
        rows.push([(isAr ? "الملخص" : "SUMMARY")]);
        rows.push([(isAr ? "الدخل الإجمالي" : "Total Income"), data.totalIncome]);
        rows.push([(isAr ? "إجمالي المصاريف" : "Total Expenses"), data.totalExpense + data.totalPurchases]);
        rows.push([(isAr ? "الالتزامات الشهرية" : "Monthly Obligations"), data.totalObligations]);
        rows.push([(isAr ? "المصاريف الدورية" : "Recurring Expenses"), data.totalRecurring]);
        rows.push([(isAr ? "الرصيد" : "Balance"), data.balance]);
      }

      const csv = rows.map(row => row.map(cell => `"${cell}"`).join(",")).join("\n");
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      await downloadBlob(blob, `budget_${personLabel}_${selectedMonth}.csv`);
      setExporting(false);
    } catch (error) {
      console.error("CSV export failed:", error);
      setExporting(false);
    }
  };

  const exportToPDF = async () => {
    if (!hasSelectedOptions) return;
    setExporting(true);
    try {
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      pdf.setFont("helvetica");
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      let yPos = 15;

      // Title
      pdf.setFontSize(18);
      pdf.text(isAr ? "تقرير الميزانية المالي" : "Financial Budget Report", pageWidth / 2, yPos, { align: "center" });
      yPos += 10;

      // Metadata
      pdf.setFontSize(9);
      pdf.setTextColor(100);
      pdf.text(
        `${isAr ? "الشخص: " : "Person: "}${personLabel} | ${isAr ? "الشهر: " : "Month: "}${selectedMonth}`,
        pageWidth / 2,
        yPos,
        { align: "center" }
      );
      yPos += 8;
      pdf.setTextColor(0);

      if (options.income && data.incomes?.length > 0) {
        pdf.setFontSize(12);
        pdf.text(isAr ? "💵 الدخل" : "💵 INCOME", 15, yPos);
        yPos += 6;
        pdf.setFontSize(9);
        data.incomes.forEach(inc => {
          pdf.text(`${inc.description || inc.type}: ${inc.amount.toFixed(0)} ${currency}`, 20, yPos);
          yPos += 5;
          if (yPos > pageHeight - 20) { pdf.addPage(); yPos = 15; }
        });
        yPos += 3;
      }

      if (options.expenses && data.expenses?.length > 0) {
        pdf.setFontSize(12);
        pdf.text(isAr ? "💸 المصاريف" : "💸 EXPENSES", 15, yPos);
        yPos += 6;
        pdf.setFontSize(9);
        data.expenses.forEach(exp => {
          pdf.text(`${exp.description || exp.category}: ${exp.amount.toFixed(0)} ${currency}`, 20, yPos);
          yPos += 5;
          if (yPos > pageHeight - 20) { pdf.addPage(); yPos = 15; }
        });
        yPos += 3;
      }

      if (options.summary) {
        if (yPos > pageHeight - 40) { pdf.addPage(); yPos = 15; }
        pdf.setFontSize(12);
        pdf.text(isAr ? "📊 الملخص" : "📊 SUMMARY", 15, yPos);
        yPos += 8;
        pdf.setFontSize(10);
        const summaryLines = [
          [isAr ? "الدخل الإجمالي" : "Total Income", `${data.totalIncome.toFixed(0)} ${currency}`],
          [isAr ? "إجمالي المصاريف" : "Total Expenses", `${(data.totalExpense + data.totalPurchases).toFixed(0)} ${currency}`],
          [isAr ? "الالتزامات" : "Obligations", `${data.totalObligations.toFixed(0)} ${currency}`],
          [isAr ? "الرصيد" : "Balance", `${data.balance.toFixed(0)} ${currency}`],
        ];
        summaryLines.forEach(([label, value]) => {
          pdf.text(label, 20, yPos);
          pdf.text(value, pageWidth - 30, yPos, { align: "right" });
          yPos += 6;
        });
      }

      pdf.setFontSize(8);
      pdf.setTextColor(150);
      pdf.text(
        isAr ? `تم الإنشاء: ${new Date().toLocaleDateString("ar-SA")}` : `Generated: ${new Date().toLocaleDateString()}`,
        pageWidth / 2,
        pageHeight - 8,
        { align: "center" }
      );

      const pdfBlob = pdf.output('blob');
      await downloadBlob(pdfBlob, `budget_${personLabel}_${selectedMonth}.pdf`);
      setExporting(false);
    } catch (error) {
      console.error("PDF export failed:", error);
      setExporting(false);
    }
  };

  const exportToPNG = async () => {
    if (!hasSelectedOptions) return;
    setExporting(true);
    try {
      const container = document.createElement("div");
      container.style.position = "fixed";
      container.style.left = "0";
      container.style.top = "0";
      container.style.zIndex = "-1";
      container.style.opacity = "1";
      container.style.pointerEvents = "none";
      container.style.width = "1000px";
      container.style.padding = "30px";
      container.style.backgroundColor = "white";
      container.style.direction = isAr ? "rtl" : "ltr";
      container.style.fontFamily = "'Arial', sans-serif";

      let html = `<h2 style="text-align: center; color: #1f2937; margin-bottom: 20px;">
        ${isAr ? "تقرير الميزانية" : "Budget Report"}</h2>
        <p style="text-align: center; color: #6b7280; margin-bottom: 30px;">
        ${isAr ? "الشخص" : "Person"}: ${personLabel} | ${isAr ? "الشهر" : "Month"}: ${selectedMonth}</p>`;

      if (options.summary) {
        html += `<div style="background: #f0f0f0; padding: 15px; margin-bottom: 20px; border-radius: 8px;">
          <h3 style="margin-top: 0; color: #1f2937;">${isAr ? "الملخص" : "Summary"}</h3>
          <p>${isAr ? "الدخل" : "Income"}: <strong>${data.totalIncome.toFixed(0)}</strong></p>
          <p>${isAr ? "المصاريف" : "Expenses"}: <strong>${data.totalExpense.toFixed(0)}</strong></p>
          <p>${isAr ? "الالتزامات" : "Obligations"}: <strong>${data.totalObligations.toFixed(0)}</strong></p>
          <p>${isAr ? "الرصيد" : "Balance"}: <strong>${data.balance.toFixed(0)}</strong></p>
        </div>`;
      }

      container.innerHTML = html;
      document.body.appendChild(container);

      const canvas = await captureElement(container, {
        scale: 2,
        backgroundColor: "#ffffff",
      });

      document.body.removeChild(container);

      await saveCanvasAsImage(canvas, `budget_${personLabel}_${selectedMonth}.png`);

      setExporting(false);
    } catch (error) {
      console.error("PNG export failed:", error);
      setExporting(false);
    }
  };

  const handleExport = () => {
    if (format === "csv") exportToCSV();
    else if (format === "json") exportToJSON();
    else if (format === "pdf") exportToPDF();
    else if (format === "png") exportToPNG();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`max-w-md rounded-none max-h-[90vh] overflow-y-auto ${isAr ? "rtl" : ""}`}>
        <DialogHeader>
          <DialogTitle className="font-heading">{t.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Options */}
          <div className="space-y-2 bg-secondary/30 rounded-none p-3">
            <p className="text-xs font-semibold uppercase">{t.selectOptions}</p>
            {[
              { key: "income", label: t.includeIncome },
              { key: "expenses", label: t.includeExpenses },
              { key: "purchases", label: t.includePurchases },
              { key: "obligations", label: t.includeObligations },
              { key: "recurring", label: t.includeRecurring },
              { key: "summary", label: t.includeSummary },
            ].map(({ key, label }) => (
              <label key={key} className="flex items-center gap-2 cursor-pointer text-sm font-body">
                <Checkbox
                  checked={options[key]}
                  onCheckedChange={() => toggleOption(key)}
                />
                {label}
              </label>
            ))}
          </div>

          {/* Format Selection */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase">{t.format}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { val: "csv", label: t.csv, icon: "📊" },
                { val: "json", label: t.json, icon: "📝" },
                { val: "pdf", label: t.pdf, icon: "📄" },
                { val: "png", label: t.png, icon: "🖼️" },
              ].map(({ val, label, icon }) => (
                <button
                  key={val}
                  onClick={() => setFormat(val)}
                  className={` rounded-none text-xs font-body text-center transition-all ${
 format === val
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
                >
                  {icon} {label}
                </button>
              ))}
            </div>
          </div>

          {/* Export Button */}
          <Button
            className="w-full h-10 rounded-none font-body text-sm"
            onClick={handleExport}
            disabled={exporting || !hasSelectedOptions}
          >
            <Download className="w-4 h-4 mr-2" />
            {exporting ? t.exporting : t.export}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
