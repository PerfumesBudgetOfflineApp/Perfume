import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download, FileText, Image as ImageIcon } from "lucide-react";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";

export default function BudgetExportDialog({
  open,
  onOpenChange,
  data,
  isAr,
  currency,
  names,
  selectedPerson,
  selectedMonth,
}) {
  const [exporting, setExporting] = useState(false);
  const [reportType, setReportType] = useState("current");

  const personLabel =
    selectedPerson === "person1"
      ? names.person1 || "A"
      : selectedPerson === "person2"
      ? names.person2 || "B"
      : selectedPerson === "together"
      ? "All Together"
      : "Family";

  const exportToCSV = async () => {
    setExporting(true);
    try {
      const rows = [];
      const headers = isAr
        ? [
            "البيان",
            "الفئة",
            "التاريخ",
            "المبلغ",
            "النوع",
            "الملاحظات",
          ]
        : ["Description", "Category", "Date", "Amount", "Type", "Notes"];

      rows.push(headers);

      // Add Income
      if (data.incomes && data.incomes.length > 0) {
        rows.push([
          isAr ? "=== الدخل ===" : "=== INCOME ===",
          "",
          "",
          "",
          "",
          "",
        ]);
        data.incomes.forEach((inc) => {
          rows.push([
            inc.description || inc.type,
            inc.type,
            inc.date,
            inc.amount,
            "Income",
            "",
          ]);
        });
      }

      // Add Expenses
      if (data.expenses && data.expenses.length > 0) {
        rows.push([
          isAr ? "=== المصاريف ===" : "=== EXPENSES ===",
          "",
          "",
          "",
          "",
          "",
        ]);
        data.expenses.forEach((exp) => {
          rows.push([
            exp.description || exp.category,
            exp.category,
            exp.date,
            exp.amount,
            "Expense",
            "",
          ]);
        });
      }

      // Add Summary
      rows.push(["", "", "", "", "", ""]);
      rows.push([
        isAr ? "الملخص" : "SUMMARY",
        "",
        "",
        "",
        "",
        "",
      ]);
      rows.push([
        isAr ? "إجمالي الدخل" : "Total Income",
        "",
        "",
        data.totalIncome,
        currency,
        "",
      ]);
      rows.push([
        isAr ? "إجمالي المصاريف" : "Total Expenses",
        "",
        "",
        data.totalExpense,
        currency,
        "",
      ]);
      rows.push([
        isAr ? "الالتزامات الشهرية" : "Monthly Obligations",
        "",
        "",
        data.totalObligations,
        currency,
        "",
      ]);
      rows.push([
        isAr ? "المصاريف الدورية" : "Recurring Expenses",
        "",
        "",
        data.totalRecurring,
        currency,
        "",
      ]);
      rows.push([
        isAr ? "الرصيد" : "Balance",
        "",
        "",
        data.balance,
        currency,
        "",
      ]);

      const csv = rows.map((row) => row.map((cell) => `"${cell}"`).join(",")).join("\n");
      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      await downloadBlob(blob, `budget_${personLabel}_${selectedMonth}.csv`);
      setExporting(false);
    } catch (error) {
      console.error("CSV export failed:", error);
      setExporting(false);
    }
  };

  const exportToPDF = async () => {
    setExporting(true);
    try {
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({
        orientation: "portrait",
        unit: "mm",
        format: "a4",
      });

      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      let yPos = 15;

      // Add Arabic support
      pdf.setFont("helvetica");

      // Title
      pdf.setFontSize(20);
      pdf.text(isAr ? "تقرير الميزانية الشهري" : "Monthly Budget Report", pageWidth / 2, yPos, {
        align: "center",
      });

      yPos += 12;
      pdf.setFontSize(10);
      pdf.setTextColor(100);
      pdf.text(
        isAr
          ? `الشخص: ${personLabel} | الشهر: ${selectedMonth}`
          : `Person: ${personLabel} | Month: ${selectedMonth}`,
        pageWidth / 2,
        yPos,
        { align: "center" }
      );

      yPos += 12;

      // Summary Section
      pdf.setFontSize(12);
      pdf.setTextColor(0);
      pdf.text(isAr ? "📊 الملخص" : "📊 SUMMARY", 15, yPos);

      yPos += 8;
      pdf.setFontSize(10);
      const summaryData = [
        [
          isAr ? "الدخل الإجمالي" : "Total Income",
          `${data.totalIncome.toFixed(0)} ${currency}`,
          "#10b981",
        ],
        [
          isAr ? "إجمالي المصاريف" : "Total Expenses",
          `${data.totalExpense.toFixed(0)} ${currency}`,
          "#ef4444",
        ],
        [
          isAr ? "الالتزامات الشهرية" : "Monthly Obligations",
          `${data.totalObligations.toFixed(0)} ${currency}`,
          "#f59e0b",
        ],
        [
          isAr ? "الرصيد" : "Balance",
          `${data.balance.toFixed(0)} ${currency}`,
          data.balance >= 0 ? "#3b82f6" : "#dc2626",
        ],
      ];

      summaryData.forEach((item) => {
        pdf.setTextColor(0);
        pdf.text(item[0], 20, yPos);
        pdf.setTextColor(0);
        pdf.text(item[1], pageWidth - 30, yPos, { align: "right" });
        yPos += 7;
      });

      yPos += 5;

      // Income Details
      if (data.incomes && data.incomes.length > 0) {
        pdf.setFontSize(11);
        pdf.text(isAr ? "💵 الدخل" : "💵 INCOME", 15, yPos);
        yPos += 7;

        pdf.setFontSize(9);
        data.incomes.forEach((inc) => {
          pdf.text(
            `${inc.description || inc.type}: ${inc.amount.toFixed(0)} ${currency}`,
            20,
            yPos
          );
          yPos += 5;
          if (yPos > pageHeight - 20) {
            pdf.addPage();
            yPos = 15;
          }
        });

        yPos += 3;
      }

      // Expenses Details
      if (data.expenses && data.expenses.length > 0) {
        pdf.setFontSize(11);
        pdf.text(isAr ? "💸 المصاريف" : "💸 EXPENSES", 15, yPos);
        yPos += 7;

        pdf.setFontSize(9);
        data.expenses.forEach((exp) => {
          pdf.text(
            `${exp.description || exp.category}: ${exp.amount.toFixed(0)} ${currency}`,
            20,
            yPos
          );
          yPos += 5;
          if (yPos > pageHeight - 20) {
            pdf.addPage();
            yPos = 15;
          }
        });

        yPos += 3;
      }

      // Obligations
      if (data.obligations && data.obligations.length > 0) {
        pdf.setFontSize(11);
        pdf.text(isAr ? "📋 الالتزامات" : "📋 OBLIGATIONS", 15, yPos);
        yPos += 7;

        pdf.setFontSize(9);
        data.obligations.forEach((obl) => {
          const remaining = obl.total_amount - obl.paid_amount;
          pdf.text(`${obl.title}`, 20, yPos);
          pdf.setTextColor(100);
          pdf.text(
            `${isAr ? "القسط الشهري:" : "Payment:"} ${obl.monthly_payment.toFixed(0)} | ${isAr ? "المتبقي:" : "Remaining:"} ${remaining.toFixed(0)} ${currency}`,
            20,
            yPos + 5
          );
          pdf.setTextColor(0);
          yPos += 10;
          if (yPos > pageHeight - 20) {
            pdf.addPage();
            yPos = 15;
          }
        });
      }

      // Add footer
      pdf.setFontSize(8);
      pdf.setTextColor(150);
      pdf.text(
        isAr ? `تم إنشاء التقرير: ${new Date().toLocaleDateString("ar-SA")}` : `Generated: ${new Date().toLocaleDateString()}`,
        pageWidth / 2,
        pageHeight - 10,
        { align: "center" }
      );

      const pdfBlob = pdf.output('blob');
      await downloadBlob(pdfBlob, `budget_${personLabel}_${selectedMonth}.pdf`);
      setExporting(false);
    } catch (error) {
      console.error("PDF export failed:", error);
      setExporting(false);
    }
  };

  const exportToImage = async () => {
    setExporting(true);
    try {
      // Create a temporary container with the report content
      const container = document.createElement("div");
      container.style.position = "fixed";
      container.style.left = "0";
      container.style.top = "0";
      container.style.zIndex = "-1";
      container.style.opacity = "1";
      container.style.pointerEvents = "none";
      container.style.width = "1200px";
      container.style.backgroundColor = "white";
      container.style.padding = "40px";
      container.style.fontFamily = "Arial, sans-serif";
      container.style.direction = isAr ? "rtl" : "ltr";

      const reportHTML = `
        <div style="text-align: center; margin-bottom: 30px;">
          <h1 style="margin: 0; color: #1f2937; font-size: 32px;">
            ${isAr ? "تقرير الميزانية الشهري" : "Monthly Budget Report"}
          </h1>
          <p style="color: #6b7280; margin: 10px 0;">
            ${isAr ? "الشخص:" : "Person:"} ${personLabel} | ${isAr ? "الشهر:" : "Month:"} ${selectedMonth}
          </p>
        </div>

        <div style="background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div>
              <p style="margin: 0; opacity: 0.9; font-size: 14px;">${isAr ? "الدخل الإجمالي" : "Total Income"}</p>
              <p style="margin: 10px 0 0 0; font-size: 28px; font-weight: bold;">${data.totalIncome.toFixed(0)} ${currency}</p>
            </div>
            <div>
              <p style="margin: 0; opacity: 0.9; font-size: 14px;">${isAr ? "إجمالي المصاريف" : "Total Expenses"}</p>
              <p style="margin: 10px 0 0 0; font-size: 28px; font-weight: bold;">${(data.totalExpense + data.totalObligations + data.totalRecurring).toFixed(0)} ${currency}</p>
            </div>
          </div>
        </div>

        ${
          data.incomes && data.incomes.length > 0
            ? `
          <div style="margin-bottom: 25px;">
            <h2 style="color: #1f2937; margin: 0 0 15px 0; border-bottom: 2px solid #10b981; padding-bottom: 10px;">
              💵 ${isAr ? "الدخل" : "INCOME"}
            </h2>
            ${data.incomes
              .map(
                (inc) => `
              <div style="padding: 10px; background: #f0fdf4; margin-bottom: 8px; border-radius: 6px; border-left: 4px solid #10b981;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <span style="color: #1f2937; font-weight: 500;">${inc.description || inc.type}</span>
                  <span style="color: #10b981; font-weight: bold; font-size: 16px;">${inc.amount.toFixed(0)} ${currency}</span>
                </div>
                <p style="margin: 5px 0 0 0; color: #6b7280; font-size: 12px;">${inc.date}</p>
              </div>
            `
              )
              .join("")}
          </div>
        `
            : ""
        }

        ${
          data.expenses && data.expenses.length > 0
            ? `
          <div style="margin-bottom: 25px;">
            <h2 style="color: #1f2937; margin: 0 0 15px 0; border-bottom: 2px solid #ef4444; padding-bottom: 10px;">
              💸 ${isAr ? "المصاريف" : "EXPENSES"}
            </h2>
            ${data.expenses
              .map(
                (exp) => `
              <div style="padding: 10px; background: #fef2f2; margin-bottom: 8px; border-radius: 6px; border-left: 4px solid #ef4444;">
                <div style="display: flex; justify-content: space-between; align-items: center;">
                  <span style="color: #1f2937; font-weight: 500;">${exp.description || exp.category}</span>
                  <span style="color: #ef4444; font-weight: bold; font-size: 16px;">${exp.amount.toFixed(0)} ${currency}</span>
                </div>
                <p style="margin: 5px 0 0 0; color: #6b7280; font-size: 12px;">${exp.date}</p>
              </div>
            `
              )
              .join("")}
          </div>
        `
            : ""
        }

        ${
          data.obligations && data.obligations.length > 0
            ? `
          <div style="margin-bottom: 25px;">
            <h2 style="color: #1f2937; margin: 0 0 15px 0; border-bottom: 2px solid #f59e0b; padding-bottom: 10px;">
              📋 ${isAr ? "الالتزامات" : "OBLIGATIONS"}
            </h2>
            ${data.obligations
              .map((obl) => {
                const remaining = obl.total_amount - obl.paid_amount;
                const progress = (obl.paid_amount / obl.total_amount) * 100;
                return `
              <div style="padding: 12px; background: #fffbeb; margin-bottom: 10px; border-radius: 6px; border-left: 4px solid #f59e0b;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                  <span style="color: #1f2937; font-weight: 500;">${obl.title}</span>
                  <span style="color: #f59e0b; font-weight: bold;">${progress.toFixed(0)}%</span>
                </div>
                <div style="width: 100%; height: 6px; background: #fcd34d; border-radius: 3px; overflow: hidden; margin-bottom: 8px;">
                  <div style="width: ${progress}%; height: 100%; background: linear-gradient(90deg, #f59e0b, #dc2626);"></div>
                </div>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 12px;">
                  <div style="color: #6b7280;">${isAr ? "القسط الشهري:" : "Payment:"} <strong style="color: #1f2937;">${obl.monthly_payment.toFixed(0)} ${currency}</strong></div>
                  <div style="color: #6b7280;">${isAr ? "المتبقي:" : "Remaining:"} <strong style="color: #ef4444;">${remaining.toFixed(0)} ${currency}</strong></div>
                </div>
              </div>
            `;
              })
              .join("")}
          </div>
        `
            : ""
        }

        <div style="background: #f3f4f6; padding: 20px; border-radius: 8px; margin-top: 30px; text-align: center;">
          <p style="margin: 0; color: #6b7280; font-size: 12px;">
            ${isAr ? "تم إنشاء التقرير:" : "Generated:"} ${new Date().toLocaleDateString(isAr ? "ar-SA" : "en-US")} | ${isAr ? "الوقت:" : "Time:"} ${new Date().toLocaleTimeString()}
          </p>
        </div>
      `;

      container.innerHTML = reportHTML;
      document.body.appendChild(container);

      const canvas = await captureElement(container, {
        scale: 2,
        logging: false,
        useCORS: true,
        backgroundColor: "#ffffff",
      });

      document.body.removeChild(container);

      await saveCanvasAsImage(canvas, `budget_${personLabel}_${selectedMonth}.png`);

      setExporting(false);
    } catch (error) {
      console.error("Image export failed:", error);
      setExporting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">
            {isAr ? "📥 تصدير التقرير" : "📥 Export Report"}
          </DialogTitle>
        </DialogHeader>
          <ExportOptionsBar />

        <div className="space-y-3">
          <div className="space-y-2">
            <p className="text-xs font-body font-semibold">
              {isAr ? "نطاق التقرير" : "Report Period"}
            </p>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="rounded-none h-9 text-sm">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="current">{isAr ? "الشهر الحالي" : "Current Month"}</SelectItem>
                <SelectItem value="weekly">{isAr ? "أسبوعي" : "Weekly"}</SelectItem>
                <SelectItem value="monthly">{isAr ? "شهري" : "Monthly"}</SelectItem>
                <SelectItem value="quarterly">{isAr ? "ربع سنوي" : "Quarterly"}</SelectItem>
                <SelectItem value="yearly">{isAr ? "سنوي" : "Yearly"}</SelectItem>
                <SelectItem value="all_time">{isAr ? "كل الوقت" : "All Time"}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <p className="text-xs text-muted-foreground font-body">
            {isAr
              ? "اختر صيغة التصدير المفضلة لديك"
              : "Choose your preferred export format"}
          </p>

          <Button
            className="w-full h-10 rounded-none flex items-center justify-center gap-2 font-body text-sm"
            onClick={exportToCSV}
            disabled={exporting}
          >
            <FileText className="w-4 h-4" />
            {exporting ? (isAr ? "جارٍ التصدير..." : "Exporting...") : "CSV"}
          </Button>

          <Button
            className="w-full h-10 rounded-none flex items-center justify-center gap-2 font-body text-sm"
            onClick={exportToPDF}
            disabled={exporting}
          >
            <Download className="w-4 h-4" />
            {exporting ? (isAr ? "جارٍ التصدير..." : "Exporting...") : "PDF"}
          </Button>

          <Button
            className="w-full h-10 rounded-none flex items-center justify-center gap-2 font-body text-sm"
            onClick={exportToImage}
            disabled={exporting}
          >
            <ImageIcon className="w-4 h-4" />
            {exporting ? (isAr ? "جارٍ التصدير..." : "Exporting...") : "Image (PNG)"}
          </Button>

          <p className="text-[10px] text-muted-foreground font-body text-center pt-2">
            {isAr
              ? "التقرير يتضمن جميع الدخل و المصاريف و الالتزامات"
              : "Report includes all income, expenses and obligations"}
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}
