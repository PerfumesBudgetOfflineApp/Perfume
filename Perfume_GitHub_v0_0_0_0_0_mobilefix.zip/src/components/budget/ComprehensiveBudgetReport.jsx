import { getAppName } from "@/lib/useAppName";
import { useState, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Download } from "lucide-react";
import { BarChart, Bar, PieChart as RechartsPieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";

// TODO: استخدام jspdf-autotable لتحسين الجداول و التنسيق للعربية
// المكتبة تحتاج تثبيت: npm install jspdf-autotable
// ستحسن التقرير بجداول احترافية و تنسيق أفضل للنصوص العربية

const CATEGORY_LABELS = {
  en: {
    food: "Food",
    transportation: "Transportation",
    utilities: "Utilities",
    shopping: "Shopping",
    entertainment: "Entertainment",
    health: "Health",
    education: "Education",
    perfume: "Perfume",
    insurance: "Insurance",
    subscription: "Subscription",
    other: "Other",
  },
  ar: {
    food: "طعام",
    transportation: "تنقل",
    utilities: "فواتير",
    shopping: "تسوق",
    entertainment: "ترفيه",
    health: "صحة",
    education: "تعليم",
    perfume: "عطور",
    insurance: "تأمين",
    subscription: "اشتراك",
    other: "أخرى",
  }
};

const TRANSLATIONS = {
  en: {
    title: "Comprehensive Financial Report",
    timeRange: "Time Range",
    daily: "Today",
    allTime: "All Time",
    thisYear: "This Year",
    sixMonths: "6 Months",
    thisMonth: "This Month",
    thisWeek: "This Week",
    customRange: "Custom Range",
    reportOptions: "Report Contents",
    stores: "Store Analytics",
    obligationsOption: "Obligations & Alerts",
    trends: "Financial Trends",
    categoryBreakdown: "Category Breakdown",
    summary: "Financial Summary",
    export: "Generate Report",
    generating: "Generating...",
    storeReport: "Store Spending Report",
    topStores: "Top Stores by Spending",
    obligationStatus: "Obligation Status",
    noData: "No data available",
    daysRemaining: "Days remaining",
    monthlyPayment: "Monthly Payment",
    remaining: "Remaining Amount",
    paid: "Paid",
    total: "Total",
    income: "Total Income",
    expenses: "Total Expenses",
    purchases: "Perfume Purchases",
    obligations: "Obligations",
    recurring: "Recurring Expenses",
    balance: "Balance",
    status: "Status",
    from: "From",
    to: "To",
  },
  ar: {
    title: "تقرير مالي شامل",
    timeRange: "نطاق الوقت",
    daily: "اليوم",
    allTime: "منذ البداية",
    thisYear: "هذا العام",
    sixMonths: "6 أشهر",
    thisMonth: "هذا الشهر",
    thisWeek: "هذا الأسبوع",
    customRange: "نطاق مخصص",
    reportOptions: "محتوى التقرير",
    stores: "تحليلات المتاجر",
    obligationsOption: "الالتزامات و التنبيهات",
    trends: "الاتجاهات المالية",
    categoryBreakdown: "توزيع الفئات",
    summary: "الملخص المالي",
    export: "إنشاء التقرير",
    generating: "جارٍ الإنشاء...",
    storeReport: "تقرير الإنفاق بالمتاجر",
    topStores: "أفضل المتاجر بالإنفاق",
    obligationStatus: "حالة الالتزامات",
    noData: "لا توجد بيانات",
    daysRemaining: "الأيام المتبقية",
    monthlyPayment: "القسط الشهري",
    remaining: "المبلغ المتبقي",
    paid: "المدفوع",
    total: "الإجمالي",
    income: "إجمالي الدخل",
    expenses: "إجمالي المصاريف",
    purchases: "مشتريات العطور",
    obligations: "الالتزامات",
    recurring: "المصاريف الدورية",
    balance: "الرصيد",
    status: "الحالة",
    from: "من",
    to: "إلى",
  }
};

export default function ComprehensiveBudgetReport({
  open,
  onOpenChange,
  data,
  isAr,
  currency,
  names,
  selectedPerson,
  stores = [],
  totalSaved: totalSavedProp = 0,
  userMark = "",
  appName = "",
}) {
  const t = TRANSLATIONS[isAr ? "ar" : "en"];
  const [generating, setGenerating] = useState(false);
  const [exportFormat, setExportFormat] = useState("pdf");
  const [reportDepth, setReportDepth] = useState("full"); // brief = مختصر (img) | full = مطوّل (pdf)
  const [timeRange, setTimeRange] = useState("thisMonth");
  const [startDate, setStartDate] = useState(new Date(new Date().getFullYear(), new Date().getMonth(), 1).toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState(new Date().toISOString().slice(0, 10));
  const [reportPerson, setReportPerson] = useState(selectedPerson);
  const [reportOptions, setReportOptions] = useState({
    summary: true,
    stores: true,
    obligations: true,
    trends: true,
    categoryBreakdown: true,
  });

  // خيارات تخصيص التقرير
  const [reportLang, setReportLang] = useState(isAr ? "ar" : "en"); // ar | en | both
  const [fontChoice, setFontChoice] = useState("amiri"); // amiri | cairo | tajawal | montserrat
  const [dirChoice, setDirChoice] = useState(isAr ? "rtl" : "ltr"); // rtl | ltr | auto
  const [showDate, setShowDate] = useState(true);
  const [showMark, setShowMark] = useState(true);
  const [showAppName, setShowAppName] = useState(true);
  const [autoIntro, setAutoIntro] = useState(true); // التطبيق يكتب مقدمة تلقائية
  const [introText, setIntroText] = useState(""); // مقدمة يحرّرها المستخدم
  const [reportImage, setReportImage] = useState(null); // صورة مرفقة (base64)
  const [imagePosition, setImagePosition] = useState("end"); // start | end

  // التطبيق يعمل أوفلاين، فلا نعتمد على خطوط الإنترنت. نستخدم خطوط النظام
  // مع بدائل عربية مضمونة (تُعرض على كل الأجهزة دون إنترنت).
  const FONT_STACK = {
    amiri: "'Amiri', 'Traditional Arabic', 'Times New Roman', serif",
    cairo: "'Cairo', 'Segoe UI', 'Tahoma', sans-serif",
    tajawal: "'Tajawal', 'Segoe UI', 'Tahoma', sans-serif",
    montserrat: "'Segoe UI', 'Tahoma', 'Arial', sans-serif",
  };
  const reportFont = FONT_STACK[fontChoice] || FONT_STACK.amiri;
  const rLangAr = reportLang === "ar" || reportLang === "both";
  const rLangEn = reportLang === "en" || reportLang === "both";
  const reportDir = dirChoice === "auto" ? (rLangAr ? "rtl" : "ltr") : dirChoice;

  const getDateRange = () => {
    const now = new Date();
    const oneYearAgo = new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
    const sixMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 6, now.getDate());
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

    switch (timeRange) {
      case "daily": return { start: now.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
      case "allTime": return { start: "2000-01-01", end: now.toISOString().slice(0, 10) };
      case "thisYear": return { start: new Date(now.getFullYear(), 0, 1).toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
      case "sixMonths": return { start: sixMonthsAgo.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
      case "thisMonth": return { start: monthStart.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
      case "thisWeek": return { start: weekAgo.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
      case "customRange": return { start: startDate, end: endDate };
      default: return { start: monthStart.toISOString().slice(0, 10), end: now.toISOString().slice(0, 10) };
    }
  };

  const dateRange = getDateRange();

  const filteredData = useMemo(() => {
    const { start, end } = dateRange;
    const filterByPerson = (arr) => {
      if (reportPerson === "together") return arr;
      return arr?.filter(item => (item.person === reportPerson || item.person === "family")) || [];
    };
    
    return {
      expenses: filterByPerson(data.expenses?.filter(e => e.date >= start && e.date <= end)) || [],
      purchases: filterByPerson(data.purchases?.filter(p => p.purchase_date >= start && p.purchase_date <= end)) || [],
      incomes: filterByPerson(data.incomes?.filter(i => i.date >= start && i.date <= end)) || [],
      recurring: filterByPerson(data.recurring?.filter(r => r.start_date <= end && (!r.end_date || r.end_date >= start))) || [],
      obligations: filterByPerson(data.obligations) || [],
    };
  }, [data, dateRange, reportPerson]);

  const storeAnalytics = useMemo(() => {
    const storeMap = {};
    filteredData.purchases.forEach(p => {
      if (p.store_id) {
        if (!storeMap[p.store_id]) {
          storeMap[p.store_id] = {
            store_id: p.store_id,
            store_name: p.store_name || "Unknown",
            total: 0,
            count: 0,
            items: []
          };
        }
        storeMap[p.store_id].total += p.cost || 0;
        storeMap[p.store_id].count += 1;
        storeMap[p.store_id].items.push(p);
      }
    });
    return Object.values(storeMap).sort((a, b) => b.total - a.total);
  }, [filteredData.purchases]);

  const categoryBreakdown = useMemo(() => {
    const cats = {};
    filteredData.expenses.forEach(e => {
      const cat = e.category || "other";
      cats[cat] = (cats[cat] || 0) + (e.amount || 0);
    });
    filteredData.purchases.forEach(p => {
      cats.perfume = (cats.perfume || 0) + (p.cost || 0);
    });
    return Object.entries(cats)
      .map(([key, value]) => [CATEGORY_LABELS[isAr ? "ar" : "en"][key] || key, value])
      .sort((a, b) => b[1] - a[1]);
  }, [filteredData.expenses, filteredData.purchases, isAr]);

  const totals = useMemo(() => {
    return {
      income: filteredData.incomes.reduce((sum, i) => sum + (i.amount || 0), 0),
      expenses: filteredData.expenses.reduce((sum, e) => sum + (e.amount || 0), 0),
      purchases: filteredData.purchases.reduce((sum, p) => sum + (p.cost || 0), 0),
      recurring: filteredData.recurring.reduce((sum, r) => {
        if (r.frequency === "monthly") return sum + (r.amount || 0);
        if (r.frequency === "weekly") return sum + ((r.amount || 0) * 4.33);
        if (r.frequency === "daily") return sum + ((r.amount || 0) * 30);
        return sum;
      }, 0),
      obligations: filteredData.obligations.reduce((sum, o) => sum + (o.monthly_payment || 0), 0),
    };
  }, [filteredData]);

  const obligationAlerts = useMemo(() => {
    return filteredData.obligations.map(obl => {
      const remaining = obl.total_amount - obl.paid_amount;
      const endDate = new Date(obl.end_date);
      const daysRemaining = Math.ceil((endDate - new Date()) / (1000 * 60 * 60 * 24));
      const progress = (obl.paid_amount / obl.total_amount) * 100;
      const status = daysRemaining < 30 ? "urgent" : daysRemaining < 90 ? "warning" : "normal";
      return { ...obl, remaining, daysRemaining, progress, status };
    });
  }, [filteredData.obligations]);

  const monthlyExpenses = totals.expenses + totals.purchases;
  const monthlyFixed = totals.obligations + totals.recurring;
  const netMonthly = totals.income - monthlyExpenses - monthlyFixed;

  const forecastData = [
    { period: isAr ? "الآن" : "Now", income: totals.income, expenses: monthlyExpenses, balance: netMonthly },
    { period: isAr ? "6 أشهر" : "6M", income: totals.income * 6, expenses: monthlyExpenses * 6, balance: netMonthly * 6 },
    { period: isAr ? "سنة" : "1Y", income: totals.income * 12, expenses: monthlyExpenses * 12, balance: netMonthly * 12 },
  ];

  // مقدمة تلقائية تصف الوضع الحالي والمستقبلي — تُولّد بلغة/لغات التقرير
  const buildAutoIntro = (lang) => {
    const ar = lang === "ar";
    const cur = currency;
    const healthy = netMonthly >= 0;
    const yearProj = (netMonthly * 12).toFixed(0);
    if (ar) {
      const status = healthy
        ? `الوضع المالي الحالي مستقر، حيث يبلغ صافي الدخل الشهري ${netMonthly.toFixed(0)} ${cur} بعد خصم المصاريف والالتزامات.`
        : `الوضع المالي الحالي يحتاج انتباهاً، حيث إن المصاريف والالتزامات تتجاوز الدخل بمقدار ${Math.abs(netMonthly).toFixed(0)} ${cur} شهرياً.`;
      const future = healthy
        ? `على المدى البعيد، يُتوقع ادخار ما يقارب ${yearProj} ${cur} خلال سنة إذا استمر النمط الحالي.`
        : `يُنصح بمراجعة المصاريف لتفادي عجز متوقع يصل إلى ${Math.abs(yearProj)} ${cur} خلال سنة.`;
      const savingsLine = totals && totalSavedProp > 0 ? ` كما تم ادخار ${totalSavedProp.toFixed(0)} ${cur} نحو الأهداف المحددة.` : "";
      return `${status} ${future}${savingsLine}`;
    }
    const status = healthy
      ? `The current financial position is stable, with a net monthly surplus of ${netMonthly.toFixed(0)} ${cur} after expenses and obligations.`
      : `The current position needs attention: expenses and obligations exceed income by ${Math.abs(netMonthly).toFixed(0)} ${cur} per month.`;
    const future = healthy
      ? `Over the longer term, roughly ${yearProj} ${cur} could be saved within a year if the current pattern holds.`
      : `Reviewing expenses is advised to avoid a projected shortfall of about ${Math.abs(yearProj)} ${cur} within a year.`;
    const savingsLine = totalSavedProp > 0 ? ` ${totalSavedProp.toFixed(0)} ${cur} has been saved toward defined goals.` : "";
    return `${status} ${future}${savingsLine}`;
  };

  const incomeDistribution = [
    { name: isAr ? "دخل" : "Income", value: totals.income }
  ];

  const expenseDistribution = [
    { name: isAr ? "مصاريف" : "Expenses", value: totals.expenses },
    { name: isAr ? "مشتريات" : "Purchases", value: totals.purchases },
    { name: isAr ? "التزامات" : "Obligations", value: totals.obligations }
  ];

  const toggleOption = (key) => {
    setReportOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const exportToExcel = async () => {
    setGenerating(true);
    try {
      let csv = `${isAr ? "تقرير مالي شامل" : "Comprehensive Financial Report"}\n`;
      csv += `${isAr ? "الفترة:" : "Period:"} ${dateRange.start} ${isAr ? "إلى" : "to"} ${dateRange.end}\n`;
      csv += `${isAr ? "المستخدم:" : "User:"} ${reportPerson === "together" ? (isAr ? "الجميع معاً" : "All Together") : reportPerson === "person1" ? names.person1 : reportPerson === "family" ? (isAr ? "العائلة" : "Family") : names.person2}\n\n`;

      csv += `${isAr ? "الملخص المالي" : "Financial Summary"}\n`;
      csv += `${isAr ? "الدخل" : "Income"},${totals.income.toFixed(0)}\n`;
      csv += `${isAr ? "المصاريف" : "Expenses"},${totals.expenses.toFixed(0)}\n`;
      csv += `${isAr ? "المشتريات" : "Purchases"},${totals.purchases.toFixed(0)}\n`;
      csv += `${isAr ? "الالتزامات" : "Obligations"},${totals.obligations.toFixed(0)}\n`;
      csv += `${isAr ? "الرصيد" : "Balance"},${(totals.income - totals.expenses - totals.purchases - totals.obligations).toFixed(0)}\n\n`;

      if (storeAnalytics.length > 0) {
        csv += `${isAr ? "أفضل المتاجر" : "Top Stores"}\n`;
        csv += `${isAr ? "المتجر" : "Store"},${isAr ? "الإجمالي" : "Total"},${isAr ? "العدد" : "Count"}\n`;
        storeAnalytics.slice(0, 10).forEach(s => {
          csv += `${s.store_name},${s.total.toFixed(0)},${s.count}\n`;
        });
        csv += "\n";
      }

      if (categoryBreakdown.length > 0) {
        csv += `${isAr ? "توزيع الفئات" : "Category Breakdown"}\n`;
        csv += `${isAr ? "الفئة" : "Category"},${isAr ? "المبلغ" : "Amount"}\n`;
        categoryBreakdown.forEach(([cat, amount]) => {
          csv += `${cat},${amount.toFixed(0)}\n`;
        });
      }

      const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
      await downloadBlob(blob, `financial_report_${new Date().toISOString().slice(0, 10)}.csv`);
      setGenerating(false);
      onOpenChange(false);
    } catch (error) {
      console.error("Excel export failed:", error);
      setGenerating(false);
    }
  };

  const exportToPNG = async () => {
    setGenerating(true);
    try {
      const reportDiv = document.createElement("div");
      reportDiv.style.position = "fixed";
      reportDiv.style.left = "0";
      reportDiv.style.top = "0";
      reportDiv.style.zIndex = "-1";
      reportDiv.style.opacity = "1";
      reportDiv.style.pointerEvents = "none";
      reportDiv.style.width = "1200px";
      reportDiv.style.padding = "40px";
      reportDiv.style.backgroundColor = "white";
      reportDiv.style.direction = reportDir;
      reportDiv.style.fontFamily = reportFont;
      reportDiv.style.textAlign = reportDir === "rtl" ? "right" : "left";

      const personLabel = reportPerson === "together" ? (isAr ? "الجميع معاً" : "All Together") : 
                          reportPerson === "person1" ? names.person1 : 
                          reportPerson === "family" ? (isAr ? "العائلة" : "Family") : 
                          names.person2;

      // مقاطع قابلة لإعادة الاستخدام تحترم خيارات المستخدم
      const titleAr = "تقرير مالي شامل";
      const titleEn = "Comprehensive Financial Report";
      const reportTitle = reportLang === "both" ? `${titleAr} · ${titleEn}` : (rLangAr ? titleAr : titleEn);
      const dateLine = showDate
        ? `<p style="color: #666; font-size: 14px;">${dateRange.start} ${rLangAr ? "إلى" : "to"} ${dateRange.end} | ${personLabel}</p>`
        : "";
      const imgTag = reportImage
        ? `<div style="text-align:center; margin: 24px 0;"><img src="${reportImage}" style="max-width:100%; max-height:340px; border-radius:10px;" /></div>`
        : "";
      // المقدمة: تلقائية + نص المستخدم
      const introParts = [];
      if (autoIntro) {
        if (rLangAr) introParts.push(buildAutoIntro("ar"));
        if (rLangEn) introParts.push(buildAutoIntro("en"));
      }
      if (introText && introText.trim()) introParts.push(introText.trim());
      const introBlock = introParts.length
        ? `<div style="background:#fafafa; border-${reportDir === "rtl" ? "right" : "left"}: 4px solid #2563eb; border-radius:8px; padding:16px 18px; margin-bottom:24px; line-height:1.9; color:#333; font-size:14px;" dir="${reportDir}">
             ${introParts.map((p) => `<p style="margin:0 0 8px 0;">${p}</p>`).join("")}
           </div>`
        : "";

      reportDiv.innerHTML = `
        <div style="text-align: ${reportDir === "rtl" ? "right" : "center"}; margin-bottom: 24px;" dir="${reportDir}">
          <h1 style="color: #2563eb; font-size: 32px; margin: 0 0 10px 0;">${reportTitle}</h1>
          ${dateLine}
        </div>

        ${imagePosition === "start" ? imgTag : ""}
        ${introBlock}

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 15px; margin-bottom: 30px;" dir="${reportDir}">
          <div style="background: #f0fdf4; border: 2px solid #10b981; border-radius: 8px; padding: 15px; text-align: ${reportDir === "rtl" ? "right" : "center"};">
            <p style="color: #059669; font-size: 12px; margin: 0 0 8px 0;">${rLangAr ? "الدخل" : "Income"}</p>
            <p style="color: #059669; font-size: 24px; font-weight: bold; margin: 0;">${totals.income.toFixed(0)}</p>
          </div>
          <div style="background: #fef2f2; border: 2px solid #ef4444; border-radius: 8px; padding: 15px; text-align: ${reportDir === "rtl" ? "right" : "center"};">
            <p style="color: #dc2626; font-size: 12px; margin: 0 0 8px 0;">${rLangAr ? "الإنفاق" : "Spending"}</p>
            <p style="color: #dc2626; font-size: 24px; font-weight: bold; margin: 0;">${(totals.expenses + totals.purchases).toFixed(0)}</p>
          </div>
          <div style="background: #fef3c7; border: 2px solid #f59e0b; border-radius: 8px; padding: 15px; text-align: ${reportDir === "rtl" ? "right" : "center"};">
            <p style="color: #d97706; font-size: 12px; margin: 0 0 8px 0;">${rLangAr ? "الالتزامات" : "Obligations"}</p>
            <p style="color: #d97706; font-size: 24px; font-weight: bold; margin: 0;">${totals.obligations.toFixed(0)}</p>
          </div>
          <div style="background: #eff6ff; border: 2px solid #3b82f6; border-radius: 8px; padding: 15px; text-align: ${reportDir === "rtl" ? "right" : "center"};">
            <p style="color: #1d4ed8; font-size: 12px; margin: 0 0 8px 0;">${rLangAr ? "الرصيد" : "Balance"}</p>
            <p style="color: #1d4ed8; font-size: 24px; font-weight: bold; margin: 0;">${(totals.income - totals.expenses - totals.purchases - totals.obligations).toFixed(0)}</p>
          </div>
        </div>

        ${reportDepth === "full" ? `
        <div style="background: #f8f8f8; border-radius: 8px; padding: 20px; margin-bottom: 20px;" dir="${reportDir}">
          <h3 style="color: #2563eb; margin-top: 0;">${isAr ? "الحالة الحالية" : "Current Status"}</h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr style="border-bottom: 1px solid #ddd;">
              <td style="padding: 10px; color: #666;">${isAr ? "الدخل الشهري" : "Monthly Income"}</td>
              <td style="padding: 10px; text-align: ${isAr ? "left" : "right"}; font-weight: bold;">${totals.income.toFixed(0)} ${currency}</td>
            </tr>
            <tr style="border-bottom: 1px solid #ddd;">
              <td style="padding: 10px; color: #666;">${isAr ? "الإنفاق الشهري" : "Monthly Expenses"}</td>
              <td style="padding: 10px; text-align: ${isAr ? "left" : "right"}; font-weight: bold;">${(totals.expenses + totals.purchases).toFixed(0)} ${currency}</td>
            </tr>
            <tr>
              <td style="padding: 10px; color: #666;">${isAr ? "الالتزامات الثابتة" : "Fixed Obligations"}</td>
              <td style="padding: 10px; text-align: ${isAr ? "left" : "right"}; font-weight: bold;">${(totals.obligations + totals.recurring).toFixed(0)} ${currency}</td>
            </tr>
          </table>
        </div>
        ` : ""}

        ${reportDepth === "full" && storeAnalytics.length > 0 ? `
          <div style="background: #f0f9ff; border-radius: 8px; padding: 20px; margin-bottom: 20px;" dir="${isAr ? "rtl" : "ltr"}">
            <h3 style="color: #0284c7; margin-top: 0;">${isAr ? "أين ينفق المال" : "Where Your Money Goes"}</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr style="background: #e0f2fe; border-bottom: 1px solid #0284c7;">
                <th style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${isAr ? "المتجر" : "Store"}</th>
                <th style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${isAr ? "المبلغ" : "Amount"}</th>
                <th style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${isAr ? "العدد" : "Count"}</th>
              </tr>
              ${storeAnalytics.slice(0, 5).map(s => `
                <tr style="border-bottom: 1px solid #ddd;">
                  <td style="padding: 10px;">${s.store_name}</td>
                  <td style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${s.total.toFixed(0)} ${currency}</td>
                  <td style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${s.count}</td>
                </tr>
              `).join('')}
            </table>
          </div>
        ` : ''}

        ${reportDepth === "full" && categoryBreakdown.length > 0 ? `
          <div style="background: #faf5ff; border-radius: 8px; padding: 20px;" dir="${isAr ? "rtl" : "ltr"}">
            <h3 style="color: #7c3aed; margin-top: 0;">${isAr ? "توزيع الفئات" : "Category Breakdown"}</h3>
            <table style="width: 100%; border-collapse: collapse;">
              <tr style="background: #f3e8ff; border-bottom: 1px solid #7c3aed;">
                <th style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${isAr ? "الفئة" : "Category"}</th>
                <th style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${isAr ? "المبلغ" : "Amount"}</th>
              </tr>
              ${categoryBreakdown.slice(0, 10).map(([cat, amount]) => `
                <tr style="border-bottom: 1px solid #ddd;">
                  <td style="padding: 10px;">${cat}</td>
                  <td style="padding: 10px; text-align: ${isAr ? "right" : "left"};">${amount.toFixed(0)} ${currency}</td>
                </tr>
              `).join('')}
            </table>
          </div>
        ` : ''}

        ${imagePosition === "end" ? imgTag : ""}

        <div style="text-align: ${reportDir === "rtl" ? "right" : "center"}; margin-top: 40px; padding-top: 20px; border-top: 2px solid #ddd;" dir="${reportDir}">
          ${showAppName && appName ? `<p style="color: #666; font-size: 12px; margin: 0;">${rLangAr ? "من تطبيق" : "From"} ${appName}</p>` : ""}
          ${showMark && userMark ? `<p style="color: #888; font-size: 11px; margin: 4px 0 0 0;">${userMark}</p>` : ""}
          ${showDate ? `<p style="color: #999; font-size: 10px; margin: 5px 0 0 0;">${rLangAr ? `تم الإنشاء: ${new Date().toLocaleDateString("ar-SA")}` : `Generated: ${new Date().toLocaleDateString()}`}</p>` : ""}
        </div>
      `;

      document.body.appendChild(reportDiv);
      const canvas = await captureElement(reportDiv, { scale: 2, backgroundColor: "#ffffff" });
      document.body.removeChild(reportDiv);

      await saveCanvasAsImage(canvas, `financial_report_${new Date().toISOString().slice(0, 10)}.png`);

      setGenerating(false);
      onOpenChange(false);
    } catch (error) {
      console.error("PNG export failed:", error);
      setGenerating(false);
    }
  };

  const handleExport = () => {
    if (exportFormat === "pdf") generatePDF();
    else if (exportFormat === "png") exportToPNG();
    else if (exportFormat === "excel") exportToExcel();
  };

  const arabicText = (text) => {
    if (!isAr) return text;
    // Use Arabic Unicode normalization
    return text.split('').reverse().join('');
  };

  const generatePDF = async () => {
    setGenerating(true);
    try {
      // عند وجود عربي في التقرير، استخدم PNG (jsPDF لا يدعم الخطوط العربية جيداً)
      if (rLangAr) {
        await exportToPNG();
        return;
      }
      
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      let yPos = 15;
      const leftMargin = 15;
      const rightMargin = pageWidth - 15;

      // Header with Color
      pdf.setFillColor(36, 99, 235);
      pdf.rect(0, 0, pageWidth, 30, "F");
      
      pdf.setFontSize(20);
      pdf.setTextColor(255, 255, 255);
      const headerText = isAr ? "تقرير مالي شامل" : "Comprehensive Financial Report";
      // Use Unicode Arabic directly
      pdf.text(headerText, pageWidth / 2, yPos + 8, { align: "center", maxWidth: pageWidth - 30 });
      yPos += 30;

      pdf.setFontSize(10);
      pdf.setTextColor(100);
      const personLabel = reportPerson === "together" ? (isAr ? "الجميع معاً" : "All Together") : 
                          reportPerson === "person1" ? names.person1 : 
                          reportPerson === "family" ? (isAr ? "العائلة" : "Family") : 
                          names.person2;
      const periodLabel = isAr ? "الفترة:" : "Period:";
      const userLabel = isAr ? "المستخدم:" : "User:";
      const toLabel = isAr ? "إلى" : "to";
      const rangText = `${periodLabel} ${dateRange.start} ${toLabel} ${dateRange.end} | ${userLabel} ${personLabel}`;
      pdf.text(rangText, pageWidth / 2, yPos, { align: "center", maxWidth: pageWidth - 30 });
      yPos += 8;
      pdf.setTextColor(0);

      // Summary Section with Background
      if (reportOptions.summary) {
        pdf.setFillColor(230, 245, 255);
        pdf.rect(10, yPos - 3, pageWidth - 20, 50, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(36, 99, 235);
        pdf.text(isAr ? "الملخص المالي" : "Financial Summary", 15, yPos);
        yPos += 8;

        pdf.setFontSize(10);
        pdf.setTextColor(0);
        const summaryData = [
          [isAr ? "الدخل الكلي" : "Total Income", `${totals.income.toFixed(0)} ${currency}`, 76, 180, 43],
          [isAr ? "المصاريف و المشتريات" : "Expenses & Purchases", `${(totals.expenses + totals.purchases).toFixed(0)} ${currency}`, 220, 38, 38],
          [isAr ? "التزامات شهرية" : "Monthly Obligations", `${totals.obligations.toFixed(0)} ${currency}`, 245, 158, 11],
          [isAr ? "الرصيد" : "Balance", `${(totals.income - totals.expenses - totals.purchases - totals.obligations).toFixed(0)} ${currency}`, 59, 130, 246],
        ];

        summaryData.forEach(([label, value, r, g, b]) => {
          pdf.setTextColor(r, g, b);
          pdf.setFontSize(10);
          pdf.text(label, leftMargin, yPos, { align: isAr ? "right" : "left", maxWidth: pageWidth - 60 });
          pdf.text(value, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 6;
        });
        yPos += 2;
        yPos += 8;
      }

      // Store Analytics
      if (reportOptions.stores && storeAnalytics.length > 0) {
        if (yPos > pageHeight - 50) { pdf.addPage(); yPos = 15; }
        pdf.setFillColor(219, 234, 254);
        pdf.rect(10, yPos - 3, pageWidth - 20, storeAnalytics.slice(0, 5).length * 6 + 8, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(30, 144, 255);
        pdf.text(isAr ? "تقرير المتاجر" : "Store Analytics", 15, yPos);
        yPos += 8;

        pdf.setFontSize(9);
        pdf.setTextColor(0);
        storeAnalytics.slice(0, 5).forEach((store, idx) => {
          if (yPos > pageHeight - 15) { pdf.addPage(); yPos = 15; }
          pdf.text(`${store.store_name}:`, leftMargin, yPos, { align: isAr ? "right" : "left", maxWidth: pageWidth - 60 });
          pdf.text(`${store.total.toFixed(0)} ${currency}`, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 5;
        });
        yPos += 4;
      }

      // Obligations Status
      if (reportOptions.obligations && obligationAlerts.length > 0) {
        if (yPos > pageHeight - 50) { pdf.addPage(); yPos = 15; }
        pdf.setFillColor(254, 243, 235);
        pdf.rect(10, yPos - 3, pageWidth - 20, obligationAlerts.slice(0, 5).length * 6 + 8, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(245, 158, 11);
        pdf.text(isAr ? "الالتزامات المالية" : "Financial Obligations", 15, yPos);
        yPos += 8;

        pdf.setFontSize(8);
        pdf.setTextColor(0);
        obligationAlerts.slice(0, 5).forEach(obl => {
          if (yPos > pageHeight - 15) { pdf.addPage(); yPos = 15; }
          const statusColor = obl.status === "urgent" ? [220, 38, 38] : obl.status === "warning" ? [245, 158, 11] : [34, 197, 94];
          pdf.setTextColor(...statusColor);
          pdf.text(`${obl.title}: ${obl.monthly_payment.toFixed(0)} ${currency}`, leftMargin, yPos, { align: isAr ? "right" : "left", maxWidth: pageWidth - 60 });
          pdf.setTextColor(0);
          const daysText = `${obl.daysRemaining} days`;
          pdf.text(daysText, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 4;
        });
        yPos += 4;
      }

      // Category Breakdown
      if (reportOptions.categoryBreakdown && categoryBreakdown.length > 0) {
        if (yPos > pageHeight - 50) { pdf.addPage(); yPos = 15; }
        pdf.setFillColor(245, 243, 254);
        pdf.rect(10, yPos - 3, pageWidth - 20, categoryBreakdown.slice(0, 8).length * 6 + 8, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(139, 92, 246);
        pdf.text(isAr ? "توزيع المصاريف حسب الفئات" : "Category Breakdown", 15, yPos);
        yPos += 8;

        pdf.setFontSize(9);
        pdf.setTextColor(0);
        const colors = [[16, 185, 129], [239, 68, 68], [245, 158, 11], [59, 130, 246], [139, 92, 246], [236, 72, 153]];
        categoryBreakdown.slice(0, 8).forEach(([cat, amount], idx) => {
          if (yPos > pageHeight - 15) { pdf.addPage(); yPos = 15; }
          const [r, g, b] = colors[idx % 6];
          pdf.setTextColor(r, g, b);
          pdf.text(`${cat}:`, leftMargin, yPos, { align: isAr ? "right" : "left", maxWidth: pageWidth - 60 });
          const percent = ((amount / (totals.expenses + totals.purchases)) * 100).toFixed(1);
          pdf.text(`${amount.toFixed(0)} ${currency} (${percent}%)`, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 5;
        });
        yPos += 4;
      }

      // Income Distribution
      if (reportOptions.summary && monthlyExpenses > 0) {
        if (yPos > pageHeight - 60) { pdf.addPage(); yPos = 15; }
        pdf.setFillColor(240, 253, 250);
        pdf.rect(10, yPos - 3, pageWidth - 20, 40, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(16, 185, 129);
        pdf.text(isAr ? "توزيع الدخل و الإنفاق" : "Income vs Spending Distribution", 15, yPos);
        yPos += 8;

        pdf.setFontSize(9);
        pdf.setTextColor(0);
        const incomePercent = 100;
        const expensePercent = ((monthlyExpenses / totals.income) * 100).toFixed(1);
        const obligationPercent = ((monthlyFixed / totals.income) * 100).toFixed(1);
        const balancePercent = (((totals.income - monthlyExpenses - monthlyFixed) / totals.income) * 100).toFixed(1);
        
        const distLines = [
          [isAr ? "نسبة الإنفاق %" : "Spending %", `${expensePercent}%`],
          [isAr ? "نسبة الالتزامات %" : "Obligations %", `${obligationPercent}%`],
          [isAr ? "الرصيد المتبقي %" : "Remaining Balance %", `${balancePercent}%`],
        ];
        distLines.forEach(([label, value]) => {
          pdf.text(label, leftMargin, yPos, { align: isAr ? "right" : "left" });
          pdf.text(value, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 5;
        });
        yPos += 4;
      }

      // Forecast Section
      if (reportOptions.trends) {
        if (yPos > pageHeight - 80) { pdf.addPage(); yPos = 15; }
        pdf.setFillColor(230, 244, 254);
        pdf.rect(10, yPos - 3, pageWidth - 20, 70, "F");
        
        pdf.setFontSize(13);
        pdf.setTextColor(79, 172, 254);
        pdf.text(isAr ? "التوقعات المالية" : "Financial Forecast", 15, yPos);
        yPos += 8;

        pdf.setFontSize(8);
        pdf.setTextColor(0);
        const forecasts = [
          [isAr ? "الآن" : "Now", `${netMonthly.toFixed(0)} ${currency}`],
          [isAr ? "6 أشهر" : "6 Months", `${(netMonthly * 6).toFixed(0)} ${currency}`],
          [isAr ? "سنة واحدة" : "1 Year", `${(netMonthly * 12).toFixed(0)} ${currency}`],
        ];
        forecasts.forEach(([label, value]) => {
          pdf.text(label, leftMargin, yPos, { align: isAr ? "right" : "left" });
          pdf.text(value, rightMargin, yPos, { align: isAr ? "left" : "right" });
          yPos += 6;
        });
      }

      // Recurring & Monthly Breakdown
      if (yPos > pageHeight - 50) { pdf.addPage(); yPos = 15; }
      pdf.setFillColor(254, 226, 226);
      pdf.rect(10, yPos - 3, pageWidth - 20, 35, "F");
      
      pdf.setFontSize(13);
      pdf.setTextColor(220, 38, 38);
      pdf.text(isAr ? "ملخص الحالة الشهرية" : "Monthly Status Summary", 15, yPos);
      yPos += 8;

      pdf.setFontSize(9);
      pdf.setTextColor(0);
      const summaryLines = [
        [isAr ? "إجمالي الدخل" : "Total Income", `${totals.income.toFixed(0)} ${currency}`],
        [isAr ? "إجمالي الإنفاق" : "Total Expenses", `${(monthlyExpenses).toFixed(0)} ${currency}`],
        [isAr ? "التزامات + دوري" : "Obligations + Recurring", `${(monthlyFixed).toFixed(0)} ${currency}`],
        [isAr ? "الرصيد النهائي" : "Final Balance", `${netMonthly.toFixed(0)} ${currency}`],
      ];
      summaryLines.forEach(([label, value]) => {
        pdf.text(label, leftMargin, yPos, { align: isAr ? "right" : "left" });
        pdf.text(value, rightMargin, yPos, { align: isAr ? "left" : "right" });
        yPos += 5;
      });
      yPos += 2;

      // Footer
      pdf.setFillColor(240, 240, 240);
      pdf.rect(0, pageHeight - 12, pageWidth, 12, "F");
      
      pdf.setFontSize(8);
      pdf.setTextColor(100);
      const footerText = `Budget From ${getAppName().name_en}`;
      pdf.text(footerText, pageWidth / 2, pageHeight - 7, { align: "center" });
      pdf.setFontSize(7);
      pdf.setTextColor(150);
      const dateText = isAr ? `تم الإنشاء: ${new Date().toLocaleDateString("ar-SA")}` : `Generated: ${new Date().toLocaleDateString()}`;
      pdf.text(dateText, pageWidth / 2, pageHeight - 3, { align: "center" });

      // Save PDF with proper name
      const fileName = isAr ? `تقرير_مالي_${new Date().toISOString().slice(0, 10)}.pdf` : `financial_report_${new Date().toISOString().slice(0, 10)}.pdf`;
      const pdfBlob = pdf.output('blob');
      await downloadBlob(pdfBlob, fileName);
      setGenerating(false);
      onOpenChange(false);
    } catch (error) {
      console.error("PDF generation failed:", error);
      setGenerating(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className={`max-w-2xl max-h-[90vh] overflow-y-auto rounded-none ${isAr ? "rtl" : ""}`}>
        <DialogHeader>
          <DialogTitle className="font-heading text-lg">{t.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 max-h-[75vh] overflow-y-auto">
          {/* Person Selection */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase">{isAr ? "المستخدم" : "User"}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { val: "person1", label: names.person1 || "User A", icon: "👤" },
                { val: "person2", label: names.person2 || "User B", icon: "👤" },
                { val: "family", label: isAr ? "👨‍👩‍👧‍👦 العائلة" : "👨‍👩‍👧‍👦 Family", icon: "" },
                { val: "together", label: isAr ? "👥 الجميع معاً" : "👥 All Together", icon: "" },
              ].map(({ val, label, icon }) => (
                <button
                  key={val}
                  onClick={() => setReportPerson(val)}
                  className={` rounded-none text-xs font-body transition-all whitespace-nowrap ${
 reportPerson === val
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
                >
                  {icon}{icon ? " " : ""}{label}
                </button>
              ))}
            </div>
          </div>

          {/* Time Range Selection */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase">{t.timeRange}</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: "daily", label: t.daily },
                { val: "thisWeek", label: t.thisWeek },
                { val: "thisMonth", label: t.thisMonth },
                { val: "sixMonths", label: t.sixMonths },
                { val: "thisYear", label: t.thisYear },
                { val: "allTime", label: t.allTime },
                { val: "customRange", label: t.customRange },
              ].map(({ val, label }) => (
                <button
                  key={val}
                  onClick={() => setTimeRange(val)}
                  className={` rounded-none text-xs font-body transition-all ${
 timeRange === val
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {timeRange === "customRange" && (
              <div className="grid grid-cols-2 gap-2 mt-2">
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="px-2 py-1 rounded text-xs border border-border"
                />
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="px-2 py-1 rounded text-xs border border-border"
                />
              </div>
            )}
          </div>

          {/* Report Options */}
          <div className="space-y-2 bg-secondary/30 rounded-none p-3">
            <p className="text-xs font-semibold uppercase">{t.reportOptions}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: "summary", label: t.summary },
                { key: "stores", label: t.stores },
                { key: "obligations", label: t.obligationsOption },
                { key: "trends", label: t.trends },
                { key: "categoryBreakdown", label: t.categoryBreakdown },
              ].map(({ key, label }) => (
                <label key={key} className="flex items-center gap-2 cursor-pointer text-xs font-body">
                  <Checkbox
                    checked={reportOptions[key]}
                    onCheckedChange={() => toggleOption(key)}
                  />
                  <span>{label}</span>
                </label>
              ))}
            </div>
          </div>

          {/* ── خيارات التخصيص ── */}
          <div className="space-y-3 bg-secondary/30 rounded-none p-3">
            <p className="text-xs font-semibold uppercase">{isAr ? "تخصيص التقرير" : "Report Customization"}</p>

            {/* اللغة */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "اللغة" : "Language"}</p>
              <div className="flex gap-1.5">
                {[{ v: "ar", l: "عربي" }, { v: "en", l: "English" }, { v: "both", l: isAr ? "اللغتين" : "Both" }].map((o) => (
                  <button key={o.v} type="button" onClick={() => setReportLang(o.v)}
                    className={`flex-1 py-1.5 rounded-none text-xs font-body border transition-all ${reportLang === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
                    {o.l}
                  </button>
                ))}
              </div>
            </div>

            {/* الخط */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "نوع الخط" : "Font"}</p>
              <div className="flex gap-1.5 flex-wrap">
                {[{ v: "amiri", l: "أميري Amiri" }, { v: "cairo", l: "القاهرة Cairo" }, { v: "tajawal", l: "تجوال Tajawal" }, { v: "montserrat", l: "Montserrat" }].map((o) => (
                  <button key={o.v} type="button" onClick={() => setFontChoice(o.v)}
                    className={` rounded-none text-xs font-body transition-all ${fontChoice === o.v ? " text-primary-foreground " : " text-muted-foreground"}`}>
                    {o.l}
                  </button>
                ))}
              </div>
            </div>

            {/* الاتجاه */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "الاتجاه" : "Direction"}</p>
              <div className="flex gap-1.5">
                {[{ v: "rtl", l: isAr ? "يمين ← يسار" : "RTL" }, { v: "ltr", l: isAr ? "يسار → يمين" : "LTR" }, { v: "auto", l: isAr ? "تلقائي" : "Auto" }].map((o) => (
                  <button key={o.v} type="button" onClick={() => setDirChoice(o.v)}
                    className={`flex-1 py-1.5 rounded-none text-xs font-body border transition-all ${dirChoice === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
                    {o.l}
                  </button>
                ))}
              </div>
            </div>

            {/* تبديلات الظهور */}
            <div className="grid grid-cols-2 gap-2">
              {[
                { k: "date", v: showDate, set: setShowDate, l: isAr ? "تاريخ التصدير" : "Export date" },
                { k: "mark", v: showMark, set: setShowMark, l: isAr ? "علامة المستخدم" : "User mark" },
                { k: "appName", v: showAppName, set: setShowAppName, l: isAr ? "اسم التطبيق" : "App name" },
                { k: "autoIntro", v: autoIntro, set: setAutoIntro, l: isAr ? "مقدمة تلقائية" : "Auto intro" },
              ].map((o) => (
                <label key={o.k} className="flex items-center gap-2 cursor-pointer text-xs font-body">
                  <Checkbox checked={o.v} onCheckedChange={() => o.set(!o.v)} />
                  <span>{o.l}</span>
                </label>
              ))}
            </div>

            {/* نص مقدمة محرّر */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "نص مقدمة إضافي (اختياري)" : "Extra intro text (optional)"}</p>
              <textarea
                value={introText}
                onChange={(e) => setIntroText(e.target.value)}
                placeholder={isAr ? "اكتب مقدمة مخصصة للتقرير..." : "Write a custom intro..."}
                dir={reportDir}
                className="w-full rounded-none text-xs font-body resize-none min-h-[60px] focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
              />
            </div>

            {/* صورة مرفقة + موضعها */}
            <div className="space-y-1">
              <p className="text-[10px] text-muted-foreground font-body">{isAr ? "صورة مرفقة (اختياري)" : "Attached image (optional)"}</p>
              <div className="flex items-center gap-2">
                <input
                  type="file" accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = (ev) => setReportImage(ev.target.result);
                    reader.readAsDataURL(file);
                  }}
                  className="text-xs font-body flex-1"
                />
                {reportImage && (
                  <button type="button" onClick={() => setReportImage(null)} className="text-xs text-destructive font-body">
                    {isAr ? "إزالة" : "Remove"}
                  </button>
                )}
              </div>
              {reportImage && (
                <div className="flex gap-1.5 mt-1">
                  {[{ v: "start", l: isAr ? "في البداية" : "At start" }, { v: "end", l: isAr ? "في النهاية" : "At end" }].map((o) => (
                    <button key={o.v} type="button" onClick={() => setImagePosition(o.v)}
                      className={`flex-1 py-1.5 rounded-none text-xs font-body border transition-all ${imagePosition === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>
                      {o.l}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gradient-to-br from-emerald-50 to-emerald-100 dark:from-emerald-900/30 dark:to-emerald-900/20 rounded-none p-2.5 border border-emerald-300 dark:border-emerald-700">
              <p className="text-[9px] text-emerald-700 dark:text-emerald-300 font-semibold">{t.income}</p>
              <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{totals.income.toFixed(0)}</p>
              <p className="text-[9px] text-emerald-600 dark:text-emerald-400 mt-1">{currency}</p>
            </div>
            <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/30 dark:to-red-900/20 rounded-none p-2.5 border border-red-300 dark:border-red-700">
              <p className="text-[9px] text-red-700 dark:text-red-300 font-semibold">{t.expenses}</p>
              <p className="text-sm font-bold text-red-600 dark:text-red-400">{(totals.expenses + totals.purchases).toFixed(0)}</p>
              <p className="text-[9px] text-red-600 dark:text-red-400 mt-1">{currency}</p>
            </div>
            <div className="bg-gradient-to-br from-orange-50 to-orange-100 dark:from-orange-900/30 dark:to-orange-900/20 rounded-none p-2.5 border border-orange-300 dark:border-orange-700">
              <p className="text-[9px] text-orange-700 dark:text-orange-300 font-semibold">{t.obligations}</p>
              <p className="text-sm font-bold text-orange-600 dark:text-orange-400">{totals.obligations.toFixed(0)}</p>
              <p className="text-[9px] text-orange-600 dark:text-orange-400 mt-1">{currency}</p>
            </div>
            <div className={`rounded-none p-2.5 border bg-gradient-to-br ${(totals.income - totals.expenses - totals.purchases - totals.obligations) >= 0 ? "from-blue-50 to-blue-100 dark:from-blue-900/30 dark:to-blue-900/20 border-blue-300 dark:border-blue-700" : "from-amber-50 to-amber-100 dark:from-amber-900/30 dark:to-amber-900/20 border-amber-300 dark:border-amber-700"}`}>
              <p className={`text-[9px] font-semibold ${(totals.income - totals.expenses - totals.purchases - totals.obligations) >= 0 ? "text-blue-700 dark:text-blue-300" : "text-amber-700 dark:text-amber-300"}`}>{t.balance}</p>
              <p className={`text-sm font-bold ${(totals.income - totals.expenses - totals.purchases - totals.obligations) >= 0 ? "text-blue-600 dark:text-blue-400" : "text-amber-600 dark:text-amber-400"}`}>{(totals.income - totals.expenses - totals.purchases - totals.obligations).toFixed(0)}</p>
              <p className={`text-[9px] mt-1 ${(totals.income - totals.expenses - totals.purchases - totals.obligations) >= 0 ? "text-blue-600 dark:text-blue-400" : "text-amber-600 dark:text-amber-400"}`}>{currency}</p>
            </div>
          </div>

          {/* Income vs Spending */}
          <div className="bg-gradient-to-br from-cyan-50 to-blue-50 dark:from-cyan-900/20 dark:to-blue-900/20 rounded-none p-3 border border-cyan-200 dark:border-cyan-700">
            <p className="text-xs font-semibold mb-2 text-cyan-700 dark:text-cyan-300">{isAr ? "الدخل مقابل الإنفاق" : "Income vs Spending"}</p>
            <ResponsiveContainer width="100%" height={150}>
              <BarChart data={[
                { name: isAr ? "دخل" : "Income", value: totals.income },
                { name: isAr ? "إنفاق" : "Spending", value: monthlyExpenses }
              ]}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" fontSize={10} />
                <YAxis fontSize={10} />
                <Tooltip formatter={(value) => `${value.toFixed(0)} ${currency}`} />
                <Bar dataKey="value" fill="#06b6d4" />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Expense Distribution */}
          {reportOptions.categoryBreakdown && categoryBreakdown.length > 0 && (
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-none p-3 border border-purple-200 dark:border-purple-700">
              <p className="text-xs font-semibold mb-2 text-purple-700 dark:text-purple-300">{isAr ? "توزيع المصاريف" : "Expense Distribution"}</p>
              <ResponsiveContainer width="100%" height={150}>
                <RechartsPieChart>
                  <Pie data={categoryBreakdown.map(([name, value]) => ({ name, value }))} cx="50%" cy="50%" radius={40} dataKey="value" outerRadius={50}>
                    {categoryBreakdown.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={["#10b981", "#ef4444", "#f59e0b", "#3b82f6", "#8b5cf6", "#ec4899"][index % 6]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `${value.toFixed(0)} ${currency}`} />
                </RechartsPieChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Forecast */}
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-none p-3 border border-indigo-200 dark:border-indigo-700">
            <p className="text-xs font-semibold mb-2 text-indigo-700 dark:text-indigo-300">{isAr ? "التوقعات المالية" : "Financial Forecast"}</p>
            <ResponsiveContainer width="100%" height={150}>
              <LineChart data={forecastData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="period" fontSize={10} />
                <YAxis fontSize={10} />
                <Tooltip formatter={(value) => `${value.toFixed(0)} ${currency}`} />
                <Legend />
                <Line type="monotone" dataKey="income" stroke="#10b981" strokeWidth={2} />
                <Line type="monotone" dataKey="expenses" stroke="#ef4444" strokeWidth={2} />
                <Line type="monotone" dataKey="balance" stroke="#3b82f6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Store Chart Preview */}
          {reportOptions.stores && storeAnalytics.length > 0 && (
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 rounded-none p-3 border border-blue-200 dark:border-blue-700">
              <p className="text-xs font-semibold mb-2 text-blue-700 dark:text-blue-300">{isAr ? "أين ينفق المال" : "Where Your Money Goes"}</p>
              <ResponsiveContainer width="100%" height={150}>
                <BarChart data={storeAnalytics.slice(0, 5).map(s => ({ name: s.store_name, value: s.total }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" fontSize={10} />
                  <YAxis fontSize={10} />
                  <Tooltip formatter={(value) => `${value.toFixed(0)} ${currency}`} />
                  <Bar dataKey="value" fill="#0ea5e9" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Debt Payoff Timeline */}
          {reportOptions.obligations && obligationAlerts.length > 0 && (
            <div className="bg-gradient-to-br from-orange-50 to-red-50 dark:from-orange-900/20 dark:to-red-900/20 rounded-none p-3 border border-orange-200 dark:border-orange-700 space-y-2">
              <p className="text-xs font-semibold text-orange-700 dark:text-orange-300">{isAr ? "جدول سداد الديون" : "Debt Payoff Timeline"}</p>
              {obligationAlerts.slice(0, 3).map((obl, idx) => (
                <div key={obl.id} className="space-y-1">
                  <div className="flex justify-between text-[10px]">
                    <span className="font-semibold">{obl.title}</span>
                    <span className="text-orange-600 dark:text-orange-400">{obl.daysRemaining} {isAr ? "يوم" : "days"}</span>
                  </div>
                  <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-none overflow-hidden">
                    <div 
                      className="h-full bg-gradient-to-r from-orange-400 to-red-500" 
                      style={{ width: `${obl.progress}%` }}
                    />
                  </div>
                  <p className="text-[9px] text-muted-foreground">{obl.remaining.toFixed(0)} {currency} {isAr ? "متبقي" : "remaining"}</p>
                </div>
              ))}
            </div>
          )}

          {/* Obligation & Savings Summary */}
          <div className="grid grid-cols-2 gap-2">
            {/* Current Status */}
            <div className="bg-gradient-to-br from-teal-50 to-green-50 dark:from-teal-900/20 dark:to-green-900/20 rounded-none p-2.5 border border-teal-200 dark:border-teal-700">
              <p className="text-[9px] font-semibold text-teal-700 dark:text-teal-300 mb-1">{isAr ? "الحالة الحالية" : "Current Status"}</p>
              <p className="text-xs font-bold text-teal-600 dark:text-teal-400">{netMonthly.toFixed(0)}</p>
              <p className="text-[9px] text-teal-600 dark:text-teal-400">{isAr ? "شهري صافي" : "monthly net"}</p>
            </div>

            {/* Monthly Fixed */}
            <div className="bg-gradient-to-br from-rose-50 to-pink-50 dark:from-rose-900/20 dark:to-pink-900/20 rounded-none p-2.5 border border-rose-200 dark:border-rose-700">
              <p className="text-[9px] font-semibold text-rose-700 dark:text-rose-300 mb-1">{isAr ? "التزامات ثابتة" : "Fixed Obligations"}</p>
              <p className="text-xs font-bold text-rose-600 dark:text-rose-400">{monthlyFixed.toFixed(0)}</p>
              <p className="text-[9px] text-rose-600 dark:text-rose-400">{currency}</p>
            </div>
          </div>

          {/* نوع التقرير: مختصر (صورة) أو مطوّل (PDF) */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase">{isAr ? "نوع التقرير" : "Report Type"}</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => { setReportDepth("brief"); setExportFormat("png"); }}
                className={` rounded-none text-xs font-body transition-all flex flex-col items-center gap-0.5 ${reportDepth === "brief" ? " text-primary-foreground " : " text-muted-foreground"}`}
              >
                <span>🖼️ {isAr ? "مختصر" : "Brief"}</span>
                <span className="text-[9px] opacity-80">{isAr ? "ملخص الوضع المالي (صورة)" : "Snapshot (image)"}</span>
              </button>
              <button
                onClick={() => { setReportDepth("full"); setExportFormat("pdf"); }}
                className={` rounded-none text-xs font-body transition-all flex flex-col items-center gap-0.5 ${reportDepth === "full" ? " text-primary-foreground " : " text-muted-foreground"}`}
              >
                <span>📄 {isAr ? "مطوّل" : "Full"}</span>
                <span className="text-[9px] opacity-80">{isAr ? "تقرير تفصيلي (PDF)" : "Detailed (PDF)"}</span>
              </button>
            </div>
          </div>

          {/* Export Format Selection */}
          <div className="space-y-2">
            <p className="text-xs font-semibold uppercase">{isAr ? "صيغة التصدير" : "Export Format"}</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { val: "pdf", label: "PDF", icon: "📄" },
                { val: "png", label: "PNG", icon: "🖼️" },
                { val: "excel", label: "Excel", icon: "📊" },
              ].map(({ val, label, icon }) => (
                <button
                  key={val}
                  onClick={() => setExportFormat(val)}
                  className={` rounded-none text-xs font-body transition-all flex items-center justify-center gap-1 ${
 exportFormat === val
 ? " text-primary-foreground "
 : " text-muted-foreground "
 }`}
                >
                  <span>{icon}</span>
                  <span>{label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <Button
            className="w-full h-10 rounded-none font-body text-sm"
            onClick={handleExport}
            disabled={generating}
          >
            <Download className="w-4 h-4 mr-2" />
            {generating ? t.generating : t.export}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
