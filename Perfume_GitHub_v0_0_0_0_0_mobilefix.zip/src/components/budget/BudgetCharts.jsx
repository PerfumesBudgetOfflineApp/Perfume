import { PieChart, Pie, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line } from "recharts";

const CATEGORY_COLORS = {
  food: "#10b981",
  transportation: "#3b82f6",
  utilities: "#f59e0b",
  shopping: "#ec4899",
  entertainment: "#8b5cf6",
  health: "#ef4444",
  education: "#06b6d4",
  perfume: "#f97316",
  insurance: "#6366f1",
  subscription: "#14b8a6",
  other: "#6b7280",
};

export default function BudgetCharts({
  expenses,
  incomes,
  isAr,
  currency,
  allMonthData = [],
}) {
  // Prepare expense distribution data
  const expensesByCategory = {};
  expenses.forEach((exp) => {
    const cat = exp.category || "other";
    expensesByCategory[cat] = (expensesByCategory[cat] || 0) + (exp.amount || 0);
  });

  const pieData = Object.entries(expensesByCategory).map(([category, amount]) => ({
    name: category,
    value: amount,
    fill: CATEGORY_COLORS[category] || "#9ca3af",
  }));

  // Prepare monthly trend data
  const monthlyData = allMonthData.map((month) => ({
    month: month.month.slice(5, 7),
    income: month.totalIncome || 0,
    expenses: month.totalExpense || 0,
    balance: month.balance || 0,
  }));

  // Prepare income breakdown
  const incomeByType = {};
  incomes.forEach((inc) => {
    const type = inc.type || "other";
    incomeByType[type] = (incomeByType[type] || 0) + (inc.amount || 0);
  });

  const incomeData = Object.entries(incomeByType).map(([type, amount]) => ({
    name: type,
    value: amount,
    fill: type === "salary" ? "#10b981" : type === "business" ? "#3b82f6" : type === "investment" ? "#f59e0b" : "#6b7280",
  }));

  const CustomTooltip = ({ active, payload, label, isAr }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded p-2 shadow-lg">
          <p className="text-xs font-body text-foreground">
            {payload[0].name}: {payload[0].value.toFixed(0)} {currency}
          </p>
        </div>
      );
    }
    return null;
  };

  const CustomBarTooltip = ({ active, payload, isAr }) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-card border border-border rounded p-2 shadow-lg space-y-1">
          {payload.map((item, idx) => (
            <p key={idx} className="text-xs font-body" style={{ color: item.color }}>
              {item.name}: {item.value.toFixed(0)} {currency}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      {/* Expense Distribution */}
      {pieData.length > 0 && (
        <div className="py-2">
          <h3 className="text-sm font-body font-semibold mb-3 flex items-center gap-2">
            <span>📊</span>
            {isAr ? "توزيع المصاريف حسب الفئة" : "Expense Distribution"}
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                innerRadius={50}
                outerRadius={80}
                paddingAngle={2}
                dataKey="value"
              >
              </Pie>
              <Tooltip
                formatter={(value) => `${value.toFixed(0)} ${currency}`}
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  fontSize: "12px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {pieData.slice(0, 6).map((item) => (
              <div key={item.name} className="flex items-center gap-2 text-xs font-body">
                <div
                  className="w-2.5 h-2.5 rounded-none flex-shrink-0"
                  style={{ backgroundColor: item.fill }}
                />
                <span className="text-muted-foreground truncate">{item.name}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Income Distribution */}
      {incomeData.length > 0 && (
        <div className="py-2">
          <h3 className="text-sm font-body font-semibold mb-3 flex items-center gap-2">
            <span>💰</span>
            {isAr ? "توزيع الدخل" : "Income Distribution"}
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie
                data={incomeData}
                cx="50%"
                cy="50%"
                outerRadius={70}
                paddingAngle={2}
                dataKey="value"
              >
              </Pie>
              <Tooltip
                formatter={(value) => `${value.toFixed(0)} ${currency}`}
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  fontSize: "12px",
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Monthly Trend */}
      {monthlyData.length > 0 && (
        <div className="py-2">
          <h3 className="text-sm font-body font-semibold mb-3 flex items-center gap-2">
            <span>📈</span>
            {isAr ? "الاتجاه الشهري" : "Monthly Trend"}
          </h3>
          <ResponsiveContainer width="100%" height={250}>
            <BarChart
              data={monthlyData}
              margin={{ top: 20, right: 30, left: 0, bottom: 20 }}
            >
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--border))"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              />
              <YAxis
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  fontSize: "12px",
                }}
                formatter={(value) => `${value.toFixed(0)} ${currency}`}
              />
              <Legend
                wrapperStyle={{ fontSize: "12px" }}
                formatter={(value) =>
                  value === "income"
                    ? isAr
                      ? "الدخل"
                      : "Income"
                    : value === "expenses"
                    ? isAr
                      ? "المصاريف"
                      : "Expenses"
                    : isAr
                    ? "الرصيد"
                    : "Balance"
                }
              />
              <Bar dataKey="income" fill="#10b981" radius={[6, 6, 0, 0]} />
              <Bar dataKey="expenses" fill="#ef4444" radius={[6, 6, 0, 0]} />
              <Bar
                dataKey="balance"
                fill="#3b82f6"
                radius={[6, 6, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* Balance Trend Line Chart */}
      {monthlyData.length > 1 && (
        <div className="py-2">
          <h3 className="text-sm font-body font-semibold mb-3 flex items-center gap-2">
            <span>📊</span>
            {isAr ? "اتجاه الرصيد" : "Balance Trend"}
          </h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={monthlyData} margin={{ top: 5, right: 30, left: 0, bottom: 5 }}>
              <CartesianGrid
                strokeDasharray="3 3"
                stroke="hsl(var(--border))"
                vertical={false}
              />
              <XAxis
                dataKey="month"
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              />
              <YAxis
                tick={{ fill: "hsl(var(--muted-foreground))", fontSize: 11 }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "hsl(var(--card))",
                  border: "1px solid hsl(var(--border))",
                  borderRadius: "0.5rem",
                  fontSize: "12px",
                }}
                formatter={(value) => `${value.toFixed(0)} ${currency}`}
              />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="#3b82f6"
                strokeWidth={2}
                dot={{ fill: "#3b82f6", r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}