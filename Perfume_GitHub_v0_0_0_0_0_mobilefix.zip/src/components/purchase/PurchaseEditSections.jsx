import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Edit2, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";

export default function PurchaseEditSections({ purchases, perfumes }) {
  const { names } = usePersonNames();
  const { formatPrice } = useCurrency();
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState(null);
  const [expandedPerson, setExpandedPerson] = useState("person1");
  const [formData, setFormData] = useState({});

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.PurchaseRecord.update(editingId, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["purchase-records"] });
      toast.success("تم التحديث");
      setEditingId(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.PurchaseRecord.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["purchase-records"] });
      toast.success("تم الحذف");
    },
  });

  const handleEdit = (record) => {
    setEditingId(record.id);
    setFormData({
      ml: record.ml || "",
      cost: record.cost || "",
      type: record.type || "sample",
    });
  };

  const handleSave = () => {
    const ml = parseFloat(formData.ml || 0);
    const cost = parseFloat(formData.cost || 0);
    if (ml <= 0 || cost <= 0) {
      toast.error("أدخل مل و تكلفة صحيحة");
      return;
    }
    updateMutation.mutate({
      ml,
      cost,
      type: formData.type,
    });
  };

  const renderPersonSection = (person) => {
    const personPurchases = purchases.filter((p) => p.person === person);

    return (
      <div key={person} className="space-y-2">
        <button
          onClick={() => setExpandedPerson(expandedPerson === person ? null : person)}
          className="w-full flex items-center justify-between px-4 py-3 bg-secondary/50 rounded-none hover:bg-secondary transition-colors"
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-none ${person === "person1" ? "bg-primary" : "bg-violet-500"}`} />
            <span className="text-sm font-body font-semibold">
              {person === "person1" ? names.person1 : names.person2}
            </span>
            <span className="text-xs text-muted-foreground">· {personPurchases.length} purchases</span>
          </div>
          {expandedPerson === person ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {expandedPerson === person && (
          <div className="bg-card rounded-none p-4 space-y-2 border border-border/60">
            {personPurchases.length === 0 ? (
              <p className="text-xs text-muted-foreground font-body text-center py-4">لا مشتريات بعد No purchases yet</p>
            ) : (
              personPurchases.map((record) => (
                <div key={record.id} className="space-y-2 pb-3 border-b border-border/30 last:border-0 last:pb-0">
                  {editingId === record.id ? (
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <button
                          onClick={() => setFormData({ ...formData, type: "sample" })}
                          className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                            formData.type === "sample"
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-muted-foreground"
                          }`}
                        >
                          Sample
                        </button>
                        <button
                          onClick={() => setFormData({ ...formData, type: "bottle" })}
                          className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                            formData.type === "bottle"
                              ? "bg-primary text-primary-foreground"
                              : "bg-secondary text-muted-foreground"
                          }`}
                        >
                          Bottle
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <Input
                          type="number"
                          step="0.5"
                          value={formData.ml}
                          onChange={(e) => setFormData({ ...formData, ml: e.target.value })}
                          placeholder="مل ML"
                          className="rounded-none font-body text-xs h-8"
                        />
                        <Input
                          type="number"
                          step="0.1"
                          value={formData.cost}
                          onChange={(e) => setFormData({ ...formData, cost: e.target.value })}
                          placeholder="التكلفة Cost"
                          className="rounded-none font-body text-xs h-8"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 rounded-none font-body text-xs h-8"
                          onClick={handleSave}
                          disabled={updateMutation.isPending}
                        >
                          {updateMutation.isPending ? "Saving..." : "Save"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="flex-1 rounded-none font-body text-xs h-8"
                          onClick={() => setEditingId(null)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between group">
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-body font-medium">{record.perfume_name}</span>
                          <span className="text-[9px] font-body rounded-none text-primary">
                            {record.type === "sample" ? "Sample" : "Bottle"}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 text-[10px] font-body text-muted-foreground">
                          <span>{record.ml}ml</span>
                          <span>{formatPrice(record.cost.toFixed(2))}</span>
                          <span>{formatPrice((record.cost / record.ml).toFixed(2))}/ml</span>
                        </div>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleEdit(record)}
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteMutation.mutate(record.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3">
      <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider px-1">تعديل المشتريات Edit Purchases</p>
      {renderPersonSection("person1")}
      {renderPersonSection("person2")}
    </div>
  );
}