import { useState, useRef } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Pencil, Trash2, Upload } from "lucide-react";
import StoreSelector from "@/components/store/StoreSelector";
import { apphost } from "@/api/apphostClient";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { useNumberEncryption } from "@/lib/useNumberEncryption";

export default function EditPurchaseDialog({ record, perfumeId, activePerson, stores, onSuccess }) {
  const [open, setOpen] = useState(false);
  const [ml, setMl] = useState(record?.ml || "");
  const [cost, setCost] = useState(record?.cost || "");
  const [date, setDate] = useState(record?.purchase_date || "");
  const [storeId, setStoreId] = useState(record?.store_id || "");
  const [type, setType] = useState(record?.type || "sample");
  const [receiptUrl, setReceiptUrl] = useState(record?.receipt_url || "");
  const [uploading, setUploading] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const qc = useQueryClient();
  const fileRef = useRef();
  const { encryptNumbers } = useNumberEncryption();

  const handleImg = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    setReceiptUrl(file_url);
    setUploading(false);
  };

  // Sync the linked ShopProduct cost when a purchase is updated/deleted
  const syncShopProduct = async (deltaAmount) => {
    const sps = await apphost.entities.ShopProduct.filter({ linked_perfume_id: perfumeId, person: activePerson === "person1" ? "person1" : "person2" });
    if (sps.length > 0) {
      const sp = sps[0];
      const newCost = Math.max(0, (sp.cost || 0) + deltaAmount);
      await apphost.entities.ShopProduct.update(sp.id, { cost: newCost });
    }
  };

  const handleSave = async () => {
    if (!ml || !cost || !date) {
      toast.error("املأ كل الحقول المطلوبة");
      return;
    }
    try {
      setIsSaving(true);
      const store = storeId ? stores.find((s) => String(s.id) === String(storeId)) : null;
      const oldCost = record.cost || 0;
      const newCost = parseFloat(cost);
      const delta = newCost - oldCost;

      const updateData = await encryptNumbers({
        ml: parseFloat(ml),
        cost: newCost,
        purchase_date: date,
        type,
        store_id: storeId || null,
        store_name: store?.name || null,
        receipt_url: receiptUrl || null,
      }, ['ml', 'cost']);
      await apphost.entities.PurchaseRecord.update(record.id, updateData);

      // Sync ShopProduct if cost changed
      if (delta !== 0) await syncShopProduct(delta);

      await qc.invalidateQueries({ queryKey: ["purchase-records", perfumeId, activePerson] });
      await qc.invalidateQueries({ queryKey: ["shop-products"] });
      toast.success("حُدّث الشراء");
      setOpen(false);
      onSuccess?.();
    } catch (error) {
      toast.error("تعذّر تحديث الشراء");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!confirm("Delete this purchase?")) return;
    try {
      setIsDeleting(true);
      const oldCost = record.cost || 0;

      await apphost.entities.PurchaseRecord.delete(record.id);

      // Sync ShopProduct cost (subtract)
      await syncShopProduct(-oldCost);

      await qc.invalidateQueries({ queryKey: ["purchase-records", perfumeId, activePerson] });
      await qc.invalidateQueries({ queryKey: ["shop-products"] });
      toast.success("حُذف الشراء");
      setOpen(false);
      onSuccess?.();
    } catch (error) {
      toast.error("تعذّر حذف الشراء");
    } finally {
      setIsDeleting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <button
        onClick={() => setOpen(true)}
        className="p-1.5 rounded-none hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
        title="Edit purchase"
      >
        <Pencil className="w-3.5 h-3.5" />
      </button>

      <DialogContent className="max-w-sm rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading">تعديل الشراء Edit Purchase</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="flex gap-2">
            <button
              onClick={() => setType("sample")}
              className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                type === "sample" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"
              }`}
            >
              Sample
            </button>
            <button
              onClick={() => setType("bottle")}
              className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                type === "bottle" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"
              }`}
            >
              Bottle
            </button>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">التاريخ Date</label>
            <Input
              type="date"
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className="rounded-none h-9 mt-1"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">ML</label>
              <Input
                type="number"
                step="0.5"
                value={ml}
                onChange={(e) => setMl(e.target.value)}
                className="rounded-none h-9 mt-1"
              />
            </div>
            <div>
              <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">التكلفة Cost</label>
              <Input
                type="number"
                step="0.1"
                value={cost}
                onChange={(e) => setCost(e.target.value)}
                className="rounded-none h-9 mt-1"
              />
            </div>
          </div>

          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">المتجر Store</label>
            <div className="mt-1">
              <StoreSelector value={storeId} onChange={setStoreId} />
            </div>
          </div>

          {/* Invoice/Receipt Upload */}
          <div>
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-widest mb-1 block">Invoice / Receipt</label>
            <div className="flex gap-2 items-center">
              <label className="flex-1 h-16 rounded-none bg-amber-50 dark:bg-amber-900/20 border-2 border-dashed border-amber-300 dark:border-amber-700 flex flex-col items-center justify-center cursor-pointer overflow-hidden">
                {uploading ? (
                  <div className="w-4 h-4 border-2 border-amber-300 border-t-amber-600 rounded-full animate-spin" />
                ) : receiptUrl ? (
                  <img src={receiptUrl} className="w-full h-full object-cover" />
                ) : (
                  <>
                    <Upload className="w-5 h-5 text-amber-500" />
                    <span className="text-[9px] text-amber-600 dark:text-amber-400 mt-1 font-body font-semibold">Invoice / PDF</span>
                  </>
                )}
                <input ref={fileRef} type="file" accept="image/*,application/pdf" className="hidden" onChange={handleImg} />
              </label>
              {receiptUrl && (
                <button onClick={() => setReceiptUrl("")} className="p-2 text-red-500 hover:bg-red-50 rounded-none">
                  <Trash2 className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          <div className="flex gap-2 pt-2">
            <Button
              className="flex-1 h-9 rounded-none font-body text-xs"
              onClick={handleSave}
              disabled={isSaving}
            >
              {isSaving ? "Saving..." : "Save"}
            </Button>
            <Button
              variant="ghost"
              className="flex-1 h-9 rounded-none font-body text-xs"
              onClick={() => setOpen(false)}
            >
              Cancel
            </Button>
          </div>

          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="w-full flex items-center justify-center gap-2 py-2 rounded-none text-xs font-body text-destructive hover:bg-destructive/10 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" /> {isDeleting ? "Deleting..." : "Delete Purchase"}
          </button>
        </div>
      </DialogContent>
    </Dialog>
  );
}