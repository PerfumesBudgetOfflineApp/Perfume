import { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export default function Pagination({ items, itemsPerPage = 50, renderItem, emptyMessage = "No items found" }) {
  const { isAr } = useLang();
  const [page, setPage] = useState(1);

  const { totalPages, paginatedItems, startIdx, endIdx } = useMemo(() => {
    const totalPages = Math.ceil(items.length / itemsPerPage);
    const startIdx = (page - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const paginatedItems = items.slice(startIdx, endIdx);
    return { totalPages, paginatedItems, startIdx, endIdx };
  }, [items, page, itemsPerPage]);

  // إذا تغيّرت القائمة (بحث/فلترة) والصفحة الحالية صارت خارج النطاق، ارجع لصفحة صحيحة
  useEffect(() => {
    if (page > totalPages && totalPages > 0) {
      setPage(1);
    }
  }, [totalPages, page]);

  if (items.length === 0) {
    return <p className="text-center text-sm text-muted-foreground py-8">{emptyMessage}</p>;
  }

  return (
    <div className="space-y-3">
      {/* Items */}
      <div>{renderItem(paginatedItems)}</div>

      {/* Pagination Controls */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between gap-2 pt-2" dir={isAr ? "rtl" : "ltr"}>
          <Button
            size="sm"
            variant="outline"
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page === 1}
            className="h-8 w-9 p-0"
            aria-label={isAr ? "السابق" : "Previous"}
          >
            {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </Button>

          <span className="text-xs text-muted-foreground font-body">
            {isAr ? `صفحة ${page} من ${totalPages}` : `Page ${page} of ${totalPages}`}
          </span>

          <Button
            size="sm"
            variant="outline"
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page === totalPages}
            className="h-8 w-9 p-0"
            aria-label={isAr ? "التالي" : "Next"}
          >
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </Button>
        </div>
      )}
    </div>
  );
}