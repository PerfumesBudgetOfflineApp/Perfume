/**
 * AppLogo — the Perfume / بيرفيوم app mark (option 4: classic atomizer).
 * Outline only, transparent background. Monochrome via `currentColor`, so the
 * parent controls the color (set `style={{ color: "var(--brand)" }}` to follow
 * the theme). Used in the page headers and as the app icon (public/logo.svg).
 */
export default function AppLogo({ className, style }) {
  return (
    <svg
      className={className}
      style={style}
      viewBox="0 0 64 64"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.8"
      strokeLinejoin="round"
      strokeLinecap="round"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="Perfume"
      role="img"
    >
      {/* bottle body */}
      <rect x="20" y="30" width="22" height="26" rx="4" />
      {/* shoulders */}
      <path d="M25 30l1.5-7h9l1.5 7" />
      {/* collar / cap */}
      <rect x="27.5" y="17" width="7" height="6" rx="1.5" />
      {/* tube to squeeze bulb */}
      <path d="M34.5 20h6.5a3 3 0 0 1 3 3v2.5" />
      {/* squeeze bulb */}
      <circle cx="47" cy="29" r="4.5" />
      {/* spray from the cap */}
      <circle cx="31" cy="11" r="1.8" fill="currentColor" stroke="none" />
      <circle cx="35.5" cy="8.5" r="1.3" fill="currentColor" stroke="none" />
      <circle cx="26.5" cy="9" r="1.3" fill="currentColor" stroke="none" />
    </svg>
  );
}
