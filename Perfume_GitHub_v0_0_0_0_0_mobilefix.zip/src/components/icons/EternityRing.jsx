/**
 * EternityRing — خاتم أبدية ذهبي مرصّع بالألماس، بوضعية مرفوعة مواجِهة للناظر.
 * خاصية tilt (بالدرجات): تميل الخاتم نحو الاسم — موجب = يمين (للعربي)،
 * سالب = يسار (للإنجليزي). خلفية شفافة.
 */
const GOLD = "var(--brand)";
const GOLD_HI = "#E6C766";
const GOLD_SH = "#9A7B1E";

export default function EternityRing({ className = "", style, tilt = 0 }) {
  const cx = 50, cy = 48, rx = 36, ry = 40, N = 24;
  const diamonds = [];
  for (let i = 0; i < N; i++) {
    const a = (i / N) * 2 * Math.PI;
    const dx = +(cx + rx * Math.cos(a)).toFixed(1);
    const dy = +(cy + ry * Math.sin(a)).toFixed(1);
    diamonds.push(
      <g key={i}>
        <circle cx={dx} cy={dy} r="2.5" fill="#ffffff" stroke="#c9d4e0" strokeWidth="0.4" />
        <circle cx={dx - 0.6} cy={dy - 0.7} r="0.75" fill="#ffffff" />
      </g>
    );
  }
  return (
    <svg viewBox="2 2 96 92" className={className} style={style} fill="none" preserveAspectRatio="xMidYMid meet" aria-hidden="true">
      <g transform={`rotate(${tilt} ${cx} ${cy})`}>
        <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="none" stroke={GOLD} strokeWidth="7" />
        <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill="none" stroke={GOLD_HI} strokeWidth="2" opacity="0.85" />
        <ellipse cx={cx - 3} cy={cy - 2} rx={rx} ry={ry} fill="none" stroke={GOLD_SH} strokeWidth="0.6" opacity="0.45" />
        {diamonds}
      </g>
    </svg>
  );
}
