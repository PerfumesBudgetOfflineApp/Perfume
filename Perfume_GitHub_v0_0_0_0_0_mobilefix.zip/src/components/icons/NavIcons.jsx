/**
 * NavIcons — solid (filled) bottom-nav icons for the traditional interface.
 * Monochrome: every icon uses fill="currentColor", so the nav controls the
 * color (active = brand green, inactive = muted gray).
 * viewBox 0 0 24 24. Set 2 "Solid" — chosen design.
 */

const base = (className) => ({
  className,
  viewBox: "0 0 24 24",
  fill: "currentColor",
  xmlns: "http://www.w3.org/2000/svg",
  "aria-hidden": "true",
});

// نشاطات — Activities (نبض/تغذية)
export function ActivitiesIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M3 14a1 1 0 0 1 0-2h2.3l2.2-7.3a1 1 0 0 1 1.93.06l2.4 11.2 1.3-5.9a1 1 0 0 1 1.86-.2L18 12h3a1 1 0 1 1 0 2h-3.6a1 1 0 0 1-.9-.55l-.7-1.4-1.45 6.6a1 1 0 0 1-1.96-.05L9.9 8.2 8.5 13.3a1 1 0 0 1-.96.7z" />
    </svg>
  );
}

// رئيسية — perfume flacon
export function FlaconIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M9.5 2h5a1 1 0 0 1 1 1v2.6l1.4 2.1A5 5 0 0 1 17.7 11v7a3 3 0 0 1-3 3h-5.4a3 3 0 0 1-3-3v-7a5 5 0 0 1 .8-2.7L8.5 5.6V3a1 1 0 0 1 1-1zm-.5 9.5a1 1 0 1 0 0 2h6a1 1 0 1 0 0-2z" />
    </svg>
  );
}

// اكتشف — Explore (عدسة)
export function ExploreIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M11 4a7 7 0 1 0 4.2 12.6l3.1 3.1a1.2 1.2 0 0 0 1.7-1.7l-3.1-3.1A7 7 0 0 0 11 4zm0 3a4 4 0 1 1 0 8 4 4 0 0 1 0-8z" />
    </svg>
  );
}

// متاجر — Stores (واجهة محل)
export function StoresIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M5 4h14l1.4 4.2A2.5 2.5 0 0 1 18 11a2.5 2.5 0 0 1-2-1 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4 0 2.5 2.5 0 0 1-4.4-1.8zM5.5 12a3.8 3.8 0 0 0 1.5-.3V19a1 1 0 0 0 1 1h2v-4h4v4h2a1 1 0 0 0 1-1v-7.3a3.8 3.8 0 0 0 1.5.3z" />
    </svg>
  );
}

// إحصائيات — Statistics (أعمدة)
export function StatsIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M4 11h3a1 1 0 0 1 1 1v7a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1v-7a1 1 0 0 1 1-1zm6.5-6h3a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zM17 9h3a1 1 0 0 1 1 1v9a1 1 0 0 1-1 1h-3a1 1 0 0 1-1-1v-9a1 1 0 0 1 1-1z" />
    </svg>
  );
}

// أهداف — Goals (هدف)
export function GoalsIcon({ className }) {
  return (
    <svg {...base(className)}>
      <path d="M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18zm0 5a4 4 0 1 1 0 8 4 4 0 0 1 0-8zm0 2.5a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3z" />
    </svg>
  );
}
