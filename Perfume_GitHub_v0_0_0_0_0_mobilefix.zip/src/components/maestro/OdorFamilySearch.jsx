import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

export default function OdorFamilySearch({ value, onChange, placeholder = "ابحث عن العائلة العطرية..." }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);

  // Fetch all notes to extract odor families
  const { data: allNotes = [] } = useQuery({
    queryKey: ["notes-for-odor-families"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 10,
  });

  // Extract unique odor families
  const odorFamilies = useMemo(() => {
    const families = new Set();
    allNotes.forEach(note => {
      if (note.odor_family) {
        families.add(note.odor_family.trim());
      }
    });
    return Array.from(families).sort();
  }, [allNotes]);

  const selectedFamilies = value ? value.split(",").map(s => s.trim()).filter(Boolean) : [];

  const filtered = useMemo(() => {
    if (!search.trim()) return odorFamilies;
    return odorFamilies.filter(f => f.toLowerCase().includes(search.toLowerCase()) && !selectedFamilies.includes(f));
  }, [search, odorFamilies, selectedFamilies]);

  const handleAdd = (family) => {
    const newList = [...selectedFamilies, family];
    onChange(newList.join(", "));
    setSearch("");
    setOpen(false);
  };

  const handleRemove = (family) => {
    const newList = selectedFamilies.filter(f => f !== family);
    onChange(newList.length > 0 ? newList.join(", ") : "");
  };

  return (
    <div className="space-y-2 relative">
      <div className="min-h-[44px] rounded-none border border-input bg-transparent px-3 py-2 flex flex-wrap gap-1 items-center cursor-text"
        onClick={() => document.getElementById("odor-family-search")?.focus()}>
        {selectedFamilies.map(family => (
          <span key={family} className="inline-flex items-center gap-1 text-amber-700 dark:text-amber-400 text-xs rounded-none">
            {family}
            <button type="button" onClick={() => handleRemove(family)}><X className="w-3 h-3" /></button>
          </span>
        ))}
        <input
          id="odor-family-search"
          type="text"
          value={search}
          onChange={(e) => { setSearch(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          placeholder={selectedFamilies.length === 0 ? placeholder : ""}
          className="flex-1 min-w-[80px] bg-transparent outline-none text-sm font-body placeholder:text-muted-foreground"
        />
      </div>
      {open && filtered.length > 0 && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-50 max-h-52 overflow-y-auto">
          {filtered.map(family => (
            <button
              key={family}
              type="button"
              onMouseDown={() => handleAdd(family)}
              className="w-full text-left px-3 py-2.5 hover:bg-secondary text-xs font-body border-b border-border/30 last:border-b-0"
            >
              {family}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}