import { useState, useMemo } from "react";
import { X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

/**
 * Search sub_notes + low_notes from DB and add as tags.
 * Works for both Perfume and Brand contexts.
 */
export default function InnovationNotesSearch({ value, onChange, edit, setEdit, perfumeId, allNotes: propNotes, lowNotes: propLow }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);

  // Fetch from DB if not passed as props
  const { data: dbSubNotes = [] } = useQuery({
    queryKey: ["notes-sub"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "sub_notes" }, "name", 500),
    staleTime: 1000 * 60 * 5,
    enabled: !propNotes || propNotes.length === 0,
  });

  const { data: dbLowNotes = [] } = useQuery({
    queryKey: ["notes-low"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "low_notes" }, "name", 500),
    staleTime: 1000 * 60 * 5,
    enabled: !propLow || propLow.length === 0,
  });

  const combinedNotes = useMemo(() => {
    const sub = (propNotes && propNotes.length > 0) ? propNotes : dbSubNotes;
    const low = (propLow && propLow.length > 0) ? propLow : dbLowNotes;
    return [...sub, ...low];
  }, [propNotes, propLow, dbSubNotes, dbLowNotes]);

  // Support both usage patterns: direct value/onChange OR edit/setEdit
  const currentValue = value !== undefined ? value : (edit?.innovation_notes || "");
  const handleChange = (newVal) => {
    if (onChange) onChange(newVal);
    else if (setEdit) setEdit(perfumeId, "innovation_notes", newVal);
  };

  const selectedNotes = currentValue.split(",").map(s => s.trim()).filter(Boolean);

  const filtered = useMemo(() => {
    if (!search) return combinedNotes;
    return combinedNotes.filter(n => n.name?.toLowerCase().includes(search.toLowerCase()));
  }, [search, combinedNotes]);

  const handleSelect = (noteName) => {
    const trimmed = noteName.trim();
    if (!selectedNotes.includes(trimmed)) {
      handleChange([...selectedNotes, trimmed].join(","));
    }
    setSearch("");
    setOpen(false);
  };

  const removeNote = (noteName) => {
    handleChange(selectedNotes.filter(n => n.trim() !== noteName.trim()).join(","));
  };

  return (
    <div className="space-y-2">
      {/* Tags display */}
      {selectedNotes.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {selectedNotes.map(note => (
            <span key={note} className="inline-flex items-center gap-1 text-foreground text-xs rounded-none">
              {note}
              <button type="button" onClick={() => removeNote(note)}><X className="w-3 h-3" /></button>
            </span>
          ))}
        </div>
      )}
      {/* Search input */}
      <div className="relative">
        <input
          type="text"
          placeholder="ابحث عن نوتة إضافية..."
          value={search}
          onChange={(e) => { setSearch(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => setTimeout(() => setOpen(false), 150)}
          className="w-full h-9 rounded-none border border-input bg-transparent px-3 text-sm font-body placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        />
        {open && filtered.length > 0 && (
          <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-48 overflow-y-auto">
            {filtered.map(note => {
              const isSelected = selectedNotes.includes(note.name);
              return (
                <button
                  key={note.id}
                  type="button"
                  onMouseDown={() => handleSelect(note.name)}
                  className={`w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary border-b border-border/30 last:border-b-0 transition-colors ${isSelected ? "bg-primary/10 text-primary font-semibold" : ""}`}
                >
                  {note.name}
                  {note.note_category && <span className="text-[10px] text-muted-foreground ml-2">{note.note_category === "sub_notes" ? "Sub" : "Low"}</span>}
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}