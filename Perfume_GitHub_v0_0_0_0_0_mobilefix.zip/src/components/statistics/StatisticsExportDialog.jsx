import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, openHtmlReport } from "@/lib/exportHelper";

// خطوط جديدة جذرياً: رفيع أنيق رسمي — لا «أميري/القاهرة» المعتادة.
// استُخدمت عائلات نظام عامّة (Garamond/Georgia/Tahoma) المتوفّرة على WebView/PDF
// لضمان رسم نصّ حقيقي لا صورة، مع fallback عربي لائق.
const FONT_STACK = {
  elegant: "'EB Garamond', Garamond, 'Cormorant Garamond', Georgia, 'Tahoma', serif",
  classic: "Georgia, 'Times New Roman', 'Tahoma', serif",
  modern:  "system-ui, -apple-system, 'Segoe UI', 'Tahoma', sans-serif",
};

/**
 * StatisticsExportDialog — exports the household dashboard as a brief image or
 * full PDF, with the same options used elsewhere (language, font, direction,
 * toggles, image, intro). Receives a pre-computed `stats` object so it stays
 * in sync with what's shown on screen.
 */
export default function StatisticsExportDialog({ open, onOpenChange, stats, scopeLabel, isAr, fmt, appName = "Process" }) {
  const [generating, setGenerating] = useState(false);
  const [reportLang, setReportLang] = useState("both");
  const [fontChoice, setFontChoice] = useState("elegant");
  const [dirChoice, setDirChoice] = useState("auto");
  const [depth, setDepth] = useState("full");
  const [showDate, setShowDate] = useState(true);
  const [showAppName, setShowAppName] = useState(true);
  const [autoIntro, setAutoIntro] = useState(true);
  const [introText, setIntroText] = useState("");
  const [reportImage, setReportImage] = useState(null);
  const [imagePosition, setImagePosition] = useState("end");
  const [scopeName, setScopeName] = useState(scopeLabel);

  const rLangAr = reportLang === "ar" || reportLang === "both";
  const rLangEn = reportLang === "en" || reportLang === "both";
  const reportDir = dirChoice === "auto" ? (rLangAr ? "rtl" : "ltr") : dirChoice;
  const reportFont = FONT_STACK[fontChoice] || FONT_STACK.elegant;

  const autoIntroText = (ar) => {
    const healthy = stats.netMonthly >= 0;
    if (ar) {
      return `يستعرض هذا التقرير الوضع المالي والعطري لـ"${scopeLabel}". الوضع المالي ${healthy ? "مستقر بفائض شهري" : "بحاجة لمتابعة بعجز شهري"} يقارب ${fmt(Math.abs(stats.netMonthly))}. تضم المجموعة ${stats.ownedPerfumes} عطراً، وبلغ إجمالي الإنفاق ${fmt(stats.totalSpent)}.`;
    }
    return `This report covers the financial and fragrance status for "${scopeLabel}". The financial position is ${healthy ? "stable with a monthly surplus" : "in need of attention with a monthly deficit"} of about ${fmt(Math.abs(stats.netMonthly))}. The collection holds ${stats.ownedPerfumes} perfumes, with total spending of ${fmt(stats.totalSpent)}.`;
  };

  const buildHTML = () => {
    const titleAr = "تقرير الأسرة";
    const titleEn = "Household Report";
    const title = reportLang === "both" ? `${titleAr} ${titleEn}` : (rLangAr ? titleAr : titleEn);
    const imgTag = reportImage ? `<div style="text-align:center; margin:24px 0;"><img src="${reportImage}" style="max-width:100%; max-height:340px; border-radius:10px;" /></div>` : "";
    const introParts = [];
    if (autoIntro) { if (rLangAr) introParts.push(autoIntroText(true)); if (rLangEn) introParts.push(autoIntroText(false)); }
    if (introText.trim()) introParts.push(introText.trim());
    const introBlock = introParts.length
      ? `<div style="background:#f5f3ff; border-${reportDir === "rtl" ? "right" : "left"}:4px solid #7c3aed; border-radius:8px; padding:16px 18px; margin-bottom:24px; line-height:1.9; color:#333; font-size:14px;" dir="${reportDir}">${introParts.map((p) => `<p style="margin:0 0 8px 0;">${p}</p>`).join("")}</div>`
      : "";

    const card = (label, value, color) => `
      <div style="background:#fff; border:2px solid ${color}; border-radius:8px; padding:14px; text-align:center;">
        <p style="color:${color}; font-size:12px; margin:0 0 6px;">${label}</p>
        <p style="color:${color}; font-size:22px; font-weight:bold; margin:0;">${value}</p>
      </div>`;

    const moneyCards = `
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:12px; margin-bottom:20px;" dir="${reportDir}">
        ${card(rLangAr ? "الدخل" : "Income", fmt(stats.monthlyIncome), "#059669")}
        ${card(rLangAr ? "المصاريف" : "Expenses", fmt(stats.monthlyExpense), "#dc2626")}
        ${card(rLangAr ? "الالتزامات" : "Obligations", fmt(stats.monthlyObligations), "#d97706")}
        ${card(rLangAr ? "الصافي" : "Net", fmt(stats.netMonthly), "#1d4ed8")}
      </div>`;

    const perfumeCards = `
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:12px; margin-bottom:20px;" dir="${reportDir}">
        ${card(rLangAr ? "العطور" : "Perfumes", stats.ownedPerfumes, "#7c3aed")}
        ${card(rLangAr ? "الإنفاق الكلي" : "Total spent", fmt(stats.totalSpent), "#0891b2")}
        ${card(rLangAr ? "الارتداءات" : "Wears", stats.totalWears, "#0d9488")}
        ${card(rLangAr ? "المشتريات" : "Purchases", stats.totalPurchases, "#c026d3")}
      </div>`;

    const forecastBlock = depth === "full" ? `
      <div style="background:#f8f8f8; border-radius:8px; padding:18px; margin-bottom:18px;" dir="${reportDir}">
        <h3 style="color:#7c3aed; margin-top:0;">${rLangAr ? "التوقعات المستقبلية" : "Forecast"}</h3>
        <table style="width:100%; border-collapse:collapse; font-size:14px;">
          <tr style="border-bottom:1px solid #ddd;"><td style="padding:8px; color:#666;">${rLangAr ? "متوقع خلال 6 أشهر" : "Over 6 months"}</td><td style="padding:8px; text-align:${reportDir === "rtl" ? "left" : "right"}; font-weight:bold;">${fmt(stats.netMonthly * 6)}</td></tr>
          <tr><td style="padding:8px; color:#666;">${rLangAr ? "متوقع خلال سنة" : "Over a year"}</td><td style="padding:8px; text-align:${reportDir === "rtl" ? "left" : "right"}; font-weight:bold;">${fmt(stats.yearProjection)}</td></tr>
        </table>
      </div>` : "";

    const savingsBlock = (depth === "full" && (stats.totalSavingsTarget > 0 || stats.totalSaved > 0)) ? `
      <div style="background:#ecfdf5; border-radius:8px; padding:18px; margin-bottom:18px;" dir="${reportDir}">
        <h3 style="color:#059669; margin-top:0;">${rLangAr ? "الادخار" : "Savings"}</h3>
        <p style="margin:4px 0;">${rLangAr ? "المُدخر" : "Saved"}: <b>${fmt(stats.totalSaved)}</b> / ${rLangAr ? "المستهدف" : "Target"}: <b>${fmt(stats.totalSavingsTarget)}</b></p>
      </div>` : "";

    return `
      <div style="text-align:${reportDir === "rtl" ? "right" : "center"}; margin-bottom:8px;" dir="${reportDir}">
        <h1 style="color:#7c3aed; font-size:30px; margin:0 0 6px 0;">${title}</h1>
        <p style="color:#888; font-size:13px; margin:0;">${showDate ? (rLangAr ? new Date().toLocaleDateString("ar-SA") : new Date().toLocaleDateString()) : ""}</p>
      </div>
      ${imagePosition === "start" ? imgTag : ""}
      ${introBlock}
      <h3 style="color:#1d4ed8;" dir="${reportDir}">${rLangAr ? "الميزانية الشهرية" : "Monthly Budget"}</h3>
      ${moneyCards}
      <h3 style="color:#7c3aed;" dir="${reportDir}">${rLangAr ? "العطور" : "Perfumes"}</h3>
      ${perfumeCards}
      ${forecastBlock}
      ${savingsBlock}
      ${imagePosition === "end" ? imgTag : ""}
      <div style="text-align:${reportDir === "rtl" ? "right" : "center"}; margin-top:28px; padding-top:16px; border-top:2px solid #eee;" dir="${reportDir}">
        <p style="color:#666; font-size:13px; margin:0 0 2px; font-weight:bold;">${[rLangAr ? "تقرير مُصدَّر" : null, rLangEn ? "Exported report" : null].filter(Boolean).join(" ")}</p>
        <p style="color:#444; font-size:14px; margin:0 0 8px;">${scopeName}</p>
        ${showAppName && appName ? `<p style="color:#888; font-size:12px; margin:0;">${rLangAr ? "من تطبيق" : "From"} ${appName}</p>` : ""}
      </div>`;
  };

  const exportImage = async () => {
    setGenerating(true);
    try {
      const div = document.createElement("div");
      div.style.cssText = `position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none; width:1000px; padding:40px; background:#fff; direction:${reportDir}; font-family:${reportFont}; text-align:${reportDir === "rtl" ? "right" : "left"};`;
      div.innerHTML = buildHTML();
      document.body.appendChild(div);
      const canvas = await captureElement(div, { scale: 2, backgroundColor: "#ffffff" });
      document.body.removeChild(div);
      await saveCanvasAsImage(canvas, `household_report_${new Date().toISOString().slice(0, 10)}.png`);
    } catch (e) { console.error("Stats image export failed", e); }
    setGenerating(false);
    onOpenChange(false);
  };

  const exportPDF = async () => {
    setGenerating(true);
    try {
      const titleAr = "تقرير الأسرة";
      const titleEn = "Household Report";
      const fullTitle = reportLang === "both" ? `${titleAr} ${titleEn}` : (rLangAr ? titleAr : titleEn);
      // تراكب قابل للحفظ/الطباعة — يعمل على الجوال (APK) والويب، بدل window.open المعطّل في WebView.
      const html = `<!DOCTYPE html><html dir="${reportDir}"><head><meta charset="utf-8" />
        <title>${fullTitle}</title>
        <style>
          @page{margin:14mm;}
          body{font-family:${reportFont}; padding:32px; margin:0; color:#1c1917;}
          h1, h2, h3 { font-family:${reportFont}; font-weight:600; }
          table { font-family:${reportFont}; }
          p, td, th, div, span { font-family:${reportFont}; }
        </style>
        </head><body>${buildHTML()}</body></html>`;
      await openHtmlReport(html, `household_report_${new Date().toISOString().slice(0, 10)}`);
    } catch (e) { console.error("Stats PDF export failed", e); }
    setGenerating(false);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-[calc(100vw-2rem)] max-h-[90vh] overflow-y-auto rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">{isAr ? "📊 تصدير تقرير الأسرة" : "📊 Export Household Report"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => setDepth("brief")} className={` rounded-none text-xs font-body flex flex-col items-center gap-0.5 ${depth === "brief" ? " text-primary-foreground" : " text-muted-foreground"}`}>
              <span>🖼️ {isAr ? "مختصر" : "Brief"}</span><span className="text-[9px] opacity-80">{isAr ? "صورة" : "Image"}</span>
            </button>
            <button onClick={() => setDepth("full")} className={` rounded-none text-xs font-body flex flex-col items-center gap-0.5 ${depth === "full" ? " text-primary-foreground" : " text-muted-foreground"}`}>
              <span>📄 {isAr ? "مطوّل" : "Full"}</span><span className="text-[9px] opacity-80">PDF</span>
            </button>
          </div>

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "اللغة" : "Language"}</p>
            <div className="flex gap-1.5">
              {[{ v: "ar", l: "عربي" }, { v: "en", l: "English" }, { v: "both", l: isAr ? "اللغتين" : "Both" }].map((o) => (
                <button key={o.v} onClick={() => setReportLang(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${reportLang === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "الخط" : "Font"}</p>
            <div className="flex gap-1.5 flex-wrap">
              {[{ v: "elegant", l: isAr ? "أنيق" : "Elegant" }, { v: "classic", l: isAr ? "كلاسيكي" : "Classic" }, { v: "modern", l: isAr ? "حديث" : "Modern" }].map((o) => (
                <button key={o.v} onClick={() => setFontChoice(o.v)} className={` rounded-none text-xs font-body ${fontChoice === o.v ? " text-primary-foreground " : " text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "الاتجاه" : "Direction"}</p>
            <div className="flex gap-1.5">
              {[{ v: "rtl", l: "RTL" }, { v: "ltr", l: "LTR" }, { v: "auto", l: isAr ? "تلقائي" : "Auto" }].map((o) => (
                <button key={o.v} onClick={() => setDirChoice(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${dirChoice === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            {[
              { v: showDate, set: setShowDate, l: isAr ? "تاريخ التصدير" : "Date" },
              { v: showAppName, set: setShowAppName, l: isAr ? "اسم التطبيق" : "App name" },
              { v: autoIntro, set: setAutoIntro, l: isAr ? "مقدمة تلقائية" : "Auto intro" },
            ].map((o, i) => (
              <label key={i} className="flex items-center gap-2 cursor-pointer text-xs font-body">
                <Checkbox checked={o.v} onCheckedChange={() => o.set(!o.v)} /><span>{o.l}</span>
              </label>
            ))}
          </div>

          <textarea value={introText} onChange={(e) => setIntroText(e.target.value)} placeholder={isAr ? "نص مقدمة إضافي (اختياري)" : "Extra intro (optional)"} dir={reportDir} className="w-full rounded-none text-xs font-body resize-none min-h-[54px]" />

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "صورة مرفقة (اختياري)" : "Attached image (optional)"}</p>
            <div className="flex items-center gap-2">
              <input type="file" accept="image/*" onChange={(e) => { const file = e.target.files?.[0]; if (!file) return; const r = new FileReader(); r.onload = (ev) => setReportImage(ev.target.result); r.readAsDataURL(file); }} className="text-xs font-body flex-1" />
              {reportImage && <button onClick={() => setReportImage(null)} className="text-xs text-destructive font-body">{isAr ? "إزالة" : "Remove"}</button>}
            </div>
            {reportImage && (
              <div className="flex gap-1.5 mt-1">
                {[{ v: "start", l: isAr ? "البداية" : "Start" }, { v: "end", l: isAr ? "النهاية" : "End" }].map((o) => (
                  <button key={o.v} onClick={() => setImagePosition(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${imagePosition === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
                ))}
              </div>
            )}
          </div>

          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "اسم النطاق (يظهر أسفل التقرير)" : "Scope name (shown at the bottom)"}</p>
            <input value={scopeName} onChange={(e) => setScopeName(e.target.value)} placeholder={scopeLabel} dir="auto" className="w-full rounded-none text-xs font-body" />
          </div>

          <Button className="w-full h-10 rounded-none font-body" onClick={() => (depth === "full" ? exportPDF() : exportImage())} disabled={generating}>
            {generating ? (isAr ? "جارٍ..." : "Generating...") : (depth === "full" ? (isAr ? "تصدير PDF" : "Export PDF") : (isAr ? "تصدير صورة" : "Export Image"))}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
