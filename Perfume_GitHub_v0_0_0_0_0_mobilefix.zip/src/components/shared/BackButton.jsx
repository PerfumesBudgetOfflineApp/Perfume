import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * BackButton — زر رجوع موحّد للصفحات الفرعية.
 * يرجع للصفحة السابقة (navigate(-1))، وإن لم يوجد سجلّ تنقّل يذهب لـ`fallback`.
 */
export default function BackButton({ fallback = "/", className = "" }) {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const goBack = () => {
    if (typeof window !== "undefined" && window.history.length > 1) navigate(-1);
    else navigate(fallback);
  };
  return (
    <button
      type="button"
      onClick={goBack}
      title={isAr ? "رجوع" : "Back"}
      aria-label={isAr ? "رجوع" : "Back"}
      className={`w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors shrink-0 ${className}`}
    >
      <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
    </button>
  );
}
