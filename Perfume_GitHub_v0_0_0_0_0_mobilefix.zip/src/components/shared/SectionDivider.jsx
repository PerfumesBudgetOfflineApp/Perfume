/**
 * SectionDivider — فاصل ذهبي رفيع بين الأقسام داخل صفحات الميزانية/التقدّم/الأهداف/التسوّق.
 * يحفظ هوية التطبيق البصرية ويُبسّط القراءة دون استخدام إطارات كاملة حول كل قسم.
 */
export default function SectionDivider({ className = "" }) {
  return (
    <div
      aria-hidden="true"
      className={`h-px my-5 ${className}`}
      style={{ background: "rgba(200, 160, 46, 0.4)" }}
    />
  );
}
