import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Copy, Check, ChevronLeft, ChevronRight, Download } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { displayTag, isArabic } from "@/lib/atMentions";

// Tags may arrive as a comma string OR (in some seeded stories) an array,
// and very rarely as a number. Coerce anything to a comma string so .split()
// never throws on a non-string value.
const toTagStr = (t) => {
  if (Array.isArray(t)) return t.join(", ");
  if (typeof t === "string") return t;
  return t == null ? "" : String(t);
};

// عنوان القصة للتنقل: يتفادى القيم الفارغة/nan ويختصر للعرض المضغوط
function storyTitle(s, isAr) {
  const pick = isAr ? (s?.term_ar || s?.term_en) : (s?.term_en || s?.term_ar);
  const t = String(pick ?? "").trim();
  if (!t || t.toLowerCase() === "nan" || t.toLowerCase() === "null" || t === "undefined") return "";
  return t.length > 24 ? t.slice(0, 24) + "…" : t;
}

/**
 * StoryFooter — sits at the very bottom of a story, giving the reader:
 *   1. Copy buttons: Arabic only / English only / both languages
 *   2. The notebook (bookmark) button, mirrored from the top of the page
 *   3. Previous / Next story navigation, so stories can be read in sequence
 *
 * The meaning text is stored as:  English ... \n\n---\n\n النسخة العربية ...
 * so we split on the first standalone "---" to separate the two languages.
 */

function splitMeaning(meaning = "") {
  // The unified story structure is:
  //   [title]\n\n---\n\nEnglish Version 🇬🇧\n\n[EN body]\n\n---\n\nالنسخة العربية 🇸🇦\n\n[AR body]\n\n---\n\n[footer]
  // Split on the language LABELS (not on the first --- divider, which would
  // wrongly lump the EN+AR bodies together).
  const enLabel = /English Version[^\n]*\n+/i;
  const arLabel = /النسخة العربية[^\n]*\n+/;

  const arLabelMatch = meaning.match(arLabel);
  if (arLabelMatch) {
    const arStart = arLabelMatch.index + arLabelMatch[0].length;
    // Everything from the AR label onward is the Arabic body (trim trailing footer/---).
    let arBody = meaning.slice(arStart);
    // Everything before the AR label is title + EN section.
    let beforeAr = meaning.slice(0, arLabelMatch.index);
    const enMatch = beforeAr.match(enLabel);
    let enBody = enMatch ? beforeAr.slice(enMatch.index + enMatch[0].length) : beforeAr;

    const clean = (t) => t
      .replace(/\n\s*---\s*\n\s*\*[^]*$/m, "")   // drop trailing footer block after last ---
      .replace(/\n\s*---\s*\n?\s*$/m, "")          // drop a dangling trailing ---
      .trim();
    return { en: clean(enBody), ar: clean(arBody) };
  }

  // Fallback (old/unlabeled entries): split on the first standalone --- divider.
  const parts = meaning.split(/\n\s*---\s*\n/);
  if (parts.length >= 2) {
    const en = parts[0].trim();
    const ar = parts.slice(1).join("\n\n---\n\n").trim();
    return { en, ar };
  }
  return { en: meaning.trim(), ar: "" };
}

export default function StoryFooter({ term, stories = [], bookmark, onExportPdf, onExportImg, showActions = true, showNav = true, tags = "", topBorder = true }) {
  const navigate = useNavigate();  const { isAr } = useLang();
  const [copied, setCopied] = useState("");
  const tagsStr = toTagStr(tags);

  // اللون مرتبط بنوع الصفحة: amber للقصص، emerald للمصطلحات.
  // كل الـclasses موجودة في الكود فلا مخاوف من Tailwind purge.
  // كل عناصر التذييل بلون الخطّ الذهبي (primary) — بلا إطار ولا خلفية.
  const accentText = "text-primary hover:opacity-70";
  const accentTextSolid = "text-primary";
  const accentBorder = "border-[#C8A02E]/30";

  // Prefer the dedicated EN / AR fields. Fall back to splitting a legacy
  // combined `meaning` (older entries that folded both languages together).
  let en = term?.meaning || "";
  let ar = term?.meaning_ar || "";
  if (!ar && /[\u0600-\u06FF]/.test(en)) {
    const s = splitMeaning(en);
    en = s.en;
    ar = s.ar;
  }

  const doCopy = async (which) => {
    let text = "";
    if (which === "ar") {
      // العنوان بالعربية ثم النص العربي
      const t = (term?.term_ar || term?.term_en || "").trim();
      text = [t, ar].filter(Boolean).join("\n\n");
    } else if (which === "en") {
      // English title then English body
      const t = (term?.term_en || term?.term_ar || "").trim();
      text = [t, en].filter(Boolean).join("\n\n");
    } else {
      // "All": title(s), both languages, tags.
      const titleLine = [term?.term_en, term?.term_ar].filter(Boolean).join(" ");
      const tags = toTagStr(term?.tags).split(",").map((t) => t.trim()).filter(Boolean);
      const tagLine = tags.length ? `\n\n${tags.map((t) => `@${t}`).join("  ")}` : "";
      const both = [en, ar].filter(Boolean).join("\n\n———\n\n");
      text = `${titleLine ? titleLine + "\n\n" : ""}${both}${tagLine}`.trim();
    }
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      setTimeout(() => setCopied(""), 1500);
    } catch {
      /* clipboard unavailable; ignore */
    }
  };

  // Find current index among stories to compute prev / next.
  const idx = stories.findIndex((s) => String(s.id) === String(term?.id));
  const prev = idx > 0 ? stories[idx - 1] : null;
  const next = idx >= 0 && idx < stories.length - 1 ? stories[idx + 1] : null;

  // زر شفاف بلا إطار ولا خلفية — فقط لون، للراحة البصرية
  const CopyBtn = ({ which, label }) => (
    <button
      type="button"
      onClick={() => doCopy(which)}
      className={`flex items-center justify-center gap-1.5 px-2 py-1.5 bg-transparent text-xs font-body transition-colors ${accentText}`}
    >
      {copied === which ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      {label}
    </button>
  );

  const PdfBtn = ({ lang, label }) => (
    <button
      type="button"
      onClick={() => onExportPdf?.(lang)}
      className={`flex items-center justify-center gap-1.5 px-2 py-1.5 bg-transparent text-xs font-body transition-colors ${accentText}`}
    >
      <Download className="w-3.5 h-3.5" /> {label}
    </button>
  );

  return (
    <div className={`pt-6 mt-4 ${topBorder ? `border-t ${accentBorder}` : ""} space-y-5`}>
      {/* نسخ + PDF — أزرار شفافة بلا إطار/خلفية، فقط لون */}
      {showActions && (
      <div className="space-y-2">
        <div className="flex flex-wrap items-center justify-center gap-1">
          {ar && <CopyBtn which="ar" label="نسخ عربي Copy AR" />}
          {en && <CopyBtn which="en" label="نسخ إنجليزي Copy EN" />}
          <CopyBtn which="both" label="نسخ الكل Copy All" />
        </div>
        {onExportPdf && (
          <div className="flex flex-wrap items-center justify-center gap-1">
            {en && <PdfBtn lang="en" label="PDF EN" />}
            {ar && <PdfBtn lang="ar" label="PDF AR" />}
            <PdfBtn lang="both" label="PDF" />
          </div>
        )}
        {onExportImg && (
          <div className="flex flex-wrap items-center justify-center gap-1">
            {ar && <button type="button" onClick={() => onExportImg("ar")} className={`flex items-center justify-center gap-1.5 px-2 py-1.5 bg-transparent text-xs font-body transition-colors ${accentText}`}><Download className="w-3.5 h-3.5" /> IMG AR</button>}
            {en && <button type="button" onClick={() => onExportImg("en")} className={`flex items-center justify-center gap-1.5 px-2 py-1.5 bg-transparent text-xs font-body transition-colors ${accentText}`}><Download className="w-3.5 h-3.5" /> IMG EN</button>}
            <button type="button" onClick={() => onExportImg("both")} className={`flex items-center justify-center gap-1.5 px-2 py-1.5 bg-transparent text-xs font-body transition-colors ${accentText}`}><Download className="w-3.5 h-3.5" /> IMG AR EN</button>
          </div>
        )}
      </div>
      )}

      {/* الهاشتاقات — فوق التنقّل، بلا إطار وبلا خلفية، فقط بلون الصفحة.
          كلّ هاشتاق رابط إلى /at?name=X لاستعراض كلّ ما يرتبط به. */}
      {tagsStr && (() => {
        // Dedupe case-insensitively. Pre-292 seed data shipped some glossary
        // entries with duplicate tags (e.g. "music, ..., music") which broke
        // React's unique-key contract when rendered as <span key={tag}>.
        const seen = new Set();
        const tagItems = tagsStr
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean)
          .filter((t) => {
            const k = t.toLowerCase();
            if (seen.has(k)) return false;
            seen.add(k);
            return true;
          });
        if (tagItems.length === 0) return null;
        return (
          <div className="flex gap-x-3 gap-y-1 flex-wrap justify-center" dir={isAr ? "rtl" : "ltr"}>
            {tagItems.map((tag) => (
              <Link
                key={tag}
                to={`/at?name=${encodeURIComponent(tag)}`}
                className={`text-xs font-body ${accentTextSolid} hover:underline transition-all`}
                dir={isArabic(tag) ? "rtl" : "ltr"}
              >
                {displayTag(tag)}
              </Link>
            ))}
          </div>
        );
      })()}

      {/* Prev / Next navigation — بلا إطار وبلا خلفية، نفس لون الصفحة */}
      {showNav && (
      <div className="flex items-stretch gap-2">
        <button
          type="button"
          disabled={!prev}
          onClick={() => prev && navigate(`/glossary-term?id=${prev.id}`)}
          className={`flex-1 min-w-0 flex items-center gap-1.5 px-1 py-2 bg-transparent disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-left ${accentText}`}
        >
          {isAr ? <ChevronRight className="w-4 h-4 flex-shrink-0" /> : <ChevronLeft className="w-4 h-4 flex-shrink-0" />}
          <span className="min-w-0 flex-1">
            <span className="block text-[9px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "السابقة" : "Previous"}</span>
            {prev && storyTitle(prev, isAr) && <span className="block text-xs font-body font-medium truncate">{storyTitle(prev, isAr)}</span>}
          </span>
        </button>
        <button
          type="button"
          disabled={!next}
          onClick={() => next && navigate(`/glossary-term?id=${next.id}`)}
          className={`flex-1 min-w-0 flex items-center justify-end gap-1.5 px-1 py-2 bg-transparent disabled:opacity-30 disabled:cursor-not-allowed transition-colors text-right ${accentText}`}
        >
          <span className="min-w-0 flex-1">
            <span className="block text-[9px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "التالية" : "Next"}</span>
            {next && storyTitle(next, isAr) && <span className="block text-xs font-body font-medium truncate">{storyTitle(next, isAr)}</span>}
          </span>
          {isAr ? <ChevronLeft className="w-4 h-4 flex-shrink-0" /> : <ChevronRight className="w-4 h-4 flex-shrink-0" />}
        </button>
      </div>
      )}
    </div>
  );
}
