import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

/**
 * usePagedList — tiny client-side pager for in-place lists (Budget tabs, shop
 * log, etc.) where adding the full Pagination component would be heavy.
 *
 *   const { pageItems, page, setPage, totalPages } = usePagedList(items, 50);
 *
 * Resets to page 1 whenever the list length changes (e.g. a new month is
 * selected or an entry is added/removed).
 */
export function usePagedList(items = [], pageSize = 50) {
  const [page, setPage] = useState(1);
  const totalPages = Math.max(1, Math.ceil(items.length / pageSize));

  useEffect(() => {
    setPage(1);
  }, [items.length]);

  const start = (page - 1) * pageSize;
  const pageItems = items.slice(start, start + pageSize);

  return { pageItems, page, setPage, totalPages, total: items.length };
}

/**
 * SimplePager — compact prev / page-indicator / next control. Renders nothing
 * when there is only one page, so it can be dropped in unconditionally.
 */
export function SimplePager({ page, setPage, totalPages, isAr = false }) {
  if (totalPages <= 1) return null;
  return (
    <div className="flex items-center justify-center gap-3 pt-2" dir={isAr ? "rtl" : "ltr"}>
      <button
        type="button"
        disabled={page <= 1}
        onClick={() => setPage((p) => Math.max(1, p - 1))}
        className="flex items-center justify-center w-8 h-8 rounded-none border border-border bg-secondary/50 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-secondary transition-colors"
        aria-label={isAr ? "السابق" : "Previous"}
      >
        {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>
      <span className="text-xs font-body text-muted-foreground tabular-nums">
        {page} / {totalPages}
      </span>
      <button
        type="button"
        disabled={page >= totalPages}
        onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
        className="flex items-center justify-center w-8 h-8 rounded-none border border-border bg-secondary/50 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-secondary transition-colors"
        aria-label={isAr ? "التالي" : "Next"}
      >
        {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>
    </div>
  );
}
