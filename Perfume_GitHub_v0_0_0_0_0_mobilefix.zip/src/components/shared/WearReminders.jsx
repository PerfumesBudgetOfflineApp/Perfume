import { useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { CalendarClock, Check, X } from "lucide-react";
import { format } from "date-fns";
import { Link } from "react-router-dom";

/**
 * WearReminders — shows perfume wear-schedules that are due (today or overdue)
 * and still active. Reusable across Favorites, Activity and Goals pages.
 *
 * A schedule is "due" when its next occurrence date <= today and it hasn't been
 * marked done for that occurrence. Repeat schedules roll forward after "done".
 *
 * Props:
 *   compact  : tighter styling for embedding above other content
 *   title    : optional heading override
 */
function addPeriod(dateStr, repeat) {
  const d = new Date(dateStr + "T00:00:00");
  if (repeat === "daily") d.setDate(d.getDate() + 1);
  else if (repeat === "weekly") d.setDate(d.getDate() + 7);
  else if (repeat === "monthly") d.setMonth(d.getMonth() + 1);
  else if (repeat === "yearly") d.setFullYear(d.getFullYear() + 1);
  return format(d, "yyyy-MM-dd");
}

export default function WearReminders({ compact = false, title }) {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const today = format(new Date(), "yyyy-MM-dd");

  const { data: schedules = [] } = useQuery({
    queryKey: ["wear-schedules"],
    queryFn: () => apphost.entities.WearSchedule.list("scheduled_date"),
    staleTime: 1000 * 60,
  });

  // Determine which schedules are due now.
  const due = useMemo(() => {
    return schedules.filter((s) => {
      if (!s.is_active) return false;
      // The "current occurrence date" is scheduled_date, advanced past any
      // already-completed occurrences for repeating schedules.
      let occ = s.scheduled_date;
      if (s.repeat && s.repeat !== "once" && s.last_done_date) {
        // roll forward while the occurrence has been done
        let guard = 0;
        while (s.last_done_date >= occ && guard < 500) {
          occ = addPeriod(occ, s.repeat);
          guard++;
        }
      }
      // once + already done → not due
      if ((!s.repeat || s.repeat === "once") && s.last_done_date) return false;
      return occ <= today;
    });
  }, [schedules, today]);

  const doneMutation = useMutation({
    mutationFn: ({ schedule }) => {
      if (!schedule.repeat || schedule.repeat === "once") {
        return apphost.entities.WearSchedule.update(schedule.id, { last_done_date: today, is_active: false });
      }
      return apphost.entities.WearSchedule.update(schedule.id, { last_done_date: today });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["wear-schedules"] }),
  });

  const dismissMutation = useMutation({
    mutationFn: (id) => apphost.entities.WearSchedule.update(id, { is_active: false }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["wear-schedules"] }),
  });

  if (due.length === 0) return null;

  const repeatLabel = (r) => {
    const map = {
      once: isAr ? "مرة" : "Once",
      daily: isAr ? "يومي" : "Daily",
      weekly: isAr ? "أسبوعي" : "Weekly",
      monthly: isAr ? "شهري" : "Monthly",
      yearly: isAr ? "سنوي" : "Yearly",
    };
    return map[r] || map.once;
  };

  return (
    <div className={`rounded-none border border-amber-300/60 dark:border-amber-700/40 bg-amber-50/70 dark:bg-amber-950/20 ${compact ? "p-3" : "p-4"} space-y-2.5`}>
      <div className="flex items-center gap-2">
        <CalendarClock className="w-4 h-4 text-amber-700 dark:text-amber-400" />
        <p className="text-sm font-heading font-semibold text-amber-800 dark:text-amber-300">
          {title || (isAr ? "تذكير ارتداء العطر" : "Wear Reminders")}
        </p>
        <span className="text-[10px] font-body font-bold text-amber-700 rounded-none">
          {due.length}
        </span>
      </div>

      <div className="space-y-2">
        {due.map((s) => (
          <div key={s.id} className="flex items-center gap-3 bg-white/70 dark:bg-black/20 rounded-none p-2.5">
            <Link to={`/perfume?id=${s.perfume_id}`} className="w-10 h-10 rounded-none overflow-hidden bg-white flex items-center justify-center flex-shrink-0 border border-amber-200/50">
              {s.image_url ? (
                <img src={s.image_url} alt="" className="w-full h-full object-contain" />
              ) : (
                <span className="text-lg">🧴</span>
              )}
            </Link>
            <Link to={`/perfume?id=${s.perfume_id}`} className="flex-1 min-w-0">
              <p className="text-xs font-body font-semibold truncate">{s.perfume_name}</p>
              <p className="text-[10px] text-muted-foreground font-body truncate">
                {s.brand_name}{s.note ? ` · ${s.note}` : ""} · {repeatLabel(s.repeat)}
              </p>
            </Link>
            <button
              onClick={() => doneMutation.mutate({ schedule: s })}
              title={isAr ? "تم الارتداء" : "Mark worn"}
              className="w-8 h-8 rounded-none bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 flex items-center justify-center hover:bg-emerald-200 transition-colors flex-shrink-0"
            >
              <Check className="w-4 h-4" />
            </button>
            <button
              onClick={() => dismissMutation.mutate(s.id)}
              title={isAr ? "إلغاء" : "Dismiss"}
              className="w-8 h-8 rounded-none text-muted-foreground hover:text-destructive flex items-center justify-center transition-colors flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
