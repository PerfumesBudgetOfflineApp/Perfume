import { ChevronLeft, ChevronRight } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * Pagination — a compact, bilingual page switcher used by list pages
 * (Quotes, Glossary, Blog). Showing every row at once is the main cause of
 * sluggishness on large datasets (the quote DB alone is 4,000+ rows), so
 * lists render one page (default 50 items) and switch pages instead of
 * scrolling through everything.
 *
 * Stateless: parent owns `page` and total count; this only renders controls.
 *
 * Props:
 *   page        : current 1-based page
 *   pageCount   : total number of pages
 *   onChange    : (newPage) => void
 *   totalItems  : optional, for the "X–Y of Z" label
 *   pageSize    : optional, for the label (default 50)
 */
export default function Pagination({ page, pageCount, onChange, totalItems = 0, pageSize = 50 }) {
  const { isAr } = useLang();
  if (pageCount <= 1) return null;

  const from = (page - 1) * pageSize + 1;
  const to = Math.min(page * pageSize, totalItems || page * pageSize);

  const go = (p) => onChange(Math.min(Math.max(1, p), pageCount));

  return (
    <div className="flex items-center justify-center gap-3 py-4">
      <button
        type="button"
        onClick={() => go(page - 1)}
        disabled={page <= 1}
        className="flex items-center justify-center w-9 h-9 rounded-none border border-border bg-secondary/50 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-secondary transition-colors"
        aria-label={isAr ? "السابق" : "Previous"}
      >
        {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
      </button>

      <div className="text-center font-body">
        <span className="text-sm font-medium">{page}</span>
        <span className="text-muted-foreground text-sm"> / {pageCount}</span>
        {totalItems > 0 && (
          <p className="text-[10px] text-muted-foreground mt-0.5">
            {from}–{to} {isAr ? "من" : "of"} {totalItems}
          </p>
        )}
      </div>

      <button
        type="button"
        onClick={() => go(page + 1)}
        disabled={page >= pageCount}
        className="flex items-center justify-center w-9 h-9 rounded-none border border-border bg-secondary/50 disabled:opacity-30 disabled:cursor-not-allowed hover:bg-secondary transition-colors"
        aria-label={isAr ? "التالي" : "Next"}
      >
        {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
      </button>
    </div>
  );
}
