/**
 * CopyMenu — small dropdown with two copy options:
 *   - Database info only (DB)
 *   - Full report (DB + the current user's contributions)
 *
 * Usage:
 *   <CopyMenu
 *     dbText={perfumeDbText(perfume)}
 *     fullText={perfumeFullText(perfume, extras)}
 *     entity="perfume"  // or "brand"
 *   />
 *
 * Both `dbText` and `fullText` are plain strings, computed by callers using
 * the serializers in src/lib/copyData.js. The component itself only knows
 * how to display the menu and call navigator.clipboard.
 */

import { useState } from "react";
import { Copy, Check, FileText, FilePlus2 } from "lucide-react";
import { toast } from "sonner";
import { copyToClipboard } from "@/lib/copyData";
import { useLang } from "@/lib/LanguageContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function CopyMenu({
  dbText,
  fullText,
  entity = "perfume", // "perfume" | "brand"
  size = "sm",        // "sm" | "icon"
  className = "",
}) {
  const { isAr } = useLang();
  const [copied, setCopied] = useState(false);

  const labels = entity === "brand"
    ? {
        title:    isAr ? "نسخ"                 : "Copy",
        db:       isAr ? "معلومات البراند"     : "Brand info (DB)",
        full:     isAr ? "تقرير كامل (مع بياناتي)" : "Full report (with my data)",
        successDb:   isAr ? "تم نسخ معلومات البراند"   : "Brand info copied",
        successFull: isAr ? "تم نسخ التقرير الكامل"    : "Full report copied",
      }
    : {
        title:    isAr ? "نسخ"                 : "Copy",
        db:       isAr ? "معلومات العطر"        : "Perfume info (DB)",
        full:     isAr ? "تقرير كامل (مع بياناتي)" : "Full report (with my data)",
        successDb:   isAr ? "تم نسخ معلومات العطر"     : "Perfume info copied",
        successFull: isAr ? "تم نسخ التقرير الكامل"    : "Full report copied",
      };

  const flash = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const doCopy = async (text, successMsg) => {
    if (!text) {
      toast.error(isAr ? "لا توجد بيانات" : "Nothing to copy");
      return;
    }
    const ok = await copyToClipboard(text);
    if (ok) {
      toast.success(successMsg);
      flash();
    } else {
      toast.error(isAr ? "فشل النسخ" : "Copy failed");
    }
  };

  const trigger = size === "icon"
    ? (
      <button
        type="button"
        className={`w-8 h-8 bg-transparent border-0 flex items-center justify-center hover:opacity-70 transition-opacity ${className}`}
        aria-label={labels.title}
        title={labels.title}
      >
        {copied
          ? <Check className="w-4 h-4 text-emerald-500" />
          : <Copy className="w-4 h-4 text-rose-400" />}
      </button>
    )
    : (
      <button
        type="button"
        className={`flex items-center gap-1.5 px-2 py-1.5 bg-transparent border-0 text-rose-400 hover:opacity-70 text-xs font-body transition-opacity ${className}`}
      >
        {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
        <span>{labels.title}</span>
      </button>
    );

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        {trigger}
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="min-w-[240px]">
        <DropdownMenuItem onClick={() => doCopy(dbText, labels.successDb)} className="gap-2 cursor-pointer">
          <FileText className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-body">{labels.db}</span>
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => doCopy(fullText, labels.successFull)} className="gap-2 cursor-pointer">
          <FilePlus2 className="w-4 h-4 text-primary" />
          <span className="text-sm font-body">{labels.full}</span>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
