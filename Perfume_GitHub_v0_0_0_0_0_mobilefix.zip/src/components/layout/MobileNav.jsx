import { useState, useEffect, useRef, useCallback } from "react";
import { createPortal } from "react-dom";
import { Link, useLocation } from "react-router-dom";
import { Settings } from "lucide-react";
import { ActivitiesIcon, FlaconIcon, ExploreIcon, StoresIcon, StatsIcon, GoalsIcon } from "@/components/icons/NavIcons";
import { cn } from "@/lib/utils";
import { useLang } from "@/lib/LanguageContext";
import { getSecureStorage } from "@/lib/storageEncryption";

function PerfumeBottle({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3h8v2H8z" />
      <path d="M10 5v3h4V5" />
      <path d="M9 8h6v10c0 1.1-.9 2-2 2h-2c-1.1 0-2-.9-2-2V8z" />
    </svg>
  );
}

// Petal-burst overlay: 12 petals (6 rose-wine, 6 deep blue) rise from the
// bottle CAP upward, then fall and fade. One-shot per trigger. Drawn on an
// absolutely-positioned SVG layer above the lucide icon — never touches the
// icon itself (no color/size change). Exposed via ref: ref.current.burst().
const PetalBurst = (function () {
  const ROSE = ["#be123c", "#e11d48", "#fb7185"];
  const NAVY = ["#1e3a8a", "#1d4ed8", "#3b82f6"];
  return function PetalBurstLayer({ fireRef }) {
    const svgRef = useRef(null);

    const burst = useCallback(() => {
      const svg = svgRef.current;
      if (!svg) return;
      const NS = "http://www.w3.org/2000/svg";
      // viewBox 0 0 90 90; the icon sits centered, cap near top.
      const capX = 45, capY = 30;
      for (let i = 0; i < 12; i++) {
        const pal = i % 2 === 0 ? ROSE : NAVY;
        const color = pal[(Math.random() * pal.length) | 0];
        const p = document.createElementNS(NS, "ellipse");
        p.setAttribute("rx", "3.2");
        p.setAttribute("ry", "1.9");
        p.setAttribute("cx", capX);
        p.setAttribute("cy", capY);
        p.setAttribute("fill", color);
        svg.appendChild(p);

        const ang = -Math.PI / 2 + (i - 5.5) * 0.16 + (Math.random() - 0.5) * 0.16;
        const dist = 24 + Math.random() * 20;
        const dx = Math.cos(ang) * dist;
        const dy = Math.sin(ang) * dist;
        const rot = (Math.random() - 0.5) * 220;
        const t0 = performance.now();
        const dur = 850;
        const frame = (t) => {
          const k = Math.min(1, (t - t0) / dur);
          const ease = 1 - Math.pow(1 - k, 2);
          const x = dx * ease;
          const y = dy * ease + (k > 0.5 ? (k - 0.5) * 20 : 0);
          p.setAttribute("transform", `translate(${x},${y}) rotate(${rot * k} ${capX} ${capY})`);
          p.setAttribute("opacity", String(k < 0.12 ? k / 0.12 : 1 - (k - 0.12) / 0.88));
          if (k < 1) requestAnimationFrame(frame);
          else if (p.parentNode) svg.removeChild(p);
        };
        requestAnimationFrame(frame);
      }
    }, []);

    useEffect(() => {
      if (fireRef) fireRef.current = burst;
    }, [fireRef, burst]);

    return (
      <svg
        ref={svgRef}
        width="90"
        height="90"
        viewBox="0 0 90 90"
        aria-hidden="true"
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          transform: "translate(-50%,-50%)",
          pointerEvents: "none",
          overflow: "visible",
        }}
      />
    );
  };
})();

export default function MobileNav() {
  const location = useLocation();
  const { isAr } = useLang();
  const explodeRef = useRef(null);
  const [showLabels, setShowLabels] = useState(() => getSecureStorage("showTabLabels", false));
  const [showMaestro, setShowMaestro] = useState(() => getSecureStorage("showMaestroNav", false));
  const [navTabs, setNavTabs] = useState(() => {
    const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
    return getSecureStorage("navTabSettings", defaults);
  });

  useEffect(() => {
    const handler = () => {
      setShowLabels(getSecureStorage("showTabLabels", false));
      setShowMaestro(getSecureStorage("showMaestroNav", false));
      const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
      setNavTabs(getSecureStorage("navTabSettings", defaults));
    };
    
    window.addEventListener("tabLabelsChanged", handler);
    window.addEventListener("maestroNavChanged", handler);
    window.addEventListener("navTabSettingsChanged", handler);
    
    return () => {
      window.removeEventListener("tabLabelsChanged", handler);
      window.removeEventListener("maestroNavChanged", handler);
      window.removeEventListener("navTabSettingsChanged", handler);
    };
  }, []);

  const navItems = [
    { key: "home", path: "/home", icon: ActivitiesIcon, label: isAr ? "نشاطات" : "Activities", visible: navTabs.home !== false },
    { key: "perfumes", path: "/", icon: FlaconIcon, label: isAr ? "رئيسية" : "Home", visible: navTabs.perfumes !== false },
    { key: "explore", path: "/explore", icon: ExploreIcon, label: isAr ? "اكتشف" : "Explore", visible: navTabs.explore !== false },
    { key: "shopping", path: "/shopping", icon: StoresIcon, label: isAr ? "متاجر" : "Stores", visible: navTabs.shopping !== false },
    { key: "progress", path: "/progress", icon: StatsIcon, label: isAr ? "إحصائيات" : "Statistics", visible: navTabs.progress !== false },
    { key: "goals", path: "/goals", icon: GoalsIcon, label: isAr ? "أهداف" : "Goals", visible: navTabs.goals !== false },
    { key: "maestro", path: "/maestro", icon: Settings, label: "Admin", visible: showMaestro && navTabs.maestro !== false },
  ].filter(item => item.visible && item.icon != null);

  const navEl = (
    <nav id="app-bottom-nav" className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-xl border-t border-border" style={{ paddingBottom: "env(safe-area-inset-bottom)", pointerEvents: "auto" }}>
      <div dir="ltr" className="flex items-center justify-around w-full py-2 min-h-[56px]">
        {navItems.map(({ key, path, icon: NavIcon, label }) => {
          if (!NavIcon) return null;
          const isActive = location.pathname === path || (path === "/maestro" && location.pathname.startsWith("/maestro"));
          const isExplore = key === "explore";
          return (
            <Link
              key={path}
              to={path}
              title={label}
              onClick={isExplore ? () => { if (explodeRef.current) explodeRef.current(); } : undefined}
              className="flex flex-col items-center gap-0.5 flex-1 min-w-0 py-1.5 rounded-none transition-all duration-200"
              style={{ color: isActive ? "var(--brand)" : "#9aa8a0" }}
            >
              {isExplore ? (
                <span className="relative inline-flex items-center justify-center w-5 h-5 shrink-0">
                  <PetalBurst fireRef={explodeRef} />
                  <NavIcon className={cn("w-5 h-5 shrink-0", isActive && "stroke-[2.5]")} />
                </span>
              ) : (
                <NavIcon className={cn("w-5 h-5 shrink-0", isActive && "stroke-[2.5]")} />
              )}
              {showLabels && (
                <span
                  className="font-body font-medium w-full text-center leading-tight"
                  style={{ fontSize: navItems.length > 5 ? "8px" : "10px" }}
                >
                  {label}
                </span>
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
  return typeof document !== "undefined" ? createPortal(navEl, document.body) : navEl;
}