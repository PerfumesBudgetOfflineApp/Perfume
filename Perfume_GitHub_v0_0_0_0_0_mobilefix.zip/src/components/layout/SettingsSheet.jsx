import { useState, useEffect, useRef } from "react";
import { Sheet, SheetContent, SheetTrigger, SheetTitle, SheetDescription } from "@/components/ui/sheet";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";
import { THEMES, THEME_ORDER } from "@/lib/themeColor";
import { User, CloudUpload, Info, Camera, List, Droplets, Moon, Sun, Monitor, ChevronDown, ChevronUp, RefreshCw, Trash2, Notebook, Heart, Sparkles } from "lucide-react";
import EraserIcon from "@/components/icons/EraserIcon";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "react-router-dom";
import { useCurrency } from "@/lib/useCurrency";
import { getThemePref, setThemePref } from "@/lib/theme";
import { DEFAULT_USER_MARK } from "@/lib/exportSettings";
import UserTotals from "@/components/perfume/UserTotals";
import CombinedTotals from "@/components/perfume/CombinedTotals";
import { ReadingLangToggle, FontSizeControl } from "@/components/shared/ReadingControls";

const COLORS = [
  "#10b981", "#8b5cf6", "#f59e0b", "#ef4444", "#3b82f6",
  "#ec4899", "#14b8a6", "#f97316", "#6366f1", "#84cc16",
];

function PersonCard({ personKey, name, profile, onUpdateName, onUpdateProfile }) {
  const { isAr } = useLang();
  const fileRef = useRef();

  const handlePhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    onUpdateProfile(personKey, "photo", file_url);
  };

  return (
    <div className="py-2 space-y-3">
      <div className="flex items-center gap-3">
        <div className="relative flex-shrink-0">
          <button
            onClick={() => fileRef.current?.click()}
            className="w-14 h-14 rounded-none overflow-hidden border-2 flex items-center justify-center hover:opacity-80 transition-opacity"
            style={{ borderColor: profile.color }}
          >
            {profile.photo ? (
              <img src={profile.photo} alt={name} className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full flex items-center justify-center" style={{ background: profile.color + "22" }}>
                <User className="w-6 h-6" style={{ color: profile.color }} />
              </div>
            )}
          </button>
          <div
            className="absolute -bottom-1 -right-1 w-5 h-5 rounded-none flex items-center justify-center shadow"
            style={{ background: profile.color }}
          >
            <Camera className="w-2.5 h-2.5 text-white" />
          </div>
          <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handlePhoto} />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-[10px] text-muted-foreground font-body mb-1">{personKey === "person1" ? "Profile A" : "Profile B"}</p>
          <Input
            value={name}
            onChange={(e) => onUpdateName(personKey, e.target.value)}
            className="h-8 rounded-none font-body text-sm"
            placeholder={personKey === "person1" ? "e.g. Alpha" : "e.g. Bravo"}
          />
        </div>
      </div>
      <div className="space-y-1.5">
        <p className="text-[10px] text-muted-foreground font-body">{isAr ? "اللون" : "Color"}</p>
        <div className="flex gap-2 flex-wrap">
          {COLORS.map((c) => (
            <button
              key={c}
              onClick={() => onUpdateProfile(personKey, "color", c)}
              className="w-6 h-6 rounded-none transition-transform hover:scale-110"
              style={{ background: c, outline: profile.color === c ? `3px solid ${c}` : "none", outlineOffset: "2px" }}
            />
          ))}
        </div>
      </div>
      <div className="space-y-1.5">
        <p className="text-[10px] text-muted-foreground font-body">{isAr ? "نبذة" : "Bio"}</p>
        <Textarea
          value={profile.bio}
          onChange={(e) => onUpdateProfile(personKey, "bio", e.target.value)}
          className="min-h-[56px] rounded-none font-body text-xs resize-none"
          placeholder="كلمات عنك... A few words about you..."
        />
      </div>
    </div>
  );
}

export default function SettingsSheet({ children }) {
  const { lang, toggle, setLang, isAr } = useLang();
  const { names, updateName, profiles, updateProfile } = usePersonNames();
  const { currency, setCurrency } = useCurrency();
  const [user, setUser] = useState(null);
  const [userPhoto, setUserPhoto] = useState(null);
  const [themePref, setThemePrefState] = useState(() => getThemePref());
  const [showTabLabels, setShowTabLabels] = useState(() => getSecureStorage("showTabLabels", false));
  const [themeColor, setThemeColor] = useState(() => getSecureStorage("themeColor", "green"));
  const [showMaestro, setShowMaestro] = useState(() => getSecureStorage("showMaestroNav", false));
  const [showActivity, setShowActivity] = useState(() => getSecureStorage("showActivityTimeline", true));
  const [showNavTabSettings, setShowNavTabSettings] = useState(false);
  const [navTabSettings, setNavTabSettings] = useState(() => {
    const defaults = { home: true, perfumes: true, explore: true, shopping: true, progress: true, goals: true, maestro: true };
    return getSecureStorage("navTabSettings", defaults);
  });
  const [showLinksSettings, setShowLinksSettings] = useState(false);
  const [linkSettings, setLinkSettings] = useState(() => {
    const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, glossary: true };
    const stored = getSecureStorage("perfumeLinkSettings", {});
    // Merge: any key not explicitly set to false defaults to true
    return Object.fromEntries(Object.keys(defaults).map(k => [k, stored[k] !== false]));
  });
  const [showGlossarySettings, setShowGlossarySettings] = useState(false);
  const [glossarySettings, setGlossarySettings] = useState(() => {
    return getSecureStorage("glossarySettings", { sortOrder: "alpha_asc" });
  });
  const [markInput, setMarkInput] = useState({});
  const [displayName, setDisplayName] = useState(""); // shown in exports when "App Name + User" toggle is on
  const [showHomeSettings, setShowHomeSettings] = useState(false);
  const [showThoughtSettings, setShowThoughtSettings] = useState(false);
  const [filters, setFilters] = useState(() => {
    const defaults = { reviews: true, purchases: true, favorites: true, wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true, budgetEntries: true, quotesActivity: true };
    return getSecureStorage("homeFilters", defaults);
  });
  const [sortOrder, setSortOrder] = useState(() => getSecureStorage("homeSortOrder", "newest"));
  const [thoughtSettings, setThoughtSettings] = useState(() => {
    const defaults = {
      sortOrder: "newest",
      show: { not_set: true, idea: true, poetry: true, thought: true, knowledge: true, concept: true, memo: true },
    };
    return getSecureStorage("thoughtSettings", defaults);
  });
  const photoRef = useRef();

  useEffect(() => {
    apphost.auth.me().then((u) => {
      setUser(u);
      // Show the default mark (🧴) in the field so the user can see & change it.
      setMarkInput({ person1: u?.mark || DEFAULT_USER_MARK });
      setUserPhoto(u?.profile_photo || null);
      // Show the default name ("Name") in the field so the user can see & change it.
      // Ignore the technical offline default ("Local User") — treat it as unset.
      const resolvedName = u?.display_name?.trim()
        || (u?.full_name && u.full_name !== "Local User" ? u.full_name : "")
        || "Name";
      setDisplayName(resolvedName);
    }).catch(() => {});
  }, []);

  const handleUserPhoto = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    setUserPhoto(file_url);
    await apphost.auth.updateMe({ profile_photo: file_url });
    // Notify all UserAvatarButton instances and other listeners that
    // the profile has changed so they re-fetch.
    window.dispatchEvent(new CustomEvent("userProfileChanged"));
  };

  const chooseTheme = (pref) => {
    setThemePrefState(pref);
    setThemePref(pref); // saves + applies (handles system follow)
  };

  const toggleTabLabels = () => {
    const newVal = !showTabLabels;
    setShowTabLabels(newVal);
    setSecureStorage("showTabLabels", newVal);
    window.dispatchEvent(new Event("tabLabelsChanged"));
  };

  const toggleMaestro = () => {
    const newVal = !showMaestro;
    setShowMaestro(newVal);
    setSecureStorage("showMaestroNav", newVal);
    window.dispatchEvent(new Event("maestroNavChanged"));
  };

  const toggleActivity = () => {
    const newVal = !showActivity;
    setShowActivity(newVal);
    setSecureStorage("showActivityTimeline", newVal);
    window.dispatchEvent(new Event("activitySectionChanged"));
  };

  const toggleLinkSetting = (key) => {
    const newSettings = { ...linkSettings, [key]: !linkSettings[key] };
    setLinkSettings(newSettings);
    // Only persist the false values so new keys always default to true
    const toStore = Object.fromEntries(Object.entries(newSettings).filter(([, v]) => v === false));
    setSecureStorage("perfumeLinkSettings", toStore);
    window.dispatchEvent(new CustomEvent("perfumeLinkSettingsChanged"));
  };

  const toggleFilter = (key) => {
    const newFilters = { ...filters, [key]: !filters[key] };
    setFilters(newFilters);
    setSecureStorage("homeFilters", newFilters);
    window.dispatchEvent(new Event("homeSettingsChanged"));
  };

  const handleSortChange = (order) => {
    setSortOrder(order);
    setSecureStorage("homeSortOrder", order);
    window.dispatchEvent(new Event("homeSettingsChanged"));
  };

  return (
    <Sheet>
      <SheetTrigger asChild>{children}</SheetTrigger>
      <SheetContent side="right" dir={isAr ? "rtl" : "ltr"} className="w-[85vw] max-w-sm p-0 h-full overflow-y-auto">
        <SheetTitle className="sr-only">{isAr ? 'القائمة' : 'Menu'}</SheetTitle>
        <SheetDescription className="sr-only">{isAr ? 'إعدادات وروابط التطبيق' : 'App settings and links'}</SheetDescription>
        {/* User profile header: Photo Name Mark — يمرّر مع بقية الصفحة (صفحة واحدة) */}
        <div className="bg-gradient-to-br from-primary/10 to-accent px-6 py-5 flex flex-col items-center gap-3">
          <div className="relative">
            <button
              onClick={() => photoRef.current?.click()}
              className="w-16 h-16 overflow-hidden flex items-center justify-center hover:opacity-80 transition-opacity"
              style={{ background: "#ffffff", border: "2px solid var(--brand)", borderRadius: 0 }}
            >
              {userPhoto && (
                <img src={userPhoto} alt="" className="w-full h-full object-cover" />
              )}
              {/* When no photo: clean white square with sharp gold border — no icon, no letters */}
            </button>
            <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-none bg-primary flex items-center justify-center shadow">
              <Camera className="w-3 h-3 text-white" />
            </div>
            <input ref={photoRef} type="file" accept="image/*" className="hidden" onChange={handleUserPhoto} />
          </div>

          {/* Name — type directly in the box to edit */}
          <div className="w-full space-y-1">
            <span className="block text-[10px] text-muted-foreground font-body uppercase tracking-wider text-center">
              {isAr ? "الاسم" : "Name"}
            </span>
            <Input
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              onBlur={() => {
                const val = displayName.trim();
                // Don't persist the placeholder default ("Name") as a real name.
                apphost.auth.updateMe({ display_name: val === "Name" ? "" : val });
                window.dispatchEvent(new CustomEvent("userProfileChanged"));
              }}
              placeholder={isAr ? "الاسم" : "Name"}
              maxLength="40"
              className="h-9 w-full rounded-none font-body text-sm text-center bg-white/70 dark:bg-black/20 border-0"
            />
          </div>

          {/* Mark — for review exports. Shows 🧴 by default; editable. */}
          <div className="w-full space-y-1">
            <span className="block text-[10px] text-muted-foreground font-body uppercase tracking-wider text-center">
              {isAr ? "علامة التصدير" : "Mark"}
            </span>
            <Input
              value={markInput.person1 || ""}
              onChange={(e) => {
                const val = e.target.value;
                setMarkInput({ ...markInput, person1: val });
                apphost.auth.updateMe({ mark: val });
                window.dispatchEvent(new CustomEvent("userProfileChanged"));
              }}
              maxLength="5"
              className="h-9 w-full rounded-none font-body text-center text-lg bg-white/70 dark:bg-black/20 border-0"
            />
          </div>
        </div>

        {/* Settings */}
        <div className="px-4 py-5 space-y-4 pb-20">

          <Link to="/notebook" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <Notebook className="w-4 h-4" strokeWidth={1.25} style={{ color: "#1450c8" }} />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "مفكرة" : "Notebook"}</span>
            </div>
          </Link>

          <Link to="/cast-away" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <EraserIcon className="w-4 h-4" strokeWidth={1.25} style={{ color: "#d97706" }} />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "المهملات" : "Cast Away"}</span>
            </div>
          </Link>

          <Link to="/reading-guide" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <span className="text-sm font-body font-medium">{lang === "ar" ? "موجِّهة القراءة" : "Reading Guide"}</span>
          </Link>
          <Link to="/guide" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" aria-hidden="true">
                <rect x="3.5" y="3.5" width="17" height="17" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinejoin="round" />
              </svg>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "شرح المميزات" : "Features Definition"}</span>
            </div>
          </Link>
          <Link to="/accords-guide" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" aria-hidden="true">
                <rect x="3.5" y="3.5" width="17" height="17" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinejoin="round" />
              </svg>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "التناغمات العطرية" : "Perfume Accords"}</span>
            </div>
          </Link>
          <Link to="/headache-guide" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" aria-hidden="true">
                <rect x="3.5" y="3.5" width="17" height="17" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinejoin="round" />
              </svg>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "صداع و حساسية" : "Headache & Sensitivity"}</span>
            </div>
          </Link>
          <Link to="/timelines" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <svg viewBox="0 0 24 24" className="w-3.5 h-3.5" aria-hidden="true">
                <rect x="3.5" y="3.5" width="17" height="17" fill="none" stroke="var(--brand)" strokeWidth="1.5" strokeLinejoin="round" />
              </svg>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "مصنفات" : "Classification"}</span>
            </div>
          </Link>

          {/* Consumption & Decision */}
          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">{lang === "ar" ? "احصاء سريع" : "Quick Stats"}</p>
          <UserTotals person="person1" label={names.person1 || "Profile A"} />
          <UserTotals person="person2" label={names.person2 || "Profile B"} />
          <CombinedTotals />

          {/* Actions (moved above Appearance) */}
          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">{lang === "ar" ? "إجراءات" : "Actions"}</p>

          <Link to="/add" className="flex items-center justify-between px-2 py-3 hover:bg-primary/10 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <span className="text-sm font-body font-medium">{lang === "ar" ? "إضافة & عطر" : "Add & Perfume"}</span>
            </div>
          </Link>

          {/* Lists & Samples */}
           <Link to="/lists" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
             <div className="flex items-center gap-2.5">
               <List className="w-4 h-4 text-primary" />
               <span className="text-sm font-body font-medium">{lang === "ar" ? "إدارة المجموعات" : "Manage Sets"}</span>
             </div>
           </Link>
           <Link to="/samples" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
             <div className="flex items-center gap-2.5">
               <Droplets className="w-4 h-4 text-primary" />
               <span className="text-sm font-body font-medium">{lang === "ar" ? "قائمة العينات" : "Sample List"}</span>
             </div>
           </Link>
           <Link to="/wishlist" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
             <div className="flex items-center gap-2.5">
               <Heart className="w-4 h-4 text-primary" />
               <span className="text-sm font-body font-medium">{lang === "ar" ? "قائمة الرغبات" : "Wishlist"}</span>
             </div>
           </Link>
           <Link to="/marketing-card" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
             <div className="flex items-center gap-2.5">
               <Sparkles className="w-4 h-4 text-primary" />
               <span className="text-sm font-body font-medium">{lang === "ar" ? "بطاقة تسويق" : "Marketing Card"}</span>
             </div>
           </Link>

          {/* Theme: Light (default) / Dark / System */}
          <div className="px-1 py-2 space-y-2">
            <div className="flex items-center gap-2.5">
              {themePref === "dark" ? <Moon className="w-4 h-4 text-primary" />
                : themePref === "system" ? <Monitor className="w-4 h-4 text-primary" />
                : <Sun className="w-4 h-4 text-primary" />}
              <span className="text-sm font-body font-medium">{lang === "ar" ? "المظهر" : "Appearance"}</span>
            </div>
            <div className="grid grid-cols-3 gap-1.5">
              {[
                { pref: "light",  icon: Sun,     en: "Light",  ar: "فاتح" },
                { pref: "dark",   icon: Moon,    en: "Dark",   ar: "داكن" },
                { pref: "system", icon: Monitor, en: "System", ar: "الجهاز" },
              ].map(({ pref, icon: Icon, en, ar }) => (
                <button
                  key={pref}
                  onClick={() => chooseTheme(pref)}
                  className={cn(
                    "flex flex-col items-center gap-1 py-2 rounded-none border text-[11px] font-body transition-all",
                    themePref === pref
                      ? "bg-primary/10 border-primary text-primary font-semibold"
                      : "bg-background/40 border-border text-muted-foreground hover:text-foreground"
                  )}
                >
                  <Icon className="w-4 h-4" />
                  {lang === "ar" ? ar : en}
                </button>
              ))}
            </div>
          </div>

          {/* Profiles */}
          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-2">{lang === "ar" ? "الملفات الشخصية" : "Profiles"}</p>

          {/* Profile A */}
          <PersonCard personKey="person1" name={names.person1} profile={profiles.person1} onUpdateName={updateName} onUpdateProfile={updateProfile} />

          {/* Profile B */}
          <PersonCard personKey="person2" name={names.person2} profile={profiles.person2} onUpdateName={updateName} onUpdateProfile={updateProfile} />

          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">{lang === "ar" ? "الإعدادات" : "Settings"}</p>

          <div className="py-2 space-y-3">
            <p className="text-sm font-body font-medium">Language اللغة</p>
            <div className="flex gap-2">
              <button
                onClick={() => setLang("en")}
                className={cn("flex-1 py-2 rounded-none text-sm font-body font-medium transition-all", lang === "en" ? "bg-primary text-primary-foreground shadow" : "bg-background border border-border text-muted-foreground")}
              >
                English
              </button>
              <button
                onClick={() => setLang("ar")}
                className={cn("flex-1 py-2 rounded-none text-sm font-body font-medium transition-all", lang === "ar" ? "bg-primary text-primary-foreground shadow" : "bg-background border border-border text-muted-foreground")}
              >
                العربية
              </button>
            </div>
          </div>

          <div className="py-2 space-y-3">
            <p className="text-sm font-body font-medium">{isAr ? "العملة" : "Currency"}</p>
            <div className="flex gap-2 flex-wrap">
              {["USD", "SAR"].map((code) => (
                <button
                  key={code}
                  onClick={() => setCurrency(code)}
                  className={cn("px-3 py-2 rounded-none text-xs font-body font-medium transition-all", currency === code ? "bg-primary text-primary-foreground shadow" : "bg-background border border-border text-muted-foreground")}
                >
                  {code}
                </button>
              ))}
            </div>
            <Input
              placeholder="عملة مخصصة (مثل EUR) Custom currency"
              defaultValue={!["USD", "SAR"].includes(currency) ? currency : ""}
              onBlur={(e) => { const val = e.target.value.toUpperCase().trim(); if (val) setCurrency(val); }}
              className="h-8 rounded-none font-body text-xs"
            />
          </div>

          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">{lang === "ar" ? "العرض" : "Display"}</p>

          {/* المعجم و القصص — لغة العرض الافتراضية + حجم الخطّ (يُطبَّق على صفحات القصّة/المصطلح) */}
          <div className="px-2 py-3 space-y-2 border-b border-border/40">
            <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "المعجم و القصص" : "Glossary & Stories"}</p>
            <ReadingLangToggle accent="amber" className="justify-start" />
            <FontSizeControl accent="amber" className="justify-start" />
          </div>

          {/* Home Settings */}
          <button
            onClick={() => setShowHomeSettings(!showHomeSettings)}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-primary text-sm">🏠</span>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "إعدادات الرئيسية" : "Home Settings"}</span>
            </div>
            {showHomeSettings ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>

          {showHomeSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "مرشّحات النشاط" : "Activity Filters"}</p>
              {[
                 { key: "reviews", label: "📝 Reviews" },
                 { key: "wishes", label: "💕 Wish List" },
                 { key: "purchases", label: "🛍 Purchases" },
                 { key: "favorites", label: "🤎 Favorites" },
                 { key: "goals", label: "🎯 Goals / Tasks" },
                 { key: "wearLogs", label: "💧 Wear Logs" },
                 { key: "blogEntries", label: "📖 Blog Entries" },
                 { key: "glossaryEntries", label: "📚 Glossary" },
                 { key: "budgetEntries", label: "💰 Budget Entries" },
                 { key: "quotesActivity", label: "💬 Quotes" },
               ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => toggleFilter(key)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 rounded border flex items-center justify-center transition-colors", filters[key] ? "bg-primary border-primary" : "border-border")}>
                    {filters[key] && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={filters[key] ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
              <div className="pt-2 border-t border-border/40 space-y-1.5">
                <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "ترتيب العرض" : "Sort Order"}</p>
                <div className="flex gap-2 flex-wrap">
                  {[
                    { value: "newest", label: "Newest" },
                    { value: "oldest", label: "Oldest" },
                    { value: "alpha_asc", label: "Alphabetical" },
                    { value: "alpha_desc", label: "Reversed" },
                  ].map(({ value, label }) => (
                    <button
                      key={value}
                      onClick={() => handleSortChange(value)}
                      className={cn("flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all min-w-[60px]", sortOrder === value ? "bg-primary text-primary-foreground" : "bg-background border border-border text-muted-foreground")}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Thoughts Settings */}
          <button
            onClick={() => setShowThoughtSettings(!showThoughtSettings)}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-primary text-sm">📖</span>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "إعدادات المدونة" : "Blogs Settings"}</span>
            </div>
            {showThoughtSettings ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>

          {showThoughtSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "إظهار أنواع المدخلات" : "Show Blog Entry Types"}</p>
              {[
                { key: "not_set", label: "Not Set" },
                { key: "idea", label: "💡 Idea" },
                { key: "poetry", label: "✍️ Poetry" },
                { key: "thought", label: "💭 Thought" },
                { key: "knowledge", label: "🧠 Knowledge" },
                { key: "concept", label: "🔮 Concept" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => {
                    const newSettings = {
                      ...thoughtSettings,
                      show: { ...thoughtSettings.show, [key]: !thoughtSettings.show[key] },
                    };
                    setThoughtSettings(newSettings);
                    setSecureStorage("thoughtSettings", newSettings);
                    window.dispatchEvent(new Event("thoughtSettingsChanged"));
                  }}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 rounded border flex items-center justify-center transition-colors", thoughtSettings.show[key] !== false ? "bg-primary border-primary" : "border-border")}>
                    {thoughtSettings.show[key] !== false && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={thoughtSettings.show[key] !== false ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
              <div className="pt-2 border-t border-border/40 space-y-1.5">
                <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "ترتيب العرض" : "Sort Order"}</p>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const newSettings = { ...thoughtSettings, sortOrder: "newest" };
                      setThoughtSettings(newSettings);
                      setSecureStorage("thoughtSettings", newSettings);
                      window.dispatchEvent(new Event("thoughtSettingsChanged"));
                    }}
                    className={cn("flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all", thoughtSettings.sortOrder === "newest" ? "bg-primary text-primary-foreground" : "bg-background border border-border text-muted-foreground")}
                  >
                    Newest
                  </button>
                  <button
                    onClick={() => {
                      const newSettings = { ...thoughtSettings, sortOrder: "oldest" };
                      setThoughtSettings(newSettings);
                      setSecureStorage("thoughtSettings", newSettings);
                      window.dispatchEvent(new Event("thoughtSettingsChanged"));
                    }}
                    className={cn("flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all", thoughtSettings.sortOrder === "oldest" ? "bg-primary text-primary-foreground" : "bg-background border border-border text-muted-foreground")}
                  >
                    Oldest
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Nav Tabs Settings */}
          <button
            onClick={() => setShowNavTabSettings(!showNavTabSettings)}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-primary text-sm">📱</span>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "إعدادات أشرطة التنقل" : "Nav Tabs Settings"}</span>
            </div>
            {showNavTabSettings ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>
          {showNavTabSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">Show / Hide Nav Tabs</p>
              {[
                { key: "home", label: "🌸 Activities · نشاطات" },
                { key: "perfumes", label: "🌸 Home · رئيسية" },
                { key: "explore", label: "🌸 Explore · اكتشف" },
                { key: "shopping", label: "🛍 Stores · متاجر" },
                { key: "progress", label: "📈 Statistics · إحصائيات" },
                { key: "goals", label: "🎯 Goals · أهداف" },
                { key: "maestro", label: "🛠️ Admin · أدمن" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => {
                    const newSettings = { ...navTabSettings, [key]: !navTabSettings[key] };
                    setNavTabSettings(newSettings);
                    setSecureStorage("navTabSettings", newSettings);
                    window.dispatchEvent(new Event("navTabSettingsChanged"));
                  }}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 rounded border flex items-center justify-center transition-colors", navTabSettings[key] !== false ? "bg-primary border-primary" : "border-border")}>
                    {navTabSettings[key] !== false && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={navTabSettings[key] !== false ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Links Settings */}
          <button
            onClick={() => setShowLinksSettings(!showLinksSettings)}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-primary text-sm">🔗</span>
              <span className="text-sm font-body font-medium">{lang === "ar" ? "إعدادات الروابط" : "Links Settings"}</span>
            </div>
            {showLinksSettings ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
          </button>

          {showLinksSettings && (
            <div className="py-2 space-y-3">
              <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "روابط تبويب العطر" : "Perfume Tab Links"}</p>
              {[
                { key: "brands", label: "🏷 Brands" },
                { key: "mixer", label: "⚗️ The Mixer" },
                { key: "culture", label: "🌸 Culture & Courtesy" },
                { key: "budget", label: "💰 Budget" },
                { key: "stores", label: "🛍 Shops & Stores" },
                { key: "lists", label: "📌 Lists" },
                { key: "blog", label: "📖 Blog" },
                { key: "perfumers", label: "👑 Perfumers" },
                { key: "notes", label: "🌿 Notes" },
                { key: "glossary", label: "📚 Glossary" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => toggleLinkSetting(key)}
                  className="w-full flex items-center gap-2 text-xs font-body"
                >
                  <div className={cn("w-4 h-4 rounded border flex items-center justify-center transition-colors", linkSettings[key] ? "bg-primary border-primary" : "border-border")}>
                    {linkSettings[key] && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  <span className={linkSettings[key] ? "text-foreground" : "text-muted-foreground"}>{label}</span>
                </button>
              ))}
            </div>
          )}

          {/* Tab Labels */}
          <button
            onClick={toggleTabLabels}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <List className="w-4 h-4 text-primary" />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "تسميات الأشرطة" : "Tab Labels"}</span>
            </div>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative", showTabLabels ? "bg-primary" : "bg-border")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showTabLabels ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* Theme-color picker — five swatches, no labels; selected gets an outline */}
          <div className="px-2 py-3 border-b border-border/40">
            <div className="flex items-center justify-center gap-3">
              {THEME_ORDER.map((key) => {
                const t = THEMES[key];
                const isSelected = themeColor === key;
                const isDefault = key === "default";
                return (
                  <button
                    key={key}
                    type="button"
                    onClick={() => {
                      setThemeColor(key);
                      setSecureStorage("themeColor", key);
                      window.dispatchEvent(new Event("themeColorChanged"));
                    }}
                    className="w-9 h-9 transition-all"
                    style={{
                      background: t.swatch,
                      border: isDefault ? `2px solid ${t.border}` : "1px solid rgba(0,0,0,0.15)",
                      outline: isSelected ? "2px solid var(--brand)" : "none",
                      outlineOffset: "2px",
                    }}
                    aria-label={key}
                  />
                );
              })}
            </div>
          </div>

          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">{lang === "ar" ? "التطبيق" : "App"}</p>

          <Link to="/progress" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <span className="text-base">📊</span>
              <div>
                <span className="text-sm font-body font-medium">{lang === "ar" ? "الإحصائيات" : "Statistics"}</span>
                <p className="text-[10px] text-muted-foreground">{lang === "ar" ? "ملخص نشاطك ومجموعتك" : "Your activity and collection summary"}</p>
              </div>
            </div>
          </Link>

          <Link to="/backup" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <CloudUpload className="w-4 h-4 text-primary" />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "النسخ و الاستعادة" : "Backup / Restore"}</span>
            </div>
          </Link>

          <button
            onClick={() => window.location.reload()}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <RefreshCw className="w-4 h-4 text-primary" />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "تحديث التطبيق" : "Refresh App"}</span>
            </div>
          </button>

          {/* Sections — show/hide app sections (e.g. Admin) */}
          <button
            onClick={toggleActivity}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-sm">📋</span>
              <div className="text-left">
                <span className="text-sm font-body font-medium">{lang === "ar" ? "قسم النشاطات" : "Activities Section"}</span>
                <p className="text-[10px] text-muted-foreground">{showActivity ? (lang === "ar" ? "ظاهر — اضغط للإخفاء" : "Visible — tap to hide") : (lang === "ar" ? "مخفي — اضغط للإظهار" : "Hidden — tap to show")}</p>
              </div>
            </div>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative flex-shrink-0", showActivity ? "bg-amber-500" : "bg-border")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showActivity ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* Admin Mode */}
          <button
            onClick={toggleMaestro}
            className="w-full flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40"
          >
            <div className="flex items-center gap-2.5">
              <span className="text-sm">🛠️</span>
              <div className="text-left">
                <span className="text-sm font-body font-medium">{lang === "ar" ? "وضع الأدمن" : "Admin Mode"}</span>
                <p className="text-[10px] text-muted-foreground">{showMaestro ? "Active — DB management enabled" : "Hidden — tap to enable"}</p>
              </div>
            </div>
            <div className={cn("w-9 h-5 rounded-none transition-colors relative flex-shrink-0", showMaestro ? "bg-amber-500" : "bg-border")}>
              <div className={cn("absolute top-0.5 w-4 h-4 rounded-none bg-white shadow transition-all", showMaestro ? "left-4" : "left-0.5")} />
            </div>
          </button>

          {/* App Info — after Admin Mode */}
          <p className="text-xs text-muted-foreground font-body uppercase tracking-wider px-1 pt-1">App</p>
          <Link to="/app-info" className="flex items-center justify-between px-2 py-3 hover:bg-secondary/30 transition-colors border-b border-border/40">
            <div className="flex items-center gap-2.5">
              <Info className="w-4 h-4 text-primary" />
              <span className="text-sm font-body font-medium">{lang === "ar" ? "عن التطبيق" : "App Info"} <span style={{ color: "#e11d48" }}>❤️</span></span>
            </div>
          </Link>

        </div>
      </SheetContent>
    </Sheet>
  );
}