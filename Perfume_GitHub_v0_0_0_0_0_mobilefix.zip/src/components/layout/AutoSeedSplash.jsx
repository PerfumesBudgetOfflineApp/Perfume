import { useEffect, useState, useRef } from 'react';
import { useLang } from "@/lib/LanguageContext";
import { apphost } from '@/api/apphostClient';
import { seedAllLocal, getExpectedSeedCounts, topUpStoriesLocal, topUpGlossaryLocal, migrateExamplePerfumeLocal, migrateNoteCategoriesLocal } from '@/lib/localSeeder';
import { ensurePerfumeTagIndexLocal } from '@/lib/perfumeTagIndex';
import { getAppName } from '@/lib/useAppName';

// Friendly labels for each entity (EN / AR)
const ENTITY_LABELS = {
  PerfumeBrand: { en: 'Brands',    ar: 'البراندات' },
  PerfumeNote:  { en: 'Notes',     ar: 'النوتات' },
  Perfumer:     { en: 'Perfumers', ar: 'العطّارون' },
  Perfume:      { en: 'Perfumes',  ar: 'العطور' },
  GlossaryTerm: { en: 'Glossary',  ar: 'المسرد' },
  Story:        { en: 'Stories',   ar: 'القصص' },
  Quote:        { en: 'Quotes',    ar: 'الاقتباسات' },
  Wisdom:       { en: 'Wisdom',    ar: 'حِكَم' },
};

// Real entities to count for the empty-DB check (Story is stored as GlossaryTerm).
const ENTITY_ORDER = ['PerfumeBrand', 'PerfumeNote', 'Perfumer', 'Perfume', 'GlossaryTerm', 'Quote', 'Wisdom'];
// Display order for the progress rows — adds the distinct "Stories" line.
const DISPLAY_ORDER = ['PerfumeBrand', 'PerfumeNote', 'Perfumer', 'Perfume', 'GlossaryTerm', 'Story', 'Quote', 'Wisdom'];

/**
 * Detects whether the local database is empty and, if so, runs the
 * built-in seeder while showing an elegant progress UI.
 *
 * Children render only AFTER seeding completes (or if data already exists).
 */
export default function AutoSeedSplash({ children }) {
  const { isAr } = useLang();
  const [phase, setPhase] = useState('checking'); // 'checking' | 'seeding' | 'done' | 'error'
  const [progress, setProgress] = useState({});
  const [overallPercent, setOverallPercent] = useState(0);
  const [error, setError] = useState(null);
  const ranOnce = useRef(false);

  useEffect(() => {
    if (ranOnce.current) return;
    ranOnce.current = true;

    // Safety net: if anything stalls during the initial check, never trap the
    // user on the splash — force the app to render after this many ms. Seeding
    // (which legitimately takes longer) sets phase to 'seeding' first and is
    // unaffected, because we only fire this while still 'checking'.
    const safetyTimer = setTimeout(() => {
      setPhase((p) => (p === 'checking' ? 'done' : p));
    }, 4000);

    (async () => {
      const startedAt = Date.now();
      // Keep the splash visible for at least this long so the message is
      // actually readable and never flashes by on a fast device.
      const MIN_VISIBLE_MS = 700;
      const settle = (fn) => {
        const elapsed = Date.now() - startedAt;
        const wait = Math.max(0, MIN_VISIBLE_MS - elapsed);
        setTimeout(fn, wait);
      };

      try {
        const stats = await getDbStats();
        const isEmpty = Object.values(stats).every((n) => n === 0);
        clearTimeout(safetyTimer); // got an answer — no longer need the net

        if (!isEmpty) {
          // إطلاق عادي: القاعدة فيها بيانات. قبل الدخول نُجري «استكمال القصص»:
          // إضافة القصص الجديدة التي جاءت مع نسخة التطبيق ولم تكن موجودة بعد
          // (لأنّ البذر الكامل لا يُعاد على قاعدة غير فارغة). الفحص سريع جداً
          // ويتخطّى فوراً إن لا جديد. لا يحذف ولا يعدّل أيّ قصّة قائمة.
          try {
            const top = await topUpStoriesLocal();
            const topTerms = await topUpGlossaryLocal();
            await migrateExamplePerfumeLocal();
            // فهرس وسوم العطور للبحث السريع في /at — يُبنى في الخلفية مرّة واحدة
            // (لا await) فلا يعيق الدخول؛ يتخطّى فوراً إن كان موجوداً ومطابقاً.
            ensurePerfumeTagIndexLocal();
            migrateNoteCategoriesLocal();
            if ((top && top.added > 0) || (topTerms && topTerms.added > 0)) {
              // أظهرنا مؤشّر تحديث قصيراً ثمّ ندخل.
              setPhase('refresh');
              await new Promise((r) => setTimeout(r, 500));
            }
          } catch { /* غير حرِج — ندخل التطبيق على أيّ حال */ }
          settle(() => setPhase('done'));
          return;
        }

        // First run (empty DB): show the waiting-with-value screen (message +
        // percentages) first, hold it for 6 seconds, then begin seeding.
        const expected = getExpectedSeedCounts();
        const initial = {};
        for (const ent of DISPLAY_ORDER) {
          initial[ent] = { current: 0, total: expected[ent] || 0, percent: 0 };
        }
        setProgress(initial);
        setOverallPercent(0);
        setPhase('welcome');
        await new Promise((r) => setTimeout(r, 2500));

        setPhase('seeding');

        await seedAllLocal((info) => {
          setProgress((prev) => ({
            ...prev,
            [info.entity]: {
              current: info.current,
              total: info.total,
              percent: info.percent,
            },
          }));
          if (typeof info.overallPercent === 'number') {
            setOverallPercent(info.overallPercent);
          }
        });

        setOverallPercent(100);
        // Force every row to 100% so the completion table reads cleanly full.
        setProgress((prev) => {
          const full = {};
          for (const ent of DISPLAY_ORDER) {
            const p = prev[ent] || { current: 0, total: 0 };
            full[ent] = { current: p.total, total: p.total, percent: 100 };
          }
          return full;
        });
        // Show the "installation complete" state, then auto-advance after 4s.
        setPhase('complete');
        // ابنِ فهرس وسوم العطور في الخلفية بعد البذر الأول (لا await).
        ensurePerfumeTagIndexLocal();
        setTimeout(() => setPhase('done'), 4000);
      } catch (e) {
        // Fail OPEN: if we can't determine DB state, never trap the user on a
        // blank/splash screen — just show the app and let it load on its own.
        console.error('Auto-seed check failed (showing app anyway):', e);
        settle(() => setPhase('done'));
      }
    })();

    return () => clearTimeout(safetyTimer);
  }, []);

  if (phase === 'done') return children;

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        zIndex: 999998,
        background: 'linear-gradient(135deg, #fafaf9 0%, #f5f5f4 100%)',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '32px 24px',
        paddingTop: 'calc(32px + env(safe-area-inset-top, 0px))',
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif',
        color: '#1c1917',
      }}
    >
      {/* Logo + title */}
      <div style={{ marginBottom: 32, textAlign: 'center' }}>
        <h1
          style={{
            fontSize: 26,
            fontWeight: 700,
            letterSpacing: '-0.02em',
            margin: 0,
            background: 'linear-gradient(135deg, #065f46, #047857)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
            backgroundClip: 'text',
          }}
        >
          {isAr ? getAppName().name_ar : getAppName().name_en}
        </h1>
        <p style={{ fontSize: 11, color: '#78716c', marginTop: 10, fontWeight: 500, maxWidth: 300, lineHeight: 1.6, paddingLeft: 8, paddingRight: 8 }}>
          {(() => {
            const m =
              phase === 'checking' ? { ar: 'جارٍ التحقق', en: 'Checking' }
              : phase === 'refresh' ? { ar: 'في طور التحديث', en: 'Refreshing' }
              : phase === 'welcome' ? { ar: 'نجهز تطبيقك: للانتظار قيمة', en: 'Preparing Your App: Waiting Has Value' }
              : phase === 'complete' ? { ar: 'اكتمل تنصيب قاعدة البيانات', en: 'Database installation complete' }
              : { ar: 'في طور الاعداد', en: 'Setting Up' };
            return (
              <>
                <span dir="rtl" style={{ display: 'block' }}>{m.ar}</span>
                <span dir="ltr" style={{ display: 'block' }}>{m.en}</span>
              </>
            );
          })()}
        </p>
      </div>

      {/* Spinner while checking/refreshing (before seeding card appears) */}
      {(phase === 'checking' || phase === 'refresh') && (
        <div style={{ marginTop: 8 }}>
          <div
            style={{
              width: 28,
              height: 28,
              border: '3px solid #e7e5e4',
              borderTopColor: '#065f46',
              borderRadius: '50%',
              animation: 'processSpin 0.8s linear infinite',
            }}
          />
          <style>{`@keyframes processSpin { to { transform: rotate(360deg); } }`}</style>
        </div>
      )}

      {/* Progress card */}
      {(phase === 'welcome' || phase === 'seeding' || phase === 'complete') && (
        <div
          style={{
            width: '100%',
            maxWidth: 380,
            background: '#ffffff',
            borderRadius: 16,
            padding: 20,
            boxShadow: '0 10px 30px -10px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.05)',
            border: '1px solid #e7e5e4',
          }}
        >
          {/* Per-entity rows */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {DISPLAY_ORDER.map((ent) => {
              const label = ENTITY_LABELS[ent];
              const p = progress[ent] || { current: 0, total: 0, percent: 0 };
              if (!p.total) return null;
              return (
                <EntityRow
                  key={ent}
                  label={isAr ? label.ar : label.en}
                  percent={p.percent}
                  current={p.current}
                  total={p.total}
                  isAr={isAr}
                />
              );
            })}
          </div>

          {/* Overall bar */}
          <div style={{ marginTop: 18, paddingTop: 16, borderTop: '1px solid #f5f5f4' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
              <span style={{ fontSize: 11, fontWeight: 600, color: '#57534e', textTransform: 'uppercase', letterSpacing: '0.08em' }}>
                {isAr ? 'الإجمالي' : 'Overall'}
              </span>
              <span style={{ fontSize: 11, fontWeight: 700, color: '#065f46' }}>{overallPercent}%</span>
            </div>
            <div style={{ height: 4, background: '#f5f5f4', borderRadius: 999, overflow: 'hidden' }}>
              <div
                style={{
                  height: '100%',
                  width: `${overallPercent}%`,
                  background: 'linear-gradient(90deg, #10b981, #065f46)',
                  transition: 'width 200ms ease-out',
                  borderRadius: 999,
                }}
              />
            </div>
          </div>

          {/* Completion line — only on the complete phase */}
          {phase === 'complete' && (
            <p style={{ marginTop: 14, textAlign: 'center', fontSize: 12, fontWeight: 700, color: '#065f46', lineHeight: 1.6 }}>
              <span dir="rtl" style={{ display: 'block' }}>تم</span>
              <span dir="ltr" style={{ display: 'block' }}>{isAr ? "تم" : "Done"}</span>
            </p>
          )}
        </div>
      )}

      {/* Footnote — both languages, small */}
      <p
        style={{
          fontSize: 9,
          color: '#a8a29e',
          marginTop: 32,
          textAlign: 'center',
          maxWidth: 320,
          lineHeight: 1.6,
          letterSpacing: '0.02em',
        }}
      >
        Waiting has value للانتظار قيمة
      </p>

      {/* Error state */}
      {phase === 'error' && (
        <div style={{ marginTop: 16, padding: 12, background: '#fef2f2', borderRadius: 8, color: '#991b1b', fontSize: 12, maxWidth: 380, textAlign: 'center' }}>
          {error}
          <br />
          <button
            type="button"
            onClick={() => window.location.reload()}
            style={{ marginTop: 8, padding: '6px 12px', background: '#991b1b', color: '#fff', border: 'none', borderRadius: 6, fontSize: 11, cursor: 'pointer' }}
          >
            {isAr ? 'إعادة المحاولة' : 'Try again'}
          </button>
        </div>
      )}
    </div>
  );
}

/** Single entity progress row — text only, no icons */
function EntityRow({ label, percent, current, total, isAr }) {
  const done = percent >= 100;
  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 5 }}>
        <span style={{ fontSize: 12, fontWeight: 600, color: '#292524' }}>
          {label}
        </span>
        <span style={{ fontSize: 11, fontWeight: 500, color: done ? '#065f46' : '#a8a29e', fontVariantNumeric: 'tabular-nums' }}>
          {done ? (isAr ? 'تم' : 'Done') : `${current}/${total}`}
        </span>
      </div>
      <div style={{ height: 3, background: '#f5f5f4', borderRadius: 999, overflow: 'hidden' }}>
        <div
          style={{
            height: '100%',
            width: `${percent}%`,
            background: done ? '#10b981' : 'linear-gradient(90deg, #34d399, #10b981)',
            transition: 'width 200ms ease-out',
            borderRadius: 999,
          }}
        />
      </div>
    </div>
  );
}

/** Quick count of records in each entity to detect a fresh install */
async function getDbStats() {
  const stats = {};
  for (const ent of ENTITY_ORDER) {
    try {
      if (!apphost?.entities?.[ent]) {
        stats[ent] = 0;
        continue;
      }
      // عدّ سريع عبر IndexedDB count (فوري، بلا جلب أو فكّ تشفير السجلات).
      // نسقط للطريقة القديمة فقط لو count غير متاحة.
      if (typeof apphost.entities[ent].count === "function") {
        stats[ent] = await apphost.entities[ent].count();
      } else {
        const sample = await apphost.entities[ent].list('-created_date', 1);
        stats[ent] = Array.isArray(sample) ? sample.length : 0;
      }
    } catch {
      stats[ent] = 0;
    }
  }
  return stats;
}
