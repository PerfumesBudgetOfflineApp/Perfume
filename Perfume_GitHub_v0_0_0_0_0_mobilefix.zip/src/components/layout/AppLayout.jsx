import { Outlet, useLocation } from "react-router-dom";
import MobileNav from "./MobileNav";
import ErrorBoundary from "@/components/ErrorBoundary";
import { useLang } from "@/lib/LanguageContext";
import { useEffect } from "react";
import { apphost } from "@/api/apphostClient";

const DEFAULT_LISTS = [
  { icon: "📦", name: "Own" },
  { icon: "🛒", name: "Wishlist" },
];

export default function AppLayout() {
  const { isAr, lang } = useLang();
  const location = useLocation();

  // Defensive: a Radix modal (e.g. the settings sheet) can leave
  // `pointer-events: none` on <body> if it re-renders mid-open — which the
  // language switch triggers. If no dialog is actually open, restore it so the
  // fixed bottom nav stays interactive.
  useEffect(() => {
    const id = setTimeout(() => {
      if (
        document.body.style.pointerEvents === "none" &&
        !document.querySelector('[role="dialog"][data-state="open"]')
      ) {
        document.body.style.pointerEvents = "";
      }
    }, 60);
    return () => clearTimeout(id);
  }, [lang, location.pathname]);

  useEffect(() => {
    // Seed default lists if they don't exist yet
    apphost.entities.CustomList.list("name").then((lists) => {
      DEFAULT_LISTS.forEach(({ icon, name }) => {
        const exists = lists.some((l) => l.name === name);
        if (!exists) {
          apphost.entities.CustomList.create({ name, icon, perfume_ids: "" });
        }
      });
    });
  }, []);

  return (
    <div className="min-h-screen bg-background font-body" dir={isAr ? "rtl" : "ltr"}>
      <main className="pb-24">
        <ErrorBoundary isAr={isAr} resetKey={location.pathname}>
          <Outlet />
        </ErrorBoundary>
      </main>
      <MobileNav />
    </div>
  );
}