import { getAppName } from "@/lib/useAppName";
import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";
import { Printer, Image, FileText } from "lucide-react";
import { captureElement } from "@/lib/captureCanvas";
import { apphost } from "@/api/apphostClient";
import { openHtmlReport, saveCanvasAsImage, downloadBlob, downscaleCanvas } from "@/lib/exportHelper";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";
import { splitMedia } from "@/components/blog/MediaSection";

const ENTRY_TYPE_LABEL = { 
  memo: "📝 Memo", 
  not_set: "Not Set",
  perfume: "🌹 Perfume",
  music: "🎵 Music",
  tv: "📺 TV",
  films: "🎬 Films",
  idea: "💡 Idea",
  poetry: "✍️ Poetry", 
  thought: "💭 Thought",
  knowledge: "🧠 Knowledge",
  concept: "🔮 Concept"
};

export default function BlogExportDialog({ post, open, onClose, personName }) {
  const [includeBody, setIncludeBody] = useState(true);
  const [includeMedia, setIncludeMedia] = useState(true);
  const [includeLinks, setIncludeLinks] = useState(true);
  const [includeTags, setIncludeTags] = useState(true);
  const [exporting, setExporting] = useState(false);
  const [bgColor, setBgColor] = useState("#ffffff");
  const [textColor, setTextColor] = useState("#1a1a1a");
  const [fontSize, setFontSize] = useState("16");
  const [includeMark, setIncludeMark] = useState(true);
  const [userMark, setUserMark] = useState("");
  const [addGoldenFrame, setAddGoldenFrame] = useState(true);
  const [orientation, setOrientation] = useState("portrait");
  const [includeDate, setIncludeDate] = useState(false);
  const [includeType, setIncludeType] = useState(true);
  const [includeUser, setIncludeUser] = useState(true);
  const [alignment, setAlignment] = useState("center");
  const [hideAppName, setHideAppName] = useState(true);
  const previewRef = useRef(null);

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("name"),
  });

  const { data: perfumers = [] } = useQuery({
    queryKey: ["perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  useEffect(() => {
    if (open) {
      apphost.auth.me().then((user) => {
        if (user?.mark) setUserMark(user.mark);
      });
    }
  }, [open]);

  if (!post) return null;

  const tags = post.tags ? post.tags.split(",").map((t) => t.trim()).filter(Boolean) : [];
  const mediaUrls = splitMedia(post.media_urls);
  const hasLinks = post.linked_perfume_name || post.linked_brand_name || post.linked_perfumer_name || post.linked_notes;

  const handlePrint = async () => {
    const el = previewRef.current;
    if (!el) return;
    await openHtmlReport(`<html><head><title>${post.title}</title>
      <meta charset="UTF-8" />
      <style>
        * { margin: 0; padding: 0; }
        body { 
          font-family: 'Segoe UI', 'Arial', 'Droid Sans Arabic', 'Tahoma', sans-serif; 
          padding: 40px; 
          max-width: 900px; 
          margin: auto; 
          color: ${textColor}; 
          background-color: ${bgColor};
          line-height: 1.6;
          direction: auto;
        }
        h1 { font-size: 28px; margin-bottom: 8px; font-weight: 600; }
        .meta { font-size: 13px; color: #666; margin-bottom: 20px; }
        .body { font-size: ${fontSize}px; line-height: 1.8; white-space: pre-wrap; margin-bottom: 16px; direction: auto; }
        .tags { margin-bottom: 12px; }
        .tags span { display: inline-block; background: #f5f5f5; border-radius: 20px; padding: 4px 12px; font-size: 12px; margin-right: 6px; margin-bottom: 4px; }
        .links { margin-top: 16px; font-size: 13px; color: #555; border-top: 1px solid #ddd; padding-top: 12px; direction: auto; }
        .links div { margin-bottom: 6px; }
        img { max-width: 100%; border-radius: 8px; margin: 12px 0; }
        .mark { font-size: 24px; font-weight: bold; text-align: center; margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; }
        @media print { 
          body { padding: 20px; }
          h1 { page-break-after: avoid; }
        }
      </style>
    </head><body>${el.innerHTML}</body></html>`);
    // User triggers print via the overlay's built-in Print button — no auto-print.
  };

  const captureCanvas = async (scale = 2) => {
    const el = previewRef.current;
    // Temporarily remove ALL clipping constraints
    const originalStyle = el.style.cssText;
    const parentEl = el.parentElement;
    const originalParentStyle = parentEl ? parentEl.style.cssText : "";
    el.style.cssText = "";
    el.style.position = "fixed";
    el.style.left = "0";
    el.style.top = "0";
    el.style.zIndex = "-1";
    el.style.opacity = "1";
    el.style.pointerEvents = "none";
    el.style.width = orientation === "landscape" ? "1122px" : "794px"; // A4 px at 96dpi
    if (parentEl) {
      parentEl.style.overflow = "visible";
      parentEl.style.maxHeight = "none";
    }
    // Wait for reflow
    await new Promise(r => setTimeout(r, 100));
    const canvas = await captureElement(el, {
      scale,
      useCORS: true,
      backgroundColor: addGoldenFrame ? "#d4af37" : bgColor,
      logging: false,
      allowTaint: true,
      height: el.scrollHeight,
      width: el.scrollWidth,
    });
    el.style.cssText = originalStyle;
    if (parentEl) parentEl.style.cssText = originalParentStyle;
    return canvas;
  };

  const handleExportPDF = async () => {
    setExporting(true);
    const canvas = await captureCanvas(2);
    const imgData = canvas.toDataURL("image/png");
    const isLandscape = orientation === "landscape";
    // page dimensions
    const pageW = isLandscape ? 297 : 210;
    const pageH = isLandscape ? 210 : 297;
    const imgRatio = canvas.height / canvas.width;
    const imgW = pageW;
    const imgH = imgW * imgRatio;
    const { jsPDF } = await import("jspdf");
    const pdf = new jsPDF({
      orientation,
      unit: "mm",
      format: [pageW, Math.max(imgH, pageH)],
    });
    pdf.addImage(imgData, "PNG", 0, 0, imgW, imgH);
    const fileName = post.title.replace(/\s+/g, "_").replace(/[^\w-]/g, "");
    // pdf.output('blob') so we can use our cross-platform downloadBlob.
    // pdf.save() falls back to <a download> which doesn't trigger on Android WebView.
    const blob = pdf.output('blob');
    await downloadBlob(blob, `${fileName || "export"}.pdf`);
    setExporting(false);
  };

  const handleExportImage = async () => {
    setExporting(true);
    let canvas = await captureCanvas(1);
    canvas = downscaleCanvas(canvas, 1080); // keep export image ≤1080px wide
    const fileName = post.title.replace(/\s+/g, "_").replace(/[^\w-]/g, "");
    await saveCanvasAsImage(canvas, `${fileName || "export"}.png`);
    setExporting(false);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm rounded-none max-h-[92vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">تصدير / طباعة Export / Print</DialogTitle>
        </DialogHeader>
          <ExportOptionsBar />

        {/* Options */}
         <div className="space-y-3">
           <div>
             <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-2">تضمين في التصدير Include in export</p>
             <div className="space-y-2">
               <p className="text-[10px] font-heading font-semibold text-muted-foreground">Meta Data:</p>
               {[
                 { label: "Date", val: includeDate, set: setIncludeDate },
                 { label: "Type", val: includeType, set: setIncludeType },
                 { label: "User", val: includeUser, set: setIncludeUser },
               ].map(({ label, val, set }) => (
                 <label key={label} className="flex items-center gap-3 px-3 py-2 bg-secondary/50 rounded-none cursor-pointer">
                   <input type="checkbox" checked={val} onChange={(e) => set(e.target.checked)} className="w-4 h-4 accent-primary" />
                   <span className="text-xs font-body">{label}</span>
                 </label>
               ))}
             </div>
             <div className="space-y-2">
               <p className="text-[10px] font-heading font-semibold text-muted-foreground">Content:</p>
               {[
                 { label: "Body / Content", val: includeBody, set: setIncludeBody },
                 { label: "Tags", val: includeTags, set: setIncludeTags },
                 { label: "Media (images)", val: includeMedia, set: setIncludeMedia },
                 { label: "Linked items", val: includeLinks, set: setIncludeLinks },
               ].map(({ label, val, set }) => (
                 <label key={label} className="flex items-center gap-3 px-3 py-2 bg-secondary/50 rounded-none cursor-pointer">
                   <input type="checkbox" checked={val} onChange={(e) => set(e.target.checked)} className="w-4 h-4 accent-primary" />
                   <span className="text-xs font-body">{label}</span>
                 </label>
               ))}
             </div>
             <div className="space-y-2">
              <p className="text-[10px] font-heading font-semibold text-muted-foreground">Footer:</p>
              <label className="flex items-center gap-3 px-3 py-2 bg-secondary/50 rounded-none cursor-pointer">
                <input type="checkbox" checked={includeMark} onChange={(e) => setIncludeMark(e.target.checked)} className="w-4 h-4 accent-primary" />
                <span className="text-xs font-body">My Mark / Signature</span>
              </label>
              <label className="flex items-center gap-3 px-3 py-2 bg-secondary/50 rounded-none cursor-pointer">
                <input type="checkbox" checked={hideAppName} onChange={(e) => setHideAppName(e.target.checked)} className="w-4 h-4 accent-primary" />
                <span className="text-xs font-body">إخفاء اسم التطبيق Hide App Name</span>
              </label>
             </div>
           </div>

           {/* Formatting Options */}
           <div>
             <label className="flex items-center gap-3 px-3 py-2 bg-secondary/50 rounded-none cursor-pointer mb-2">
               <input type="checkbox" checked={addGoldenFrame} onChange={(e) => setAddGoldenFrame(e.target.checked)} className="w-4 h-4 accent-amber-500" />
               <span className="text-xs font-body">✨ Add Golden Frame</span>
             </label>

             <div className="mb-2">
               <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1.5">الاتجاه Orientation</p>
               <div className="flex gap-2">
                 <button
                   onClick={() => setOrientation("portrait")}
                   className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                     orientation === "portrait"
                       ? "bg-primary text-primary-foreground shadow"
                       : "bg-secondary text-muted-foreground hover:text-foreground"
                   }`}
                 >
                   📄 Portrait
                 </button>
                 <button
                   onClick={() => setOrientation("landscape")}
                   className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                     orientation === "landscape"
                       ? "bg-primary text-primary-foreground shadow"
                       : "bg-secondary text-muted-foreground hover:text-foreground"
                   }`}
                 >
                   🖥 Landscape
                 </button>
               </div>
             </div>

             <div className="mb-2">
               <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-1.5">محاذاة البطاقة Card Alignment</p>
               <div className="flex gap-2">
                 <button
                   onClick={() => setAlignment("right")}
                   className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                     alignment === "right"
                       ? "bg-primary text-primary-foreground shadow"
                       : "bg-secondary text-muted-foreground hover:text-foreground"
                   }`}
                 >
                   → Right
                 </button>
                 <button
                   onClick={() => setAlignment("center")}
                   className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                     alignment === "center"
                       ? "bg-primary text-primary-foreground shadow"
                       : "bg-secondary text-muted-foreground hover:text-foreground"
                   }`}
                 >
                   ↔ Center
                 </button>
                 <button
                   onClick={() => setAlignment("left")}
                   className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                     alignment === "left"
                       ? "bg-primary text-primary-foreground shadow"
                       : "bg-secondary text-muted-foreground hover:text-foreground"
                   }`}
                 >
                   ← Left
                 </button>
               </div>
             </div>

             <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body mb-2">التنسيق Formatting</p>

             <div className="space-y-2">
               <div>
                 <label className="text-[10px] text-muted-foreground font-body uppercase">لون الخلفية Background Color</label>
                 <div className="flex gap-2 mt-1">
                   {["#ffffff", "#f3f4f6", "#fef3c7", "#f0fdf4", "#f0f9ff"].map((color) => (
                     <button
                       key={color}
                       onClick={() => setBgColor(color)}
                       className={`w-6 h-6 rounded border-2 transition-all ${bgColor === color ? "border-primary shadow-md" : "border-border"}`}
                       style={{ backgroundColor: color }}
                       title={color}
                     />
                   ))}
                   <input
                     type="color"
                     value={bgColor}
                     onChange={(e) => setBgColor(e.target.value)}
                     className="w-6 h-6 rounded cursor-pointer"
                   />
                 </div>
               </div>

               <div>
                 <label className="text-[10px] text-muted-foreground font-body uppercase">لون النص Text Color</label>
                 <div className="flex gap-2 mt-1">
                   {["#1a1a1a", "#374151", "#6b7280", "#1e3a8a"].map((color) => (
                     <button
                       key={color}
                       onClick={() => setTextColor(color)}
                       className={`w-6 h-6 rounded border-2 transition-all ${textColor === color ? "border-primary shadow-md" : "border-border"}`}
                       style={{ backgroundColor: color }}
                       title={color}
                     />
                   ))}
                   <input
                     type="color"
                     value={textColor}
                     onChange={(e) => setTextColor(e.target.value)}
                     className="w-6 h-6 rounded cursor-pointer"
                   />
                 </div>
               </div>

               <div>
                 <label className="text-[10px] text-muted-foreground font-body uppercase">حجم الخط Font Size</label>
                 <select
                   value={fontSize}
                   onChange={(e) => setFontSize(e.target.value)}
                   className="w-full px-2 py-1.5 rounded-none border border-input bg-transparent text-xs mt-1"
                 >
                   <option value="14">Small (14px)</option>
                   <option value="16">Normal (16px)</option>
                   <option value="18">Large (18px)</option>
                   <option value="20">Extra Large (20px)</option>
                 </select>
               </div>
             </div>
           </div>
         </div>

        {/* Hidden preview div that gets rendered to canvas/print */}
         <div className="mt-3 border border-border rounded-none overflow-hidden max-h-96 overflow-y-auto">
           <p className="text-[10px] text-muted-foreground font-body px-3 pt-2 sticky top-0 bg-secondary/50">معاينة Preview</p>
           {/* Outer wrapper = golden frame (rendered as solid background padding) */}
           <div ref={previewRef} style={{
             background: addGoldenFrame ? "#d4af37" : bgColor,
             padding: addGoldenFrame ? "12px" : "0",
           }}>
           <div style={{ 
             padding: "40px", 
             background: bgColor, 
             color: textColor, 
             fontFamily: "'Segoe UI', 'Droid Sans Arabic', Arial, sans-serif", 
             direction: "auto",
             boxShadow: addGoldenFrame ? "inset 0 0 30px rgba(212, 175, 55, 0.25)" : "none",
             textAlign: alignment === "center" ? "center" : alignment === "right" ? "right" : "left"
           }}>
             <div style={{ fontSize: "13px", color: textColor, marginBottom: "8px", opacity: 0.7 }}>
               {includeType && <span>{ENTRY_TYPE_LABEL[post.entry_type] || "Thought"}</span>}
               {includeType && includeUser && <span> · </span>}
               {includeUser && <span>{personName}</span>}
               {(includeType || includeUser) && includeDate && <span> · </span>}
               {includeDate && <span>{format(new Date(post.created_date), "dd MMM yyyy")}</span>}
             </div>
             <h1 style={{ fontSize: "28px", fontWeight: "600", marginBottom: "16px", lineHeight: 1.2, direction: "auto", wordBreak: "break-word" }}>{post.title}</h1>
             {includeBody && (
               <p style={{ fontSize: `${fontSize}px`, lineHeight: "1.8", whiteSpace: "pre-wrap", marginBottom: "16px", direction: "auto", wordBreak: "break-word" }}>{post.body}</p>
             )}
             {includeTags && tags.length > 0 && (
               <div style={{ marginBottom: "12px", direction: "auto" }}>
                 {tags.map((t) => (
                   <span key={t} style={{ display: "inline-block", background: "rgba(0,0,0,0.1)", borderRadius: "20px", padding: "4px 12px", fontSize: "12px", marginRight: "6px", marginBottom: "4px" }}>@{t}</span>
                 ))}
               </div>
             )}
             {includeMedia && mediaUrls.length > 0 && (
               <div style={{ marginBottom: "16px" }}>
                 {mediaUrls.map((url, i) => (
                   <img key={i} src={url} alt="" style={{ maxWidth: "100%", borderRadius: "8px", marginBottom: "8px" }} crossOrigin="anonymous" />
                 ))}
               </div>
             )}
             {includeLinks && hasLinks && (
               <div style={{ fontSize: "13px", color: textColor, borderTop: `1px solid ${textColor}22`, paddingTop: "12px", marginTop: "12px", direction: "auto" }}>
                 <div style={{ marginBottom: "12px", fontWeight: "600" }}>Related ارتباط</div>
                 {post.linked_perfume_name && (
                   <div style={{ marginBottom: "8px" }}>
                     <div style={{ fontSize: "11px", fontWeight: "600", color: textColor, opacity: 0.7, marginBottom: "4px", textTransform: "uppercase" }}>🌹 Perfume عطر</div>
                     <div style={{ marginLeft: "12px" }}>{post.linked_perfume_name}</div>
                   </div>
                 )}
                 {post.linked_perfumer_name && (
                   <div style={{ marginBottom: "8px" }}>
                     <div style={{ fontSize: "11px", fontWeight: "600", color: textColor, opacity: 0.7, marginBottom: "4px", textTransform: "uppercase" }}>👤 Perfumer عطار</div>
                     <div style={{ marginLeft: "12px" }}>{post.linked_perfumer_name}</div>
                   </div>
                 )}
                 {post.linked_notes && (
                   <div>
                     <div style={{ fontSize: "11px", fontWeight: "600", color: textColor, opacity: 0.7, marginBottom: "4px", textTransform: "uppercase" }}>🌿 Note نوتة</div>
                     <div style={{ marginLeft: "12px" }}>{post.linked_notes}</div>
                   </div>
                 )}
               </div>
             )}
             {includeMark && userMark && (
              <div style={{ fontSize: "24px", fontWeight: "bold", textAlign: "center", marginTop: "20px", paddingTop: "20px", borderTop: `1px solid ${textColor}22` }}>
                {userMark}
              </div>
             )}
             {!hideAppName && (
               <div style={{ fontSize: "10px", color: textColor, opacity: 0.4, textAlign: "center", marginTop: "12px", fontFamily: "sans-serif" }}>
                 {getAppName().name_en} · {getAppName().name_ar}
               </div>
             )}
             </div>{/* end inner content */}
             </div>{/* end frame wrapper */}
             </div>

        {/* Actions */}
        <div className="flex gap-2 pt-1">
          <Button variant="outline" size="sm" className="flex-1 rounded-none font-body text-xs h-9" onClick={handlePrint}>
            <Printer className="w-3.5 h-3.5" /> Print
          </Button>
          <Button variant="outline" size="sm" className="flex-1 rounded-none font-body text-xs h-9" onClick={handleExportPDF} disabled={exporting}>
            <FileText className="w-3.5 h-3.5" /> PDF
          </Button>
          <Button variant="outline" size="sm" className="flex-1 rounded-none font-body text-xs h-9" onClick={handleExportImage} disabled={exporting}>
            <Image className="w-3.5 h-3.5" /> Photo
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}