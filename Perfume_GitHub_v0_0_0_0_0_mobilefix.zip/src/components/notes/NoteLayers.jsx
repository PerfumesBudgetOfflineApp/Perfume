import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Trash2, Save } from "lucide-react";

const NOTE_CATEGORIES = {
  main_note: { label: "Main Notes", emoji: "🌟", color: "bg-amber-50 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/50" },
  sub_notes: { label: "Sub Notes", emoji: "✨", color: "bg-rose-50 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/50" },
  other_notes: { label: "Other Notes", emoji: "🌸", color: "bg-sky-50 dark:bg-sky-950/30 border-sky-200 dark:border-sky-900/50" },
};

export default function NoteLayers() {
  const { isAr } = useLang();
  const queryClient = useQueryClient();
  const [layerName, setLayerName] = useState("");
  const [layers, setLayers] = useState({ main_note: [], sub_notes: [], other_notes: [] });
  const [draggedNote, setDraggedNote] = useState(null);

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  // Group notes by category
  const notesByCategory = useMemo(() => {
    const grouped = { main_note: [], sub_notes: [], other_notes: [] };
    notes.forEach((note) => {
      const cat = note.note_category || "main_note";
      if (grouped[cat]) grouped[cat].push(note);
    });
    return grouped;
  }, [notes]);

  // Create custom layer
  const saveMutation = useMutation({
    mutationFn: async () => {
      if (!layerName.trim()) {
        toast.error((isAr ? "أدخل اسم الطبقة" : "Please enter a layer name"));
        return;
      }
      const layerData = {
        name: layerName,
        main_note_ids: layers.main_note.map(n => n.id).join(","),
        main_note_names: layers.main_note.map(n => n.name).join(", "),
        sub_note_ids: layers.sub_notes.map(n => n.id).join(","),
        sub_note_names: layers.sub_notes.map(n => n.name).join(", "),
        other_note_ids: layers.other_notes.map(n => n.id).join(","),
        other_note_names: layers.other_notes.map(n => n.name).join(", "),
      };
      await apphost.entities.CustomLayer?.create(layerData) || apphost.functions.invoke("saveCustomLayer", layerData);
    },
    onSuccess: () => {
      toast.success((isAr ? "حُفظت الطبقة" : "Layer saved"));
      setLayerName("");
      setLayers({ main_note: [], sub_notes: [], other_notes: [] });
      queryClient.invalidateQueries({ queryKey: ["custom-layers"] });
    },
  });

  const handleDragStart = (note, category) => {
    setDraggedNote({ note, fromCategory: category });
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (toCategory) => {
    if (!draggedNote) return;
    const { note, fromCategory } = draggedNote;

    if (fromCategory === toCategory) {
      setDraggedNote(null);
      return;
    }

    // Remove from old category
    if (fromCategory) {
      setLayers({
        ...layers,
        [fromCategory]: layers[fromCategory].filter(n => n.id !== note.id),
      });
    }

    // Add to new category
    setLayers({
      ...layers,
      [toCategory]: [...layers[toCategory], note],
    });

    setDraggedNote(null);
  };

  const handleRemoveNote = (category, noteId) => {
    setLayers({
      ...layers,
      [category]: layers[category].filter(n => n.id !== noteId),
    });
  };

  const totalNotes = layers.main_note.length + layers.sub_notes.length + layers.other_notes.length;

  return (
    <div className="space-y-4">
      {/* Palette - Available notes */}
      <div className="bg-card rounded-none p-4 space-y-3 border border-border/50">
        <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">{isAr ? "النوتات المتاحة" : "Available Notes"}</p>
        <div className="space-y-3">
          {Object.entries(notesByCategory).map(([category, categoryNotes]) => (
            <div key={category} className="space-y-2">
              <p className="text-xs font-body font-medium text-foreground/70">{NOTE_CATEGORIES[category].label}</p>
              <div className="flex flex-wrap gap-2">
                {categoryNotes.slice(0, 15).map((note) => (
                  <button
                    key={note.id}
                    draggable
                    onDragStart={() => handleDragStart(note, null)}
                    className=" rounded-none text-xs font-body font-medium cursor-grab active:cursor-grabbing transition-colors"
                  >
                    {note.name}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Drop zones - Layer builder */}
      <div className="space-y-3">
        {Object.entries(NOTE_CATEGORIES).map(([category, { label, emoji, color }]) => (
          <div
            key={category}
            onDragOver={handleDragOver}
            onDrop={() => handleDrop(category)}
            className={`border-2 border-dashed rounded-none p-4 min-h-[120px] transition-colors ${color} flex flex-col`}
          >
            <div className="flex items-center gap-2 mb-3">
              <span className="text-2xl">{emoji}</span>
              <p className="text-sm font-body font-semibold">{label}</p>
              <span className="text-xs text-muted-foreground font-body">({layers[category].length})</span>
            </div>
            <div className="flex flex-wrap gap-2 flex-1">
              {layers[category].length === 0 ? (
                <p className="text-xs text-muted-foreground font-body flex items-center h-full">{isAr ? "اسحب النوتات هنا" : "Drag notes here..."}</p>
              ) : (
                layers[category].map((note) => (
                  <div
                    key={note.id}
                    draggable
                    onDragStart={() => handleDragStart(note, category)}
                    className="flex items-center gap-2 px-3 py-1.5 rounded-none bg-white/60 dark:bg-black/20 border border-current/30 group cursor-grab active:cursor-grabbing hover:shadow-md transition-all"
                  >
                    <span className="text-sm font-body font-medium text-foreground">{note.name}</span>
                    <button
                      onClick={() => handleRemoveNote(category, note.id)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-3 h-3 text-destructive hover:text-destructive/80" />
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Save layer */}
      {totalNotes > 0 && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 space-y-3">
          <p className="text-sm font-body font-semibold">{isAr ? "حفظ طبقة مخصّصة" : "Save Custom Layer"}</p>
          <Input
            value={layerName}
            onChange={(e) => setLayerName(e.target.value)}
            placeholder="e.g. Summer Blend, Rose Garden..."
            className="rounded-none font-body"
          />
          <Button
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending || !layerName.trim()}
            className="w-full rounded-none font-body gap-2"
          >
            <Save className="w-4 h-4" /> Save Layer ({totalNotes} notes)
          </Button>
        </div>
      )}
    </div>
  );
}