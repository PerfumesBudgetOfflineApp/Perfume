import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { usePersonNames } from "@/lib/usePersonNames";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Sparkles, RefreshCw, AlertTriangle } from "lucide-react";

export default function AIRecommendations() {
  const { names } = usePersonNames();
  const navigate = useNavigate();
  const [activePerson, setActivePerson] = useState("person1");
  const [recommendations, setRecommendations] = useState(null);
  const [loading, setLoading] = useState(false);

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes-ai"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const queryClient = useQueryClient();

  const getRecommendations = async () => {
    setLoading(true);
    setRecommendations(null);

    // الكتالوج الكامل (130 ألف) يُحمّل عند الطلب فقط — لا عند فتح الصفحة (تسريع التصفّح).
    const allPerfumes = await queryClient.fetchQuery({
      queryKey: ["perfumes"],
      queryFn: () => apphost.entities.Perfume.list("-created_date"),
      staleTime: 1000 * 60 * 5,
    });

    const myPerfumes = userPerfumes.filter(u => u.person === activePerson);

    // Positive perfumes (loved/liked/highly rated)
    const positives = myPerfumes.filter(u =>
      u.other_rating === "love_it" || u.other_rating === "like_it" ||
      u.list === "favorite" || (u.rating && u.rating >= 4)
    );

    // Perfumes causing health issues
    const badHealth = myPerfumes.filter(u =>
      (u.headache && u.headache !== "none") ||
      (u.sinus_sensitivity && u.sinus_sensitivity === "yes")
    );

    // Disliked perfumes
    const negatives = myPerfumes.filter(u =>
      u.other_rating === "hate_it" || u.impression === "not_great" || u.list === "dislike"
    );

    // Extract notes from positive perfumes
    const positivePerfumeIds = positives.map(u => u.perfume_id);
    const positivePerfumeData = allPerfumes.filter(p => positivePerfumeIds.includes(p.id));

    // Extract notes from health-problematic perfumes
    const badPerfumeIds = badHealth.map(u => u.perfume_id);
    const badPerfumeData = allPerfumes.filter(p => badPerfumeIds.includes(p.id));

    // Collect liked brands
    const likedBrands = [...new Set(positives.map(u => u.brand_name).filter(Boolean))];

    // Collect liked notes from positive perfumes
    const likedNotes = [...new Set(
      positivePerfumeData.flatMap(p => [
        ...(p.top_notes || "").split(","),
        ...(p.heart_notes || "").split(","),
        ...(p.base_notes || "").split(","),
      ].map(n => n.trim()).filter(Boolean))
    )];

    // Collect notes to avoid
    const avoidNotes = [...new Set(
      badPerfumeData.flatMap(p => [
        ...(p.top_notes || "").split(","),
        ...(p.heart_notes || "").split(","),
        ...(p.base_notes || "").split(","),
      ].map(n => n.trim()).filter(Boolean))
    )];

    // Odor families liked
    const likedOdorFamilies = [...new Set(
      positivePerfumeData.map(p => p.odor_family).filter(Boolean).flatMap(f => f.split(",").map(s => s.trim()))
    )];

    // Perfumes already in collection
    const alreadyOwnedIds = myPerfumes.map(u => u.perfume_id);
    const alreadyOwnedNames = myPerfumes.map(u => u.perfume_name).filter(Boolean);

    // Perfumes to explicitly exclude (bad health)
    const avoidPerfumeNames = badHealth.map(u => u.perfume_name).filter(Boolean);
    const negativePerfumeNames = negatives.map(u => u.perfume_name).filter(Boolean);

    // Candidate perfumes not yet owned
    const candidates = allPerfumes
      .filter(p => !alreadyOwnedIds.includes(p.id))
      .slice(0, 150)
      .map(p => `${p.name_en || p.name_ar} by ${p.brand_name} (${p.gender || ""}, ${p.odor_family || ""}, notes: ${[p.top_notes, p.heart_notes, p.base_notes].filter(Boolean).join(", ")})`)
      .join("\n");

    const prompt = `You are a professional perfumer and fragrance advisor. 
    
The user (${activePerson === "person1" ? names.person1 : names.person2}) has the following fragrance profile:

LOVED PERFUMES (high rated or favorited): ${positives.map(u => u.perfume_name).join(", ") || "None"}
LIKED FRAGRANCE NOTES: ${likedNotes.slice(0, 20).join(", ") || "Unknown"}
PREFERRED ODOR FAMILIES: ${likedOdorFamilies.join(", ") || "Unknown"}
PREFERRED BRANDS: ${likedBrands.slice(0, 10).join(", ") || "Unknown"}

AVOID - CAUSED HEADACHE OR SINUS ISSUES: ${avoidPerfumeNames.join(", ") || "None"}
AVOID - NOTES FROM PROBLEMATIC PERFUMES: ${avoidNotes.slice(0, 15).join(", ") || "None"}
DISLIKED PERFUMES: ${negativePerfumeNames.join(", ") || "None"}
ALREADY IN COLLECTION: ${alreadyOwnedNames.slice(0, 20).join(", ") || "None"}

AVAILABLE PERFUMES TO RECOMMEND FROM:
${candidates || "General catalog"}

Please recommend exactly 5 perfumes from the available list above that would suit this user's taste profile. For each recommendation:
1. Pick perfumes with similar notes/families to what they love
2. STRICTLY avoid perfumes with notes similar to those causing headaches/sinus issues
3. Do NOT recommend perfumes already in their collection

Respond in this JSON format only:
{
  "profile_summary": "2-sentence summary of their taste profile in English",
  "recommendations": [
    {
      "name": "Perfume Name",
      "brand": "Brand Name",
      "reason": "Why this suits them (1-2 sentences)",
      "notes_highlight": "Key notes they'd love",
      "health_safe": true
    }
  ],
  "notes_to_explore": ["note1", "note2", "note3"],
  "avoid_warning": "Brief note about what to be careful of health-wise"
}`;

    const result = await apphost.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: {
        type: "object",
        properties: {
          profile_summary: { type: "string" },
          recommendations: {
            type: "array",
            items: {
              type: "object",
              properties: {
                name: { type: "string" },
                brand: { type: "string" },
                reason: { type: "string" },
                notes_highlight: { type: "string" },
                health_safe: { type: "boolean" },
              }
            }
          },
          notes_to_explore: { type: "array", items: { type: "string" } },
          avoid_warning: { type: "string" },
        }
      }
    });

    setRecommendations(result);
    setLoading(false);
  };

  const personRecommendations = recommendations;

  return (
    <div className="space-y-4">
      {/* Person Selector */}
      <div className="flex gap-2 bg-secondary/50 p-1 rounded-none">
        <button
          onClick={() => { setActivePerson("person1"); setRecommendations(null); }}
          className={`flex-1 py-2 rounded-none text-xs font-body font-semibold transition-all ${activePerson === "person1" ? "bg-card shadow text-primary" : "text-muted-foreground"}`}>
          {names.person1}
        </button>
        <button
          onClick={() => { setActivePerson("person2"); setRecommendations(null); }}
          className={`flex-1 py-2 rounded-none text-xs font-body font-semibold transition-all ${activePerson === "person2" ? "bg-card shadow text-violet-500" : "text-muted-foreground"}`}>
          {names.person2}
        </button>
      </div>

      {/* Generate Button */}
      <Button
        onClick={getRecommendations}
        disabled={loading}
        className="w-full h-12 rounded-none font-body gap-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white border-0"
      >
        {loading ? (
          <><RefreshCw className="w-4 h-4 animate-spin" /> Analyzing your taste profile...</>
        ) : (
          <><Sparkles className="w-4 h-4" /> Get AI Recommendations</>
        )}
      </Button>

      {loading && (
        <div className="bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900/50 rounded-none p-5 text-center space-y-2">
          <div className="flex justify-center"><div className="w-8 h-8 border-4 border-purple-300 border-t-purple-600 rounded-full animate-spin" /></div>
          <p className="text-sm font-body text-purple-700 dark:text-purple-300">Analyzing your fragrance preferences, health data, and taste profile...</p>
        </div>
      )}

      {personRecommendations && !loading && (
        <div className="space-y-4">
          {/* Profile Summary */}
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-950/30 dark:to-indigo-950/30 border border-purple-200 dark:border-purple-800/50 rounded-none p-4 space-y-2">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-purple-600" />
              <p className="text-xs font-body font-semibold text-purple-700 dark:text-purple-300 uppercase tracking-wider">ملف ذوقك Your Taste Profile</p>
            </div>
            <p className="text-sm font-body text-foreground/80 leading-relaxed">{personRecommendations.profile_summary}</p>
          </div>

          {/* Health Warning */}
          {personRecommendations.avoid_warning && (
            <div className="bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800/50 rounded-none p-3 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <p className="text-xs font-body text-amber-800 dark:text-amber-200 leading-relaxed">{personRecommendations.avoid_warning}</p>
            </div>
          )}

          {/* Recommendations */}
          <div className="space-y-3">
            <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">موصى به لك Recommended For You</p>
            {(personRecommendations.recommendations || []).map((rec, i) => (
              <div key={i} className="bg-card border border-border/50 rounded-none p-4 shadow-sm space-y-2">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="font-heading font-bold text-sm leading-tight">{rec.name}</p>
                    <p className="text-xs text-muted-foreground font-body">{rec.brand}</p>
                  </div>
                  <div className="flex items-center gap-1.5 flex-shrink-0">
                    <span className="text-[10px] text-purple-700 dark:text-purple-300 rounded-none font-body font-semibold">#{i + 1}</span>
                    {rec.health_safe && <span className="text-[10px] text-emerald-700 dark:text-emerald-300 rounded-none font-body font-semibold">آمن Safe</span>}
                  </div>
                </div>
                {rec.notes_highlight && (
                  <p className="text-[11px] text-primary font-body font-medium">🎵 {rec.notes_highlight}</p>
                )}
                <p className="text-xs font-body text-foreground/70 leading-relaxed">{rec.reason}</p>
                <button
                  onClick={() => navigate(`/explore?q=${encodeURIComponent(rec.name)}`)}
                  className="text-[10px] font-body font-semibold text-primary hover:underline"
                >
                  Search in catalog →
                </button>
              </div>
            ))}
          </div>

          {/* Notes to Explore */}
          {personRecommendations.notes_to_explore?.length > 0 && (
            <div className="bg-card rounded-none p-4 border border-border/50 space-y-2">
              <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider">نوتات لاستكشافها Notes to Explore</p>
              <div className="flex flex-wrap gap-2">
                {personRecommendations.notes_to_explore.map((note, i) => (
                  <span key={i} className="text-xs text-indigo-700 dark:text-indigo-300 rounded-none font-body font-medium">
                    {note}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!personRecommendations && !loading && (
        <div className="text-center py-12 space-y-3 bg-card rounded-none border border-border/50">
          <p className="text-4xl">🤖</p>
          <p className="font-heading font-semibold">مستشار العطور الذكي AI Perfume Advisor</p>
          <p className="text-sm font-body text-muted-foreground px-6 leading-relaxed">
            Tap the button above to get personalized recommendations based on your taste profile, favorite notes, and health sensitivity data.
          </p>
        </div>
      )}
    </div>
  );
}