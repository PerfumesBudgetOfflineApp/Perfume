import { useState } from "react";
import { apphost } from "@/api/apphostClient";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Search, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";

export default function StoreSelector({ value, onChange, onAddNew }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [newStoreOpen, setNewStoreOpen] = useState(false);
  const [newStore, setNewStore] = useState({ name: "", website: "", logo_url: "" });
  const [isCreating, setIsCreating] = useState(false);
  const qc = useQueryClient();

  const { data: stores = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });

  const filtered = stores.filter((s) =>
    (s.name || s.name_ar || "").toLowerCase().includes(search.toLowerCase())
  );

  const selectedStore = value ? stores.find((s) => String(s.id) === String(value)) : null;

  const handleAddStore = async () => {
    if (!newStore.name.trim()) return;
    try {
      setIsCreating(true);
      const created = await apphost.entities.ShopBrand.create({
        name: newStore.name,
        type: "perfume_store",
        person: "family",
        website: newStore.website || null,
        logo_url: newStore.logo_url || null,
      });
      await qc.invalidateQueries({ queryKey: ["shop-brands"] });
      if (onChange) onChange(created.id);
      onAddNew?.(created);
      setNewStore({ name: "", website: "", logo_url: "" });
      setNewStoreOpen(false);
      setOpen(false);
      toast.success("أُنشئ المتجر");
    } catch (error) {
      toast.error("تعذّر إنشاء المتجر");
    } finally {
      setIsCreating(false);
    }
  };

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="w-full flex items-center justify-between bg-secondary/50 rounded-none px-3 py-2 text-sm hover:bg-secondary transition-colors"
      >
        <span className="font-body">
          {selectedStore ? selectedStore.name : "Select Store"}
        </span>
        {value && (
          <X
            className="w-3.5 h-3.5 text-muted-foreground"
            onClick={(e) => {
              e.stopPropagation();
              onChange(null);
            }}
          />
        )}
      </button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading">اختر متجراً Select Store</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative">
              <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="ابحث عن متاجر Search stores..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-9 rounded-none h-10"
              />
            </div>

            <div className="space-y-2 max-h-64 overflow-y-auto">
              {filtered.length === 0 ? (
                <p className="text-center text-xs text-muted-foreground py-4">
                  {search ? "No stores found" : "No stores yet"}
                </p>
              ) : (
                filtered.map((store) => (
                  <button
                    key={store.id}
                    onClick={() => {
                      onChange(store.id);
                      setOpen(false);
                    }}
                    className={`w-full text-left px-3 py-2 rounded-none text-sm transition-all ${
                      value === store.id
                        ? "bg-primary text-primary-foreground"
                        : "bg-secondary/50 hover:bg-secondary"
                    }`}
                  >
                    {store.logo_url && (
                      <img
                        src={store.logo_url}
                        alt={store.name}
                        className="w-4 h-4 inline-block mr-2 rounded"
                      />
                    )}
                    <span className="font-body font-medium">{store.name}</span>
                  </button>
                ))
              )}
            </div>

            <Button
              size="sm"
              variant="outline"
              className="w-full rounded-none gap-2 h-9"
              onClick={() => setNewStoreOpen(true)}
            >
              Add New Store
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={newStoreOpen} onOpenChange={setNewStoreOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading">إضافة متجر جديد Add New Store</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Input
              placeholder="اسم المتجر Store name"
              value={newStore.name}
              onChange={(e) => setNewStore({ ...newStore, name: e.target.value })}
              className="rounded-none h-10"
            />
            <Input
              placeholder="الموقع اختياري Website (optional)"
              value={newStore.website}
              onChange={(e) =>
                setNewStore({ ...newStore, website: e.target.value })
              }
              className="rounded-none h-10"
            />
            <Input
              placeholder="رابط الشعار اختياري Logo URL (optional)"
              value={newStore.logo_url}
              onChange={(e) =>
                setNewStore({ ...newStore, logo_url: e.target.value })
              }
              className="rounded-none h-10 text-xs"
            />
            <Button
              className="w-full rounded-none h-10"
              onClick={handleAddStore}
              disabled={isCreating || !newStore.name.trim()}
            >
              {isCreating ? "Creating..." : "Create Store"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}