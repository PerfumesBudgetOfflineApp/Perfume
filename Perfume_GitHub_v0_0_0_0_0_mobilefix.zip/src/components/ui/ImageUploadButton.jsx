import { useState, useRef } from "react";
import { Upload, Loader2 } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { compressImage } from "@/utils/imageCompressor";
import { toast } from "sonner";

/**
 * Reusable image upload button that compresses before uploading.
 * @param {function} onUploaded - called with the uploaded file_url
 * @param {string} className - extra classes for the label
 * @param {object} options - { maxWidth, maxHeight, quality } passed to compressImage
 */
export default function ImageUploadButton({ onUploaded, className = "", options = {} }) {
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setLoading(true);
    try {
      const compressed = await compressImage(file, {
        maxWidth: 800,
        maxHeight: 800,
        quality: 0.78,
        ...options,
      });
      const { file_url } = await apphost.integrations.Core.UploadFile({ file: compressed });
      onUploaded(file_url);
      toast.success("تم رفع الصورة");
    } catch {
      toast.error("فشل رفع الصورة");
    }
    setLoading(false);
    // reset so same file can be re-selected
    if (inputRef.current) inputRef.current.value = "";
  };

  return (
    <label className={`cursor-pointer inline-flex items-center gap-1.5 rounded-none border-dashed transition-colors text-xs text-muted-foreground font-body ${className}`}>
      {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
      {loading ? "جاري الرفع..." : "رفع صورة"}
      <input ref={inputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} disabled={loading} />
    </label>
  );
}