export default function StatCard({ label, value, sub }) {
  return (
    <div className="bg-card rounded-none p-3 border border-border/60 flex flex-col gap-0.5">
      <span className="text-lg font-heading font-bold text-foreground leading-tight">{value}</span>
      <span className="text-[10px] font-body font-medium text-foreground/80 leading-tight">{label}</span>
      {sub && <span className="text-[9px] text-muted-foreground font-body leading-tight">{sub}</span>}
    </div>
  );
}