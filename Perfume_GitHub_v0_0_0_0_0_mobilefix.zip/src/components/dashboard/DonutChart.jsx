import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from "recharts";

const PALETTE = [
  "hsl(36,60%,42%)", "hsl(20,50%,55%)", "hsl(173,45%,42%)",
  "hsl(197,40%,45%)", "hsl(45,65%,52%)", "hsl(10,55%,52%)",
  "hsl(270,35%,55%)", "hsl(150,40%,48%)",
];

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-card border border-border rounded-none px-3 py-2 shadow-lg">
      <p className="text-xs font-body font-semibold">{payload[0].name}</p>
      <p className="text-xs text-muted-foreground font-body">{payload[0].value} · {payload[0].payload.percent}%</p>
    </div>
  );
};

const renderLegend = (props) => {
  const { payload } = props;
  return (
    <div className="flex flex-wrap justify-center gap-x-3 gap-y-1 mt-2">
      {payload.map((entry, i) => (
        <div key={i} className="flex items-center gap-1">
          <div className="w-2 h-2 rounded-none flex-shrink-0" style={{ background: entry.color }} />
          <span className="text-[10px] font-body text-muted-foreground">{entry.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function DonutChart({ perfumes, field, label }) {
  const counts = perfumes.reduce((acc, p) => {
    const val = p[field] || "Unknown";
    acc[val] = (acc[val] || 0) + 1;
    return acc;
  }, {});

  const total = perfumes.length;
  const data = Object.entries(counts)
    .map(([name, value]) => ({ name, value, percent: total ? Math.round((value / total) * 100) : 0 }))
    .sort((a, b) => b.value - a.value);

  if (!data.length) return <div className="h-[200px] flex items-center justify-center text-xs text-muted-foreground font-body">لا بيانات بعد No data yet</div>;

  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie
          data={data}
          cx="50%"
          cy="45%"
          innerRadius="45%"
          outerRadius="70%"
          paddingAngle={3}
          dataKey="value"
        >
          {data.map((_, i) => (
            <Cell key={i} fill={PALETTE[i % PALETTE.length]} stroke="none" />
          ))}
        </Pie>
        <Tooltip content={<CustomTooltip />} />
        <Legend content={renderLegend} />
      </PieChart>
    </ResponsiveContainer>
  );
}