import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const GOLD_SHADES = [
  "hsl(36,35%,72%)", "hsl(36,45%,62%)", "hsl(36,55%,52%)", "hsl(36,62%,42%)", "hsl(36,70%,34%)",
];

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const stars = "■".repeat(payload[0].payload.stars) + "□".repeat(5 - payload[0].payload.stars);
  return (
    <div className="bg-card border border-border rounded-none px-3 py-2 shadow-lg">
      <p className="text-sm">{stars}</p>
      <p className="text-xs text-muted-foreground font-body">{payload[0].value} perfume{payload[0].value !== 1 ? "s" : ""}</p>
    </div>
  );
};

export default function RatingChart({ perfumes }) {
  const rated = perfumes.filter((p) => p.rating && p.rating > 0);

  const data = [1, 2, 3, 4, 5].map((stars) => ({
    stars,
    label: "■".repeat(stars),
    count: rated.filter((p) => Math.round(p.rating) === stars).length,
  }));

  const unratedCount = perfumes.length - rated.length;

  if (!perfumes.length) return <div className="h-[180px] flex items-center justify-center text-xs text-muted-foreground font-body">لا بيانات بعد No data yet</div>;

  return (
    <div className="space-y-3">
      <ResponsiveContainer width="100%" height={160}>
        <BarChart data={data} margin={{ top: 4, right: 4, left: -24, bottom: 4 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsl(30,15%,88%)" />
          <XAxis
            dataKey="label"
            tick={{ fontSize: 12, fill: "hsl(36,60%,42%)" }}
            tickLine={false}
            axisLine={false}
          />
          <YAxis tick={{ fontSize: 10, fontFamily: "var(--font-body)", fill: "hsl(20,8%,50%)" }} tickLine={false} axisLine={false} allowDecimals={false} />
          <Tooltip content={<CustomTooltip />} cursor={{ fill: "hsl(30,20%,96%)" }} />
          <Bar dataKey="count" radius={[6, 6, 0, 0]}>
            {data.map((_, i) => (
              <Cell key={i} fill={GOLD_SHADES[i]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
      {unratedCount > 0 && (
        <p className="text-[11px] text-muted-foreground font-body text-center">
          {unratedCount} perfume{unratedCount !== 1 ? "s" : ""} not yet rated
        </p>
      )}
    </div>
  );
}