import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, openHtmlReport } from "@/lib/exportHelper";
import { CATEGORIES } from "@/lib/goalConstants";

// خطوط جديدة جذرياً: رفيع أنيق رسمي — لا «أميري/القاهرة» المعتادة.
// استُخدمت عائلات نظام عامّة (Garamond/Georgia/Tahoma) المتوفّرة على WebView/PDF
// لضمان رسم نصّ حقيقي لا صورة، مع fallback عربي لائق.
const FONT_STACK = {
  elegant: "'EB Garamond', Garamond, 'Cormorant Garamond', Georgia, 'Tahoma', serif",
  classic: "Georgia, 'Times New Roman', 'Tahoma', serif",
  modern:  "system-ui, -apple-system, 'Segoe UI', 'Tahoma', sans-serif",
};

const catLabel = (val, isAr) => {
  const c = CATEGORIES.find((x) => x.value === val);
  if (!c) return val || "";
  return `${c.emoji} ${c.label}`;
};

/**
 * GoalsExportDialog — exports a goals report as image (brief) or opens a
 * printable PDF (full). Mirrors the budget report options: language, font,
 * direction, toggles, attached image, editable + auto intro.
 */
export default function GoalsExportDialog({ open, onOpenChange, goals = [], isAr, names, appName = "Process" }) {
  const [generating, setGenerating] = useState(false);
  const [reportLang, setReportLang] = useState(isAr ? "ar" : "en");
  const [fontChoice, setFontChoice] = useState("elegant");
  const [dirChoice, setDirChoice] = useState(isAr ? "rtl" : "ltr");
  const [depth, setDepth] = useState("full"); // brief=img | full=pdf (افتراضي PDF نصّي)
  const [showDate, setShowDate] = useState(true);
  const [showAppName, setShowAppName] = useState(true);
  const [autoIntro, setAutoIntro] = useState(true);
  const [introText, setIntroText] = useState("");
  const [reportImage, setReportImage] = useState(null);
  const [imagePosition, setImagePosition] = useState("end");

  const rLangAr = reportLang === "ar" || reportLang === "both";
  const rLangEn = reportLang === "en" || reportLang === "both";
  const reportDir = dirChoice === "auto" ? (rLangAr ? "rtl" : "ltr") : dirChoice;
  const reportFont = FONT_STACK[fontChoice] || FONT_STACK.elegant;

  const pending = goals.filter((g) => g.status !== "done" && g.status !== "skipped");
  const done = goals.filter((g) => g.status === "done");
  const skipped = goals.filter((g) => g.status === "skipped");
  const completion = goals.length ? Math.round((done.length / goals.length) * 100) : 0;

  const buildAutoIntro = (ar) => {
    if (ar) {
      return `يضم هذا التقرير ${goals.length} هدفاً، أُنجز منها ${done.length} (${completion}%)، ولا يزال ${pending.length} قيد التنفيذ. ${completion >= 50 ? "التقدّم جيد، استمر على هذا المنوال." : "هناك مجال للتقدّم — ركّز على الأهداف القريبة من الإنجاز."}`;
    }
    return `This report covers ${goals.length} goals: ${done.length} completed (${completion}%) and ${pending.length} still in progress. ${completion >= 50 ? "Progress is solid — keep it up." : "There is room to improve — focus on goals close to completion."}`;
  };

  const buildHTML = () => {
    const titleAr = "تقرير الأهداف";
    const titleEn = "Goals Report";
    const title = reportLang === "both" ? `${titleAr} ${titleEn}` : (rLangAr ? titleAr : titleEn);
    const imgTag = reportImage
      ? `<div style="text-align:center; margin:24px 0;"><img src="${reportImage}" style="max-width:100%; max-height:340px; border-radius:10px;" /></div>`
      : "";
    const introParts = [];
    if (autoIntro) {
      if (rLangAr) introParts.push(buildAutoIntro(true));
      if (rLangEn) introParts.push(buildAutoIntro(false));
    }
    if (introText.trim()) introParts.push(introText.trim());
    const introBlock = introParts.length
      ? `<div style="background:#faf7ff; border-${reportDir === "rtl" ? "right" : "left"}:4px solid #7c3aed; border-radius:8px; padding:16px 18px; margin-bottom:24px; line-height:1.9; color:#333; font-size:14px;" dir="${reportDir}">
           ${introParts.map((p) => `<p style="margin:0 0 8px 0;">${p}</p>`).join("")}
         </div>`
      : "";

    const goalRow = (g) => `
      <tr style="border-bottom:1px solid #eee;">
        <td style="padding:9px;">${g.title || ""}</td>
        <td style="padding:9px;">${catLabel(g.category, rLangAr)}</td>
        <td style="padding:9px;">${g.person === "both" ? (rLangAr ? "كلاهما" : "Both") : (g.person === "person2" ? (names?.person2 || "B") : (names?.person1 || "A"))}</td>
        <td style="padding:9px;">${g.status === "done" ? (rLangAr ? "منجز" : "Done") : g.status === "skipped" ? (rLangAr ? "⏭ متخطّى" : "⏭ Skipped") : (rLangAr ? "⏳ جارٍ" : "⏳ Pending")}</td>
      </tr>`;

    const fullTable = depth === "full"
      ? `<div style="margin-top:24px;" dir="${reportDir}">
           <h3 style="color:#7c3aed;">${rLangAr ? "تفاصيل الأهداف" : "Goal Details"}</h3>
           <table style="width:100%; border-collapse:collapse; font-size:13px;">
             <tr style="background:#f3e8ff; text-align:${reportDir === "rtl" ? "right" : "left"};">
               <th style="padding:9px;">${rLangAr ? "الهدف" : "Goal"}</th>
               <th style="padding:9px;">${rLangAr ? "الفئة" : "Category"}</th>
               <th style="padding:9px;">${rLangAr ? "الشخص" : "Person"}</th>
               <th style="padding:9px;">${rLangAr ? "الحالة" : "Status"}</th>
             </tr>
             ${goals.map(goalRow).join("")}
           </table>
         </div>`
      : "";

    return `
      <div style="text-align:${reportDir === "rtl" ? "right" : "center"}; margin-bottom:24px;" dir="${reportDir}">
        <h1 style="color:#7c3aed; font-size:30px; margin:0 0 8px 0;">${title}</h1>
        ${showDate ? `<p style="color:#888; font-size:13px;">${rLangAr ? `تم الإنشاء: ${new Date().toLocaleDateString("ar-SA")}` : `Generated: ${new Date().toLocaleDateString()}`}</p>` : ""}
      </div>
      ${imagePosition === "start" ? imgTag : ""}
      ${introBlock}
      <div style="display:grid; grid-template-columns:1fr 1fr 1fr 1fr; gap:14px; margin-bottom:24px;" dir="${reportDir}">
        <div style="background:#f5f3ff; border:2px solid #7c3aed; border-radius:8px; padding:14px; text-align:center;">
          <p style="color:#7c3aed; font-size:12px; margin:0 0 6px;">${rLangAr ? "الإجمالي" : "Total"}</p>
          <p style="color:#7c3aed; font-size:24px; font-weight:bold; margin:0;">${goals.length}</p>
        </div>
        <div style="background:#ecfdf5; border:2px solid #10b981; border-radius:8px; padding:14px; text-align:center;">
          <p style="color:#059669; font-size:12px; margin:0 0 6px;">${rLangAr ? "منجز" : "Done"}</p>
          <p style="color:#059669; font-size:24px; font-weight:bold; margin:0;">${done.length}</p>
        </div>
        <div style="background:#fffbeb; border:2px solid #f59e0b; border-radius:8px; padding:14px; text-align:center;">
          <p style="color:#d97706; font-size:12px; margin:0 0 6px;">${rLangAr ? "جارٍ" : "Pending"}</p>
          <p style="color:#d97706; font-size:24px; font-weight:bold; margin:0;">${pending.length}</p>
        </div>
        <div style="background:#eff6ff; border:2px solid #3b82f6; border-radius:8px; padding:14px; text-align:center;">
          <p style="color:#1d4ed8; font-size:12px; margin:0 0 6px;">${rLangAr ? "الإنجاز" : "Completion"}</p>
          <p style="color:#1d4ed8; font-size:24px; font-weight:bold; margin:0;">${completion}%</p>
        </div>
      </div>
      ${fullTable}
      ${imagePosition === "end" ? imgTag : ""}
      <div style="text-align:${reportDir === "rtl" ? "right" : "center"}; margin-top:32px; padding-top:18px; border-top:2px solid #eee;" dir="${reportDir}">
        ${showAppName && appName ? `<p style="color:#888; font-size:12px; margin:0;">${rLangAr ? "من تطبيق" : "From"} ${appName}</p>` : ""}
      </div>`;
  };

  const exportImage = async () => {
    setGenerating(true);
    try {
      const div = document.createElement("div");
      div.style.cssText = `position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none; width:1000px; padding:40px; background:#fff; direction:${reportDir}; font-family:${reportFont}; text-align:${reportDir === "rtl" ? "right" : "left"};`;
      div.innerHTML = buildHTML();
      document.body.appendChild(div);
      const canvas = await captureElement(div, { scale: 2, backgroundColor: "#ffffff" });
      document.body.removeChild(div);
      await saveCanvasAsImage(canvas, `goals_report_${new Date().toISOString().slice(0, 10)}.png`);
    } catch (e) {
      console.error("Goals image export failed", e);
    }
    setGenerating(false);
    onOpenChange(false);
  };

  const exportPDF = async () => {
    setGenerating(true);
    try {
      // تقرير قابل للحفظ/الطباعة عبر تراكب التطبيق — يعمل على الجوال (APK) والويب معاً،
      // بدل window.open الذي يُرجع null داخل WebView الأندرويد فلا يحدث شيء.
      const html = `<!DOCTYPE html><html dir="${reportDir}"><head><meta charset="utf-8" />
        <title>${title}</title>
        <style>
          body{font-family:${reportFont}; padding:32px; margin:0; color:#1c1917;}
          h1, h2, h3 { font-family:${reportFont}; font-weight:600; }
          table { font-family:${reportFont}; }
        </style>
        </head><body>${buildHTML()}</body></html>`;
      await openHtmlReport(html, `goals_report_${new Date().toISOString().slice(0, 10)}`);
    } catch (e) {
      console.error("Goals PDF export failed", e);
    }
    setGenerating(false);
    onOpenChange(false);
  };

  const handleExport = () => (depth === "full" ? exportPDF() : exportImage());

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md w-[calc(100vw-2rem)] max-h-[90vh] overflow-y-auto rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">{isAr ? "📊 تصدير تقرير الأهداف" : "📊 Export Goals Report"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          {/* النوع */}
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => setDepth("brief")} className={` rounded-none text-xs font-body flex flex-col items-center gap-0.5 ${depth === "brief" ? " text-primary-foreground" : " text-muted-foreground"}`}>
              <span>🖼️ {isAr ? "مختصر" : "Brief"}</span><span className="text-[9px] opacity-80">{isAr ? "صورة" : "Image"}</span>
            </button>
            <button onClick={() => setDepth("full")} className={` rounded-none text-xs font-body flex flex-col items-center gap-0.5 ${depth === "full" ? " text-primary-foreground" : " text-muted-foreground"}`}>
              <span>📄 {isAr ? "مطوّل" : "Full"}</span><span className="text-[9px] opacity-80">PDF</span>
            </button>
          </div>

          {/* اللغة */}
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "اللغة" : "Language"}</p>
            <div className="flex gap-1.5">
              {[{ v: "ar", l: "عربي" }, { v: "en", l: "English" }, { v: "both", l: isAr ? "اللغتين" : "Both" }].map((o) => (
                <button key={o.v} onClick={() => setReportLang(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${reportLang === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          {/* الخط */}
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "الخط" : "Font"}</p>
            <div className="flex gap-1.5 flex-wrap">
              {[{ v: "elegant", l: isAr ? "أنيق" : "Elegant" }, { v: "classic", l: isAr ? "كلاسيكي" : "Classic" }, { v: "modern", l: isAr ? "حديث" : "Modern" }].map((o) => (
                <button key={o.v} onClick={() => setFontChoice(o.v)} className={` rounded-none text-xs font-body ${fontChoice === o.v ? " text-primary-foreground " : " text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          {/* الاتجاه */}
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "الاتجاه" : "Direction"}</p>
            <div className="flex gap-1.5">
              {[{ v: "rtl", l: "RTL" }, { v: "ltr", l: "LTR" }, { v: "auto", l: isAr ? "تلقائي" : "Auto" }].map((o) => (
                <button key={o.v} onClick={() => setDirChoice(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${dirChoice === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
              ))}
            </div>
          </div>

          {/* تبديلات */}
          <div className="grid grid-cols-2 gap-2">
            {[
              { v: showDate, set: setShowDate, l: isAr ? "تاريخ التصدير" : "Date" },
              { v: showAppName, set: setShowAppName, l: isAr ? "اسم التطبيق" : "App name" },
              { v: autoIntro, set: setAutoIntro, l: isAr ? "مقدمة تلقائية" : "Auto intro" },
            ].map((o, i) => (
              <label key={i} className="flex items-center gap-2 cursor-pointer text-xs font-body">
                <Checkbox checked={o.v} onCheckedChange={() => o.set(!o.v)} />
                <span>{o.l}</span>
              </label>
            ))}
          </div>

          {/* مقدمة محرّرة */}
          <textarea value={introText} onChange={(e) => setIntroText(e.target.value)} placeholder={isAr ? "نص مقدمة إضافي (اختياري)" : "Extra intro (optional)"} dir={reportDir}
            className="w-full rounded-none text-xs font-body resize-none min-h-[54px]" />

          {/* صورة */}
          <div className="space-y-1">
            <p className="text-[10px] text-muted-foreground font-body">{isAr ? "صورة مرفقة (اختياري)" : "Attached image (optional)"}</p>
            <div className="flex items-center gap-2">
              <input type="file" accept="image/*" onChange={(e) => {
                const file = e.target.files?.[0]; if (!file) return;
                const r = new FileReader(); r.onload = (ev) => setReportImage(ev.target.result); r.readAsDataURL(file);
              }} className="text-xs font-body flex-1" />
              {reportImage && <button onClick={() => setReportImage(null)} className="text-xs text-destructive font-body">{isAr ? "إزالة" : "Remove"}</button>}
            </div>
            {reportImage && (
              <div className="flex gap-1.5 mt-1">
                {[{ v: "start", l: isAr ? "البداية" : "Start" }, { v: "end", l: isAr ? "النهاية" : "End" }].map((o) => (
                  <button key={o.v} onClick={() => setImagePosition(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${imagePosition === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
                ))}
              </div>
            )}
          </div>

          <Button className="w-full h-10 rounded-none font-body" onClick={handleExport} disabled={generating}>
            {generating ? (isAr ? "جارٍ..." : "Generating...") : (depth === "full" ? (isAr ? "تصدير PDF" : "Export PDF") : (isAr ? "تصدير صورة" : "Export Image"))}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
