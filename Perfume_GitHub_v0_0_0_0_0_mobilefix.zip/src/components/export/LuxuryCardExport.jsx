import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download, Palette, Type, Sliders, Image as ImageIcon, Check } from "lucide-react";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";

const REC = { no: { e: "🚫", ar: "لا", en: "No" }, women: { e: "🌸", ar: "نساء", en: "Women" }, men: { e: "🔷", ar: "رجال", en: "Men" }, any: { e: "👥", ar: "للجميع", en: "Anyone" } };
const OCC = {
  daylight: { e: "☀️", ar: "نهار", en: "Day" }, evening: { e: "🌙", ar: "مساء", en: "Evening" }, wedding: { e: "💍", ar: "زفاف", en: "Wedding" },
  celebration: { e: "🎉", ar: "احتفال", en: "Celebration" }, relax: { e: "😌", ar: "استرخاء", en: "Relax" }, work: { e: "💼", ar: "عمل", en: "Work" },
  sport: { e: "⚽", ar: "رياضة", en: "Sport" }, casual: { e: "👕", ar: "عادي", en: "Casual" }, very_special: { e: "✨", ar: "خاص جداً", en: "Very Special" },
};

/**
 * LuxuryCardExport — a beautiful, highly customizable share-card exporter that
 * works for BOTH perfumes and brands. Two content modes:
 *   - withUser  : includes personal ratings/impressions/notes
 *   - publicCard: clean catalog card, no personal data (for public sharing)
 *
 * Full controls: language (ar/en/both), theme/background (color + gradient +
 * image), font family + size scale, and per-field show/hide.
 *
 * Pass either `perfume` or `brand`. `userData` is optional (the active person's
 * record). `extra` carries computed bits (wearCount, noteLists, etc).
 */

const THEMES = [
  { id: "noir",    name: "Noir",     bg: "linear-gradient(160deg,#1a1410 0%,#2d2419 55%,#1a1410 100%)", fg: "#f5ecd9", accent: "#c8a24a", sub: "#b9a888", card: "rgba(255,255,255,0.04)" },
  { id: "ivory",   name: "Ivory",    bg: "linear-gradient(160deg,#fdfbf6 0%,#f5efe2 100%)",             fg: "#241c12", accent: "#a16207", sub: "#6b5d45", card: "rgba(0,0,0,0.03)" },
  { id: "rose",    name: "Rosé",     bg: "linear-gradient(160deg,#2a1620 0%,#3d1f2e 60%,#241019 100%)", fg: "#fbe9f0", accent: "#e8a0bf", sub: "#c890a8", card: "rgba(255,255,255,0.05)" },
  { id: "emerald", name: "Emerald",  bg: "linear-gradient(160deg,#0c1f18 0%,#13362a 60%,#0a1a14 100%)", fg: "#e6f5ec", accent: "#5fd0a0", sub: "#8fb9a8", card: "rgba(255,255,255,0.05)" },
  { id: "azure",   name: "Azure",    bg: "linear-gradient(160deg,#0d1626 0%,#16294a 60%,#0a1322 100%)", fg: "#e6eefb", accent: "#7ab0f0", sub: "#90a4c8", card: "rgba(255,255,255,0.05)" },
  { id: "blush",   name: "Blush",    bg: "linear-gradient(160deg,#fff5f7 0%,#fde8ee 100%)",             fg: "#3a1320", accent: "#c2386a", sub: "#8a5a6a", card: "rgba(0,0,0,0.03)" },
  { id: "obsidian",name: "Obsidian", bg: "linear-gradient(160deg,#0a0a0c 0%,#18181c 60%,#0a0a0c 100%)", fg: "#eaeaf0", accent: "#9a9ab0", sub: "#7a7a8a", card: "rgba(255,255,255,0.05)" },
  { id: "sand",    name: "Sand",     bg: "linear-gradient(160deg,#f7f0e4 0%,#ece0c8 100%)",             fg: "#3a2c18", accent: "#b8862f", sub: "#8a7250", card: "rgba(0,0,0,0.03)" },
  { id: "plum",    name: "Plum",     bg: "linear-gradient(160deg,#1e0f24 0%,#371a44 60%,#160a1c 100%)", fg: "#f1e6f7", accent: "#c08fe0", sub: "#a088b0", card: "rgba(255,255,255,0.05)" },
  { id: "teal",    name: "Teal",     bg: "linear-gradient(160deg,#06222a 0%,#0c3a44 60%,#041a20 100%)", fg: "#e0f5f8", accent: "#56cdd8", sub: "#88b4ba", card: "rgba(255,255,255,0.05)" },
];

const FONTS = [
  { id: "playfair", name: "Playfair", stack: "'Playfair Display', 'Amiri', serif" },
  { id: "amiri",    name: "Amiri",    stack: "'Amiri', 'Traditional Arabic', serif" },
  { id: "cairo",    name: "Cairo",    stack: "'Cairo', 'Segoe UI', sans-serif" },
  { id: "montserrat", name: "Montserrat", stack: "'Montserrat', 'Segoe UI', sans-serif" },
];

const ASPECTS = [
  { id: "portrait", name: "Portrait", w: 440 },
  { id: "square",   name: "Square",   w: 480 },
  { id: "story",    name: "Story",    w: 420 },
  { id: "wide",     name: "Wide",     w: 560 },
];

export default function LuxuryCardExport({ kind = "perfume", perfume = null, brand = null, userData = null, personName = "", extra = {}, trigger = null }) {
  const { isAr } = useLang();
  const item = kind === "perfume" ? (perfume || {}) : (brand || {});

  const [open, setOpen] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [tab, setTab] = useState("theme"); // theme | font | layout | fields
  const [lang, setLang] = useState(isAr ? "ar" : "en"); // ar | en | both
  const [theme, setTheme] = useState("noir");
  const [fontId, setFontId] = useState("playfair");
  const [fontScale, setFontScale] = useState(1);
  const [bgImage, setBgImage] = useState(null);
  const [bgDim, setBgDim] = useState(0.72); // شدة تعتيم خلفية الصورة
  const [withUser, setWithUser] = useState(!!userData);
  const [caption, setCaption] = useState("");

  // تخصيص لوني (يتجاوز السمة عند التفعيل)
  const [customOn, setCustomOn] = useState(false);
  const [cBg, setCBg] = useState("#1a1410");
  const [cFg, setCFg] = useState("#f5ecd9");
  const [cAccent, setCAccent] = useState("#c8a24a");

  // تحكم بالشكل
  const [aspect, setAspect] = useState("portrait");
  const [radius, setRadius] = useState(20);
  const [padding, setPadding] = useState(32);
  const [borderOn, setBorderOn] = useState(true);
  const [align, setAlign] = useState("center"); // center | start
  const [showMark, setShowMark] = useState(true);
  const [showDivider, setShowDivider] = useState(true);
  const [userMark, setUserMark] = useState("");

  const [fields, setFields] = useState({
    image: true, name: true, brand: true, family: true, notes: true,
    description: true, occasions: true, year: true, rating: true,
    impression: true, comment: true, wearCount: true, recommend: true,
  });

  // جلب رمز المستخدم
  useEffect(() => {
    apphost.auth.me().then((u) => { if (u?.mark) setUserMark(u.mark); }).catch(() => {});
  }, []);

  const baseTh = THEMES.find((t) => t.id === theme) || THEMES[0];
  // عند تفعيل التخصيص، نتجاوز ألوان السمة بألوان المستخدم
  const th = customOn
    ? { ...baseTh, bg: cBg, fg: cFg, accent: cAccent, sub: cFg + "aa", card: "rgba(127,127,127,0.12)" }
    : baseTh;
  const font = FONTS.find((f) => f.id === fontId) || FONTS[0];
  const cardWidth = (ASPECTS.find((a) => a.id === aspect) || ASPECTS[0]).w;
  // Scale the live preview down so the card always fits the dialog width
  // (mobile + desktop). Export itself stays at full cardWidth resolution.
  const previewScale = Math.min(1, 330 / cardWidth);
  const rAr = lang === "ar" || lang === "both";
  const rEn = lang === "en" || lang === "both";
  const dir = rAr && !rEn ? "rtl" : "ltr";
  const ta = align === "start" ? (dir === "rtl" ? "right" : "left") : "center";

  const toggleField = (k) => setFields((p) => ({ ...p, [k]: !p[k] }));

  // ── Resolve bilingual values ──
  const nameEn = item.name_en || item.name || "";
  const nameAr = item.name_ar || "";
  const brandEn = kind === "perfume" ? (item.brand_name || "") : "";
  const brandAr = kind === "perfume" ? (item.brand_name_ar || "") : "";
  const descEn = item.about_en || item.description || "";
  const descAr = item.about_ar || item.description_ar || "";
  const family = item.odor_family || item.signature_notes_names || "";
  const foundedYear = item.founded_year || item.year_established || "";

  // عنوان ثنائي بسطر/سطرين دون عكس: الإنجليزي LTR، العربي RTL، كل منهما في عنصره
  const titleBlock = () => {
    const parts = [];
    if (rEn && nameEn) parts.push(`<div dir="ltr" style="font-weight:800; font-size:${28 * fontScale}px; line-height:1.15; color:${th.fg};">${esc(nameEn)}</div>`);
    if (rAr && nameAr) parts.push(`<div dir="rtl" style="font-weight:700; font-size:${24 * fontScale}px; line-height:1.3; color:${th.fg}; font-family:'Amiri',serif;">${esc(nameAr)}</div>`);
    return parts.join("");
  };

  const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

  const labelPair = (en, ar) => (lang === "both" ? `${ar} · ${en}` : rAr ? ar : en);

  // Odor family as colored bars + percentages, using the SAME catalogue colors
  // as the perfume page (accords_builtin.json) so the card matches the app.
  const accLabel = (ref) => (lang === "both" && ref.ar ? `${ref.en} ${ref.ar}` : rAr && ref.ar ? ref.ar : ref.en);
  const buildAccordsHTML = () => {
    const list = String(item.accords || "").split(";").map((e) => {
      const [id, pct] = e.split(":");
      const ref = ACCORDS[id];
      if (!ref) return null;
      const n = parseInt(pct, 10);
      return { id, pct: Number.isFinite(n) ? n : 0, ...ref };
    }).filter(Boolean);
    if (!list.length) return "";
    const [top, ...rest] = list;
    const head = `<div style="font-size:${10 * fontScale}px;color:${th.sub};text-transform:uppercase;letter-spacing:0.1em;margin-bottom:6px;text-align:${ta};">${labelPair("Odor Family", "العائلة العطرية")}</div>`;
    const band = `<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px;color:${th.fg};"><span style="width:20px;height:8px;background:${top.bar};display:inline-block;"></span><span style="font-size:${13 * fontScale}px;font-weight:700;">${esc(accLabel(top))}</span><span style="font-size:${11 * fontScale}px;opacity:.7;margin-${dir === "rtl" ? "right" : "left"}:auto;">${top.pct}%</span></div>`;
    const chips = rest.map((a) => `<span style="display:inline-flex;align-items:center;gap:6px;font-size:${10.5 * fontScale}px;color:${th.fg};margin:2px 12px 2px 0;"><span style="width:16px;height:6px;background:${a.bar};display:inline-block;"></span>${esc(accLabel(a))}<span style="opacity:.6;margin-${dir === "rtl" ? "right" : "left"}:3px;">${a.pct}%</span></span>`).join("");
    return `<div style="margin-bottom:12px;" dir="${dir}">${head}${band}${rest.length ? `<div style="display:flex;flex-wrap:wrap;gap:4px;">${chips}</div>` : ""}</div>`;
  };

  const buildCardHTML = () => {
    const blocks = [];

    // الصورة
    if (fields.image && item.image_url) {
      blocks.push(`<div style="text-align:center; margin-bottom:18px;"><img src="${item.image_url}" style="max-width:160px; max-height:200px; object-fit:contain; background:transparent;" /></div>`);
    }

    // العنوان
    if (fields.name) {
      blocks.push(`<div style="text-align:center; margin-bottom:6px;">${titleBlock()}</div>`);
    }

    // البراند (للعطر)
    if (kind === "perfume" && fields.brand && (brandEn || brandAr)) {
      const b = lang === "both" && brandAr ? `${esc(brandEn)} · ${esc(brandAr)}` : (rAr && brandAr ? esc(brandAr) : esc(brandEn));
      blocks.push(`<div style="text-align:center; font-size:${13 * fontScale}px; color:${th.accent}; letter-spacing:0.08em; text-transform:uppercase; margin-bottom:14px;">${b}</div>`);
    }

    // البلد (للبراند)
    if (kind === "brand" && fields.year && (item.country || item.country_ar)) {
      const c = rAr && item.country_ar ? esc(item.country_ar) : esc(item.country);
      blocks.push(`<div style="text-align:center; font-size:${12 * fontScale}px; color:${th.sub}; margin-bottom:12px;">${c}${foundedYear ? " · " + foundedYear : ""}</div>`);
    }

    // فاصل ذهبي (اختياري)
    if (showDivider) blocks.push(`<div style="height:1px; background:linear-gradient(90deg,transparent,${th.accent}66,transparent); margin:14px 0;"></div>`);

    // العائلة العطرية / نوتة التوقيع
    if (fields.family) {
      const accHtml = buildAccordsHTML();
      if (accHtml) {
        blocks.push(accHtml);
      } else if (family) {
        blocks.push(`<div style="text-align:center; margin-bottom:12px;"><span style="font-size:${10 * fontScale}px; color:${th.sub}; text-transform:uppercase; letter-spacing:0.1em;">${labelPair("Odor Family", "العائلة العطرية")}</span><div style="font-size:${15 * fontScale}px; color:${th.fg}; margin-top:3px;">${esc(family)}</div></div>`);
      }
    }

    // النوتات (للعطر)
    if (kind === "perfume" && fields.notes) {
      const pyramid = [
        { l: labelPair("Top", "المقدمة"), v: item.top_notes },
        { l: labelPair("Heart", "القلب"), v: item.heart_notes },
        { l: labelPair("Base", "القاعدة"), v: item.base_notes },
      ].filter((n) => n.v);
      if (pyramid.length) {
        const rows = pyramid.map((n) => `<div style="margin:5px 0;"><span style="font-size:${10 * fontScale}px; color:${th.accent}; text-transform:uppercase; letter-spacing:0.08em;">${n.l}</span><div style="font-size:${13 * fontScale}px; color:${th.fg};">${esc(n.v)}</div></div>`).join("");
        blocks.push(`<div style="background:${th.card}; border-radius:10px; padding:14px 16px; margin-bottom:12px;">${rows}</div>`);
      }
    }

    // الوصف
    if (fields.description) {
      const d = [];
      if (rEn && descEn) d.push(`<p dir="ltr" style="margin:0 0 6px; font-size:${12.5 * fontScale}px; line-height:1.7; color:${th.fg}cc;">${esc(descEn)}</p>`);
      if (rAr && descAr) d.push(`<p dir="rtl" style="margin:0; font-size:${13 * fontScale}px; line-height:1.9; color:${th.fg}cc; font-family:'Amiri',serif;">${esc(descAr)}</p>`);
      if (d.length) blocks.push(`<div style="margin-bottom:12px;">${d.join("")}</div>`);
    }

    // السنة والمناسبات (للعطر)
    if (kind === "perfume") {
      const meta = [];
      if (fields.year && item.release_year) meta.push(`${labelPair("Year", "السنة")}: ${item.release_year}`);
      if (fields.occasions && item.occasions) {
        const occHtml = item.occasions.split(",").map((o) => { const k = o.trim(); const c = OCC[k]; return c ? `${c.e} ${labelPair(c.en, c.ar)}` : esc(k); }).filter(Boolean).join("  ·  ");
        if (occHtml) meta.push(occHtml);
      }
      if (meta.length) blocks.push(`<div style="text-align:center; font-size:${11 * fontScale}px; color:${th.sub}; margin-bottom:10px;">${meta.join("  ·  ")}</div>`);
    }

    // ── مدخلات المستخدم (وضع withUser فقط) ──
    if (withUser && userData) {
      const u = [];
      if (fields.rating && userData.rating) {
        u.push(`<div style="text-align:center; margin:6px 0;"><span style="font-size:${18 * fontScale}px; color:${th.accent}; letter-spacing:2px;">${"■".repeat(Math.round(userData.rating))}${"□".repeat(Math.max(0, 5 - Math.round(userData.rating)))}</span></div>`);
      }
      if (fields.impression && userData.impression) {
        const imp = { love: "😍", like: "🙂", neutral: "😐", dislike: "🙁" }[userData.impression] || "";
        if (imp) u.push(`<div style="text-align:center; font-size:${20 * fontScale}px;">${imp}</div>`);
      }
      if (fields.recommend && userData.recommend_to && REC[userData.recommend_to]) {
        const r = REC[userData.recommend_to];
        u.push(`<div style="text-align:center; font-size:${12 * fontScale}px; color:${th.fg}dd; margin:4px 0;">${r.e} ${labelPair(r.en, r.ar)}</div>`);
      }
      if (fields.comment && userData.comment) {
        u.push(`<p dir="auto" style="text-align:center; font-style:italic; font-size:${12.5 * fontScale}px; color:${th.fg}dd; margin:8px 0;">"${esc(userData.comment)}"</p>`);
      }
      if (fields.wearCount && extra.wearCount) {
        u.push(`<div style="text-align:center; font-size:${11 * fontScale}px; color:${th.sub};">${labelPair("Worn", "ارتُدي")} ${extra.wearCount}×</div>`);
      }
      if (u.length) {
        blocks.push(`<div style="height:1px; background:linear-gradient(90deg,transparent,${th.accent}66,transparent); margin:14px 0;"></div>`);
        blocks.push(`<div>${personName ? `<div style="text-align:center; font-size:${10 * fontScale}px; color:${th.sub}; text-transform:uppercase; letter-spacing:0.1em; margin-bottom:6px;">${esc(personName)}</div>` : ""}${u.join("")}</div>`);
      }
    }

    // التعليق التوضيحي للمستخدم
    if (caption.trim()) {
      blocks.push(`<p dir="auto" style="text-align:${ta}; font-size:${12 * fontScale}px; color:${th.fg}cc; margin-top:14px;">${esc(caption)}</p>`);
    }

    // رمز المستخدم في التذييل
    if (showMark && userMark) {
      blocks.push(`<div style="text-align:center; margin-top:16px; font-size:${16 * fontScale}px;">${esc(userMark)}</div>`);
    }

    const dimRgba = (th.id === "ivory" || th.id === "blush" || th.id === "sand")
      ? `rgba(255,255,255,${bgDim})`
      : `rgba(15,12,10,${bgDim})`;
    const bgStyle = bgImage
      ? `background-image:linear-gradient(${dimRgba},${dimRgba}),url(${bgImage}); background-size:cover; background-position:center;`
      : `background:${th.bg};`;
    const borderStyle = borderOn ? `border:1px solid ${th.accent}44;` : "";

    return `<div style="width:${cardWidth}px; ${bgStyle} padding:${padding}px ${Math.round(padding * 0.9)}px; border-radius:${radius}px; font-family:${font.stack}; box-sizing:border-box; ${borderStyle} text-align:${ta};" dir="${dir}">
      ${blocks.join("")}
    </div>`;
  };

  const handleExport = async () => {
    setGenerating(true);
    try {
      const wrap = document.createElement("div");
      wrap.style.cssText = "position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none;";
      wrap.innerHTML = buildCardHTML();
      document.body.appendChild(wrap);
      // انتظار تحميل الصور
      const imgs = wrap.querySelectorAll("img");
      await Promise.all(Array.from(imgs).map((img) => img.complete ? Promise.resolve() : new Promise((res) => { img.onload = res; img.onerror = res; })));
      const rawCanvas = await captureElement(wrap.firstElementChild, { scale: 2, backgroundColor: null, useCORS: false, allowTaint: false });
      document.body.removeChild(wrap);
      // Cap longest side at 1080px with high-quality smoothing.
      let canvas = rawCanvas;
      const longest = Math.max(rawCanvas.width, rawCanvas.height);
      if (longest > 1080) {
        const ratio = 1080 / longest;
        canvas = document.createElement("canvas");
        canvas.width = Math.round(rawCanvas.width * ratio);
        canvas.height = Math.round(rawCanvas.height * ratio);
        const cx = canvas.getContext("2d");
        cx.imageSmoothingEnabled = true; cx.imageSmoothingQuality = "high";
        cx.drawImage(rawCanvas, 0, 0, canvas.width, canvas.height);
      }
      const base = (nameEn || nameAr || kind).toLowerCase().replace(/[^a-z0-9]+/g, "_").slice(0, 40);
      await saveCanvasAsImage(canvas, `${base}_card.png`);
      toast.success(isAr ? "تم تصدير البطاقة" : "Card exported");
      setOpen(false);
    } catch (e) {
      console.error("Card export failed", e);
      toast.error(isAr ? "فشل التصدير" : "Export failed");
    }
    setGenerating(false);
  };

  // معاينة حية
  const previewHTML = useMemo(() => buildCardHTML(), [lang, theme, fontId, fontScale, bgImage, bgDim, withUser, caption, fields, item, userData, customOn, cBg, cFg, cAccent, aspect, radius, padding, borderOn, align, showMark, showDivider, userMark]);

  const ALL_FIELDS = kind === "perfume"
    ? [
        ["image", "🖼 صورة", "🖼 Image"], ["name", "📝 الاسم", "📝 Name"], ["brand", "🏷 البراند", "🏷 Brand"],
        ["family", "🎨 العائلة", "🎨 Family"], ["notes", "🌸 النوتات", "🌸 Notes"], ["description", "📖 الوصف", "📖 Description"],
        ["occasions", "📍 المناسبات", "📍 Occasions"], ["year", "📅 السنة", "📅 Year"],
        ["rating", "■ التقييم", "■ Rating"], ["impression", "😊 الانطباع", "😊 Impression"],
        ["comment", "💬 التعليق", "💬 Comment"], ["wearCount", "👃 الارتداء", "👃 Wears"],
        ["recommend", "👍 التوصية", "👍 Recommend"],
      ]
    : [
        ["image", "🖼 الشعار", "🖼 Logo"], ["name", "📝 الاسم", "📝 Name"], ["year", "📅 البلد/السنة", "📅 Country/Year"],
        ["family", "🎨 نوتة التوقيع", "🎨 Signature"], ["description", "📖 الوصف", "📖 Description"],
        ["rating", "■ التقييم", "■ Rating"], ["impression", "😊 الانطباع", "😊 Impression"], ["comment", "💬 التعليق", "💬 Comment"],
      ];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {trigger || (
          <Button variant="outline" className="w-full h-10 rounded-none font-body gap-2" style={{ background: "#C8A02E", color: "#fff", border: "none" }}>
            <Download className="w-4 h-4" /> {isAr ? "تصدير بطاقة" : "Export Card"}
          </Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-md w-[calc(100vw-1.5rem)] max-h-[92vh] overflow-y-auto rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading text-base">{isAr ? "🎴 تصدير بطاقة فاخرة" : "🎴 Export Luxury Card"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          {/* معاينة حية — مثبّتة بالأعلى وتُصغّر لتناسب الشاشة، والخيارات تمرّر تحتها */}
          <div className="sticky top-0 z-20 -mx-4 px-4 pt-1 pb-2 bg-background">
            <div className="rounded-none overflow-auto border border-border flex justify-center bg-secondary/30 p-2" style={{ maxHeight: "44vh" }}>
              <div style={{ zoom: previewScale }} dangerouslySetInnerHTML={{ __html: previewHTML }} />
            </div>
          </div>

          {/* وضع المحتوى: مع/بدون مدخلات */}
          <div className="grid grid-cols-2 gap-2">
            <button onClick={() => setWithUser(true)} disabled={!userData}
              className={` rounded-none text-xs font-body ${withUser ? " text-primary-foreground" : " text-muted-foreground"} ${!userData ? "opacity-40" : ""}`}>
              {isAr ? "مع تقييمي" : "With my review"}
            </button>
            <button onClick={() => setWithUser(false)}
              className={` rounded-none text-xs font-body ${!withUser ? " text-primary-foreground" : " text-muted-foreground"}`}>
              {isAr ? "بطاقة تعريفية" : "Public card"}
            </button>
          </div>

          {/* اللغة */}
          <div className="flex gap-1.5">
            {[{ v: "ar", l: "عربي" }, { v: "en", l: "EN" }, { v: "both", l: isAr ? "اللغتين" : "Both" }].map((o) => (
              <button key={o.v} onClick={() => setLang(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${lang === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
            ))}
          </div>

          {/* تبويبات الخيارات */}
          <div className="flex gap-1.5 border-b border-border">
            {[
              { id: "theme", icon: <Palette className="w-3.5 h-3.5" />, l: isAr ? "السمة" : "Theme" },
              { id: "font", icon: <Type className="w-3.5 h-3.5" />, l: isAr ? "الخط" : "Font" },
              { id: "layout", icon: <Sliders className="w-3.5 h-3.5" />, l: isAr ? "الشكل" : "Layout" },
              { id: "fields", icon: <Check className="w-3.5 h-3.5" />, l: isAr ? "الحقول" : "Fields" },
            ].map((t) => (
              <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-1 px-3 py-2 text-xs font-body border-b-2 transition-colors ${tab === t.id ? "border-primary text-primary" : "border-transparent text-muted-foreground"}`}>
                {t.icon} {t.l}
              </button>
            ))}
          </div>

          {/* محتوى التبويب: السمة */}
          {tab === "theme" && (
            <div className="space-y-3">
              <div className="grid grid-cols-3 gap-2">
                {THEMES.map((t) => (
                  <button key={t.id} onClick={() => setTheme(t.id)}
                    className={`h-12 rounded-none border-2 transition-all relative ${theme === t.id ? "border-primary" : "border-transparent"}`}
                    style={{ background: t.bg }}>
                    <span style={{ color: t.fg, fontSize: 11 }}>{t.name}</span>
                    {theme === t.id && <Check className="w-3 h-3 absolute top-1 right-1" style={{ color: t.accent }} />}
                  </button>
                ))}
              </div>
              {/* خلفية صورة */}
              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-xs font-body text-primary cursor-pointer">
                  <ImageIcon className="w-3.5 h-3.5" /> {isAr ? "خلفية صورة" : "Background image"}
                  <input type="file" accept="image/*" className="hidden" onChange={(e) => {
                    const f = e.target.files?.[0]; if (!f) return;
                    const r = new FileReader(); r.onload = (ev) => setBgImage(ev.target.result); r.readAsDataURL(f);
                  }} />
                </label>
                {bgImage && <button onClick={() => setBgImage(null)} className="text-xs text-destructive font-body">{isAr ? "إزالة" : "Remove"}</button>}
              </div>
              {/* شدة تعتيم خلفية الصورة */}
              {bgImage && (
                <div>
                  <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? `تعتيم الخلفية: ${Math.round(bgDim * 100)}%` : `Background dim: ${Math.round(bgDim * 100)}%`}</p>
                  <input type="range" min="0.2" max="0.95" step="0.05" value={bgDim} onChange={(e) => setBgDim(parseFloat(e.target.value))} className="w-full accent-primary" />
                </div>
              )}
              {/* ألوان مخصّصة */}
              <div className="border-t border-border pt-2 space-y-2">
                <label className="flex items-center gap-2 text-xs font-body cursor-pointer">
                  <span className={`w-3.5 h-3.5 rounded-none flex items-center justify-center ${customOn ? "bg-primary text-primary-foreground" : "border border-border"}`}>{customOn && <Check className="w-2.5 h-2.5" />}</span>
                  <input type="checkbox" checked={customOn} onChange={() => setCustomOn(!customOn)} className="hidden" />
                  {isAr ? "ألوان مخصّصة (تتجاوز السمة)" : "Custom colors (override theme)"}
                </label>
                {customOn && (
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { l: isAr ? "خلفية" : "BG", v: cBg, set: setCBg },
                      { l: isAr ? "نص" : "Text", v: cFg, set: setCFg },
                      { l: isAr ? "تمييز" : "Accent", v: cAccent, set: setCAccent },
                    ].map((c, i) => (
                      <label key={i} className="flex flex-col items-center gap-1 text-[10px] font-body text-muted-foreground">
                        {c.l}
                        <input type="color" value={c.v} onChange={(e) => c.set(e.target.value)} className="w-full h-8 rounded cursor-pointer bg-transparent" />
                      </label>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* محتوى التبويب: الخط */}
          {tab === "font" && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                {FONTS.map((f) => (
                  <button key={f.id} onClick={() => setFontId(f.id)} style={{ fontFamily: f.stack }}
                    className={`py-2 rounded-none text-sm border ${fontId === f.id ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border"}`}>
                    {f.name}
                  </button>
                ))}
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? `حجم الخط: ${Math.round(fontScale * 100)}%` : `Font size: ${Math.round(fontScale * 100)}%`}</p>
                <input type="range" min="0.8" max="1.4" step="0.05" value={fontScale} onChange={(e) => setFontScale(parseFloat(e.target.value))} className="w-full accent-primary" />
              </div>
              <input value={caption} onChange={(e) => setCaption(e.target.value)} placeholder={isAr ? "نص/تعليق إضافي (اختياري)" : "Caption (optional)"} dir="auto"
                className="w-full rounded-none text-xs font-body" />
            </div>
          )}

          {/* محتوى التبويب: الشكل/التخطيط */}
          {tab === "layout" && (
            <div className="space-y-3">
              {/* الأبعاد */}
              <div>
                <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? "الأبعاد" : "Aspect"}</p>
                <div className="grid grid-cols-4 gap-1.5">
                  {ASPECTS.map((a) => (
                    <button key={a.id} onClick={() => setAspect(a.id)} className={`py-1.5 rounded-none text-[11px] font-body border ${aspect === a.id ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{a.name}</button>
                  ))}
                </div>
              </div>
              {/* المحاذاة */}
              <div>
                <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? "المحاذاة" : "Alignment"}</p>
                <div className="flex gap-1.5">
                  {[{ v: "center", l: isAr ? "وسط" : "Center" }, { v: "start", l: isAr ? "بداية" : "Start" }].map((o) => (
                    <button key={o.v} onClick={() => setAlign(o.v)} className={`flex-1 py-1.5 rounded-none text-xs font-body border ${align === o.v ? "bg-primary text-primary-foreground border-primary" : "bg-background border-border text-muted-foreground"}`}>{o.l}</button>
                  ))}
                </div>
              </div>
              {/* نصف قطر الحواف */}
              <div>
                <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? `استدارة الحواف: ${radius}px` : `Corner radius: ${radius}px`}</p>
                <input type="range" min="0" max="40" step="2" value={radius} onChange={(e) => setRadius(parseInt(e.target.value))} className="w-full accent-primary" />
              </div>
              {/* الحشو */}
              <div>
                <p className="text-[10px] text-muted-foreground font-body mb-1">{isAr ? `الحشو الداخلي: ${padding}px` : `Padding: ${padding}px`}</p>
                <input type="range" min="16" max="56" step="2" value={padding} onChange={(e) => setPadding(parseInt(e.target.value))} className="w-full accent-primary" />
              </div>
              {/* تبديلات */}
              <div className="grid grid-cols-1 gap-1.5">
                {[
                  { v: borderOn, set: setBorderOn, l: isAr ? "إطار رفيع" : "Thin border" },
                  { v: showDivider, set: setShowDivider, l: isAr ? "الفواصل الذهبية" : "Golden dividers" },
                  { v: showMark, set: setShowMark, l: isAr ? "رمزي الشخصي" : "My personal mark" },
                ].map((o, i) => (
                  <label key={i} className="flex items-center gap-2 text-xs font-body cursor-pointer">
                    <span className={`w-3.5 h-3.5 rounded-none flex items-center justify-center ${o.v ? "bg-primary text-primary-foreground" : "border border-border"}`}>{o.v && <Check className="w-2.5 h-2.5" />}</span>
                    <input type="checkbox" checked={o.v} onChange={() => o.set(!o.v)} className="hidden" />
                    {o.l}
                  </label>
                ))}
              </div>
            </div>
          )}

          {/* محتوى التبويب: الحقول */}
          {tab === "fields" && (
            <div className="grid grid-cols-2 gap-1.5">
              {ALL_FIELDS.map(([k, ar, en]) => (
                <button key={k} onClick={() => toggleField(k)}
                  className={`flex items-center gap-1.5 rounded-none text-xs font-body ${fields[k] ? " text-foreground" : " text-muted-foreground"}`}>
                  <span className={`w-3 h-3 rounded-none flex items-center justify-center ${fields[k] ? "bg-primary text-primary-foreground" : "border border-border"}`}>{fields[k] && <Check className="w-2.5 h-2.5" />}</span>
                  {isAr ? ar : en}
                </button>
              ))}
            </div>
          )}

          <Button className="w-full h-11 rounded-none font-body gap-2" onClick={handleExport} disabled={generating}>
            <Download className="w-4 h-4" /> {generating ? (isAr ? "جارٍ..." : "Generating...") : (isAr ? "تصدير الصورة" : "Export Image")}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
