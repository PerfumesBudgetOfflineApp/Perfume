/**
 * ExportOptionsDialog — the export options (toggles + export-color swatches)
 * presented as a popup window instead of an inline matrix. A small gear
 * trigger opens a dialog that wraps <ExportOptionsBar> plus the accent-color
 * picker. All state lives in exportSettings, so opening/closing is free.
 */

import React, { useState } from "react";
import { Settings2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import ExportOptionsBar from "./ExportOptionsBar";
import { useExportSettings } from "@/lib/exportSettings";
import { useLang } from "@/lib/LanguageContext";

const ACCENTS = ["#a16207", "#9D174D", "#047857", "#1d4ed8", "#6d28d9", "#334155"];

export default function ExportOptionsDialog({
  userMarkAvailable = true,
  showInteractionToggle = false,
  showAccent = true,
  triggerClassName = "",
}) {
  const [open, setOpen] = useState(false);
  const [settings, setSettings] = useExportSettings();
  const { isAr } = useLang();
  const exportAccent = settings.exportAccent || "#a16207";

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <button
          type="button"
          className={`inline-flex items-center gap-1.5 text-[11px] font-body text-muted-foreground hover:text-foreground transition-colors ${triggerClassName}`}
        >
          <Settings2 className="w-3.5 h-3.5" />
          {isAr ? "خيارات التصدير" : "Export options"}
        </button>
      </DialogTrigger>

      <DialogContent className="max-w-xs rounded-none">
        <DialogHeader>
          <DialogTitle className="text-sm font-heading text-center">
            {isAr ? "خيارات التصدير" : "Export options"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-5 pt-1">
          <ExportOptionsBar
            userMarkAvailable={userMarkAvailable}
            showInteractionToggle={showInteractionToggle}
          />

          {showAccent && (
            <div className="space-y-2">
              <span className="text-[10px] font-body uppercase text-muted-foreground tracking-wider">
                {isAr ? "لون التصدير" : "Export color"}
              </span>
              <div className="flex items-center gap-2 flex-wrap">
                {ACCENTS.map((c) => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setSettings({ exportAccent: c })}
                    aria-label={c}
                    className="w-6 h-6 rounded-none transition-transform"
                    style={{
                      background: c,
                      outline: exportAccent === c ? "2px solid #111827" : "1px solid rgba(0,0,0,0.15)",
                      outlineOffset: "1px",
                      transform: exportAccent === c ? "scale(1.12)" : "none",
                    }}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
