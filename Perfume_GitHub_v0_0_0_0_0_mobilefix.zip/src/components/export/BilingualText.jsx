/**
 * BilingualText — render a label with both English and Arabic safely.
 *
 * Solves the "html2canvas reverses Arabic when mixed with Latin in one string"
 * problem by emitting two isolated <span> elements with explicit direction.
 *
 * Variants:
 *   <BilingualText en="Top" ar="أعلى" />
 *     → "Top أعلى" with each side in its own bidi-isolated span
 *
 *   <BilingualText en="Top" ar="أعلى" stacked />
 *     → Top on top, أعلى below
 *
 *   <BilingualText en="Top" ar="أعلى" separator="·" />
 *     → "Top · أعلى"
 *
 * Accepts an optional `dir` prop that forces the order ("ltr" → en first,
 * "rtl" → ar first). Auto if omitted: ltr.
 */
import React from "react";

const COMMON = { unicodeBidi: "isolate", whiteSpace: "pre" };

export default function BilingualText({
  en,
  ar,
  stacked = false,
  separator = " ",
  dir = "ltr",
  className,
  style,
  lang = "mix",
}) {
  const hasEn = !!en;
  const hasAr = !!ar;
  if (!hasEn && !hasAr) return null;
  // Language scoping for export: "ar" → Arabic only, "en" → English only,
  // "mix" (default) → both. Lets the export card honor the chosen language
  // without touching each call site individually.
  if (lang === "ar" && hasAr) return <span className={className} style={style} dir="rtl">{ar}</span>;
  if (lang === "en" && hasEn) return <span className={className} style={style} dir="ltr">{en}</span>;
  if (hasEn && !hasAr) return <span className={className} style={style} dir="ltr">{en}</span>;
  if (!hasEn && hasAr) return <span className={className} style={style} dir="rtl">{ar}</span>;

  if (stacked) {
    return (
      <span className={className} style={{ display: "inline-flex", flexDirection: "column", alignItems: "flex-start", ...style }}>
        <span dir="ltr" style={COMMON}>{en}</span>
        <span dir="rtl" style={COMMON}>{ar}</span>
      </span>
    );
  }

  const first  = dir === "rtl" ? <span key="ar" dir="rtl" style={COMMON}>{ar}</span> : <span key="en" dir="ltr" style={COMMON}>{en}</span>;
  const second = dir === "rtl" ? <span key="en" dir="ltr" style={COMMON}>{en}</span> : <span key="ar" dir="rtl" style={COMMON}>{ar}</span>;
  const sep    = <span key="sep" style={{ unicodeBidi: "isolate" }}>{separator}</span>;

  return (
    <span className={className} style={style}>
      {first}{sep}{second}
    </span>
  );
}
