import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Search, Check } from "lucide-react";
import { cn } from "@/lib/utils";

export default function PerfumePicker({ perfumes, selected, onSelect, excludeIds = [] }) {
  const [search, setSearch] = useState("");

  // لا تعرض عطور حتى يكتب المستخدم — البحث يدعم العربي والإنجليزي
  const filtered = search.trim()
    ? perfumes.filter((p) => {
        if (excludeIds.includes(p.id)) return false;
        const q = search.toLowerCase();
        return (
          p.name?.toLowerCase().includes(q) ||
          p.name_en?.toLowerCase().includes(q) ||
          p.name_ar?.toLowerCase().includes(q) ||
          p.brand_name?.toLowerCase().includes(q)
        );
      }).slice(0, 30)
    : [];

  return (
    <div className="space-y-3">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث عن عطر... / Search perfume..."
          className="pl-10 h-10 rounded-none font-body bg-secondary/50 border-0 text-sm"
        />
      </div>
      {/* العطر المختار يظهر دائماً */}
      {selected && (
        <div className="flex items-center gap-3 px-3 py-2.5 rounded-none bg-primary/10 border border-primary/30">
          <div className="w-8 h-8 rounded-none bg-secondary flex items-center justify-center flex-shrink-0 text-base">
            {selected.image_url ? (
              <img src={selected.image_url} alt="" className="w-full h-full object-cover rounded-none" />
            ) : "🌸"}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-body font-semibold truncate">{selected.name_en || selected.name_ar || selected.name}</p>
            <p className="text-[10px] text-muted-foreground font-body truncate">{selected.brand_name}</p>
          </div>
          <Check className="w-4 h-4 text-primary flex-shrink-0" />
        </div>
      )}
      {/* نتائج البحث */}
      {search.trim() && (
        <div className="max-h-64 overflow-y-auto space-y-1 pr-1">
          {filtered.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => { onSelect(p); }}
              className={cn(
                "w-full flex items-center gap-3 px-3 py-2.5 rounded-none text-left transition-colors",
                selected?.id === p.id
                  ? "bg-primary/10 border border-primary/30"
                  : "hover:bg-secondary/60"
              )}
            >
              <div className="w-8 h-8 rounded-none bg-secondary flex items-center justify-center flex-shrink-0 text-base">
                {p.image_url ? (
                  <img src={p.image_url} alt="" className="w-full h-full object-cover rounded-none" />
                ) : "🌸"}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-body font-semibold truncate">{p.name_en || p.name_ar || p.name}</p>
                <p className="text-[10px] text-muted-foreground font-body truncate">{p.brand_name}</p>
              </div>
              {selected?.id === p.id && <Check className="w-4 h-4 text-primary flex-shrink-0" />}
            </button>
          ))}
          {filtered.length === 0 && (
            <p className="text-xs text-muted-foreground font-body text-center py-4">لا توجد نتائج No perfumes found</p>
          )}
        </div>
      )}
    </div>
  );
}