import { useState } from "react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isToday } from "date-fns";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const DAYS = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

export default function WearCalendar({ logs, onDayClick }) {
  const [current, setCurrent] = useState(new Date());

  const monthStart = startOfMonth(current);
  const monthEnd = endOfMonth(current);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });
  const startPad = getDay(monthStart);

  const getLogsForDay = (day) =>
    logs.filter((l) => l.date === format(day, "yyyy-MM-dd"));

  return (
    <div className="space-y-3">
      {/* Month navigation */}
      <div className="flex items-center justify-between">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrent((d) => new Date(d.getFullYear(), d.getMonth() - 1))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <h3 className="font-heading font-semibold text-sm">{format(current, "MMMM yyyy")}</h3>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrent((d) => new Date(d.getFullYear(), d.getMonth() + 1))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 gap-1">
        {DAYS.map((d) => (
          <div key={d} className="text-center text-[10px] font-body text-muted-foreground py-1">{d}</div>
        ))}

        {/* Padding cells */}
        {Array.from({ length: startPad }).map((_, i) => (
          <div key={`pad-${i}`} />
        ))}

        {/* Day cells */}
        {days.map((day) => {
          const dayLogs = getLogsForDay(day);
          const hasLog = dayLogs.length > 0;
          const today = isToday(day);

          return (
            <button
              key={day.toString()}
              onClick={() => onDayClick(day, dayLogs)}
              className={cn(
                "relative aspect-square flex flex-col items-center justify-center rounded-none text-xs font-body transition-all",
                today && "ring-2 ring-primary/50",
                hasLog ? "bg-primary/15 text-primary font-semibold hover:bg-primary/25" : "hover:bg-secondary text-foreground/80"
              )}
            >
              <span className={cn("text-xs", today && "font-bold")}>{format(day, "d")}</span>
              {hasLog && (
                <span className="text-[8px] leading-none mt-0.5 text-primary/70">
                  {dayLogs.length > 1 ? `×${dayLogs.length}` : "•"}
                </span>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}