import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Edit2, Trash2, ChevronDown, ChevronUp } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";

const moodEmojis = {
  amazing: "😍", happy: "😊", calm: "😌", confident: "😎",
  romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡",
  thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑",
};

export default function LogEditSections({ logs }) {
  const { names } = usePersonNames();
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState(null);
  const [expandedPerson, setExpandedPerson] = useState("person1");
  const [formData, setFormData] = useState({});

  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.update(editingId, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success("تم التحديث");
      setEditingId(null);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.WearLog.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success("تم الحذف");
    },
  });

  const handleEdit = (log) => {
    setEditingId(log.id);
    setFormData({
      mood: log.mood || "",
      note: log.note || "",
    });
  };

  const handleSave = () => {
    updateMutation.mutate({
      mood: formData.mood || null,
      note: formData.note,
    });
  };

  const renderPersonSection = (person) => {
    const personLogs = logs.filter((l) =>
      person === "person1"
        ? l.person === "person1" || !l.person
        : l.person === "person2"
    );

    return (
      <div key={person} className="space-y-2">
        <button
          onClick={() => setExpandedPerson(expandedPerson === person ? null : person)}
          className="w-full flex items-center justify-between px-4 py-3 bg-secondary/50 rounded-none hover:bg-secondary transition-colors"
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-none ${person === "person1" ? "bg-primary" : "bg-violet-500"}`} />
            <span className="text-sm font-body font-semibold">
              {person === "person1" ? names.person1 : names.person2}
            </span>
            <span className="text-xs text-muted-foreground">· {personLogs.length} logs</span>
          </div>
          {expandedPerson === person ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>

        {expandedPerson === person && (
          <div className="bg-card rounded-none p-4 space-y-2 border border-border/60">
            {personLogs.length === 0 ? (
              <p className="text-xs text-muted-foreground font-body text-center py-4">لا سجلات بعد No logs yet</p>
            ) : (
              personLogs.map((log) => (
                <div key={log.id} className="space-y-2 pb-3 border-b border-border/30 last:border-0 last:pb-0">
                  {editingId === log.id ? (
                    <div className="space-y-2">
                      <div>
                        <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">المزاج Mood</p>
                        <div className="grid grid-cols-4 gap-1">
                          {Object.entries(moodEmojis).map(([value, emoji]) => (
                            <button
                              key={value}
                              onClick={() => setFormData({ ...formData, mood: formData.mood === value ? "" : value })}
                              className={`py-2 rounded-none text-xs font-body transition-all ${
                                formData.mood === value
                                  ? "bg-primary/10 border border-primary shadow-sm"
                                  : "bg-secondary/40 border border-border/50"
                              }`}
                            >
                              <span className="text-sm">{emoji}</span>
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground font-body uppercase mb-1">ملاحظة Note</p>
                        <Textarea
                          value={formData.note}
                          onChange={(e) => setFormData({ ...formData, note: e.target.value })}
                          className="rounded-none font-body text-xs min-h-[48px] resize-none"
                          placeholder="ملاحظة اختيارية... Optional note..."
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          className="flex-1 rounded-none font-body text-xs h-8"
                          onClick={handleSave}
                          disabled={updateMutation.isPending}
                        >
                          {updateMutation.isPending ? "Saving..." : "Save"}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="flex-1 rounded-none font-body text-xs h-8"
                          onClick={() => setEditingId(null)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-start justify-between group">
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-body font-medium">{log.perfume_name}</span>
                          {log.mood && <span className="text-base">{moodEmojis[log.mood]}</span>}
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-muted-foreground font-body">{log.date}</span>
                          {log.note && <span className="text-[10px] text-muted-foreground italic">— {log.note}</span>}
                        </div>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => handleEdit(log)}
                          className="text-muted-foreground hover:text-primary transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteMutation.mutate(log.id)}
                          className="text-muted-foreground hover:text-destructive transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-3">
      <p className="text-xs font-body font-semibold text-muted-foreground uppercase tracking-wider px-1">تعديل سجلات الارتداء Edit Wear Logs</p>
      {renderPersonSection("person1")}
      {renderPersonSection("person2")}
    </div>
  );
}