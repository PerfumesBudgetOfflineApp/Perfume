import { useMemo } from "react";

export default function SeasonalRecommendationsTable({ perfumes, logs }) {
  const seasonalRecs = useMemo(() => {
    const SEASON_MAP = { 12: "Winter", 1: "Winter", 2: "Winter", 3: "Spring", 4: "Spring", 5: "Spring", 6: "Summer", 7: "Summer", 8: "Summer", 9: "Fall", 10: "Fall", 11: "Fall" };
    const wearCount = {};
    logs.forEach((l) => {
      if (!l.date) return;
      const m = parseInt(l.date.split("-")[1], 10);
      const s = SEASON_MAP[m];
      if (!wearCount[s]) wearCount[s] = {};
      wearCount[s][l.perfume_id] = (wearCount[s][l.perfume_id] || 0) + 1;
    });

    const recs = {};
    ["Spring", "Summer", "Fall", "Winter"].forEach((season) => {
      const counts = wearCount[season] || {};
      recs[season] = perfumes
        .filter((p) => counts[p.id])
        .sort((a, b) => counts[b.id] - counts[a.id])
        .slice(0, 3)
        .map((p) => ({ name: p.name, brand: p.brand_name, count: counts[p.id] }));
    });
    return recs;
  }, [perfumes, logs]);

  return (
    <div className="bg-card rounded-none p-4 border border-border/60 space-y-3">
      <h3 className="font-heading font-semibold text-sm">توصيات موسمية Seasonal Recommendations</h3>
      {Object.keys(seasonalRecs).every((s) => seasonalRecs[s].length === 0) ? (
        <p className="text-xs text-muted-foreground font-body text-center py-4">سجّل ارتداءات أكثر لرؤية التوصيات Log more wear data to see recommendations</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-border/40">
                <th className="text-left py-2 px-2 font-semibold text-muted-foreground">الربيع Spring</th>
                <th className="text-left py-2 px-2 font-semibold text-muted-foreground">الصيف Summer</th>
                <th className="text-left py-2 px-2 font-semibold text-muted-foreground">الخريف Fall</th>
                <th className="text-left py-2 px-2 font-semibold text-muted-foreground">الشتاء Winter</th>
              </tr>
            </thead>
            <tbody>
              {[0, 1, 2].map((i) => (
                <tr key={i} className="border-b border-border/20 last:border-b-0">
                  {["Spring", "Summer", "Fall", "Winter"].map((season) => {
                    const item = seasonalRecs[season][i];
                    return (
                      <td key={season} className="py-3 px-2">
                        {item ? (
                          <div className="space-y-1">
                            <p className="font-body font-medium text-foreground">{item.name}</p>
                            <p className="text-[10px] text-muted-foreground">{item.brand}</p>
                            <p className="text-[10px] text-primary font-semibold mt-0.5">{item.count}× worn</p>
                          </div>
                        ) : (
                          <p className="text-muted-foreground/50 text-[10px]">—</p>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}