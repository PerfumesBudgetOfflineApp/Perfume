import { useMemo, useState } from "react";
import { format } from "date-fns";
import { User, Users, StickyNote } from "lucide-react";
import { Link } from "react-router-dom";

export default function WearNotes({ logs, names }) {
  const [personFilter, setPersonFilter] = useState("all");

  const notes = useMemo(() => {
    return logs
      .filter((l) => l.note && l.note.trim())
      .filter((l) => {
        if (personFilter === "all") return true;
        if (personFilter === "person1") return l.person === "person1" || !l.person;
        return l.person === "person2";
      })
      .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
  }, [logs, personFilter]);

  // Group by month
  const grouped = useMemo(() => {
    const map = {};
    notes.forEach((l) => {
      const key = l.date ? format(new Date(l.date), "MMMM yyyy") : "Unknown";
      if (!map[key]) map[key] = [];
      map[key].push(l);
    });
    return Object.entries(map);
  }, [notes]);

  return (
    <div className="space-y-4">
      {/* Person filter */}
      <div className="flex gap-2">
        {[
          { val: "all", label: "Both", icon: <Users className="w-3 h-3" /> },
          { val: "person1", label: names.person1, icon: <User className="w-3 h-3" /> },
          { val: "person2", label: names.person2, icon: <User className="w-3 h-3" /> },
        ].map(({ val, label, icon }) => (
          <button
            key={val}
            onClick={() => setPersonFilter(val)}
            className={`flex items-center gap-1 rounded-none text-xs font-body font-medium transition-all ${
 personFilter === val
 ? val === "person2"
 ? " text-white "
 : " text-primary-foreground "
 : " text-muted-foreground hover:text-foreground"
 }`}
          >
            {icon}{label}
          </button>
        ))}
      </div>

      {grouped.length === 0 ? (
        <div className="py-12 text-center space-y-3">
          <div className="w-12 h-12 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <StickyNote className="w-6 h-6 text-muted-foreground/50" />
          </div>
          <p className="text-xs text-muted-foreground font-body">No reviews yet — add one when logging a perfume.</p>
        </div>
      ) : (
        grouped.map(([month, items]) => (
          <div key={month} className="space-y-2">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body px-1">{month}</p>
            {items.map((l) => {
              const isPerson2 = l.person === "person2";
              return (
                <div key={l.id} className="bg-card rounded-none border border-border/60 px-3 py-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className={`text-[10px] font-body font-bold rounded-none flex-shrink-0 ${isPerson2 ? " text-violet-600" : " text-primary"}`}>
                        {isPerson2 ? names.person2 : names.person1}
                      </span>
                      <Link to={`/perfume?id=${l.perfume_id}`} className="text-xs font-body font-semibold truncate hover:text-primary transition-colors">{l.perfume_name}</Link>
                      {l.brand_name && <span className="text-[10px] text-muted-foreground font-body truncate hidden sm:block">· {l.brand_name}</span>}
                    </div>
                    <span className="text-[10px] text-muted-foreground font-body flex-shrink-0">
                      {l.date ? format(new Date(l.date), "dd MMM") : ""}
                    </span>
                  </div>
                  <p className="text-xs font-body text-foreground/80 leading-relaxed pl-1">{l.note}</p>
                </div>
              );
            })}
          </div>
        ))
      )}
    </div>
  );
}