import { useMemo } from "react";

const SEASON_MAP = { 12: "Winter", 1: "Winter", 2: "Winter", 3: "Spring", 4: "Spring", 5: "Spring", 6: "Summer", 7: "Summer", 8: "Summer", 9: "Fall", 10: "Fall", 11: "Fall" };
const SEASON_ICONS = { Spring: "🌸", Summer: "☀️", Fall: "🍂", Winter: "❄️" };
const SEASON_COLORS = { Spring: "hsl(120,55%,45%)", Summer: "hsl(43,90%,55%)", Fall: "hsl(27,80%,50%)", Winter: "hsl(197,65%,50%)" };

const SEASONAL_NOTES = {
  Spring: ["Floral", "Fresh", "Citrus", "Green", "Light", "Fruity"],
  Summer: ["Citrus", "Fresh", "Aquatic", "Fruity", "Light", "Green"],
  Fall: ["Spicy", "Woody", "Warm", "Oriental", "Amber", "Vanilla"],
  Winter: ["Oriental", "Amber", "Vanilla", "Woody", "Warm", "Spicy"],
};

export default function SeasonalSuggestions({ perfumes, logs }) {
  const currentMonth = new Date().getMonth() + 1;
  const currentSeason = SEASON_MAP[currentMonth];

  const suggestions = useMemo(() => {
    if (!perfumes.length || !logs.length) return { suggestions: [], stats: null };

    // Count season-specific wear patterns
    const seasonWears = { Spring: {}, Summer: {}, Fall: {}, Winter: {} };
    logs.forEach((log) => {
      if (!log.date) return;
      const m = parseInt(log.date.split("-")[1], 10);
      const s = SEASON_MAP[m];
      if (s) {
        if (!seasonWears[s][log.perfume_id]) seasonWears[s][log.perfume_id] = 0;
        seasonWears[s][log.perfume_id]++;
      }
    });

    // Score perfumes for current season
    const scoredPerfumes = perfumes.map((p) => {
      let score = 0;

      // Season match
      if (p.season === currentSeason || p.season === "All Seasons") score += 2;

      // Time of day relevance (day = summer/spring, night = winter/fall)
      const dayWeight = ["Summer", "Spring"].includes(currentSeason) ? 1 : 0;
      const nightWeight = ["Winter", "Fall"].includes(currentSeason) ? 1 : 0;
      if (p.time_of_day === "All") score += 1;
      if (p.time_of_day === "Day" && dayWeight) score += 2;
      if (p.time_of_day === "Night" && nightWeight) score += 2;

      // Note profile matching
      const notes = [p.top_notes, p.heart_notes, p.base_notes].filter(Boolean);
      const noteStr = notes.join(" ").toUpperCase();
      const seasonalNotes = SEASONAL_NOTES[currentSeason] || [];
      const matchedNotes = seasonalNotes.filter((n) => noteStr.includes(n.toUpperCase())).length;
      score += matchedNotes * 1.5;

      // Past wear frequency in this season
      const seasonWearCount = seasonWears[currentSeason][p.id] || 0;
      score += Math.min(seasonWearCount, 5) * 0.5;

      // Ratings boost
      if (p.rating >= 4) score += 2;
      if (p.rating === 5) score += 1;

      return { ...p, score, matchedNotes };
    });

    const sorted = scoredPerfumes
      .filter((p) => p.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 6);

    // Calculate stats
    const totalLogged = new Set(logs.map((l) => l.perfume_id)).size;
    const seasonLogged = new Set(
      logs.filter((l) => {
        if (!l.date) return false;
        const m = parseInt(l.date.split("-")[1], 10);
        return SEASON_MAP[m] === currentSeason;
      }).map((l) => l.perfume_id)
    ).size;

    return {
      suggestions: sorted,
      stats: { totalLogged, seasonLogged, seasonWearTotal: logs.filter((l) => SEASON_MAP[parseInt(l.date?.split("-")[1] || 0, 10)] === currentSeason).length },
    };
  }, [perfumes, logs, currentSeason]);

  if (!suggestions.suggestions.length) {
    return (
      <div className="bg-card rounded-none p-4 border border-border/60 space-y-3">
        <h3 className="font-heading font-semibold text-sm">توصيات موسمية Seasonal Recommendations</h3>
        <div className="py-6 text-center text-xs text-muted-foreground font-body">No suggestions yet. Build wear history to see personalized recommendations!</div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-none p-4 border border-border/60 space-y-4">
      <div className="space-y-1">
        <h3 className="font-heading font-semibold text-sm">توصيات موسمية Seasonal Recommendations</h3>
        <p className="text-[11px] text-muted-foreground font-body">
          Best picks for {currentSeason} {SEASON_ICONS[currentSeason]}
        </p>
      </div>

      {suggestions.stats && (
        <div className="grid grid-cols-3 gap-2">
          <div className="bg-secondary/40 rounded-none p-2">
            <p className="text-[9px] text-muted-foreground font-body uppercase font-semibold">إجمالي العطور Total Perfumes</p>
            <p className="text-sm font-body font-semibold">{suggestions.stats.totalLogged}</p>
          </div>
          <div className="bg-secondary/40 rounded-none p-2">
            <p className="text-[9px] text-muted-foreground font-body uppercase font-semibold">في هذا الموسم In This Season</p>
            <p className="text-sm font-body font-semibold">{suggestions.stats.seasonLogged}</p>
          </div>
          <div className="bg-secondary/40 rounded-none p-2">
            <p className="text-[9px] text-muted-foreground font-body uppercase font-semibold">ارتداءات الموسم Season Wears</p>
            <p className="text-sm font-body font-semibold">{suggestions.stats.seasonWearTotal}</p>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {suggestions.suggestions.map((p, i) => (
          <div key={p.id} className="bg-secondary/40 rounded-none p-3 space-y-1.5">
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-body font-bold text-muted-foreground flex-shrink-0">#{i + 1}</span>
                  <p className="text-xs font-body font-semibold truncate">{p.name}</p>
                </div>
                <p className="text-[10px] text-muted-foreground font-body truncate">{p.brand_name}</p>
              </div>
              <div className="flex items-center gap-1 flex-shrink-0">
                {p.rating > 0 && (
                  <div className="flex">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <span key={s} className={`text-[9px] ${s <= p.rating ? "text-primary" : "text-border"}`}>{s <= p.rating ? "■" : "□"}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Match indicators */}
            <div className="flex flex-wrap gap-1">
              {p.season && p.season !== "All Seasons" && (
                <span className="inline-flex items-center gap-0.5 text-primary rounded-none text-[9px] font-body font-medium">
                  🌍 {p.season}
                </span>
              )}
              {p.time_of_day && p.time_of_day !== "All" && (
                <span className="inline-flex items-center gap-0.5 text-accent-foreground rounded-none text-[9px] font-body font-medium">
                  {p.time_of_day === "Day" ? "☀️" : "🌙"} {p.time_of_day}
                </span>
              )}
              {p.matchedNotes > 0 && (
                <span className="inline-flex items-center gap-0.5 text-pink-600 dark:text-pink-400 rounded-none text-[9px] font-body font-medium">
                  🎨 {p.matchedNotes} notes
                </span>
              )}
            </div>

            {/* Description */}
            {p.description && (
              <p className="text-[10px] text-muted-foreground font-body italic line-clamp-2">{p.description}</p>
            )}
          </div>
        ))}
      </div>

      <div className="text-[10px] text-muted-foreground font-body bg-accent/30 rounded-none p-2 italic">
        💡 Recommendations based on seasonal notes, time of day preferences, ratings, and your wear history.
      </div>
    </div>
  );
}