import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { Link } from "react-router-dom";
import { Trash2, Check } from "lucide-react";
import { format } from "date-fns";
import { toast } from "sonner";

/**
 * WearListView — ONE shared component for showing the wear log (past) or the
 * wear schedule (future) grouped per person. Editing/deleting happens here so
 * the same logic is reused on the Collection page and elsewhere (no duplicated
 * edit screens → fewer of the bugs we saw with perfume/brand edits).
 *
 * mode: "log"  → reads WearLog,     past entries
 *       "future" → reads WearSchedule, active upcoming entries
 */
export default function WearListView({ mode = "log", names, profiles }) {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const today = format(new Date(), "yyyy-MM-dd");

  const isFuture = mode === "future";

  const { data: logs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-date"),
    enabled: !isFuture,
  });

  const { data: schedules = [] } = useQuery({
    queryKey: ["wear-schedules"],
    queryFn: () => apphost.entities.WearSchedule.list("scheduled_date"),
    enabled: isFuture,
  });

  const delLog = useMutation({
    mutationFn: (id) => apphost.entities.WearLog.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wear-logs"] }); toast.success(isAr ? "حُذف" : "Removed"); },
  });

  const delSchedule = useMutation({
    mutationFn: (id) => apphost.entities.WearSchedule.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wear-schedules"] }); qc.invalidateQueries({ queryKey: ["wear-schedules-perfume"] }); toast.success(isAr ? "حُذف" : "Removed"); },
  });

  const doneSchedule = useMutation({
    mutationFn: (s) => {
      if (!s.repeat || s.repeat === "once") {
        return apphost.entities.WearSchedule.update(s.id, { last_done_date: today, is_active: false });
      }
      return apphost.entities.WearSchedule.update(s.id, { last_done_date: today });
    },
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["wear-schedules"] }); toast.success(isAr ? "تم" : "Done"); },
  });

  const repeatLabel = (r) => {
    const map = {
      once: isAr ? "مرة" : "Once", daily: isAr ? "يومي" : "Daily",
      weekly: isAr ? "أسبوعي" : "Weekly", monthly: isAr ? "شهري" : "Monthly", yearly: isAr ? "سنوي" : "Yearly",
    };
    return map[r] || map.once;
  };
  const moodEmojis = { amazing: "😍", happy: "😊", calm: "😌", confident: "😎", romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡", thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑" };

  const persons = ["person1", "person2"];

  const itemsFor = (person) =>
    (isFuture ? schedules.filter((s) => s.is_active) : logs).filter((x) => (x.person || "person1") === person);

  return (
    <div className="space-y-6">
      {persons.map((person) => {
        const items = itemsFor(person);
        const name = names?.[person] || (person === "person2" ? "Person 2" : "Person 1");
        const color = profiles?.[person]?.color || (person === "person2" ? "#8b5cf6" : "#16a34a");
        const photo = profiles?.[person]?.photo;
        return (
          <div key={person} className="space-y-3">
            {/* Person header */}
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-none border-2 overflow-hidden flex items-center justify-center flex-shrink-0" style={{ borderColor: color, background: color + "22" }}>
                {photo ? <img src={photo} alt={name} className="w-full h-full object-cover" /> : <span className="text-xs font-bold" style={{ color }}>{name?.[0]?.toUpperCase()}</span>}
              </div>
              <div>
                <p className="font-heading font-semibold text-sm">{name}</p>
                <p className="text-[11px] text-muted-foreground font-body">
                  {items.length} {isFuture ? (isAr ? "مجدول" : "scheduled") : (isAr ? "ارتداء" : "logged")}
                </p>
              </div>
            </div>

            {items.length === 0 ? (
              <p className="text-xs text-muted-foreground font-body pl-10">
                {isFuture ? (isAr ? "لا ارتداء قادم." : "Nothing scheduled.") : (isAr ? "لا سجل ارتداء." : "No wear logs.")}
              </p>
            ) : (
              <div className="space-y-2">
                {items.map((x) => (
                  <div key={x.id} className="flex items-center gap-2 bg-secondary/40 rounded-none p-2.5">
                    <Link to={`/perfume?id=${x.perfume_id}`} className="w-9 h-9 rounded-none overflow-hidden bg-white flex items-center justify-center flex-shrink-0 border border-border/30">
                      {x.image_url ? <img src={x.image_url} alt="" className="w-full h-full object-contain" /> : <span className="text-base">🧴</span>}
                    </Link>
                    <Link to={`/perfume?id=${x.perfume_id}`} className="flex-1 min-w-0">
                      <p className="text-xs font-body font-semibold truncate">{x.perfume_name}</p>
                      <p className="text-[10px] text-muted-foreground font-body truncate">
                        {isFuture
                          ? `${x.scheduled_date}${x.scheduled_time ? ` · ${x.scheduled_time}` : ""} · ${repeatLabel(x.repeat)}${x.note ? ` · ${x.note}` : ""}`
                          : `${x.date}${x.mood ? ` · ${moodEmojis[x.mood] || ""}` : ""}${x.note ? ` · ${x.note}` : ""}`}
                      </p>
                    </Link>
                    {isFuture && (
                      <button onClick={() => doneSchedule.mutate(x)} title={isAr ? "تم الارتداء" : "Mark worn"} className="w-8 h-8 rounded-none bg-pink-100 dark:bg-pink-900/30 text-pink-600 dark:text-pink-400 flex items-center justify-center hover:bg-pink-200 transition-colors flex-shrink-0">
                        <Check className="w-4 h-4" />
                      </button>
                    )}
                    <button onClick={() => (isFuture ? delSchedule : delLog).mutate(x.id)} className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0 w-8 h-8 flex items-center justify-center">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
