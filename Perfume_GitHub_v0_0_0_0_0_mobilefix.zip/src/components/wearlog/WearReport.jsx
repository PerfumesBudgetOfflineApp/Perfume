import { getAppName } from "@/lib/useAppName";
import { useState } from "react";
import { format, startOfDay, startOfWeek, startOfMonth, startOfYear } from "date-fns";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { apphost } from "@/api/apphostClient";
import { FileDown, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useCurrency } from "@/lib/useCurrency";
import { openHtmlReport } from "@/lib/exportHelper";

const PERIODS = [
  { value: "daily", label: "Today" },
  { value: "weekly", label: "This Week" },
  { value: "monthly", label: "This Month" },
  { value: "yearly", label: "This Year" },
  { value: "all", label: "All Time" },
];

function getRangeStart(period) {
  const now = new Date();
  switch (period) {
    case "daily": return startOfDay(now);
    case "weekly": return startOfWeek(now, { weekStartsOn: 1 });
    case "monthly": return startOfMonth(now);
    case "yearly": return startOfYear(now);
    case "all": return new Date(0);
    default: return startOfMonth(now);
  }
}

function buildReportText({ period, logs, names }) {
  const start = getRangeStart(period);
  const periodLabel = PERIODS.find((p) => p.value === period)?.label || period;
  const filtered = logs.filter((l) => l.date && new Date(l.date) >= start);

  const p1Logs = filtered.filter((l) => l.person === "person1" || !l.person);
  const p2Logs = filtered.filter((l) => l.person === "person2");

  const countMap = (arr) => {
    const c = {};
    arr.forEach((l) => {
      const key = l.perfume_name;
      if (!c[key]) c[key] = { name: l.perfume_name, brand: l.brand_name, count: 0, notes: [] };
      c[key].count++;
      if (l.note) c[key].notes.push(l.note);
    });
    return Object.values(c).sort((a, b) => b.count - a.count);
  };

  const p1Top = countMap(p1Logs);
  const p2Top = countMap(p2Logs);
  const notedLogs = filtered.filter((l) => l.note).sort((a, b) => (b.date || "").localeCompare(a.date || ""));

  let text = `ME / WE — ${periodLabel.toUpperCase()} REPORT\n`;
  text += `Generated: ${format(new Date(), "dd MMM yyyy, HH:mm")}\n`;
  text += `Period: ${format(start, "dd MMM yyyy")} → ${format(new Date(), "dd MMM yyyy")}\n`;
  text += `${"─".repeat(40)}\n\n`;
  text += `SUMMARY\n`;
  text += `Total logs: ${filtered.length}  |  ${names.person1}: ${p1Logs.length}  |  ${names.person2}: ${p2Logs.length}\n`;
  text += `Unique days: ${new Set(filtered.map((l) => l.date)).size}\n\n`;

  const section = (personName, top) => {
    if (top.length === 0) return `${personName}\n  — No logs this period\n\n`;
    let s = `${personName} (${top.reduce((a, t) => a + t.count, 0)} logs)\n`;
    top.forEach((t, i) => {
      s += `  ${i + 1}. ${t.name} (${t.brand || "—"}) — ${t.count}×\n`;
      t.notes.forEach((n) => { s += `     💬 "${n}"\n`; });
    });
    return s + "\n";
  };

  text += section(names.person1, p1Top);
  text += section(names.person2, p2Top);

  if (notedLogs.length > 0) {
    text += `ALL NOTES (${notedLogs.length})\n`;
    notedLogs.forEach((l) => {
      const who = l.person === "person2" ? names.person2 : names.person1;
      text += `  [${l.date}] ${who} — ${l.perfume_name}: "${l.note}"\n`;
    });
  }

  return text;
}

export default function WearReport({ logs, names }) {
  const { formatPrice } = useCurrency();
  const [open, setOpen] = useState(false);
  const [period, setPeriod] = useState("monthly");
  const [loading, setLoading] = useState(false);
  const [purchases, setPurchases] = useState([]);

  const handleExport = async () => {
    setLoading(true);
    const text = buildReportText({ period, logs, names });

    // Fetch purchases
    const allPurchases = await apphost.entities.PurchaseRecord.list("-created_date");
    setPurchases(allPurchases);

    // Use LLM to produce a nicely formatted HTML report, then convert via jsPDF
    const periodLabel = PERIODS.find((p) => p.value === period)?.label || period;

    const start = getRangeStart(period);
    const filtered = logs.filter((l) => l.date && new Date(l.date) >= start);
    const filteredPurchases = allPurchases.filter((p) => p.purchase_date && new Date(p.purchase_date) >= start);
    const p1Logs = filtered.filter((l) => l.person === "person1" || !l.person);
    const p2Logs = filtered.filter((l) => l.person === "person2");
    const p1Purchases = filteredPurchases.filter((p) => p.person === "person1" || !p.person);
    const p2Purchases = filteredPurchases.filter((p) => p.person === "person2");

    // Build HTML directly (no LLM needed)
    const countMap = (arr) => {
      const c = {};
      arr.forEach((l) => {
        if (!c[l.perfume_name]) c[l.perfume_name] = { name: l.perfume_name, brand: l.brand_name || "", count: 0, notes: [] };
        c[l.perfume_name].count++;
        if (l.note) c[l.perfume_name].notes.push({ date: l.date, text: l.note });
      });
      return Object.values(c).sort((a, b) => b.count - a.count);
    };

    const p1Top = countMap(p1Logs);
    const p2Top = countMap(p2Logs);
    const notedLogs = filtered.filter((l) => l.note).sort((a, b) => (b.date || "").localeCompare(a.date || ""));

    const purchaseRowsHTML = (purchases) => purchases.length === 0
      ? `<tr><td colspan="5" style="color:#888;font-style:italic;padding:6px 8px">لا مشتريات هذه الفترة No purchases this period</td></tr>`
      : purchases.map((p, i) => `
          <tr style="background:${i % 2 === 0 ? "#f9f9f7" : "#fff"}">
            <td style="padding:5px 8px;font-size:12px">${p.purchase_date}</td>
            <td style="padding:5px 8px;font-size:12px">${p.perfume_name}</td>
            <td style="padding:5px 8px;font-size:11px;color:#666">${p.type === "sample" ? "Sample" : "Bottle"}</td>
            <td style="padding:5px 8px;font-size:12px;text-align:center">${p.ml}ml</td>
            <td style="padding:5px 8px;font-size:12px;text-align:right;font-weight:600">${formatPrice(p.cost.toFixed(0))}</td>
          </tr>
        `).join("");

    const rowsHTML = (top) => top.length === 0
      ? `<tr><td colspan="3" style="color:#888;font-style:italic;padding:6px 8px">لا سجلات هذه الفترة No logs this period</td></tr>`
      : top.map((t, i) => `
          <tr style="background:${i % 2 === 0 ? "#f9f9f7" : "#fff"}">
            <td style="padding:5px 8px;font-size:12px">${i + 1}. ${t.name}</td>
            <td style="padding:5px 8px;font-size:11px;color:#666">${t.brand}</td>
            <td style="padding:5px 8px;font-size:12px;font-weight:600;text-align:center">${t.count}×</td>
          </tr>
          ${t.notes.map((n) => `<tr><td colspan="3" style="padding:2px 8px 6px 24px;font-size:11px;color:#555;font-style:italic">💬 ${n.date} — "${n.text}"</td></tr>`).join("")}
        `).join("");

    const html = `
      <html><head><meta charset="utf-8">
      <style>body{font-family:Georgia,serif;margin:32px;color:#1a1a1a}h1{font-size:22px;margin-bottom:4px}h2{font-size:15px;margin:20px 0 8px;border-bottom:1px solid #ddd;padding-bottom:4px}table{width:100%;border-collapse:collapse}th{background:#1a1a1a;color:#fff;padding:6px 8px;font-size:11px;text-align:left}.chip{display:inline-block;padding:2px 10px;border-radius:20px;font-size:11px;font-weight:600}.p1{background:#dcfce7;color:#16a34a}.p2{background:#ede9fe;color:#7c3aed}.meta{font-size:12px;color:#666;margin-bottom:20px}</style>
      </head><body>
        <h1>🌸 ${getAppName().name_en} — ${periodLabel} Report</h1>
        <div class="meta">Generated ${format(new Date(), "dd MMM yyyy, HH:mm")} &nbsp;·&nbsp; ${format(start, "dd MMM yyyy")} → ${format(new Date(), "dd MMM yyyy")}</div>
        <div style="display:flex;gap:16px;margin-bottom:20px">
          <div style="background:#f1f5f9;border-radius:10px;padding:10px 16px;text-align:center"><div style="font-size:22px;font-weight:700">${filtered.length}</div><div style="font-size:11px;color:#666">إجمالي السجلات Total Logs</div></div>
          <div style="background:#dcfce7;border-radius:10px;padding:10px 16px;text-align:center"><div style="font-size:22px;font-weight:700;color:#16a34a">${p1Logs.length}</div><div style="font-size:11px;color:#666">${names.person1}</div></div>
          <div style="background:#ede9fe;border-radius:10px;padding:10px 16px;text-align:center"><div style="font-size:22px;font-weight:700;color:#7c3aed">${p2Logs.length}</div><div style="font-size:11px;color:#666">${names.person2}</div></div>
          <div style="background:#fef9c3;border-radius:10px;padding:10px 16px;text-align:center"><div style="font-size:22px;font-weight:700;color:#ca8a04">${new Set(filtered.map((l) => l.date)).size}</div><div style="font-size:11px;color:#666">أيام Days</div></div>
        </div>
        <h2><span class="chip p1">${names.person1}</span> — Top Perfumes</h2>
        <table><thead><tr><th>العطر Perfume</th><th>البراند Brand</th><th>الارتداءات Wears</th></tr></thead><tbody>${rowsHTML(p1Top)}</tbody></table>
        <h2><span class="chip p2">${names.person2}</span> — Top Perfumes</h2>
        <table><thead><tr><th>العطر Perfume</th><th>البراند Brand</th><th>الارتداءات Wears</th></tr></thead><tbody>${rowsHTML(p2Top)}</tbody></table>
        ${filteredPurchases.length > 0 ? `
          <h2>💳 Purchases (${filteredPurchases.length})</h2>
          <table><thead><tr><th>التاريخ Date</th><th>العطر Perfume</th><th>النوع Type</th><th>ML</th><th>التكلفة Cost</th></tr></thead><tbody>${purchaseRowsHTML(filteredPurchases)}</tbody></table>
        ` : ""}
        ${notedLogs.length > 0 ? `
          <h2>📝 Notes (${notedLogs.length})</h2>
          ${notedLogs.map((l) => {
            const who = l.person === "person2" ? names.person2 : names.person1;
            const cls = l.person === "person2" ? "p2" : "p1";
            return `<div style="margin-bottom:8px;padding:8px 12px;background:#f9f9f7;border-radius:8px;border-left:3px solid ${l.person === "person2" ? "#7c3aed" : "#16a34a"}"><span class="chip ${cls}">${who}</span> <span style="font-size:11px;color:#666">${l.date} · ${l.perfume_name}</span><div style="margin-top:4px;font-size:12px;font-style:italic">"${l.note}"</div></div>`;
          }).join("")}
        ` : ""}
      </body></html>
    `;

    // Open via cross-platform overlay. User can use the overlay's Print button
    // if they want a hard copy; we don't auto-print so Android WebView doesn't
    // show its own URL/page headers.
    await openHtmlReport(html);

    setLoading(false);
    setOpen(false);
    toast.success("فُتح التقرير استخدم زر الطباعة");
  };

  return (
    <>
      <Button variant="outline" size="sm" className="rounded-none font-body h-9 gap-1.5 text-xs" onClick={() => setOpen(true)}>
        <FileDown className="w-3.5 h-3.5" /> Export Report
      </Button>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">تصدير / مشاركة التقرير Export / Share Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-xs text-muted-foreground font-body">Choose a time period for your Me / We report. It will open as a printable page — use "Save as PDF" from your browser.</p>
            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">الفترة Period</p>
              <Select value={period} onValueChange={setPeriod}>
                <SelectTrigger className="rounded-none h-10 font-body text-sm"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PERIODS.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full h-10 rounded-none font-body" onClick={handleExport} disabled={loading}>
              {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</> : <><FileDown className="w-4 h-4" /> Generate & Open</>}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}