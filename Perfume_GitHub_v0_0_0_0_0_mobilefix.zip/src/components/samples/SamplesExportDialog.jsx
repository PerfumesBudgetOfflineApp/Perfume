import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { format, subDays, startOfMonth, startOfYear } from "date-fns";
import { useLang } from "@/lib/LanguageContext";
import { useCurrency } from "@/lib/useCurrency";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";

export default function SamplesExportDialog({ purchases, personName, profiles }) {
  const { isAr } = useLang();
  const { formatPrice } = useCurrency();
  const [exportOpen, setExportOpen] = useState(false);
  const [exportFormat, setExportFormat] = useState("image");
  const [dateRange, setDateRange] = useState("all");
  const [bgColor, setBgColor] = useState("#ffffff");

  const getFilteredPurchases = () => {
    const now = new Date();
    let startDate = null;

    switch (dateRange) {
      case "week":
        startDate = subDays(now, 7);
        break;
      case "month":
        startDate = startOfMonth(now);
        break;
      case "year":
        startDate = startOfYear(now);
        break;
      case "all":
      default:
        return purchases;
    }

    return purchases.filter(p => new Date(p.purchase_date) >= startDate);
  };

  const filteredPurchases = getFilteredPurchases();
  const totalVolume = filteredPurchases.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalCost = filteredPurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  const sampleCount = filteredPurchases.filter(p => p.type === "sample").length;
  const bottleCount = filteredPurchases.filter(p => p.type === "bottle").length;

  const handleExport = async () => {
    const element = document.getElementById("samples-export-card");
    if (!element) return;

    try {
      if (exportFormat === "image") {
        const canvas = await captureElement(element, { backgroundColor: bgColor, scale: 2, useCORS: true });
        await saveCanvasAsImage(canvas, `samples-${format(new Date(), "yyyy-MM-dd")}.png`);
      } else {
        const canvas = await captureElement(element, { backgroundColor: bgColor, scale: 2, useCORS: true });
        const imgData = canvas.toDataURL("image/png");
        const { jsPDF } = await import("jspdf");
        const pdf = new jsPDF("portrait", "mm", "a4");
        const imgWidth = 210;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;
        pdf.addImage(imgData, "PNG", 0, 0, imgWidth, imgHeight);
        const blob = pdf.output('blob');
        await downloadBlob(blob, `samples-${format(new Date(), "yyyy-MM-dd")}.pdf`);
      }
      setExportOpen(false);
    } catch (error) {
      console.error("Export failed:", error);
    }
  };

  return (
    <Dialog open={exportOpen} onOpenChange={setExportOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 font-body">
          <Download className="w-4 h-4" /> {isAr ? "تصدير" : "Export"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl w-[95vw] rounded-none max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-heading">{isAr ? "تصدير التقرير" : "Export Report"}</DialogTitle>
        </DialogHeader>
          <ExportOptionsBar />

        <div className="space-y-4">
          {/* Format selector */}
          <div className="space-y-2">
            <p className="text-sm font-body font-medium">{isAr ? "الصيغة" : "Format"}</p>
            <div className="flex gap-2">
              <button
                onClick={() => setExportFormat("image")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${
                  exportFormat === "image"
                    ? "bg-primary text-primary-foreground shadow"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                📸 {isAr ? "صورة" : "Image"}
              </button>
              <button
                onClick={() => setExportFormat("pdf")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${
                  exportFormat === "pdf"
                    ? "bg-primary text-primary-foreground shadow"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                📄 PDF
              </button>
            </div>
          </div>

          {/* Date range selector */}
          <div className="space-y-2">
            <p className="text-sm font-body font-medium">{isAr ? "الفترة الزمنية" : "Time Period"}</p>
            <div className="grid grid-cols-4 gap-2">
              {[
                { value: "week", label: isAr ? "أسبوع" : "Week" },
                { value: "month", label: isAr ? "شهر" : "Month" },
                { value: "year", label: isAr ? "سنة" : "Year" },
                { value: "all", label: isAr ? "الكل" : "All" },
              ].map(({ value, label }) => (
                <button
                  key={value}
                  onClick={() => setDateRange(value)}
                  className={`py-2 rounded-none text-xs font-body font-medium transition-all ${
                    dateRange === value
                      ? "bg-primary text-primary-foreground shadow"
                      : "bg-secondary text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Background color */}
          <div className="space-y-2">
            <p className="text-sm font-body font-medium">{isAr ? "الخلفية" : "Background"}</p>
            <div className="flex gap-2">
              {[
                { name: "White", color: "#ffffff" },
                { name: "Cream", color: "#fffdf7" },
                { name: "Light Gray", color: "#f8fafc" },
              ].map(({ name, color }) => (
                <button
                  key={color}
                  onClick={() => setBgColor(color)}
                  className={`h-10 w-10 rounded-none border-2 transition-all ${
                    bgColor === color ? "border-primary shadow-md" : "border-border"
                  }`}
                  style={{ backgroundColor: color }}
                  title={name}
                />
              ))}
              <input
                type="color"
                value={bgColor}
                onChange={(e) => setBgColor(e.target.value)}
                className="h-10 w-10 rounded-none cursor-pointer"
              />
            </div>
          </div>

          {/* Preview Card */}
          <div id="samples-export-card" style={{ backgroundColor: bgColor, padding: "24px" }} className="rounded-none border border-border">
            <div className="space-y-4">
              {/* Header */}
              <div className="border-b pb-4">
                <p className="text-2xl font-heading font-bold">{isAr ? "تقرير العطور" : "Sample Report"}</p>
                <p className="text-sm text-muted-foreground font-body mt-1">
                  {personName} · {format(new Date(), "dd MMM yyyy")}
                </p>
                {dateRange !== "all" && (
                  <p className="text-xs text-muted-foreground font-body mt-1">
                    {dateRange === "week" && (isAr ? "آخر 7 أيام" : "Last 7 days")}
                    {dateRange === "month" && (isAr ? "هذا الشهر" : "This month")}
                    {dateRange === "year" && (isAr ? "هذا العام" : "This year")}
                  </p>
                )}
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-4 gap-3">
                <div className="bg-slate-50 dark:bg-slate-900 rounded-none p-3 text-center">
                  <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الإجمالي" : "Total"}</p>
                  <p className="text-lg font-heading font-bold">{filteredPurchases.length}</p>
                </div>
                <div className="bg-blue-50 dark:bg-blue-900/20 rounded-none p-3 text-center">
                  <p className="text-[10px] text-blue-600 dark:text-blue-400 font-body uppercase">💧 {isAr ? "عينات" : "Samples"}</p>
                  <p className="text-lg font-heading font-bold">{sampleCount}</p>
                </div>
                <div className="bg-amber-50 dark:bg-amber-900/20 rounded-none p-3 text-center">
                  <p className="text-[10px] text-amber-600 dark:text-amber-400 font-body uppercase">🍾 {isAr ? "زجاجات" : "Bottles"}</p>
                  <p className="text-lg font-heading font-bold">{bottleCount}</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-900 rounded-none p-3 text-center">
                  <p className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "الحجم الكلي" : "Volume"}</p>
                  <p className="text-lg font-heading font-bold">{totalVolume}ml</p>
                </div>
              </div>

              {/* Cost Summary */}
              <div className="bg-gradient-to-r from-emerald-500/10 to-emerald-400/5 rounded-none p-4 border border-emerald-200/30">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-[10px] text-emerald-700 dark:text-emerald-400 font-body uppercase mb-1">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
                    <p className="text-2xl font-heading font-bold text-emerald-600 dark:text-emerald-400">{formatPrice(totalCost.toFixed(0))}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-emerald-700 dark:text-emerald-400 font-body uppercase mb-1">{isAr ? "السعر للملل" : "Cost/ml"}</p>
                    <p className="text-2xl font-heading font-bold text-emerald-600 dark:text-emerald-400">
                      {formatPrice((totalVolume > 0 ? (totalCost / totalVolume).toFixed(2) : 0))}
                    </p>
                  </div>
                </div>
              </div>

              {/* Items List */}
              {filteredPurchases.length > 0 && (
                <div className="space-y-2">
                  <p className="text-xs font-body font-bold text-muted-foreground uppercase">{isAr ? "التفاصيل" : "Details"}</p>
                  <div className="space-y-1 max-h-48 overflow-y-auto">
                    {filteredPurchases.map((p, idx) => (
                      <div key={p.id} className="flex items-center justify-between text-[10px] font-body py-1 border-b border-border/20">
                        <div>
                          <p className="font-medium">{p.perfume_name}</p>
                          <p className="text-muted-foreground text-[9px]">{p.brand_name}</p>
                        </div>
                        <div className="text-right flex items-center gap-4">
                          <span className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[9px]">
                            {p.type === "sample" ? "💧" : "🍾"} {p.ml}ml
                          </span>
                          <span className="font-bold min-w-fit">{formatPrice(p.cost.toFixed(0))}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Export Button */}
          <Button onClick={handleExport} className="w-full h-10 rounded-none font-body gap-2">
            <Download className="w-4 h-4" />
            {isAr ? "تنزيل" : "Download"} {exportFormat === "pdf" ? "PDF" : "PNG"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}