import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Search, User, ChevronRight } from "lucide-react";

export default function PerfumersTable({ perfumes = [], brands = [] }) {
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ name: "", name_ar: "", nationality: "", gender: "Male", birth_year: "", death_year: "", famous_works: "", bio: "", brand_names: "", perfume_names: "" });
  const queryClient = useQueryClient();

  const { data: perfumers = [], isLoading } = useQuery({
    queryKey: ["perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.Perfumer.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfumers"] });
      toast.success("أُضيف المعطّر");
      setAddOpen(false);
      setForm({ name: "", nationality: "", bio: "", brand_names: "", perfume_names: "" });
    },
  });

  const currentYear = new Date().getFullYear();

  const filtered = perfumers.filter((p) => {
    const matchSearch = !search || p.name?.toLowerCase().includes(search.toLowerCase()) || p.nationality?.toLowerCase().includes(search.toLowerCase()) || p.name_ar?.includes(search);
    const matchGender = genderFilter === "all" || p.gender === genderFilter;
    return matchSearch && matchGender;
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-lg font-semibold">المعطّرون Perfumers</h2>
          <p className="text-xs text-muted-foreground font-body">{perfumers.length} nose{perfumers.length !== 1 ? "s" : ""}</p>
        </div>
        <Button size="sm" className="rounded-none font-body gap-1" onClick={() => setAddOpen(true)}>
          Add
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث عن معطّرين Search perfumers..."
          className="pl-9 h-9 rounded-none font-body text-sm bg-secondary/50 border-0"
        />
      </div>
      <div className="flex gap-2">
        {["all", "Male", "Female"].map((g) => (
          <button key={g} onClick={() => setGenderFilter(g)}
            className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${genderFilter === g ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
            {g === "all" ? "All" : g === "Male" ? "♂ Male" : "♀ Female"}
          </button>
        ))}
      </div>

      {isLoading ? (
        <div className="flex justify-center py-8">
          <div className="w-5 h-5 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-8 space-y-2">
          <div className="w-12 h-12 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <User className="w-6 h-6 text-primary/30" />
          </div>
          <p className="text-sm text-muted-foreground font-body">لا معطّرين بعد No perfumers yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map((perfumer) => {
            const brandList = perfumer.brand_names ? perfumer.brand_names.split(",").map(b => b.trim()).filter(Boolean) : [];
            const perfumeList = perfumer.perfume_names ? perfumer.perfume_names.split(",").map(p => p.trim()).filter(Boolean) : [];
            return (
              <Link key={perfumer.id} to={`/perfumer?id=${perfumer.id}`}>
              <div
                className="bg-card rounded-none p-4 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-none bg-secondary flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {perfumer.photo_url ? (
                      <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-full object-cover" />
                    ) : (
                      <span className="font-heading font-bold text-primary/50">{perfumer.name?.[0]?.toUpperCase()}</span>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <p className="font-body font-semibold text-sm">{perfumer.name}</p>
                      {perfumer.gender && (
                        <span className={`text-[9px] rounded-none font-body font-bold ${perfumer.gender === "Female" ? " text-pink-600 " : " text-sky-600 "}`}>
                          {perfumer.gender === "Female" ? "♀" : "♂"}
                        </span>
                      )}
                    </div>
                    {perfumer.name_ar && <p className="text-xs text-muted-foreground font-body" dir="rtl">{perfumer.name_ar}</p>}
                    <div className="flex items-center gap-2 flex-wrap mt-0.5">
                      {perfumer.nationality && <span className="text-xs text-muted-foreground font-body">{perfumer.nationality}</span>}
                      {perfumer.birth_year && (
                        <span className="text-xs text-muted-foreground font-body">
                          b. {perfumer.birth_year}
                          {!perfumer.death_year && ` (${currentYear - perfumer.birth_year})`}
                          {perfumer.death_year && ` – ${perfumer.death_year}`}
                        </span>
                      )}
                    </div>
                    {perfumer.famous_works && (
                      <p className="text-[10px] text-primary/80 font-body mt-1 line-clamp-1">⭐ {perfumer.famous_works}</p>
                    )}
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {brandList.slice(0, 2).map((bName) => {
                        const brand = brands.find(b => b.name === bName);
                        return brand ? (
                          <Link key={bName} to={`/brand?id=${brand.id}`} onClick={(e) => e.stopPropagation()}
                            className="text-[10px] font-body font-medium rounded-none text-primary transition-colors">
                            {bName}
                          </Link>
                        ) : (
                          <span key={bName} className="text-[10px] font-body font-medium rounded-none text-muted-foreground">{bName}</span>
                        );
                      })}
                      {brandList.length > 2 && <span className="text-[10px] font-body text-muted-foreground px-1">+{brandList.length - 2}</span>}
                    </div>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {perfumeList.slice(0, 2).map((pName) => {
                        const perfume = perfumes.find(p => p.name === pName);
                        return perfume ? (
                          <Link key={pName} to={`/perfume?id=${perfume.id}`} onClick={(e) => e.stopPropagation()}
                            className="text-[10px] font-body rounded-none text-amber-700 dark:text-amber-400 dark:hover:bg-amber-900/60 transition-colors">
                            {pName}
                          </Link>
                        ) : (
                          <span key={pName} className="text-[10px] font-body rounded-none text-muted-foreground">{pName}</span>
                        );
                      })}
                      {perfumeList.length > 2 && <span className="text-[10px] font-body text-muted-foreground px-1">+{perfumeList.length - 2}</span>}
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                </div>
              </div>
              </Link>
            );
          })}
        </div>
      )}

      {/* Add Perfumer Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading">إضافة معطّر Add Perfumer</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-body">الاسم بالإنجليزية Name (EN)</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Jacques Polge" className="rounded-none font-body" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">الاسم (AR)</Label>
                <Input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} placeholder="بالعربي" className="rounded-none font-body" dir="rtl" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1.5">
                <Label className="text-xs font-body">الجنسية Nationality</Label>
                <Input value={form.nationality} onChange={(e) => setForm({ ...form, nationality: e.target.value })} placeholder="e.g. French" className="rounded-none font-body" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">سنة الميلاد Birth Year</Label>
                <Input type="number" value={form.birth_year} onChange={(e) => setForm({ ...form, birth_year: Number(e.target.value) || "" })} placeholder="1960" className="rounded-none font-body" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">الفئة Gender</Label>
              <div className="flex gap-2">
                {["Male", "Female"].map((g) => (
                  <button key={g} type="button" onClick={() => setForm({ ...form, gender: g })}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.gender === g ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
                    {g}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">Famous Works (comma-separated)</Label>
              <Input value={form.famous_works} onChange={(e) => setForm({ ...form, famous_works: e.target.value })} placeholder="e.g. No. 5, Sauvage" className="rounded-none font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">Brands (comma-separated)</Label>
              <Input value={form.brand_names} onChange={(e) => setForm({ ...form, brand_names: e.target.value })} placeholder="e.g. Chanel, Dior" className="rounded-none font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">نبذة Bio</Label>
              <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="نبذة مختصرة Short biography..." className="rounded-none font-body min-h-[60px]" />
            </div>
            <Button className="w-full rounded-none font-body" onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending || !form.name.trim()}>
              {createMutation.isPending ? "Saving..." : "Add Perfumer"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

    </div>
  );
}