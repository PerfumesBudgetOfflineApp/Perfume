import { useMemo } from "react";
import { format } from "date-fns";
import { BarChart, Bar, XAxis, YAxis, Tooltip, PieChart, Pie, Cell, ResponsiveContainer } from "recharts";

const COLORS = ["#10b981", "#8b5cf6", "#f59e0b", "#ef4444", "#3b82f6", "#ec4899", "#14b8a6", "#f97316", "#6366f1", "#84cc16"];

export default function BrandsAnalytics({ brands, perfumes }) {
  // عدّ العطور لكل براند مرّة واحدة — يتفادى O(براندات × عطور) الذي كان
  // يجمّد الشاشة على البيانات الكبيرة (~٨٠٠٠ براند × ~٣٢٠٠٠ عطر ≈ ٧٥٠ مليون عملية).
  const countByBrand = useMemo(() => {
    const m = new Map();
    for (const p of perfumes) {
      if (!p.brand_name) continue;
      m.set(p.brand_name, (m.get(p.brand_name) || 0) + 1);
    }
    return m;
  }, [perfumes]);

  // Perfume count by country
  const countryData = useMemo(() => {
    const map = {};
    brands.forEach((b) => {
      const country = b.country || "Unknown";
      const count = countByBrand.get(b.name) || 0;
      map[country] = (map[country] || 0) + count;
    });
    return Object.entries(map)
      .map(([country, count]) => ({ country, count }))
      .filter((x) => x.count > 0)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [brands, countByBrand]);

  // Top brands by perfume count
  const topBrands = useMemo(() => {
    return brands
      .map((b) => ({ name: b.name, count: countByBrand.get(b.name) || 0 }))
      .filter((x) => x.count > 0)
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);
  }, [brands, countByBrand]);

  // Brands added per month timeline
  const timeline = useMemo(() => {
    const map = {};
    brands.forEach((b) => {
      if (!b.created_date) return;
      const key = format(new Date(b.created_date), "MMM yy");
      map[key] = (map[key] || 0) + 1;
    });
    // Sort by date
    const sorted = Object.entries(map)
      .map(([month, count]) => ({ month, count }))
      .sort((a, b) => {
        const da = new Date("01 " + a.month);
        const db = new Date("01 " + b.month);
        return da - db;
      });
    return sorted.slice(-12); // last 12 months
  }, [brands]);

  const totalPerfumes = perfumes.length;
  const brandsWithPerfumes = useMemo(
    () => brands.filter((b) => (countByBrand.get(b.name) || 0) > 0).length,
    [brands, countByBrand]
  );

  return (
    <div className="space-y-6 pb-8">
      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-primary/5 border border-primary/20 rounded-none p-3 text-center">
          <p className="font-heading text-xl font-bold text-primary">{brands.length}</p>
          <p className="text-[10px] text-muted-foreground font-body">إجمالي البراندات Total Brands</p>
        </div>
        <div className="bg-secondary rounded-none p-3 text-center">
          <p className="font-heading text-xl font-bold">{totalPerfumes}</p>
          <p className="text-[10px] text-muted-foreground font-body">العطور Perfumes</p>
        </div>
        <div className="bg-secondary rounded-none p-3 text-center">
          <p className="font-heading text-xl font-bold">{brandsWithPerfumes}</p>
          <p className="text-[10px] text-muted-foreground font-body">البراندات النشطة Active Brands</p>
        </div>
      </div>

      {/* Top Brands by Perfume Count */}
      {topBrands.length > 0 && (
        <div className="space-y-3">
          <p className="text-xs font-body font-semibold uppercase tracking-wider text-muted-foreground">أبرز البراندات بعدد العطور Top Brands by Perfume Count</p>
          <div className="bg-card rounded-none border border-border/50 p-4">
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={topBrands} layout="vertical" margin={{ left: 4, right: 16, top: 4, bottom: 4 }}>
                <XAxis type="number" tick={{ fontSize: 10, fontFamily: "var(--font-body)" }} />
                <YAxis type="category" dataKey="name" width={90} tick={{ fontSize: 10, fontFamily: "var(--font-body)" }} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, fontSize: 11, fontFamily: "var(--font-body)" }}
                  formatter={(val) => [val, "Perfumes"]}
                />
                <Bar dataKey="count" radius={[0, 6, 6, 0]}>
                  {topBrands.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* Perfumes by Country */}
      {countryData.length > 0 && (
        <div className="space-y-3">
          <p className="text-xs font-body font-semibold uppercase tracking-wider text-muted-foreground">العطور حسب بلد البراند Perfumes by Country of Brand</p>
          <div className="bg-card rounded-none border border-border/50 p-4 flex flex-col items-center gap-4">
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={countryData} dataKey="count" nameKey="country" cx="50%" cy="50%" outerRadius={80} innerRadius={40} paddingAngle={2}>
                  {countryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Tooltip
                  contentStyle={{ borderRadius: 12, fontSize: 11, fontFamily: "var(--font-body)" }}
                  formatter={(val, name) => [val, name]}
                />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap gap-2 justify-center">
              {countryData.map((d, i) => (
                <div key={d.country} className="flex items-center gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-none flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                  <span className="text-[10px] font-body text-muted-foreground">{d.country} ({d.count})</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Brands Added Timeline */}
      {timeline.length > 1 && (
        <div className="space-y-3">
          <p className="text-xs font-body font-semibold uppercase tracking-wider text-muted-foreground">البراندات المضافة عبر الوقت Brands Added Over Time</p>
          <div className="bg-card rounded-none border border-border/50 p-4">
            <ResponsiveContainer width="100%" height={160}>
              <BarChart data={timeline} margin={{ left: 0, right: 8, top: 4, bottom: 4 }}>
                <XAxis dataKey="month" tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} />
                <YAxis tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{ borderRadius: 12, fontSize: 11, fontFamily: "var(--font-body)" }}
                  formatter={(val) => [val, "Brands added"]}
                />
                <Bar dataKey="count" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {countryData.length === 0 && topBrands.length === 0 && (
        <div className="text-center py-16 space-y-2">
          <p className="text-muted-foreground font-body text-sm">لا بيانات كافية للتحليل Not enough data for analytics yet.</p>
          <p className="text-xs text-muted-foreground font-body">أضف براندات و عطوراً لعرض الرسوم Add brands and perfumes to see charts.</p>
        </div>
      )}
    </div>
  );
}