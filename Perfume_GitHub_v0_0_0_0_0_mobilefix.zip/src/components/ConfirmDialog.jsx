import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";

export function ConfirmDialog({ open, title, description, onConfirm, onCancel, confirmText = "Delete", isDangerous = false }) {
  return (
    <Dialog open={open} onOpenChange={onCancel}>
      <DialogContent className="max-w-sm rounded-none">
        <DialogHeader>
          <DialogTitle className="font-heading">{title}</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground font-body">{description}</p>
        <DialogFooter className="gap-2">
          <Button variant="outline" onClick={onCancel} className="rounded-none">
            Cancel
          </Button>
          <Button 
            onClick={onConfirm} 
            className={`rounded-none ${isDangerous ? "bg-red-500 hover:bg-red-600 text-white" : ""}`}
          >
            {confirmText}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}