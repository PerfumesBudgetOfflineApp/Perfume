import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { Package, Calendar, Store, Search, ChevronDown, ChevronUp } from "lucide-react";
import { useCurrency } from "@/lib/useCurrency";
import { apphost } from "@/api/apphostClient";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { usePagedList, SimplePager } from "@/components/shared/usePagedList";
import { toast } from "sonner";
import { usePersonNames } from "@/lib/usePersonNames";
import { useNumberEncryption } from "@/lib/useNumberEncryption";

// Added logging
export default function ShopPurchaseLog({ products, brands, search, isAr, onRefresh }) {
  const { formatPrice } = useCurrency();
  const { names } = usePersonNames();
  const { encryptNumbers } = useNumberEncryption();
  const queryClient = useQueryClient();
  const [sortBy, setSortBy] = useState("newest");

  // Quick add form state
  const [form, setForm] = useState({
    name: "",
    cost: "",
    purchase_date: new Date().toISOString().slice(0, 10),
    person: "family",
    linked_product_id: "",
    linked_product_name: "",
  });
  const [saving, setSaving] = useState(false);
  const [showProductSearch, setShowProductSearch] = useState(false);
  const [productQuery, setProductQuery] = useState("");
  const [showForm, setShowForm] = useState(true);

  const PERSONS = [
    { value: "person1", label: names?.person1 || "A" },
    { value: "person2", label: names?.person2 || "B" },
    { value: "family", label: isAr ? "كل" : "All" },
  ];

  const upd = (k, v) => setForm(p => ({ ...p, [k]: v }));

  // Filter products for linking
  const filteredProducts = useMemo(() => {
    if (!productQuery) return products.slice(0, 6);
    return products.filter(p =>
      p.name?.toLowerCase().includes(productQuery.toLowerCase()) ||
      p.brand_name?.toLowerCase().includes(productQuery.toLowerCase())
    ).slice(0, 6);
  }, [products, productQuery]);

  const handleSave = async () => {
    try {
      // ===== VALIDATION =====
      if (!form.name?.trim() && !form.linked_product_id) {
        toast.error(isAr ? "⚠️ أدخل اسم الشراء أو اختر منتج موجود" : "⚠️ Enter purchase name or select product");
        return;
      }
      if (!form.purchase_date) {
        toast.error(isAr ? "⚠️ حدد تاريخ الشراء" : "⚠️ Select purchase date");
        return;
      }
      if (!form.person) {
        toast.error(isAr ? "⚠️ حدد لمن هذا الشراء" : "⚠️ Select who made this purchase");
        return;
      }

      setSaving(true);

      const linkedProduct = products?.find(p => String(p.id) === String(form.linked_product_id));
      const saveData = {
        name: (form.name?.trim() || form.linked_product_name || "Purchase").substring(0, 255),
        name_ar: linkedProduct?.name_ar || "",
        cost: form.cost ? Number(form.cost) : 0,
        purchase_date: form.purchase_date,
        person: form.person,
        linked_perfume_id: linkedProduct?.linked_perfume_id || "",
        linked_perfume_name: linkedProduct?.linked_perfume_name || "",
        brand_id: linkedProduct?.brand_id || "",
        brand_name: linkedProduct?.brand_name || "",
        category_id: linkedProduct?.category_id || "",
        category_name_en: linkedProduct?.category_name_en || "Uncategorized",
        category_name_ar: linkedProduct?.category_name_ar || "غير مصنف",
        image_url: linkedProduct?.image_url || "",
        recurring: false,
        recurring_frequency: "once",
        status: "active",
        purchase_type: "product",
      };

      // Save product
       const product = await apphost.entities.ShopProduct.create(saveData);

       // Create PurchaseRecord if linked to perfume
       if (linkedProduct?.linked_perfume_id) {
         await apphost.entities.PurchaseRecord.create({
           perfume_id: linkedProduct.linked_perfume_id,
           perfume_name: linkedProduct.linked_perfume_name,
           brand_name: linkedProduct.brand_name,
           brand_id: linkedProduct.brand_id,
           person: saveData.person,
           type: "product",
           ml: 0,
           cost: saveData.cost,
           purchase_date: saveData.purchase_date,
           store_id: linkedProduct.brand_id,
           store_name: linkedProduct.brand_name,
         });
       }

       // Create budget expense if cost > 0
       if (saveData.cost > 0) {
         const expenseData = {
           date: saveData.purchase_date,
           amount: saveData.cost,
           category: "shopping",
           description: saveData.name,
           person: saveData.person,
           type: "essential",
           recurring: false,
           frequency: "once",
         };
         await apphost.entities.BudgetExpense.create(expenseData);
       }

      toast.success(isAr ? "تمت الإضافة بنجاح" : "Purchase added!");
      setForm({ name: "", cost: "", purchase_date: new Date().toISOString().slice(0, 10), person: "family", linked_product_id: "", linked_product_name: "" });
      setProductQuery("");
      setShowProductSearch(false);
      onRefresh();
    } catch (error) {
      console.error("Save error:", error);
      const msg = error?.message || error?.toString() || "Unknown error";
      toast.error(isAr ? `⚠️ ${msg}` : `⚠️ ${msg}`);
    } finally {
      setSaving(false);
    }
  };

  // Filter + sort log
  const filtered = useMemo(() => {
    const s = search?.toLowerCase() || "";
    const result = [...products].filter(p => !s || p.name?.toLowerCase().includes(s) || p.brand_name?.toLowerCase().includes(s));
    
    if (sortBy === "newest") result.sort((a, b) => {
      const da = a.purchase_date || a.created_date || "";
      const db = b.purchase_date || b.created_date || "";
      return db.localeCompare(da);
    });
    else if (sortBy === "oldest") result.sort((a, b) => {
      const da = a.purchase_date || a.created_date || "";
      const db = b.purchase_date || b.created_date || "";
      return da.localeCompare(db);
    });
    else if (sortBy === "highest") result.sort((a, b) => b.cost - a.cost);
    else if (sortBy === "lowest") result.sort((a, b) => a.cost - b.cost);
    
    return result;
  }, [products, search, sortBy]);

  // Group by date
  const grouped = useMemo(() => {
    const map = {};
    filtered.forEach(p => {
      const date = p.purchase_date || p.created_date?.slice(0, 10) || "Unknown";
      if (!map[date]) map[date] = [];
      map[date].push(p);
    });
    return Object.entries(map).sort((a, b) => b[0].localeCompare(a[0]));
  }, [filtered]);

  // Paginate the day-groups so a long history stays manageable.
  const groupedPager = usePagedList(grouped, 50);

  const personLabel = (person) => {
    if (person === "person1") return names?.person1 || "A";
    if (person === "person2") return names?.person2 || "B";
    return isAr ? "الكل" : "All";
  };

  return (
    <div className="space-y-3">
      {/* Sort Options */}
      <div className="flex gap-2">
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="flex-1 px-3 py-2 border border-[var(--brand)] bg-white text-xs font-body"
        >
          <option value="newest">{isAr ? "الأحدث" : "Newest"}</option>
          <option value="oldest">{isAr ? "الأقدم" : "Oldest"}</option>
          <option value="highest">{isAr ? "الأعلى سعر" : "Highest Cost"}</option>
          <option value="lowest">{isAr ? "الأقل سعر" : "Lowest Cost"}</option>
        </select>
      </div>

      {/* ── Quick Add Form ── */}
      <div className="bg-white border border-[var(--brand)] overflow-hidden">
        <button
          onClick={() => setShowForm(f => !f)}
          className="w-full flex items-center justify-between px-4 py-3 text-left"
        >
          <span className="text-xs font-body font-bold text-primary">
            🛒 {isAr ? "إضافة شراء سريع" : "Add Purchase"}
          </span>
          {showForm ? <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" /> : <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />}
        </button>

        {showForm && (
          <div className="px-4 pb-4 space-y-2.5 border-t border-border/50">
            {/* Link to existing product (optional) — purple (linking) */}
            <div className="pt-2">
              <p className="text-[9px] font-body uppercase mb-1" style={{ color: "#7c3aed" }}>{isAr ? "ربط بمنتج موجود (اختياري)" : "Link to existing product (optional)"}</p>
              {form.linked_product_id ? (
                <div className="flex items-center justify-between bg-primary/5 border border-primary/20 px-3 py-2">
                  <span className="text-xs font-body font-semibold text-primary truncate">{form.linked_product_name}</span>
                  <button onClick={() => { upd("linked_product_id", ""); upd("linked_product_name", ""); upd("name", ""); setProductQuery(""); }}
                    className="text-[9px] text-muted-foreground ml-2 flex-shrink-0">✕</button>
                </div>
              ) : (
                <div className="relative">
                  <Search className="absolute left-2.5 top-2 w-3 h-3 text-muted-foreground" />
                  <Input
                    value={productQuery}
                    onChange={e => { setProductQuery(e.target.value); setShowProductSearch(true); }}
                    onFocus={() => setShowProductSearch(true)}
                    placeholder={isAr ? "ابحث عن منتج..." : "Search product..."}
                    className="pl-7 h-8 rounded-none font-body text-xs"
                  />
                  {showProductSearch && filteredProducts.length > 0 && (
                    <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-36 overflow-y-auto">
                      {filteredProducts.map(p => (
                        <button key={p.id} type="button"
                          onClick={() => {
                            upd("linked_product_id", p.id);
                            upd("linked_product_name", p.name);
                            upd("name", p.name);
                            setProductQuery("");
                            setShowProductSearch(false);
                          }}
                          className="w-full text-left px-3 py-2 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 flex items-center gap-2">
                          {p.image_url ? <img src={p.image_url} className="w-6 h-6 rounded object-cover flex-shrink-0" /> : <Package className="w-4 h-4 text-muted-foreground/40 flex-shrink-0" />}
                          <span className="truncate">{p.name}</span>
                          {p.brand_name && <span className="text-muted-foreground ml-auto flex-shrink-0">· {p.brand_name}</span>}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Name — amber (the thing itself) */}
            {!form.linked_product_id && (
              <div>
                <p className="text-[9px] font-body uppercase mb-1" style={{ color: "#a16207" }}>{isAr ? "اسم الشراء" : "Purchase name"} *</p>
                <Input value={form.name} onChange={e => upd("name", e.target.value)}
                  placeholder={isAr ? "اسم المنتج / الشراء" : "Item name"}
                  className="h-9 rounded-none font-body text-sm" />
              </div>
            )}

            {/* Cost (emerald = money) + Date (blue = time) */}
            <div className="grid grid-cols-2 gap-2 min-w-0">
              <div className="min-w-0">
                <p className="text-[9px] font-body uppercase mb-1" style={{ color: "#059669" }}>{isAr ? "المبلغ" : "Amount"}</p>
                <Input value={form.cost} onChange={e => upd("cost", e.target.value)}
                  type="number" placeholder="0.00"
                  className="h-9 rounded-none font-body text-sm" />
              </div>
              <div className="min-w-0">
                <p className="text-[9px] font-body uppercase mb-1" style={{ color: "#1d4ed8" }}>{isAr ? "التاريخ" : "Date"}</p>
                <Input value={form.purchase_date} onChange={e => upd("purchase_date", e.target.value)}
                  type="text" placeholder="YYYY-MM-DD" className="h-9 rounded-none font-body text-sm" />
              </div>
            </div>

            {/* Person — slate (ownership) */}
            <div>
              <p className="text-[9px] font-body uppercase mb-1" style={{ color: "#475569" }}>{isAr ? "الشخص" : "Person"}</p>
              <div className="flex gap-1.5">
                {PERSONS.map(p => (
                  <button key={p.value} onClick={() => upd("person", p.value)}
                    className={`flex-1 py-1.5 rounded-none text-[10px] font-body border transition-all ${form.person === p.value ? "bg-primary text-primary-foreground border-primary" : "bg-secondary border-border"}`}>
                    {p.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Save */}
            <button onClick={handleSave} disabled={saving}
              className="w-full py-2.5 bg-primary text-primary-foreground rounded-none text-xs font-body font-bold disabled:opacity-50">
              {saving ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "إضافة الشراء" : "Add Purchase")}
            </button>
          </div>
        )}
      </div>

      {/* ── Log List ── */}
      {grouped.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 gap-2 text-center">
          <Package className="w-10 h-10 text-muted-foreground/20" />
          <p className="text-sm text-muted-foreground font-body">{isAr ? "لا توجد مشتريات بعد" : "No purchases yet"}</p>
        </div>
      ) : (
        groupedPager.pageItems.map(([date, items]) => {
          const dayTotal = items.reduce((s, p) => s + (Number(p.cost) || 0), 0);
          return (
            <div key={date}>
              <div className="flex items-center justify-between mb-1.5">
                <div className="flex items-center gap-1.5">
                  <Calendar className="w-3 h-3 text-muted-foreground" />
                  <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-wider">{date}</span>
                </div>
                {dayTotal > 0 && (
                  <span className="text-[10px] font-body font-bold text-primary">{formatPrice(dayTotal)}</span>
                )}
              </div>
              <div className="space-y-1.5">
                {items.map(p => (
                  <Link key={p.id} to={`/shop-product?id=${p.id}`}
                    className="flex items-center gap-3 px-2 py-2 rounded-none hover:bg-secondary/40 transition-colors">
                    {p.image_url ? (
                      <img src={p.image_url} className="w-9 h-9 rounded-none object-cover flex-shrink-0" />
                    ) : (
                      <div className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
                        <Package className="w-4 h-4 text-muted-foreground/40" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-body font-semibold truncate">{isAr && p.name_ar ? p.name_ar : p.name}</p>
                      <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                        {p.brand_name && (
                          <span className="flex items-center gap-0.5 text-[9px] text-muted-foreground font-body">
                            <Store className="w-2.5 h-2.5" />{p.brand_name}
                          </span>
                        )}
                        <span className="text-[9px] text-muted-foreground font-body">· {personLabel(p.person)}</span>
                      </div>
                    </div>
                    {p.cost > 0 && (
                      <p className="flex-shrink-0 text-xs font-bold text-primary font-heading">{formatPrice(p.cost)}</p>
                    )}
                  </Link>
                ))}
              </div>
            </div>
          );
        })
      )}
      <SimplePager page={groupedPager.page} setPage={groupedPager.setPage} totalPages={groupedPager.totalPages} isAr={isAr} />
    </div>
  );
}