import { useState, useRef, useMemo, useEffect } from "react";
import { useLang } from "@/lib/LanguageContext";
import { useCurrency } from "@/lib/useCurrency";
import { loadAllPerfumesMerged } from "@/lib/perfumeShards";
async function fetchAllPerfumes() {
  return loadAllPerfumesMerged();
}
import { Search, Download, Image as ImageIcon, Package, Save, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { resolveUserMark, DEFAULT_USER_MARK } from "@/lib/exportSettings";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";

const BG_COLORS = [
  "#ffffff", "#165d31", "#0c447c", "#4b1528", "#173404", "#412402",
  "#26215c", "#2c2c2a", "#5b1a1a", "#0f4c4c", "#3d3416", "#1a1a2e",
];
const TEXT_COLORS = ["", "#165d31", "#ffffff", "#1a1a1a", "#854f0b", "#993556", "#0c447c", "#b8860b"];

const DMAP = { "0": "o", "1": "a", "2": "b", "3": "c", "4": "d", "5": "e", "6": "f", "7": "g", "8": "h", "9": "i" };
const norm = (s) => (s || "").toLowerCase().replace(/[^a-z0-9]/g, "");

let NOTE_LOOKUP = {};
let _noteLookupLoaded = false;
async function ensureNoteLookup() {
  if (_noteLookupLoaded) return;
  _noteLookupLoaded = true;
  try {
    const res = await fetch(`${import.meta.env.BASE_URL || '/'}seed/notes_builtin.json`);
    const notesData = await res.json();
    const m = {};
    for (const n of notesData) {
      const en = n.name_en || (n.name || "").replace(/[\u0600-\u06FF].*$/, "").trim();
      if (en) m[norm(en)] = { image_url: n.image_url || "", name_en: en, name_ar: n.name_ar || "" };
    }
    NOTE_LOOKUP = m;
  } catch { _noteLookupLoaded = false; }
}

function parseNotes(str) {
  if (!str) return [];
  return str.split(",").map((part) => {
    const raw = part.trim();
    if (!raw) return null;
    const m = raw.match(/[\u0600-\u06FF]/);
    const en = (m ? raw.slice(0, m.index) : raw).trim();
    const ar = (m ? raw.slice(m.index) : "").trim();
    const look = NOTE_LOOKUP[norm(en)] || {};
    return { en, ar: ar || look.name_ar || "", image_url: look.image_url || "" };
  }).filter(Boolean);
}

const TIER_STYLE = {
  top:   { label: { ar: "مقدمة", en: "Top" },   color: "#854f0b", bg: "rgba(186,117,23,0.16)" },
  heart: { label: { ar: "قلب", en: "Heart" },       color: "#993556", bg: "rgba(212,83,126,0.16)" },
  base:  { label: { ar: "أساس", en: "Base" },        color: "#534ab7", bg: "rgba(83,74,183,0.16)" },
};

const STORE_KEY = "marketingCards";
function loadCards() { try { return JSON.parse(localStorage.getItem(STORE_KEY) || "[]"); } catch { return []; } }
function saveCards(arr) { try { localStorage.setItem(STORE_KEY, JSON.stringify(arr)); } catch (e) { console.error(e); } }

/**
 * Inline-editable text on the card. Defined at module scope (NOT inside the
 * component) so its identity is stable across re-renders — otherwise React
 * remounts the contentEditable on every state change and the caret jumps /
 * typed text resets.
 *
 * When empty it shows the placeholder faintly (a hint, not real content):
 *   - focusing an empty field clears the hint so the user types into a blank
 *   - on blur, the placeholder text is never saved as the value
 *   - data-empty="1" lets exportImage() drop unfilled fields from the PNG
 */
// حقل نصّي مرتّب بسطر واحد لحاوية التحرير (مناسب للجوال).
function TextField({ label, value, setter, ph, dir }) {
  return (
    <label className="flex items-center gap-2 border rounded-none px-3 py-2">
      <span className="text-xs text-muted-foreground whitespace-nowrap" style={{ minWidth: 72 }}>{label}</span>
      <input
        value={value}
        onChange={(e) => setter(e.target.value)}
        placeholder={ph}
        dir={dir}
        className="flex-1 bg-transparent outline-none text-sm"
      />
    </label>
  );
}

function Edit({ value, setter, ph, style }) {
  const empty = !value;
  return (
    <span
      contentEditable
      suppressContentEditableWarning
      data-empty={empty ? "1" : undefined}
      onFocus={(e) => { if (!value) e.currentTarget.textContent = ""; }}
      onBlur={(e) => {
        const txt = (e.currentTarget.textContent || "").trim();
        setter(txt === ph ? "" : txt);
      }}
      style={{ outline: "none", cursor: "text", ...(empty ? { display: "inline-block", minWidth: 44, borderBottom: "1px dashed rgba(127,127,127,0.45)", opacity: 0.5, fontStyle: "italic" } : null), ...style }}
    >
      {value || ph}
    </span>
  );
}

export default function MarketingCard() {
  const { isAr } = useLang();
  const { symbol } = useCurrency();
  const [, _setNoteReady] = useState(0);
  useEffect(() => { ensureNoteLookup().then(() => _setNoteReady((v) => v + 1)); }, []);

  const [type, setType] = useState("perfume");
  const [bg, setBg] = useState("#ffffff");
  const [bgImage, setBgImage] = useState(null);
  const [productImage, setProductImage] = useState(null);
  const [frame, setFrame] = useState("dotted");
  const [orientation, setOrientation] = useState("portrait");
  const [discount, setDiscount] = useState("");
  const [taxPct, setTaxPct] = useState("");
  const [shipping, setShipping] = useState("");
  const [curSymbol, setCurSymbol] = useState(symbol || "﷼");
  const [customCur, setCustomCur] = useState(false);
  const [textColor, setTextColor] = useState("");
  const [fontScale, setFontScale] = useState(1);
  const [showMark, setShowMark] = useState(false);

  const [nameEn, setNameEn] = useState("");
  const [nameAr, setNameAr] = useState("");
  const [brand, setBrand] = useState("");
  const [desc, setDesc] = useState("");
  const [company, setCompany] = useState("");
  const [location, setLocation] = useState("");
  const [social, setSocial] = useState("");
  const [perfumer, setPerfumer] = useState("");
  const [price, setPrice] = useState("");
  const [notes, setNotes] = useState({ top: [], heart: [], base: [] });

  // optional attribute lines (below the image): each {show, value}
  const [attrs, setAttrs] = useState({
    family:   { show: false, value: "" },
    occasion: { show: false, value: "" },
    time:     { show: false, value: "" },
    ptype:    { show: false, value: "" },
    season:   { show: false, value: "" },
    perfumerLine: { show: false, value: "" },
  });
  // how the attribute-line label shows: none | icon | ar | en | all  (no colon)
  const [labelMode, setLabelMode] = useState("en");
  // how the note-tier labels show: ar | en | none (none = single pyramid icon, no repeats)
  const [noteLabelMode, setNoteLabelMode] = useState("en");
  const ATTR_LABELS = {
    family:   { ar: "العائلة العطرية", en: "Fragrance family", icon: "🌸" },
    occasion: { ar: "المناسبة", en: "Occasion", icon: "" },
    time:     { ar: "الوقت", en: "Time", icon: "🕐" },
    ptype:    { ar: "النوع", en: "Type", icon: "🏷️" },
    season:   { ar: "الموسم", en: "Season", icon: "🍂" },
    perfumerLine: { ar: "العطّار", en: "Perfumer", icon: "👃" },
  };
  const attrLabel = (key) => {
    const L = ATTR_LABELS[key];
    if (labelMode === "icon") return L.icon;
    if (labelMode === "ar") return L.ar;
    if (labelMode === "all") return `${L.icon} ${L.ar} ${L.en}`;
    return L.en;
  };

  const [query, setQuery] = useState("");
  const [results, setResults] = useState([]);
  const [savedCards, setSavedCards] = useState(loadCards());
  const [perfumesData, setPerfumesData] = useState({});
  const cardRef = useRef(null);

  // ── معاينة مباشرة تتقلّص لعرض الشاشة ───────────────────────────────
  // البطاقة تبقى 640px داخلياً (جودة تصدير عالية)، لكنها تُعرض مُحجَّمة
  // لتملأ عرض الحاوية بلا تمرير أفقي، وتتحدّث تلقائياً مع كل تعديل.
  const fitWrapRef = useRef(null);
  const [fit, setFit] = useState({ scale: 1, height: 0, offsetX: 0 });
  useEffect(() => {
    const wrap = fitWrapRef.current;
    const card = cardRef.current;
    if (!wrap || !card) return;
    const CARD_W = 640;
    const recompute = () => {
      const avail = wrap.clientWidth || CARD_W;
      const scale = Math.min(1, avail / CARD_W);
      const height = card.offsetHeight * scale;
      const offsetX = Math.max(0, (avail - CARD_W * scale) / 2);
      setFit((prev) =>
        prev.scale === scale && prev.height === height && prev.offsetX === offsetX
          ? prev
          : { scale, height, offsetX }
      );
    };
    recompute();
    const ro = new ResizeObserver(recompute);
    ro.observe(wrap);
    ro.observe(card);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    let alive = true;
    fetchAllPerfumes().then((d) => { if (alive) setPerfumesData(d); });
    return () => { alive = false; };
  }, []);

  // جلب العطور المضافة يدوياً من قاعدة البيانات
  const { data: dbPerfumes = [] } = useQuery({
    queryKey: ["perfumes-for-marketing-card"],
    queryFn: () => apphost.entities.Perfume.list("name_en"),
    staleTime: 1000 * 60 * 5,
  });

  const [userMark, setUserMark] = useState(DEFAULT_USER_MARK);
  useEffect(() => {
    let alive = true;
    resolveUserMark().then((m) => { if (alive) setUserMark(m || DEFAULT_USER_MARK); });
    return () => { alive = false; };
  }, []);

  const isWhite = bg.toLowerCase() === "#ffffff" && !bgImage;
  const green = "#165d31", greenSoft = "#2f6b42";
  const autoMain = isWhite ? green : "#fff";
  const autoSoft = isWhite ? greenSoft : "rgba(255,255,255,0.9)";
  const textMain = textColor || autoMain;
  const textSoft = textColor || autoSoft;

  const allPerfumes = useMemo(() => {
    const out = [];
    for (const [b, list] of Object.entries(perfumesData)) {
      for (const p of list) {
        const en = (p.name_en || p.name || "").replace(/[\u0600-\u06FF].*$/, "").trim() || p.name_en || p.name || "";
        out.push({ brand: b, en, ar: p.name_ar || "", raw: p });
      }
    }
    return out;
  }, [perfumesData]);

  // العطور من DB المضافة يدوياً بنفس الشكل
  const allDbPerfumes = useMemo(() => {
    return dbPerfumes.map((p) => ({
      brand: p.brand_name || "",
      en: p.name_en || p.name || "",
      ar: p.name_ar || "",
      raw: p,
      fromDb: true,
    }));
  }, [dbPerfumes]);

  function runSearch(q) {
    setQuery(q);
    const t = (q || "").trim();
    if (t.length < 1) { setResults([]); return; }
    const nq = norm(t);

    // بحث في JSON الثابت
    const fromJson = allPerfumes.filter((p) =>
      (p.en && norm(p.en).includes(nq)) || (p.ar && p.ar.includes(t)) || (p.brand && norm(p.brand).includes(nq))
    ).slice(0, 8);

    // بحث في قاعدة البيانات الحية (العطور المضافة يدوياً)
    const fromDb = allDbPerfumes.filter((p) =>
      (p.en && norm(p.en).includes(nq)) || (p.ar && p.ar.includes(t)) || (p.brand && norm(p.brand).includes(nq))
    ).slice(0, 5);

    // دمج النتائج — DB أولاً لأنها أحدث
    const merged = [...fromDb, ...fromJson.filter(j => !fromDb.some(d => norm(d.en) === norm(j.en) && norm(d.brand) === norm(j.brand)))].slice(0, 10);
    setResults(merged);
  }

  function pickPerfume(p) {
    const raw = p.raw || {};
    setNameEn(p.en || "");
    setNameAr(p.ar || "");
    setBrand(p.brand || "");
    setNotes({
      top: parseNotes(raw.top_notes),
      heart: parseNotes(raw.heart_notes),
      base: parseNotes(raw.base_notes),
    });
    // Auto-fill the optional attribute lines from the perfume's DB fields and
    // reveal the ones that actually have data, so they appear (below the notes)
    // immediately instead of staying empty/hidden.
    const fill = (v) => (v || "").trim();
    setAttrs((s) => {
      const dbVal = {
        family:   fill(raw.odor_family),
        occasion: fill(raw.occasions),
        time:     fill(raw.time_of_day),
        ptype:    fill(raw.type),
        season:   fill(raw.season),
      };
      const next = { ...s };
      for (const k of Object.keys(dbVal)) {
        const v = dbVal[k];
        next[k] = { value: v || s[k].value, show: v ? true : s[k].show };
      }
      return next; // perfumerLine has no DB source — left as-is (manual)
    });
    setResults([]);
    setQuery("");
    toast.success(isAr ? "تم ربط العطر" : "Perfume linked");
  }

  function onImagePick(setter) {
    return (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const r = new FileReader();
      r.onload = () => setter(r.result);
      r.readAsDataURL(f);
    };
  }

  // ---- price math: (price + tax) - discount + shipping ----
  const priceNum = parseFloat(price) || 0;
  const taxNum = parseFloat(taxPct) || 0;
  const discNum = parseFloat(discount) || 0;
  const shipNum = parseFloat(shipping) || 0;
  const taxAmount = priceNum * (taxNum / 100);
  const afterTax = priceNum + taxAmount;
  const discAmount = afterTax * (discNum / 100);
  const total = Math.round(afterTax - discAmount + shipNum);
  const inclLine = (taxNum > 0 && shipNum > 0)
    ? (isAr ? "شامل ضريبة وشحن" : "incl. tax & shipping")
    : (taxNum > 0 ? (isAr ? "شامل الضريبة" : "incl. tax")
      : (shipNum > 0 ? (isAr ? "شامل الشحن" : "incl. shipping") : ""));

  async function exportImage() {
    const src = cardRef.current;
    if (!src) return;
    // ننسخ البطاقة إلى حاوية خارج الشاشة بحجمها الطبيعي (640px) بلا أي
    // transform/قصّ — لأن المعاينة الحيّة مُحجَّمة (scale) داخل حاوية
    // overflow:hidden، والتقاطها مباشرةً يُنتج صورة مشوّهة/مقصوصة.
    const clone = src.cloneNode(true);
    clone.style.transform = "none";
    clone.style.margin = "0";
    clone.style.width = "640px";
    // إخفاء الحقول الفارغة (التلميحات) في النسخة فقط
    clone.querySelectorAll('[data-empty="1"]').forEach((n) => { n.style.display = "none"; });
    const holder = document.createElement("div");
    holder.style.cssText = "position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none; width:640px; background:transparent;";
    holder.appendChild(clone);
    document.body.appendChild(holder);
    try {
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      // ننتظر تحميل أي صور (صورة المنتج/الخلفية) قبل الالتقاط
      const imgs = Array.from(clone.querySelectorAll("img"));
      await Promise.all(imgs.map((img) => (img.complete && img.naturalWidth > 0)
        ? Promise.resolve()
        : new Promise((res) => { img.onload = img.onerror = () => res(); setTimeout(res, 3000); })));
      await new Promise((r) => requestAnimationFrame(r));
      const w = clone.offsetWidth || 640;
      const h = clone.offsetHeight;
      const canvas = await captureElement(clone, {
        scale: 2.5, useCORS: true, allowTaint: true, logging: false, backgroundColor: null,
        width: w, height: h, windowWidth: w, windowHeight: h,
      });
      const base = (nameEn || nameAr || brand || "card")
        .toLowerCase().replace(/[^a-z0-9\u0600-\u06FF]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 32) || "card";
      const stamp = Date.now().toString().slice(-6);
      await saveCanvasAsImage(canvas, `marketing-${base}-${stamp}.png`);
      toast.success(isAr ? "تم تصدير الصورة" : "Image exported");
    } catch (err) { console.error(err); toast.error(isAr ? "تعذّر التصدير" : "Export failed"); }
    finally { document.body.removeChild(holder); }
  }

  function snapshot() {
    return {
      id: Date.now(), savedAt: new Date().toISOString(),
      type, bg, bgImage, productImage, frame, orientation, discount, taxPct, shipping,
      curSymbol, textColor, fontScale, showMark,
      nameEn, nameAr, brand, desc, company, location, social, perfumer, price, notes, attrs, attrLabelMode: labelMode, noteLabelMode,
    };
  }
  function applyCard(c) {
    setType(c.type); setBg(c.bg); setBgImage(c.bgImage); setProductImage(c.productImage);
    setFrame(c.frame); setOrientation(c.orientation); setDiscount(c.discount || ""); setTaxPct(c.taxPct || "");
    setShipping(c.shipping || ""); setCurSymbol(c.curSymbol); setTextColor(c.textColor || ""); setFontScale(c.fontScale || 1);
    setShowMark(!!c.showMark); setNameEn(c.nameEn); setNameAr(c.nameAr); setBrand(c.brand); setDesc(c.desc);
    setCompany(c.company); setLocation(c.location); setSocial(c.social); setPerfumer(c.perfumer); setPrice(c.price);
    setNotes(c.notes || { top: [], heart: [], base: [] });
    if (c.attrs) setAttrs(c.attrs);
    setLabelMode(c.attrLabelMode || "en");
    setNoteLabelMode(c.noteLabelMode || "en");
    toast.success(isAr ? "تم تحميل البطاقة" : "Card loaded");
  }
  function saveCard() {
    if (!nameEn && !nameAr) { toast.error(isAr ? "أضف اسم المنتج أولاً" : "Add a product name first"); return; }
    const arr = loadCards();
    arr.unshift(snapshot());
    saveCards(arr); setSavedCards(arr);
    toast.success(isAr ? "تم حفظ البطاقة" : "Card saved");
  }
  function deleteCard(id) {
    const arr = loadCards().filter((c) => c.id !== id);
    saveCards(arr); setSavedCards(arr);
  }

  const cardBgStyle = bgImage
    ? { backgroundImage: `linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.5)), url(${bgImage})`, backgroundSize: "cover", backgroundPosition: "center" }
    : { background: bg };

  const fs = (n) => Math.round(n * fontScale);

  const isLandscape = orientation === "landscape";

  return (
    <div className="flex flex-col gap-4">
      {/* type + frame + orientation — split into labelled sections for mobile
          clarity instead of one cramped flex-wrap row. */}
      <div className="space-y-2">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-muted-foreground font-body uppercase tracking-wider" style={{ minWidth: 48 }}>
            {isAr ? "النوع" : "Type"}
          </span>
          <button onClick={() => setType("perfume")} className={`text-xs rounded-none ${type === "perfume" ? " text-background" : " text-muted-foreground"}`}>{isAr ? "عطر" : "Perfume"}</button>
          <button onClick={() => setType("product")} className={`text-xs rounded-none ${type === "product" ? " text-background" : " text-muted-foreground"}`}>{isAr ? "منتج عادي" : "Product"}</button>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-muted-foreground font-body uppercase tracking-wider" style={{ minWidth: 48 }}>
            {isAr ? "الإطار" : "Frame"}
          </span>
          <button onClick={() => setFrame("dotted")} className={`text-xs rounded-none ${frame === "dotted" ? " text-background" : " text-muted-foreground"}`}>{isAr ? "منقّط" : "Dotted"}</button>
          <button onClick={() => setFrame("none")} className={`text-xs rounded-none ${frame === "none" ? " text-background" : " text-muted-foreground"}`}>{isAr ? "بدون" : "None"}</button>
          <span className="text-[10px] text-muted-foreground font-body uppercase tracking-wider ms-2">
            {isAr ? "الاتجاه" : "Layout"}
          </span>
          <button onClick={() => setOrientation(isLandscape ? "portrait" : "landscape")} className="text-xs rounded-none text-muted-foreground">{isLandscape ? (isAr ? "أفقي" : "Landscape") : (isAr ? "عمودي" : "Portrait")}</button>
        </div>
      </div>

      {/* perfume search */}
      {type === "perfume" && (
        <div className="relative">
          <div className="flex items-center gap-2 border rounded-none px-3 py-2">
            <Search className="w-4 h-4 text-muted-foreground" />
            <input value={query} onChange={(e) => runSearch(e.target.value)} placeholder={isAr ? "ابحث عن عطر لربطه..." : "Search a perfume..."} className="flex-1 bg-transparent outline-none text-sm" />
          </div>
          {results.length > 0 && (
            <div className="absolute z-20 left-0 right-0 mt-1 bg-background border rounded-none shadow-lg max-h-64 overflow-auto">
              {results.map((p, i) => (
                <button key={i} onClick={() => pickPerfume(p)} className="w-full text-start px-3 py-2 hover:bg-muted text-sm border-b last:border-0">
                  <div className="flex items-center gap-1.5">
                    <span className="font-medium">{p.en || p.ar}</span>
                    {p.ar && <span className="text-muted-foreground text-xs">· {p.ar}</span>}
                    {p.fromDb && <span className="text-[9px] text-primary rounded-none">مضاف</span>}
                  </div>
                  <span className="block text-[10px] text-muted-foreground">{p.brand}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {/* THE CARD — معاينة مباشرة مُحجَّمة، مرفوعة لأعلى المحرّر (order -1)، لاصقة */}
      <div style={{ order: -1, position: "sticky", top: 6, zIndex: 5, background: "hsl(var(--background))", paddingBottom: 6 }}>
        <p className="text-[10px] text-muted-foreground font-body mb-1 text-center uppercase tracking-wider">
          {isAr ? "معاينة مباشرة" : "Live preview"}
        </p>
        <div
          ref={fitWrapRef}
          dir="ltr"
          style={{ width: "100%", overflow: "hidden", position: "relative", height: fit.height || undefined, pointerEvents: "none", display: "flex", justifyContent: "center" }}
        >
          <div style={{ width: 640, flex: "0 0 auto", transform: `scale(${fit.scale})`, transformOrigin: "top center" }}>
            <div ref={cardRef} dir="rtl" style={{
          width: 640, ...cardBgStyle, borderRadius: 20, padding: 28,
          display: "flex", flexDirection: "column", gap: 16,
          minHeight: isLandscape ? 420 : 560, margin: "0 auto",
          fontFamily: "'Playfair Display','Amiri',serif", boxSizing: "border-box",
        }}>
          {/* title — centered; brand sits as a small raised line above */}
          <div style={{ textAlign: "center", color: textMain }}>
            {type === "perfume" && brand && (
              <div style={{ fontSize: fs(10), letterSpacing: "2px", textTransform: "uppercase", color: textSoft, marginBottom: 1, lineHeight: 1 }}>{brand}</div>
            )}
            <div>
              <Edit value={nameAr} setter={setNameAr} ph="اسم المنتج" style={{ fontSize: fs(24), fontWeight: 500, letterSpacing: "0.3px" }} />
              {"  "}
              <Edit value={nameEn} setter={setNameEn} ph="Product Name" style={{ fontSize: fs(17), fontStyle: "italic", opacity: 0.72 }} />
            </div>
          </div>

          {/* body — image left, notes right (in RTL, landscape uses row-reverse); small side inset */}
          <div style={{ display: "flex", gap: 20, alignItems: "flex-start", flexDirection: isLandscape ? "row-reverse" : "row", padding: "0 10px" }}>
            {/* LEFT: product image, and beneath it the company + pricing as stacked lines */}
            <div style={{ width: 200, flexShrink: 0, display: "flex", flexDirection: "column", gap: 12, marginTop: isLandscape ? 0 : 22 }}>
              <div style={{
                position: "relative",
                width: "100%", height: isLandscape ? 220 : 238,
                borderRadius: 16, background: productImage ? "transparent" : "rgba(127,127,127,0.12)",
                border: frame === "dotted" ? "2px dashed rgba(127,127,127,0.4)" : "none",
                display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                gap: 8, overflow: "hidden",
              }}>
                {productImage
                  ? <img src={productImage} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                  : <span data-empty="1" style={{ fontSize: fs(13), color: isWhite ? "#aaa" : "rgba(255,255,255,0.7)" }}>{isAr ? "صورة المنتج" : "Product image"}</span>}
              </div>

              {/* under the image — company info + prices, each on its own line */}
              <div style={{ display: "flex", flexDirection: "column", gap: 5, textAlign: "right" }}>
                <div data-empty={company ? undefined : "1"} style={{ fontSize: fs(14), color: textMain }}>
                  <Edit value={company} setter={setCompany} ph={isAr ? "اسم الشركة" : "Company"} style={{ fontWeight: 600 }} />
                </div>
                {/* attribute lines (family · occasion · time · type · season) — below the image */}
                {Object.entries(attrs).map(([key, a]) => (
                  (a.show && a.value) ? (
                    <div key={key} style={{ fontSize: fs(11), color: textSoft }}>
                      {labelMode !== "none" && <span style={{ fontWeight: 500, color: textMain }}>{attrLabel(key)} </span>}{a.value}
                    </div>
                  ) : null
                ))}
                <div data-empty={perfumer ? undefined : "1"} style={{ fontSize: fs(11), color: textSoft }}>
                  <Edit value={perfumer} setter={setPerfumer} ph={isAr ? "العطّار" : "Perfumer"} />
                </div>

                {/* user mark */}
                {showMark && userMark && (
                  <div style={{ fontSize: fs(18), color: textMain, textAlign: "right", marginTop: 2 }}>{userMark}</div>
                )}
              </div>
            </div>

            {/* RIGHT: description + notes + extra attribute lines */}
            <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 14, minWidth: 0, overflow: "hidden" }}>
              <div data-empty={desc ? undefined : "1"} style={{ fontSize: fs(15), lineHeight: 1.55, color: textSoft, textAlign: "right", wordBreak: "break-word", overflowWrap: "anywhere" }}>
                <Edit value={desc} setter={setDesc} ph={isAr ? "أضف وصف المنتج" : "Add a marketing line"} />
              </div>
              {type === "perfume" && (notes.top.length + notes.heart.length + notes.base.length) > 0 && (
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {noteLabelMode === "none" && (
                    <div style={{ display: "flex", justifyContent: "flex-end" }}>
                      <svg width={fs(24)} height={fs(24)} viewBox="0 0 24 24" fill="none" stroke={textMain} strokeWidth="1.4" strokeLinejoin="round" aria-hidden="true">
                        <path d="M12 3 L21 20 H3 Z" />
                        <path d="M8 13 H16" opacity="0.55" />
                        <path d="M6 17 H18" opacity="0.55" />
                      </svg>
                    </div>
                  )}
                  {["top", "heart", "base"].map((tier) => {
                    const list = notes[tier];
                    if (!list || list.length === 0) return null;
                    const st = TIER_STYLE[tier];
                    return (
                      <div key={tier} style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                        {noteLabelMode !== "none" && (
                          <span style={{ fontSize: fs(12), color: textColor || (isWhite ? st.color : "rgba(255,255,255,0.8)") }}>{noteLabelMode === "ar" ? st.label.ar : st.label.en}</span>
                        )}
                        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", justifyContent: "flex-end" }}>
                          {list.map((n, i) => (
                            <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, width: 44 }}>
                              <div style={{ width: 36, height: 36, borderRadius: "50%", background: isWhite ? st.bg : "rgba(255,255,255,0.16)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}>
                                {n.image_url
                                  ? <img src={n.image_url} alt="" crossOrigin="anonymous" style={{ width: "100%", height: "100%", objectFit: "cover" }} />
                                  : <span style={{ fontSize: fs(9), color: isWhite ? st.color : "#fff" }}>{n.en.slice(0, 3)}</span>}
                              </div>
                              <span style={{ fontSize: fs(8), lineHeight: 1.15, textAlign: "center", color: textSoft }}>{n.en}<br />{n.ar}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
          {/* footer — price, location & social all on ONE line */}
          <div style={{ borderTop: `1px solid ${isWhite ? "#eee" : "rgba(255,255,255,0.2)"}`, paddingTop: 10, marginTop: 2, display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", color: textSoft, fontSize: fs(11) }}>
            {/* price group — single line */}
            <div style={{ display: "flex", alignItems: "center", gap: 8, whiteSpace: "nowrap" }}>
              <span style={{ fontSize: fs(16), fontWeight: 600, color: textMain }}>{total || priceNum || 0}{curSymbol}</span>
              {discNum > 0 && priceNum > 0 && (
                <>
                  <span style={{ textDecoration: "line-through", opacity: 0.55 }}>{priceNum}{curSymbol}</span>
                  <span style={{ opacity: 0.8 }}>−{discNum}%</span>
                </>
              )}
              {shipNum > 0 && (
                <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}><Package style={{ width: fs(12), height: fs(12) }} />{shipNum}{curSymbol}</span>
              )}
              {inclLine && <span style={{ fontSize: fs(9), opacity: 0.8 }}>{inclLine}</span>}
            </div>
            {/* location + social */}
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div data-empty={location ? undefined : "1"}>
                <Edit value={location} setter={setLocation} ph={isAr ? "الموقع" : "Location"} />
              </div>
              <div data-empty={social ? undefined : "1"}>
                <Edit value={social} setter={setSocial} ph="@social" />
              </div>
            </div>
          </div>
        </div>
          </div>
        </div>
      </div>

      {/* ---- controls ---- */}
      <div className="space-y-3">
        {/* نصوص البطاقة — كل التحرير هنا، سطراً سطراً (مناسب للجوال) */}
        <div className="border rounded-none p-3 space-y-2">
          <p className="text-xs text-muted-foreground font-medium">{isAr ? "نصوص البطاقة" : "Card text"}</p>
          <TextField label={isAr ? "الاسم (ع)" : "Name (AR)"} value={nameAr} setter={setNameAr} ph={isAr ? "اسم المنتج" : "اسم المنتج"} dir="rtl" />
          <TextField label={isAr ? "الاسم (En)" : "Name (EN)"} value={nameEn} setter={setNameEn} ph="Product Name" dir="ltr" />
          <TextField label={isAr ? "البراند" : "Brand"} value={brand} setter={setBrand} ph={isAr ? "البراند" : "Brand"} dir={isAr ? "rtl" : "ltr"} />
          <TextField label={isAr ? "الشركة" : "Company"} value={company} setter={setCompany} ph={isAr ? "اسم الشركة" : "Company"} dir={isAr ? "rtl" : "ltr"} />
          {type === "perfume" && (
            <TextField label={isAr ? "العطّار" : "Perfumer"} value={perfumer} setter={setPerfumer} ph={isAr ? "العطّار" : "Perfumer"} dir={isAr ? "rtl" : "ltr"} />
          )}
          <TextField label={isAr ? "السطر التسويقي" : "Tagline"} value={desc} setter={setDesc} ph={isAr ? "أضف وصف المنتج" : "Add a marketing line"} dir={isAr ? "rtl" : "ltr"} />
          <TextField label={isAr ? "الموقع" : "Location"} value={location} setter={setLocation} ph={isAr ? "الموقع" : "Location"} dir={isAr ? "rtl" : "ltr"} />
          <TextField label={isAr ? "التواصل" : "Social"} value={social} setter={setSocial} ph="@social" dir="ltr" />
        </div>

        {/* bg colors */}
        <div className="space-y-1.5">
          <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "لون الخلفية" : "Background color"}</p>
          <div className="flex flex-wrap gap-2 items-center">
            {BG_COLORS.map((c) => (
              <button key={c} onClick={() => { setBg(c); setBgImage(null); }} aria-label={c} style={{ width: 30, height: 30, borderRadius: "50%", background: c, border: bg === c ? "2px solid var(--brand)" : "2px solid rgba(127,127,127,0.3)" }} />
            ))}
          </div>
        </div>
        {/* images */}
        <div className="flex gap-2">
          <label className="flex-1 flex items-center justify-center gap-2 text-xs py-2 border rounded-none cursor-pointer">
            <ImageIcon className="w-4 h-4" /> {isAr ? "صورة خلفية" : "Background"}
            <input type="file" accept="image/*" className="hidden" onChange={onImagePick(setBgImage)} />
          </label>
          <label className="flex-1 flex items-center justify-center gap-2 text-xs py-2 border rounded-none cursor-pointer">
            <ImageIcon className="w-4 h-4" /> {isAr ? "صورة المنتج" : "Product image"}
            <input type="file" accept="image/*" className="hidden" onChange={onImagePick(setProductImage)} />
          </label>
        </div>

        {/* text color + size */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-muted-foreground">{isAr ? "لون الخط" : "Text color"}</span>
          {TEXT_COLORS.map((c, i) => (
            <button key={i} onClick={() => setTextColor(c)} aria-label={c || "auto"} title={c || "auto"} style={{ width: 24, height: 24, borderRadius: "50%", background: c || "conic-gradient(#165d31,#0c447c,#993556,#854f0b)", border: textColor === c ? "2px solid var(--color-text-primary)" : "1px solid rgba(127,127,127,0.4)" }} />
          ))}
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">{isAr ? "حجم الخط" : "Font size"}</span>
          <input type="range" min="0.8" max="1.3" step="0.05" value={fontScale} onChange={(e) => setFontScale(+e.target.value)} className="flex-1" />
          <span className="text-sm font-medium w-10">{Math.round(fontScale * 100)}%</span>
        </div>

        {/* numeric fields — semantic color labels for at-a-glance scanning */}
        <div className="grid grid-cols-2 gap-2">
          <label className="flex items-center gap-2 border rounded-none px-3 py-2">
            <span className="text-xs whitespace-nowrap" style={{ color: "#059669" }}>{isAr ? "السعر" : "Price"}</span>
            <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="0" className="w-full bg-transparent outline-none text-sm text-right" />
          </label>
          <label className="flex items-center gap-2 border rounded-none px-3 py-2">
            <span className="text-xs whitespace-nowrap" style={{ color: "#dc2626" }}>{isAr ? "الخصم %" : "Discount %"}</span>
            <input type="number" value={discount} onChange={(e) => setDiscount(e.target.value)} placeholder="0" className="w-full bg-transparent outline-none text-sm text-right" />
          </label>
          <label className="flex items-center gap-2 border rounded-none px-3 py-2">
            <span className="text-xs whitespace-nowrap" style={{ color: "#d97706" }}>{isAr ? "الضريبة %" : "Tax %"}</span>
            <input type="number" value={taxPct} onChange={(e) => setTaxPct(e.target.value)} placeholder="0" className="w-full bg-transparent outline-none text-sm text-right" />
          </label>
          <label className="flex items-center gap-2 border rounded-none px-3 py-2">
            <span className="text-xs whitespace-nowrap" style={{ color: "#1d4ed8" }}>{isAr ? "الشحن" : "Shipping"}</span>
            <input type="number" value={shipping} onChange={(e) => setShipping(e.target.value)} placeholder="0" className="w-full bg-transparent outline-none text-sm text-right" />
          </label>
        </div>

        {/* attribute lines (perfume only) */}
        {type === "perfume" && (
          <div className="border rounded-none p-3 space-y-2">
            <p className="text-xs text-muted-foreground font-medium">{isAr ? "أسطر إضافية (تحت الصورة)" : "Extra lines (below image)"}</p>
            <div className="flex items-center gap-1.5 flex-wrap pb-1">
              <span className="text-[11px] text-muted-foreground">{isAr ? "المسمّى:" : "Label:"}</span>
              {[
                { v: "none", ar: "بدون", en: "None" },
                { v: "icon", ar: "أيقونة", en: "Icon" },
                { v: "ar",   ar: "عربي",   en: "AR" },
                { v: "en",   ar: "إنجليزي", en: "EN" },
                { v: "all",  ar: "الكل",   en: "All" },
              ].map((o) => (
                <button key={o.v} type="button" onClick={() => setLabelMode(o.v)}
                  className={`text-[11px] rounded-none ${labelMode === o.v ? " text-background" : " text-muted-foreground"}`}>
                  {isAr ? o.ar : o.en}
                </button>
              ))}
            </div>
            <div className="flex items-center gap-1.5 flex-wrap pb-1">
              <span className="text-[11px] text-muted-foreground">{isAr ? "مسمّى النوتات:" : "Notes label:"}</span>
              {[
                { v: "none", ar: "هرم فقط", en: "Pyramid only" },
                { v: "ar",   ar: "عربي",    en: "AR" },
                { v: "en",   ar: "إنجليزي",  en: "EN" },
              ].map((o) => (
                <button key={o.v} type="button" onClick={() => setNoteLabelMode(o.v)}
                  className={`text-[11px] rounded-none ${noteLabelMode === o.v ? " text-background" : " text-muted-foreground"}`}>
                  {isAr ? o.ar : o.en}
                </button>
              ))}
            </div>
            {Object.keys(attrs).map((key) => (
              <div key={key} className="flex items-center gap-2">
                <label className="flex items-center gap-1.5 text-xs cursor-pointer w-28 flex-shrink-0">
                  <input type="checkbox" checked={attrs[key].show} onChange={(e) => setAttrs((s) => ({ ...s, [key]: { ...s[key], show: e.target.checked } }))} />
                  {isAr ? ATTR_LABELS[key].ar : ATTR_LABELS[key].en}
                </label>
                <input
                  value={attrs[key].value}
                  onChange={(e) => setAttrs((s) => ({ ...s, [key]: { ...s[key], value: e.target.value } }))}
                  placeholder={isAr ? "القيمة..." : "value..."}
                  className="flex-1 border rounded-none px-2 py-1 text-sm bg-background"
                  dir={isAr ? "rtl" : "ltr"}
                />
              </div>
            ))}
          </div>
        )}

        {/* currency + mark */}
        <div className="flex items-center gap-3">
          <span className="text-xs text-muted-foreground">{isAr ? "العملة" : "Currency"}</span>
          <select
            value={curSymbol}
            onChange={(e) => { if (e.target.value === "__custom__") { setCustomCur(true); } else { setCustomCur(false); setCurSymbol(e.target.value); } }}
            className="flex-1 border rounded-none px-2 py-1.5 text-sm bg-background"
          >
            <option value={symbol || "﷼"}>{isAr ? `${symbol || "﷼"} (افتراضي)` : `${symbol || "﷼"} (default)`}</option>
            {/* Main currencies */}
            <option value="﷼">{isAr ? "ريال SAR ﷼" : "SAR ﷼"}</option>
            <option value="$">{isAr ? "دولار USD $" : "USD $"}</option>
            <option value="€">{isAr ? "يورو EUR €" : "EUR €"}</option>
            <option value="£">{isAr ? "إسترليني GBP £" : "GBP £"}</option>
            <option value="¥">{isAr ? "ين JPY ¥" : "JPY ¥"}</option>
            <option value="元">{isAr ? "يوان CNY 元" : "CNY 元"}</option>
            <option value="₹">{isAr ? "روبية INR ₹" : "INR ₹"}</option>
            {/* Gulf currencies — alphabetical */}
            <option value="AED">AED د.إ</option>
            <option value="BHD">BHD .د.ب</option>
            <option value="KWD">KWD د.ك</option>
            <option value="OMR">OMR ر.ع</option>
            <option value="QAR">QAR ر.ق</option>
            {/* Custom */}
            <option value="__custom__">{isAr ? "+ إضافة عملة" : "+ Add currency"}</option>
          </select>
          <label className="flex items-center gap-2 text-xs cursor-pointer">
            <input type="checkbox" checked={showMark} onChange={(e) => setShowMark(e.target.checked)} />
            {isAr ? "إظهار العلامة" : "Show mark"}
          </label>
        </div>
        {customCur && (
          <input
            autoFocus
            placeholder={isAr ? "اكتب رمز العملة (مثل CHF، ر.ي)" : "Type currency (e.g. CHF)"}
            onBlur={(e) => { const v = e.target.value.trim(); if (v) setCurSymbol(v); setCustomCur(false); }}
            onKeyDown={(e) => { if (e.key === "Enter") { const v = e.currentTarget.value.trim(); if (v) setCurSymbol(v); setCustomCur(false); } }}
            className="w-full border rounded-none px-3 py-2 text-sm bg-background"
          />
        )}

        {/* export + save */}
        <div className="flex gap-2">
          <button onClick={exportImage} className="flex-1 flex items-center justify-center gap-2 text-sm py-2.5 border rounded-none bg-foreground text-background">
            <Download className="w-4 h-4" /> {isAr ? "تصدير صورة" : "Export image"}
          </button>
          <button onClick={saveCard} className="flex items-center justify-center gap-2 text-sm py-2.5 px-4 border rounded-none">
            <Save className="w-4 h-4" /> {isAr ? "حفظ" : "Save"}
          </button>
        </div>

        {/* saved cards log */}
        {savedCards.length > 0 && (
          <div className="border rounded-none p-3 space-y-2">
            <p className="text-xs text-muted-foreground font-medium">{isAr ? "البطاقات المحفوظة" : "Saved cards"}</p>
            {savedCards.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-2 text-sm border-b last:border-0 pb-2 last:pb-0">
                <button onClick={() => applyCard(c)} className="flex-1 text-start hover:text-primary truncate">
                  <span className="font-medium">{c.nameAr || c.nameEn || "—"}</span>
                  <span className="text-muted-foreground text-xs"> · {c.curSymbol}{(() => { const pn = parseFloat(c.price) || 0; const tx = pn * ((parseFloat(c.taxPct) || 0) / 100); const at = pn + tx; const dc = at * ((parseFloat(c.discount) || 0) / 100); return Math.round(at - dc + (parseFloat(c.shipping) || 0)); })()}</span>
                </button>
                <button onClick={() => applyCard(c)} className="text-xs text-primary px-2">{isAr ? "تحميل" : "Load"}</button>
                <button onClick={() => deleteCard(c.id)} aria-label="delete" className="text-muted-foreground hover:text-red-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
