import { useState, useRef } from "react";
import { apphost } from "@/api/apphostClient";
import { useQueryClient } from "@tanstack/react-query";
import { Edit3, RefreshCw, LayoutGrid, BookOpen, Image } from "lucide-react";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { DEFAULT_USER_MARK } from "@/lib/exportSettings";

export default function ShopHeroQuote({ quotes, isAr, viewMode, setViewMode, mark }) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [editing, setEditing] = useState(false);
  const [addingNew, setAddingNew] = useState(false);
  const [editText, setEditText] = useState({ en: "", ar: "" });
  const [newText, setNewText] = useState({ en: "", ar: "" });
  const [exporting, setExporting] = useState(false);
  const cardRef = useRef(null);
  const queryClient = useQueryClient();

  const activeQuotes = quotes.filter(q => q.is_active !== false);
  const current = activeQuotes[currentIdx % Math.max(activeQuotes.length, 1)];

  const shuffle = () => setCurrentIdx(i => (i + 1) % Math.max(activeQuotes.length, 1));

  const startEdit = () => {
    if (!current) return;
    setEditText({ en: current.text_en || "", ar: current.text_ar || "" });
    setEditing(true);
    setAddingNew(false);
  };

  const saveEdit = async () => {
    if (!current) return;
    await apphost.entities.Wisdom.update(current.id, { wisdom: editText.en, wisdom_ar: editText.ar });
    queryClient.invalidateQueries({ queryKey: ["wisdom"] });
    setEditing(false);
    toast.success(isAr ? "تم الحفظ" : "Saved");
  };

  const startAddNew = () => {
    setNewText({ en: "", ar: "" });
    setAddingNew(true);
    setEditing(false);
  };

  const saveNew = async () => {
    if (!newText.en && !newText.ar) { toast.error(isAr ? "أدخل نصاً" : "Enter text"); return; }
    await apphost.entities.Wisdom.create({ wisdom: newText.en, wisdom_ar: newText.ar, category: "shopping", is_user: true });
    queryClient.invalidateQueries({ queryKey: ["wisdom"] });
    setCurrentIdx(activeQuotes.length);
    setAddingNew(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  const handleExport = async () => {
    if (!current) return;
    setExporting(true);
    try {
      const GOLD = "#c8a24a", GOLD_SOFT = "#e6cf95", GOLD_DEEP = "#9c7a2e";
      const userMark = (mark && mark.trim()) ? mark : DEFAULT_USER_MARK;
      // بطاقة بيضاء بلا إطارات، كتابة ذهبية، بلا فاصل في المنتصف.
      const card = document.createElement("div");
      card.style.cssText = `
        position:fixed; left:0; top:0; z-index:-1; opacity:1; pointer-events:none;
        width:560px; box-sizing:border-box;
        background:#ffffff;
        padding:44px 40px; display:flex; flex-direction:column; gap:18px;
        border-radius:18px;
        font-family:'Playfair Display','Amiri','Georgia',serif;
      `;

      // الإنجليزية — يسار، من اليسار لليمين
      if (current.text_en) {
        const en = document.createElement("div");
        en.textContent = current.text_en;
        en.style.cssText = `position:relative; direction:ltr; text-align:left; color:${GOLD}; font-size:30px; font-style:italic; line-height:1.4;`;
        card.appendChild(en);
      }

      // العربية — يمين، من اليمين لليسار (ذهبي مقروء على الأبيض)
      if (current.text_ar) {
        const ar = document.createElement("div");
        ar.textContent = current.text_ar;
        ar.style.cssText = `position:relative; direction:rtl; text-align:right; color:${GOLD}; font-size:26px; line-height:1.7; font-family:'Amiri','Traditional Arabic',serif;`;
        card.appendChild(ar);
      }

      // علامة المستخدم — ذهبية أنيقة (تظهر دائماً)
      {
        const markEl = document.createElement("div");
        markEl.textContent = userMark;
        markEl.style.cssText = `position:relative; color:${GOLD_DEEP}; font-size:15px; letter-spacing:3px; text-align:center; margin-top:6px; font-family:sans-serif;`;
        card.appendChild(markEl);
      }

      document.body.appendChild(card);
      const canvas = await captureElement(card, { scale: 2, useCORS: true, backgroundColor: "#ffffff" });
      document.body.removeChild(card);

      // اسم ملف مميّز: مقتطف من النص + ختم زمني
      const base = (current.text_en || current.text_ar || "wisdom")
        .replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-+|-+$/g, "").slice(0, 28) || "wisdom";
      const d = new Date();
      const pad = (n) => String(n).padStart(2, "0");
      const stamp = `${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(d.getMinutes())}${pad(d.getSeconds())}`;
      await saveCanvasAsImage(canvas, `Wisdom-${base}-${stamp}.png`);

      toast(isAr ? "تم التصدير" : "Exported", { position: "bottom-right" });
    } catch (e) {
      toast.error(isAr ? "فشل التصدير" : "Export failed", { position: "bottom-right" });
    }
    setExporting(false);
  };

  const inlineForms = editing || addingNew;

  return (
    <div className="relative overflow-hidden">
      {viewMode === "magazine" ? (
        <div className="px-5 pb-5" style={{paddingTop: "calc(env(safe-area-inset-top, 0px) + 4rem)"}}>
          <div className="relative text-center space-y-2">
            <p className="text-[8px] tracking-widest text-emerald-600 dark:text-emerald-400 font-body uppercase opacity-90">
              {isAr ? "حكم غير مكتملة" : "Incomplete Wisdom"}
            </p>

            {editing ? (
              <div className="space-y-2">
                <input value={editText.en} onChange={e => setEditText(p => ({ ...p, en: e.target.value }))}
                  placeholder="حكمة بالإنجليزية... English wisdom..."
                  className="w-full bg-transparent text-foreground text-center italic text-base font-heading rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" />
                <input value={editText.ar} onChange={e => setEditText(p => ({ ...p, ar: e.target.value }))}
                  placeholder="الحكمة بالعربي..."
                  className="w-full bg-transparent text-foreground text-center text-sm font-body rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" dir="rtl" />
                <div className="flex gap-2 justify-center">
                  <button onClick={saveEdit} className="px-4 py-1.5 bg-[var(--brand)] text-white rounded-none text-xs font-body font-bold">
                    {isAr ? "حفظ" : "Save"}
                  </button>
                  <button onClick={() => setEditing(false)} className="px-4 py-1.5 text-muted-foreground rounded-none text-xs font-body">
                    {isAr ? "إلغاء" : "Cancel"}
                  </button>
                </div>
              </div>
            ) : addingNew ? (
              <div className="space-y-2">
                <input value={newText.en} onChange={e => setNewText(p => ({ ...p, en: e.target.value }))}
                  placeholder="حكمة بالإنجليزية... English wisdom..."
                  className="w-full bg-transparent text-foreground text-center italic text-base font-heading rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" />
                <input value={newText.ar} onChange={e => setNewText(p => ({ ...p, ar: e.target.value }))}
                  placeholder="الحكمة بالعربي..."
                  className="w-full bg-transparent text-foreground text-center text-sm font-body rounded-none px-3 py-2 outline-none border border-[var(--brand)]/40" dir="rtl" />
                <div className="flex gap-2 justify-center">
                  <button onClick={saveNew} className="px-4 py-1.5 bg-[var(--brand)] text-white rounded-none text-xs font-body font-bold">
                    {isAr ? "حفظ" : "Save"}
                  </button>
                  <button onClick={() => setAddingNew(false)} className="px-4 py-1.5 text-muted-foreground rounded-none text-xs font-body">
                    {isAr ? "إلغاء" : "Cancel"}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <h1 className="text-xl font-heading font-bold italic leading-snug px-2" style={{ color: "var(--brand)" }}>
                  {isAr ? (current?.text_ar || current?.text_en) : (current?.text_en || "")}
                </h1>
                {!isAr && current?.text_ar && (
                  <p className="text-xs font-body" style={{ color: "rgba(200,160,46,0.7)" }} dir="rtl">{current.text_ar}</p>
                )}
                {isAr && current?.text_en && (
                  <p className="text-xs font-body" style={{ color: "rgba(200,160,46,0.7)" }}>{current.text_en}</p>
                )}
              </>
            )}

            {!inlineForms && (
              <div className="flex items-center justify-center gap-2 pt-1 flex-wrap">
                <button onClick={shuffle} className="p-1.5 text-[var(--brand)] hover:opacity-70 transition-opacity" title="Shuffle">
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
                <button onClick={startEdit} className="p-1.5 text-[var(--brand)] hover:opacity-70 transition-opacity" title="Edit">
                  <Edit3 className="w-3.5 h-3.5" />
                </button>
                <button onClick={startAddNew}
                  className="px-2.5 py-1 text-[var(--brand)] hover:opacity-70 rounded-none text-[10px] font-body font-bold transition-opacity">
                  {isAr ? "أضف حكمة" : "Add Wisdom"}
                </button>
                <button onClick={handleExport} disabled={exporting} className="p-1.5 text-[var(--brand)] hover:opacity-70 transition-opacity" title="Export as Image">
                  {exporting ? <div className="w-3.5 h-3.5 border border-[var(--brand)] border-t-transparent rounded-full animate-spin" /> : <Image className="w-3.5 h-3.5" />}
                </button>
                <div className="w-px h-4 bg-[var(--brand)]/30" />
                <button onClick={() => { setViewMode("magazine"); localStorage.setItem("shopViewMode", "magazine"); }}
                  className={`p-1.5 transition-opacity ${viewMode === "magazine" ? "text-[var(--brand)]" : "text-[var(--brand)]/50 hover:opacity-70"}`}>
                  <BookOpen className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => { setViewMode("modern"); localStorage.setItem("shopViewMode", "modern"); }}
                  className={`p-1.5 transition-opacity ${viewMode === "modern" ? "text-[var(--brand)]" : "text-[var(--brand)]/50 hover:opacity-70"}`}>
                  <LayoutGrid className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="px-5 pt-16 pb-4" style={{paddingTop: "calc(env(safe-area-inset-top, 0px) + 4rem)"}}>
          <div className="flex items-start justify-between gap-3">
            <div className="flex-1 min-w-0">
              <p className="text-[8px] tracking-widest text-emerald-600 font-body uppercase opacity-70">
                {isAr ? "حكم غير مكتملة" : "Incomplete Wisdom"}
              </p>
              {addingNew ? (
                <div className="mt-1 space-y-1.5">
                  <input value={newText.en} onChange={e => setNewText(p => ({ ...p, en: e.target.value }))}
                    placeholder="حكمة بالإنجليزية... English wisdom..."
                    className="w-full border border-border rounded-none px-2 py-1 text-sm font-body outline-none bg-background" />
                  <input value={newText.ar} onChange={e => setNewText(p => ({ ...p, ar: e.target.value }))}
                    placeholder="الحكمة بالعربي..."
                    className="w-full border border-border rounded-none px-2 py-1 text-sm font-body outline-none bg-background" dir="rtl" />
                  <div className="flex gap-2">
                    <button onClick={saveNew} className=" text-primary-foreground rounded-none text-xs font-body font-bold">{isAr ? "حفظ" : "Save"}</button>
                    <button onClick={() => setAddingNew(false)} className=" text-foreground rounded-none text-xs font-body">{isAr ? "إلغاء" : "Cancel"}</button>
                  </div>
                </div>
              ) : (
                <h1 className="text-base font-heading font-bold mt-0.5 leading-snug">
                  {isAr ? (current?.text_ar || current?.text_en) : (current?.text_en || "")}
                </h1>
              )}
            </div>
            <div className="flex gap-1 flex-shrink-0 flex-wrap justify-end">
              <button onClick={shuffle} className="p-1.5 text-muted-foreground hover:text-foreground"><RefreshCw className="w-3.5 h-3.5" /></button>
              <button onClick={startEdit} className="p-1.5 text-muted-foreground hover:text-foreground"><Edit3 className="w-3.5 h-3.5" /></button>
              <button onClick={startAddNew} className="px-2 py-1 text-[10px] text-muted-foreground hover:text-foreground font-body" title={isAr ? "أضف حكمة" : "Add Wisdom"}>{isAr ? "أضف" : "Add"}</button>
              <button onClick={handleExport} disabled={exporting} className="p-1.5 text-muted-foreground hover:text-foreground">
                {exporting ? <div className="w-3.5 h-3.5 border border-border border-t-foreground rounded-full animate-spin" /> : <Image className="w-3.5 h-3.5" />}
              </button>
              <button onClick={() => { setViewMode("magazine"); localStorage.setItem("shopViewMode", "magazine"); }}
                className="p-1.5 text-muted-foreground hover:text-foreground"><BookOpen className="w-3.5 h-3.5" /></button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}