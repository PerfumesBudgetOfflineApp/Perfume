import { getAppName } from "@/lib/useAppName";
import { useState, useMemo, useRef, useEffect } from "react";
import { apphost } from "@/api/apphostClient";
import { ArrowLeft, Download } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, CartesianGrid, LineChart, Line } from "recharts";
import { captureElement } from "@/lib/captureCanvas";
import { downloadBlob } from "@/lib/exportHelper";
import { toast } from "sonner";

const COLORS = ["#10b981","#8b5cf6","#f59e0b","#3b82f6","#ec4899","#6366f1","#f43f5e","#84cc16","#fb923c","#a855f7","#0ea5e9","#fbbf24"];

function Section({ title, icon, children, color = "emerald" }) {
  const colorMap = {
    emerald: "from-emerald-50 to-emerald-100/30 dark:from-emerald-900/20 border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-400",
    purple: "from-purple-50 to-purple-100/30 dark:from-purple-900/20 border-purple-200 dark:border-purple-800 text-purple-700 dark:text-purple-400",
    amber: "from-amber-50 to-amber-100/30 dark:from-amber-900/20 border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400",
    blue: "from-blue-50 to-blue-100/30 dark:from-blue-900/20 border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-400",
  };
  return (
    <div className={`bg-gradient-to-br ${colorMap[color]} border rounded-none p-4 space-y-3 break-inside-avoid`}>
      <h3 className={`text-xs font-body font-bold uppercase tracking-widest flex items-center gap-2 ${colorMap[color].split(" ").slice(-1)[0]}`}>
        {icon && <span>{icon}</span>}
        {title}
      </h3>
      {children}
    </div>
  );
}

function StatCard({ label, value, sub, color }) {
  return (
    <div className={`rounded-none p-3 border ${color}`}>
      <p className="text-[9px] font-body uppercase tracking-wider text-muted-foreground">{label}</p>
      <p className="text-lg font-bold font-heading mt-0.5">{value}</p>
      {sub && <p className="text-[9px] text-muted-foreground font-body mt-0.5">{sub}</p>}
    </div>
  );
}

export default function ShopReport({ products, brands, categories, isAr, currency, names, onClose }) {
  const [reportType, setReportType] = useState("full");
  const [exporting, setExporting] = useState(false);
  const reportRef = useRef();
  const [mark, setMark] = useState("");

  // Load user mark (real effect, runs once on mount)
  useEffect(() => {
    apphost.auth.me().then(u => setMark(u?.mark || "")).catch(() => {});
  }, []);

  const mainCats = useMemo(() => categories.filter(c => !c.parent_id), [categories]);
  const now = new Date();

  // === Analytics ===
  const total = useMemo(() => products.reduce((s, p) => s + (p.cost || 0), 0), [products]);
  const avgCost = products.length > 0 ? (total / products.length) : 0;

  const thisMonthProducts = useMemo(() => products.filter(p => {
    if (!p.purchase_date) return false;
    const d = new Date(p.purchase_date);
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
  }), [products]);

  const thisMonth = thisMonthProducts.reduce((s, p) => s + (p.cost || 0), 0);

  const lastMonthTotal = useMemo(() => products.filter(p => {
    if (!p.purchase_date) return false;
    const d = new Date(p.purchase_date);
    const lm = new Date(now.getFullYear(), now.getMonth() - 1);
    return d.getMonth() === lm.getMonth() && d.getFullYear() === lm.getFullYear();
  }).reduce((s, p) => s + (p.cost || 0), 0), [products]);

  const monthDiff = lastMonthTotal > 0 ? ((thisMonth - lastMonthTotal) / lastMonthTotal * 100).toFixed(0) : 0;

  const recurring = useMemo(() => products.filter(p => p.recurring), [products]);
  const recurringTotal = recurring.reduce((s, p) => s + (p.cost || 0), 0);

  const byMonth = useMemo(() => {
    const map = {};
    products.forEach(p => {
      if (!p.purchase_date) return;
      const key = p.purchase_date.slice(0, 7);
      map[key] = (map[key] || 0) + (p.cost || 0);
    });
    return Object.entries(map).sort((a, b) => a[0].localeCompare(b[0])).slice(-12).map(([k, v]) => ({ month: k.slice(5), amount: Math.round(v) }));
  }, [products]);

  const byCategory = useMemo(() => {
    const map = {};
    products.forEach(p => {
      const cat = mainCats.find(c => String(c.id) === String(p.category_id));
      const key = cat ? (isAr ? cat.name_ar : cat.name_en) : (isAr ? "غير محدد" : "Uncategorized");
      map[key] = (map[key] || 0) + (p.cost || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [products, mainCats, isAr]);

  const byPerson = useMemo(() => {
    const map = {};
    products.forEach(p => {
      const key = names?.[p.person] || p.person || "Unknown";
      map[key] = (map[key] || 0) + (p.cost || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [products, names]);

  const byBrand = useMemo(() => {
    const map = {};
    products.forEach(p => {
      if (!p.brand_name) return;
      map[p.brand_name] = (map[p.brand_name] || 0) + (p.cost || 0);
    });
    return Object.entries(map).sort((a, b) => b[1] - a[1]).slice(0, 10).map(([name, value]) => ({ name, value: Math.round(value) }));
  }, [products]);

  // Consumer behavior analysis
  const buyingProfile = useMemo(() => {
    const impulseRatio = products.filter(p => !p.recurring && p.cost > avgCost).length / Math.max(products.length, 1);
    const qualityFocus = products.filter(p => p.quality_rating >= 4).length / Math.max(products.filter(p => p.quality_rating > 0).length, 1);
    const repurchaseRate = products.filter(p => p.repurchase).length / Math.max(products.length, 1);
    const avgRating = products.filter(p => p.rating > 0).reduce((s, p) => s + p.rating, 0) / Math.max(products.filter(p => p.rating > 0).length, 1);
    const highValueItems = products.filter(p => p.cost > avgCost * 1.5).length;
    return { impulseRatio, qualityFocus, repurchaseRate, avgRating, highValueItems };
  }, [products, avgCost]);

  const consumerType = useMemo(() => {
    const { impulseRatio, qualityFocus, repurchaseRate } = buyingProfile;
    if (qualityFocus > 0.7 && repurchaseRate > 0.5) return isAr ? "🎯 مستهلك واعٍ بالجودة" : "🎯 Quality-Conscious Buyer";
    if (impulseRatio > 0.6) return isAr ? "⚡ مستهلك انفعالي" : "⚡ Impulse Buyer";
    if (repurchaseRate > 0.6) return isAr ? "🔄 مستهلك وفي للعلامات" : "🔄 Brand-Loyal Buyer";
    if (recurring.length > products.length * 0.4) return isAr ? "📅 مستهلك منتظم" : "📅 Routine Buyer";
    return isAr ? "⚖️ مستهلك متوازن" : "⚖️ Balanced Buyer";
  }, [buyingProfile, isAr, recurring, products]);

  // Shopping log — recent purchases
  const recentProducts = useMemo(() => [...products].sort((a, b) => new Date(b.purchase_date || b.created_date) - new Date(a.purchase_date || a.created_date)).slice(0, 20), [products]);

  // Stores summary
  const storesSummary = useMemo(() => {
    return brands.map(brand => {
      const brandProducts = products.filter(p => p.brand_id === brand.id);
      const spent = brandProducts.reduce((s, p) => s + (p.cost || 0), 0);
      const avgRating = brandProducts.filter(p => p.rating > 0).length > 0
        ? brandProducts.filter(p => p.rating > 0).reduce((s, p) => s + p.rating, 0) / brandProducts.filter(p => p.rating > 0).length
        : 0;
      return { ...brand, productCount: brandProducts.length, totalSpent: Math.round(spent), avgRating: avgRating.toFixed(1) };
    }).sort((a, b) => b.totalSpent - a.totalSpent);
  }, [brands, products]);

  const chartStyle = { backgroundColor: "hsl(var(--card))", border: "1px solid hsl(var(--border))", borderRadius: 8, fontSize: 10, fontFamily: "var(--font-body)" };

  const handleExport = async () => {
    if (!reportRef.current) return; // قد يكون فارغاً إن غُيّر نوع التقرير بسرعة
    setExporting(true);
    // امنح React فرصة لإظهار فوتر التصدير قبل الالتقاط
    await new Promise(r => setTimeout(r, 60));
    try {
      const node = reportRef.current;
      // scale تكيّفي: التقرير الطويل يُرسَم في canvas عملاق يتجاوز سقف WebView
      // للأبعاد/الذاكرة → تجميد أو صورة فارغة. نحسب أكبر scale يبقي الـcanvas
      // ضمن ميزانية آمنة (≤8000px لكل بُعد و≤16 ميغابكسل مساحة)، وننزل عن 1.6
      // فقط عند الحاجة (التقارير العادية تبقى بأعلى دقّة).
      const w = node.scrollWidth || node.offsetWidth || 800;
      const h = node.scrollHeight || node.offsetHeight || 800;
      const MAX_DIM = 8000;          // أقصى بُعد واحد آمن في WebView
      const MAX_AREA = 16_000_000;   // ~16 ميغابكسل ميزانية مساحة آمنة
      let scale = Math.min(1.6, MAX_DIM / w, MAX_DIM / h, Math.sqrt(MAX_AREA / (w * h)));
      if (!isFinite(scale) || scale <= 0) scale = 1;
      scale = Math.max(0.7, scale); // لا ننزل تحت 0.7 حفاظاً على الوضوح
      const canvas = await captureElement(node, { scale, useCORS: true, backgroundColor: "#ffffff", logging: false });
      // JPEG بدل PNG يقلّص الحجم بشدّة لتقرير طويل (لا شفافية مطلوبة)
      const imgData = canvas.toDataURL("image/jpeg", 0.82);
      const { jsPDF } = await import("jspdf");
      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4", compress: true });
      const pageW = pdf.internal.pageSize.getWidth();
      const pageH = pdf.internal.pageSize.getHeight();
      const imgW = pageW;
      const imgH = (canvas.height * imgW) / canvas.width;
      let posY = 0;
      let pageCount = 0;
      while (posY < imgH) {
        if (pageCount > 0) pdf.addPage();
        // alias ثابت ("shopreport") يجعل jsPDF يخزّن الصورة مرّة واحدة
        // ويعيد استخدامها في كل صفحة بدل تكرار بياناتها (السبب الرئيسي لضخامة الملف).
        pdf.addImage(imgData, "JPEG", 0, -posY, imgW, imgH, "shopreport", "FAST");
        posY += pageH;
        pageCount++;
      }
      const blob = pdf.output('blob');
      await downloadBlob(blob, `shopping-report-${new Date().toISOString().slice(0, 10)}.pdf`);
      toast.success(isAr ? "تم التصدير" : "Exported!");
    } catch (e) {
      toast.error((isAr ? "فشل التصدير" : "Export failed"));
    }
    setExporting(false);
  };

  const reportTypes = [
    { id: "full", en: "Full Report", ar: "تقرير شامل" },
    { id: "consumer", en: "Consumer Detailed", ar: "تحليل المستهلك" },
    { id: "stores", en: "Stores Report", ar: "تقرير المتاجر" },
    { id: "log", en: "Shopping Log", ar: "سجل التسوق" },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="w-full flex-1 flex flex-col overflow-x-hidden">
        {/* Toolbar — رجوع + PDF فقط */}
        <div className="sticky top-0 z-10 bg-background border-b border-border px-4 py-3 flex items-center gap-2" style={{ paddingTop: "calc(env(safe-area-inset-top, 0px) + 0.75rem)" }}>
          <button onClick={onClose} title={isAr ? "رجوع" : "Back"} className="p-1.5 text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div className="flex-1" />
          <button onClick={handleExport} disabled={exporting}
            className="flex items-center gap-1.5 text-primary-foreground rounded-none text-xs font-body font-bold flex-shrink-0">
            <Download className="w-3.5 h-3.5" />
            {exporting ? "..." : (isAr ? "تصدير PDF" : "PDF")}
          </button>
        </div>

        {/* أنواع التقرير — أزرار حرّة بجانب بعضها (سطر بعد PDF، يلتفّ حسب الشاشة) */}
        <div className="px-4 pt-3 flex flex-wrap gap-x-4 gap-y-1">
          {reportTypes.map(rt => (
            <button key={rt.id} onClick={() => setReportType(rt.id)}
              className={`text-xs font-body py-1 transition-colors ${reportType === rt.id ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`}>
              {isAr ? rt.ar : rt.en}
            </button>
          ))}
        </div>

        {/* Report Body */}
        <div ref={reportRef} className={`px-4 py-5 space-y-4 pb-20 bg-background ${isAr ? "rtl" : ""}`} style={{ fontFamily: "var(--font-body)" }}>
          {/* Header */}
          <div className="bg-gradient-to-br from-emerald-900 via-emerald-800 to-teal-900 rounded-none px-6 py-6 text-white">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-[9px] tracking-widest text-emerald-300 font-body uppercase mb-1">
                  {isAr ? "تقرير التسوق" : "Shopping Report"}
                </p>
                <h1 className="text-2xl font-heading font-bold">
                  {reportType === "consumer" ? (isAr ? "تحليل المستهلك" : "Consumer Detailed") :
                    reportType === "stores" ? (isAr ? "تقرير المتاجر" : "Stores Report") :
                    reportType === "log" ? (isAr ? "سجل التسوق" : "Shopping Log") :
                    (isAr ? "التقرير الشامل" : "Full Report")}
                </h1>
                <p className="text-xs text-emerald-300 font-body mt-1">{new Date().toLocaleDateString(isAr ? "ar-SA" : "en-US", { dateStyle: "long" })}</p>
              </div>
              <div className="text-right">
                <p className="text-3xl font-heading font-bold text-emerald-300">{Math.round(total)}</p>
                <p className="text-[9px] text-emerald-400 font-body">{currency} {isAr ? "إجمالي" : "total"}</p>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2 mt-4">
              {[
                { label: isAr ? "منتجات" : "Products", value: products.length },
                { label: isAr ? "متاجر" : "Stores", value: brands.length },
                { label: isAr ? "هذا الشهر" : "This Month", value: `${Math.round(thisMonth)}` },
                { label: isAr ? "متوسط" : "Avg", value: `${Math.round(avgCost)}` },
              ].map((s, i) => (
                <div key={i} className="bg-white/10 rounded-none p-2 text-center">
                  <p className="text-base font-bold font-heading">{s.value}</p>
                  <p className="text-[8px] text-emerald-300 font-body">{s.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* ─── FULL or CONSUMER ─── */}
          {(reportType === "full" || reportType === "consumer") && (
            <>
              {/* Consumer Profile */}
              <Section title={isAr ? "الطبيعة الشرائية" : "Buying Nature"} icon="🧠" color="purple">
                <div className="flex items-center gap-3 bg-white/50 dark:bg-white/5 rounded-none p-3">
                  <span className="text-3xl">{consumerType.slice(0, 2)}</span>
                  <div>
                    <p className="text-sm font-heading font-bold">{consumerType.slice(2).trim()}</p>
                    <p className="text-[10px] text-muted-foreground font-body">{isAr ? "نوع المستهلك" : "Consumer type"}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    { label: isAr ? "معدل إعادة الشراء" : "Repurchase Rate", value: `${(buyingProfile.repurchaseRate * 100).toFixed(0)}%`, color: "text-emerald-600" },
                    { label: isAr ? "تركيز الجودة" : "Quality Focus", value: `${(buyingProfile.qualityFocus * 100).toFixed(0)}%`, color: "text-blue-600" },
                    { label: isAr ? "متوسط التقييم" : "Avg Rating", value: `${buyingProfile.avgRating.toFixed(1)} ■`, color: "text-amber-600" },
                    { label: isAr ? "عناصر فوق المتوسط" : "High-Value Items", value: buyingProfile.highValueItems, color: "text-purple-600" },
                  ].map((s, i) => (
                    <div key={i} className="bg-white/50 dark:bg-white/5 rounded-none p-2 border border-border/30">
                      <p className="text-[9px] text-muted-foreground font-body">{s.label}</p>
                      <p className={`text-base font-bold font-heading ${s.color}`}>{s.value}</p>
                    </div>
                  ))}
                </div>
                {/* Radar-style bar traits */}
                <div className="space-y-1.5">
                  {[
                    { label: isAr ? "الانفعالية" : "Impulse Level", value: buyingProfile.impulseRatio, color: "#f43f5e" },
                    { label: isAr ? "الوفاء" : "Loyalty", value: buyingProfile.repurchaseRate, color: "#10b981" },
                    { label: isAr ? "اهتمام بالجودة" : "Quality Focus", value: buyingProfile.qualityFocus, color: "#8b5cf6" },
                  ].map((t, i) => (
                    <div key={i}>
                      <div className="flex justify-between text-[9px] font-body mb-0.5">
                        <span>{t.label}</span>
                        <span className="font-bold">{(t.value * 100).toFixed(0)}%</span>
                      </div>
                      <div className="h-2 bg-secondary rounded-none overflow-hidden">
                        <div className="h-full rounded-none transition-all" style={{ width: `${t.value * 100}%`, background: t.color }} />
                      </div>
                    </div>
                  ))}
                </div>
              </Section>

              {/* Monthly Trend */}
              {byMonth.length > 1 && (
                <Section title={isAr ? "الإنفاق الشهري" : "Monthly Spending Trend"} icon="📈" color="blue">
                  <ResponsiveContainer width="100%" height={130}>
                    <LineChart data={byMonth}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="month" tick={{ fontSize: 9, fontFamily: "var(--font-body)" }} />
                      <YAxis tick={{ fontSize: 8 }} width={32} />
                      <Tooltip contentStyle={chartStyle} formatter={v => [`${v} ${currency}`, ""]} />
                      <Line type="monotone" dataKey="amount" stroke="#10b981" strokeWidth={2.5} dot={{ r: 3, fill: "#10b981" }} />
                    </LineChart>
                  </ResponsiveContainer>
                  <div className="flex gap-2 mt-1">
                    <div className="flex-1 bg-emerald-50 dark:bg-emerald-900/20 rounded-none p-2 text-center border border-emerald-200 dark:border-emerald-800">
                      <p className="text-[9px] text-muted-foreground font-body">{isAr ? "هذا الشهر" : "This Month"}</p>
                      <p className="text-sm font-bold text-emerald-700 dark:text-emerald-400">{Math.round(thisMonth)} {currency}</p>
                    </div>
                    <div className="flex-1 bg-amber-50 dark:bg-amber-900/20 rounded-none p-2 text-center border border-amber-200 dark:border-amber-800">
                      <p className="text-[9px] text-muted-foreground font-body">{isAr ? "التغيير" : "Change"}</p>
                      <p className={`text-sm font-bold ${Number(monthDiff) >= 0 ? "text-red-500" : "text-emerald-600"}`}>{monthDiff > 0 ? "+" : ""}{monthDiff}%</p>
                    </div>
                    <div className="flex-1 bg-purple-50 dark:bg-purple-900/20 rounded-none p-2 text-center border border-purple-200 dark:border-purple-800">
                      <p className="text-[9px] text-muted-foreground font-body">{isAr ? "الدوري" : "Recurring"}</p>
                      <p className="text-sm font-bold text-purple-700 dark:text-purple-400">{Math.round(recurringTotal)} {currency}</p>
                    </div>
                  </div>
                </Section>
              )}

              {/* By Category pie */}
              {byCategory.length > 0 && (
                <Section title={isAr ? "الإنفاق حسب القسم" : "By Category"} icon="🗂" color="emerald">
                  <div className="flex gap-3">
                    <div className="flex-shrink-0">
                      <ResponsiveContainer width={120} height={120}>
                        <PieChart>
                          <Pie data={byCategory} dataKey="value" cx="50%" cy="50%" outerRadius={52} innerRadius={28}>
                            {byCategory.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                          </Pie>
                          <Tooltip contentStyle={chartStyle} formatter={v => [`${v} ${currency}`, ""]} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex-1 space-y-1.5 py-1">
                      {byCategory.slice(0, 7).map((c, i) => (
                        <div key={c.name} className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-none flex-shrink-0" style={{ background: COLORS[i % COLORS.length] }} />
                          <span className="text-[10px] font-body flex-1 truncate">{c.name}</span>
                          <span className="text-[10px] font-bold text-primary">{c.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </Section>
              )}

              {/* By Person */}
              {byPerson.length > 0 && (
                <Section title={isAr ? "الإنفاق حسب الشخص" : "Spending by Person"} icon="👤" color="amber">
                  <div className="space-y-2">
                    {byPerson.map((p, i) => {
                      const pct = total > 0 ? (p.value / total * 100).toFixed(0) : 0;
                      return (
                        <div key={p.name}>
                          <div className="flex justify-between text-xs font-body mb-1">
                            <span className="font-semibold">{p.name}</span>
                            <span className="font-bold">{p.value} {currency} <span className="text-muted-foreground text-[10px]">({pct}%)</span></span>
                          </div>
                          <div className="h-3 bg-secondary rounded-none overflow-hidden">
                            <div className="h-full rounded-none" style={{ width: `${pct}%`, background: COLORS[i] }} />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </Section>
              )}
            </>
          )}

          {/* ─── FULL or STORES ─── */}
          {(reportType === "full" || reportType === "stores") && (
            <>
              {/* Top Brands chart */}
              {byBrand.length > 0 && (
                <Section title={isAr ? "أكثر المتاجر إنفاقاً" : "Top Stores by Spending"} icon="🏪" color="purple">
                  <ResponsiveContainer width="100%" height={Math.min(byBrand.length * 28 + 20, 220)}>
                    <BarChart data={byBrand} layout="vertical" barSize={16}>
                      <XAxis type="number" tick={{ fontSize: 8 }} />
                      <YAxis type="category" dataKey="name" tick={{ fontSize: 8, fontFamily: "var(--font-body)" }} width={60} />
                      <Tooltip contentStyle={chartStyle} formatter={v => [`${v} ${currency}`, ""]} />
                      <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                        {byBrand.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Section>
              )}

              {/* Stores Table — stacked cards instead of overflow table */}
              <Section title={isAr ? "جدول المتاجر و المنتجات" : "Stores & Products Table"} icon="📋" color="blue">
                <div className="space-y-1.5">
                  {storesSummary.map((store, i) => (
                    <div key={store.id} className={`flex items-center gap-2 px-2 py-2 rounded-none ${i % 2 === 0 ? "bg-white/40 dark:bg-white/5" : ""}`}>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-body font-semibold truncate">{isAr ? (store.name_ar || store.name) : store.name}</p>
                        <p className="text-[9px] text-muted-foreground font-body">{store.productCount} {isAr ? "منتج" : "items"}</p>
                      </div>
                      <p className="text-xs font-bold text-primary flex-shrink-0">{store.totalSpent} {currency}</p>
                      <p className="text-[10px] flex-shrink-0" style={{ color: "var(--brand)" }}>{store.avgRating > 0 ? `${store.avgRating}■` : "—"}</p>
                    </div>
                  ))}
                </div>
              </Section>
            </>
          )}

          {/* ─── FULL or LOG ─── */}
          {(reportType === "full" || reportType === "log") && (
            <Section title={isAr ? "سجل التسوق" : "Shopping Log"} icon="📜" color="emerald">
              <div className="space-y-1.5">
                {recentProducts.map((p, i) => (
                  <div key={p.id} className={`flex items-center gap-2 px-2 py-2 rounded-none ${i % 2 === 0 ? "bg-white/40 dark:bg-white/5" : ""}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-body font-semibold truncate">{isAr ? (p.name_ar || p.name) : p.name}</p>
                      <p className="text-[9px] text-muted-foreground font-body truncate">{p.brand_name || "—"} · {p.purchase_date || "—"}</p>
                    </div>
                    <p className="text-xs font-bold text-primary flex-shrink-0">{p.cost || 0} {currency}</p>
                    <p className="text-[10px] flex-shrink-0" style={{ color: "var(--brand)" }}>{p.rating ? "■".repeat(Math.min(p.rating,5)) + "□".repeat(Math.max(0,5-Math.min(p.rating,5))) : "—"}</p>
                  </div>
                ))}
                <div className="flex justify-between pt-2 border-t border-border/40 px-2">
                  <p className="text-xs font-bold font-body">{isAr ? "الإجمالي" : "Total"}</p>
                  <p className="text-xs font-bold text-primary">{Math.round(total)} {currency}</p>
                </div>
              </div>
            </Section>
          )}

          {/* Footer — shown only during export (not in the on-screen view) */}
          {exporting && (
            <div className="border-t border-border/40 pt-4 text-center space-y-1">
              {mark && <p className="text-xl">{mark}</p>}
              <p className="text-[9px] text-muted-foreground font-body">
                {isAr ? "أُنشئ بواسطة" : "Created by"} <span className="font-bold">{getAppName().name_en}</span>
              </p>
              <p className="text-[9px] text-muted-foreground font-body">
                {new Date().toLocaleDateString(isAr ? "ar-SA" : "en-US")}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}