/**
 * FlaconRating — تقييم المستخدم على هيئة معيّنات (ألماسات) ذهبية عمودية.
 * مكوّن قابل لإعادة الاستخدام في أماكن مختلفة (الكاتلوج، صفحة التفاصيل، إلخ).
 *
 * - عمودي، يُملأ من الأسفل للأعلى (الخامسة في الأعلى).
 * - الممتلئة = ذهبي مصمت، الفارغة = إطار ذهبي مجوّف.
 * - يظهر فقط عند وجود تقييم (rating > 0).
 */
const GOLD = "var(--brand)";

/** مجموعة المعيّنات (للاستخدام داخل svg آخر مثل القنينة). */
export function RatingDiamonds({ rating = 0, cx = 6, top = 4, step = 11, r = 3.6 }) {
  const items = [];
  for (let i = 0; i < 5; i++) {
    // i=0 الأعلى ... i=4 الأسفل — التعبئة من الأسفل (معكوسة)
    const cy = top + i * step;
    const filled = i >= 5 - Math.max(0, Math.min(5, Math.round(rating)));
    items.push(
      <rect
        key={i}
        x={cx - r}
        y={cy - r}
        width={r * 2}
        height={r * 2}
        fill={filled ? GOLD : "none"}
        stroke={GOLD}
        strokeWidth={filled ? 0 : 1}
      />
    );
  }
  return <g>{items}</g>;
}

export default function FlaconRating({ rating = 0, className = "", style }) {
  if (!rating) return null;
  return (
    <svg
      viewBox="0 0 12 59"
      width="100%"
      height="100%"
      className={className}
      style={style}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <RatingDiamonds rating={rating} />
    </svg>
  );
}

/**
 * FlaconRatingInput — معيّنات (ألماسات) ذهبية أفقية قابلة للنقر لإدخال التقييم 0..5.
 * - تُملأ من اليسار لليمين (1..5) دائماً بصرف النظر عن اتجاه الصفحة (direction: ltr).
 * - النقر على القيمة الحالية يصفّر التقييم (toggle → 0) لإلغاء التقييم.
 * - نفس هوية المعيّن الذهبي في RatingDiamonds: الممتلئ مصمت، الفارغ إطار مجوّف.
 * - أزرار بمساحة لمس مريحة (padding) مناسبة للجوال داخل WebView.
 */
export function FlaconRatingInput({
  value = 0,
  onChange,
  diamondSize = 26,
  gap = 6,
  disabled = false,
  className = "",
}) {
  const v = Math.max(0, Math.min(5, Math.round(Number(value) || 0)));
  const handle = (n) => {
    if (disabled) return;
    onChange && onChange(v === n ? 0 : n);
  };
  return (
    <div
      className={className}
      style={{ display: "inline-flex", gap, direction: "ltr", alignItems: "center" }}
    >
      {[1, 2, 3, 4, 5].map((n) => {
        const filled = n <= v;
        return (
          <button
            key={n}
            type="button"
            onClick={() => handle(n)}
            disabled={disabled}
            aria-label={n + " / 5"}
            style={{
              background: "none",
              border: "none",
              padding: 5,
              margin: 0,
              lineHeight: 0,
              cursor: disabled ? "default" : "pointer",
              touchAction: "manipulation",
            }}
          >
            <svg width={diamondSize} height={diamondSize} viewBox="0 0 10 10" aria-hidden="true">
              <rect
                x="0.8"
                y="0.8"
                width="8.4"
                height="8.4"
                fill={filled ? GOLD : "none"}
                stroke={GOLD}
                strokeWidth={filled ? 0 : 1.1}
                strokeLinejoin="round"
              />
            </svg>
          </button>
        );
      })}
    </div>
  );
}
