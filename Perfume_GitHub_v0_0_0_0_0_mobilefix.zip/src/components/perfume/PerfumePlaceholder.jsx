import { useLang } from "@/lib/LanguageContext";

/**
 * PerfumePlaceholder — a default "no image" visual for perfumes.
 *
 * A clean minimal-line flacon (cap + short connected neck + wide body) drawn in
 * lime green, with a faint sky-blue fill and a very subtle pink inner border.
 * The brand name is NOT printed inside the flacon anymore — it now lives in the
 * card's text area, beside the perfume name. Background is fully transparent so
 * the icon blends with whatever surface it sits on.
 *
 * Props:
 *   perfume   – the perfume object (used only for the accessible label)
 *   className – optional extra classes for the wrapping svg
 */
export default function PerfumePlaceholder({ perfume = {}, className = "" }) {
  const { isAr } = useLang();

  const brand = (isAr
    ? (perfume.brand_name_ar || perfume.brand_name || "")
    : (perfume.brand_name || perfume.brand_name_ar || "")).trim();

  const lime = "#84cc16"; // body / cap outline (lime-500)
  const fill = "#e0f2fe"; // sky-blue body fill (sky-100)
  const pink = "#f9a8d4"; // faint inner border (pink-300)

  return (
    <svg
      width="100%"
      height="100%"
      viewBox="22 57 82 82"
      role="img"
      aria-label={brand ? `${brand} (no image)` : "Perfume (no image)"}
      className={className}
      preserveAspectRatio="xMidYMid meet"
    >
      <g stroke={lime} strokeWidth="2.2" strokeLinejoin="round" strokeLinecap="round">
        <rect x="49" y="62" width="28" height="11" rx="2" fill={fill} />
        <rect x="53" y="73" width="20" height="7" fill={fill} />
        <rect x="27" y="80" width="72" height="52" rx="6" fill={fill} />
      </g>
      <rect x="31" y="84" width="64" height="44" rx="4" fill="none" stroke={pink} strokeWidth="1" opacity="0.5" />
    </svg>
  );
}
