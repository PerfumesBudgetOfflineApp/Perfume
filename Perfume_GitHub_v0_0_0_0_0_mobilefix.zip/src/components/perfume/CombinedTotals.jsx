import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useCurrency } from "@/lib/useCurrency";

export default function CombinedTotals() {
  const { formatPrice } = useCurrency();

  const { data: p1 = [] } = useQuery({
    queryKey: ["user-perfumes", "person1"],
    queryFn: () => apphost.entities.UserPerfume.filter({ person: "person1" }),
  });
  const { data: p2 = [] } = useQuery({
    queryKey: ["user-perfumes", "person2"],
    queryFn: () => apphost.entities.UserPerfume.filter({ person: "person2" }),
  });

  const all = [...p1, ...p2];
  const totalMl = all.reduce((sum, u) => sum + (u.sample_ml || 0), 0);
  const totalCost = all.reduce((sum, u) => sum + (u.sample_cost || 0), 0);
  const costPerMl = totalMl > 0 ? (totalCost / totalMl).toFixed(2) : null;

  return (
    <div className="space-y-1.5">
      <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold px-1">الإجمالي Total</p>
      <div className="grid grid-cols-3 gap-2 border-2 border-primary/30 rounded-none p-2 bg-primary/5">
        <div className="bg-primary/10 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">ML</p>
          <p className="text-sm font-body font-bold text-primary">{totalMl}ml</p>
        </div>
        <div className="bg-primary/10 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">التكلفة Cost</p>
          <p className="text-sm font-body font-bold text-primary">{formatPrice(totalCost.toFixed(0))}</p>
        </div>
        <div className="bg-primary/10 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">التكلفة للمل Cost/ml</p>
          <p className="text-sm font-body font-bold text-primary">{costPerMl ? formatPrice(costPerMl) : "—"}</p>
        </div>
      </div>
    </div>
  );
}