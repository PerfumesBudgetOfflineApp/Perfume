import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { decadeFromYear } from "@/lib/decade";

/**
 * AccordFlaconCard — قنينة العطر «بلا صندوق» (التصميم المعتمد، v9 «Dior»).
 *
 * المظهر المعتمد:
 *   - علبة عريضة، إطار ذهبي رفيع، الغطاء + الرقبة «إطار ذهبي فقط» (بلا تعبئة ذهبية).
 *   - السائل يملأ النصف السفلي فقط: الأكورد المسيطر طبقة كبيرة حافتها العليا تحت المنتصف،
 *     وبقية الأكوردات طبقات رفيعة مكدّسة فوقه (تتجاوز المنتصف قليلاً) بأوزانها. النصف الأعلى أبيض.
 *   - حدّ رفيع بلون الجنس يحيط منطقة السائل بالكامل (داخل الإطار الذهبي).
 *   - النوع (يسار) والسنة (يمين) بخط Cinzel الفنّي بلون الجنس، حجم صغير جداً.
 *   - اسم الأكورد المسيطر: الإنجليزي يسار (Cinzel، أول حرف كبير) والعربي يمين (Aref Ruqaa)،
 *     بلون متكيّف من حقل `font` في قاعدة الأكوردات (أبيض على الداكن، داكن على الفاتح).
 *   - اسم العطر/البراند/التقييم/الشرائط: خارج هذا المكوّن (في PerfumeCard).
 */
const GOLD = "var(--brand)";

const TYPE_SHORT = {
  "Parfum - Extrait de Parfum": "Extrait",
  "Eau de Parfum - EDP": "EDP",
  "Eau de Toilette - EDT": "EDT",
  "Eau de Cologne - EDC": "EDC",
  "Eau Fraîche": "Fraîche",
  "Bakhoor Natural Oud - Nadd": "Nadd",
  "Bakhoor Synthetic Oud": "B.Oud",
  "Bakhoor Blue Oud": "B.Blue",
  "Oil Misk Wood": "Oil",
  "Rose Oil": "Rose",
  "Oils": "Oil",
  "Mukhallat": "Mukh",
  "Khumrah": "Khum",
  "Anbar Zafaran": "Anbar",
  "Ward Water": "Ward",
  "Musk Myrrh Benzoin": "Musk",
  "Temple Incense & Sacred Woods": "Incense",
  "Agarwood": "Agar",
  "Luban Frankincense Sandalwood": "Luban",
  "Body Mist": "Mist",
  "Body Lotion": "Lotion",
};

function genderColor(g) {
  if (g === "Men" || g === "Male") return "#22c55e";
  if (g === "Women" || g === "Female") return "#f472b6";
  return "#fcd34d"; // Unisex / unknown
}

function cap1(s) {
  s = String(s || "");
  return s ? s.charAt(0).toUpperCase() + s.slice(1) : s;
}

function parseAccords(raw) {
  const list = String(raw || "")
    .split(";")
    .map((e) => {
      const [id, w] = e.split(":");
      const ref = ACCORDS[id];
      if (!ref) return null;
      return {
        id,
        w: parseFloat(w) || 1,
        color: ref.bar || "#94a3b8",
        font: ref.font || "#ffffff",
        en: ref.en || "",
        ar: ref.ar || "",
      };
    })
    .filter(Boolean);
  list.sort((a, b) => b.w - a.w); // المسيطر = الأعلى وزناً
  return list;
}

export default function AccordFlaconCard({ perfume = {}, className = "", style, bestOfDecade = false }) {
  const list = parseAccords(perfume.accords);
  const has = list.length > 0;
  const dom = list[0] || { color: "#e5e7eb", font: "#475569", en: "", ar: "" };
  const rest = list.slice(1);
  const gcol = genderColor(perfume.gender);

  // هندسة التعبئة: النصف السفلي فقط (جسم القنينة y:80→132، المنتصف 106).
  const bottomY = 131;
  const domTop = rest.length ? 113 : 108;          // حافة المسيطر العليا تحت المنتصف
  const ndStackH = 8;                               // ارتفاع كدسة الثانوية فوق المسيطر
  const ndTop = rest.length ? domTop - ndStackH : domTop; // أعلى منطقة السائل
  const sumR = rest.reduce((a, x) => a + x.w, 0) || 1;

  let y = domTop;
  const ndBands = rest.map((a, i) => {
    const h = (ndStackH * a.w) / sumR;
    const yy = y - h;
    y = yy;
    return <rect key={i} x="28.5" y={yy} width="69" height={h + 0.4} fill={a.color} opacity="0.7" />;
  });

  const nameY = domTop + (bottomY - domTop) / 2 + 1.8;
  const typeShort = TYPE_SHORT[perfume.type] || (perfume.type ? perfume.type.slice(0, 7) : "");
  const year = perfume.release_year || "";
  const clipId = `fl-${perfume.id != null ? perfume.id : Math.random().toString(36).slice(2)}`;

  return (
    <svg
      viewBox="25 60 76 76"
      width="100%"
      height="100%"
      className={className}
      style={{ direction: "ltr", ...(style || {}) }}
      preserveAspectRatio="xMidYMid meet"
      aria-hidden="true"
    >
      <defs>
        <clipPath id={clipId}><rect x="28" y="81" width="70" height="50" rx="5" /></clipPath>
        <clipPath id={`b${clipId}`}><rect x="28" y="80.5" width="70" height="51" rx="5.5" /></clipPath>
      </defs>
      {/* جسم أبيض */}
      <rect x="27" y="80" width="72" height="52" rx="6" fill="#ffffff" />
      {/* السائل: المسيطر بالنصف السفلي + الثانوية فوقه */}
      <g clipPath={`url(#${clipId})`}>
        {ndBands}
        <rect x="28.5" y={domTop} width="69" height={bottomY - domTop} fill={dom.color} opacity="0.85" />
      </g>
      {/* حدّ رفيع بلون الجنس يحيط منطقة السائل — rx متوافق مع الإطار الذهبي الخارجي لإغلاق الفراغ */}
      {has ? (
        <rect x="28.5" y={ndTop} width="69" height={bottomY - ndTop} rx="4" fill="none" stroke={gcol} strokeWidth="1" opacity="0.75" />
      ) : null}
      {/* الغطاء + الرقبة: إطار ذهبي فقط (أبيض من الداخل) */}
      <rect x="53" y="73" width="20" height="7" fill="#ffffff" />
      <rect x="49" y="62" width="28" height="11" rx="2" fill="#ffffff" />
      <g fill="none" stroke={GOLD} strokeOpacity="0.8" strokeWidth="2" strokeLinejoin="round" strokeLinecap="round">
        <rect x="27" y="80" width="72" height="52" rx="6" />
        <rect x="53" y="73" width="20" height="7" />
        <rect x="49" y="62" width="28" height="11" rx="2" />
      </g>
      {/* شارة «أفضل العقد»: خمس معيّنات خضراء صغيرة جداً بوسط الغطاء — العقد يُشتق من سنة الإصدار، فلا تظهر لعطر بلا سنة (بيانات ناقصة) */}
      {((bestOfDecade || perfume.best_of_decade) && decadeFromYear(perfume.release_year) !== null) ? (
        <g fill="#3B6D11">
          <rect x="55.3" y="66.2" width="2.6" height="2.6" />
          <rect x="58.5" y="66.2" width="2.6" height="2.6" />
          <rect x="61.7" y="66.2" width="2.6" height="2.6" />
          <rect x="64.9" y="66.2" width="2.6" height="2.6" />
          <rect x="68.1" y="66.2" width="2.6" height="2.6" />
        </g>
      ) : null}
      {/* النوع / السنة / اسم الأكورد — مقصوصة داخل حدود القنينة فلا تتجاوزها */}
      <g clipPath={`url(#b${clipId})`}>
        {typeShort ? <text x="30" y="87.5" fontSize="3.7" letterSpacing="0.3" fill={gcol} fontFamily="'Cinzel', serif">{typeShort}</text> : null}
        {year ? <text x="96" y="87.5" fontSize="3.7" letterSpacing="0.4" fill={gcol} textAnchor="end" fontFamily="'Cinzel', serif">{year}</text> : null}
        {has && dom.en ? <text x="31" y={nameY} fontSize="4.6" letterSpacing="0.4" fill={dom.font} fontFamily="'Cinzel', serif">{cap1(dom.en)}</text> : null}
        {has && dom.ar ? <text x="95" y={nameY} fontSize="5" fill={dom.font} textAnchor="end" fontFamily="'Aref Ruqaa', serif">{dom.ar}</text> : null}
      </g>
    </svg>
  );
}
