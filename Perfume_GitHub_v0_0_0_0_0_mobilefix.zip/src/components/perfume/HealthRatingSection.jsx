/**
 * HealthRatingSection — Reusable component for headache & sinus sensitivity ratings.
 * Used in both PerfumeDetail and BrandDetail NOSE sections.
 *
 * Props:
 *   activeUserData — the current user's perfume/brand data object
 *   activePerson   — "person1" | "person2"
 *   onUpdate(field, value) — callback to save field
 */
export default function HealthRatingSection({ activeUserData, activePerson, onUpdate }) {
  const HEADACHE_OPTIONS = [
    { value: "none",   emoji: "", labelEn: "None",   labelAr: "لا" },
    { value: "weak",   emoji: "🟡", labelEn: "Weak",   labelAr: "ضعيف" },
    { value: "medium", emoji: "🟠", labelEn: "Medium", labelAr: "متوسط" },
    { value: "strong", emoji: "🔴", labelEn: "Strong", labelAr: "قوي" },
  ];

  const SINUS_OPTIONS = [
    { value: "yes",      emoji: "😤", labelEn: "Yes",      labelAr: "نعم" },
    { value: "a_little", emoji: "😕", labelEn: "A Little", labelAr: "قليلاً" },
    { value: "no",       emoji: "😊", labelEn: "No",       labelAr: "لا" },
  ];

  return (
    <div className="space-y-4 border-t border-border/30 pt-4">
      {/* Headache */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">
          صداع Headache
        </p>
        <div className="grid grid-cols-4 gap-2">
          {HEADACHE_OPTIONS.map(({ value, emoji, labelEn, labelAr }) => {
            const active = activeUserData?.headache === value;
            return (
              <button
                key={value}
                onClick={() => onUpdate("headache", active ? null : value)}
                className={`flex flex-col items-center gap-1 py-2.5 rounded-none border text-[10px] font-body font-medium transition-all ${
                  active
                    ? "bg-primary/10 border-primary shadow-sm text-primary"
                    : "bg-secondary/40 border-border/50 text-muted-foreground hover:text-foreground"
                }`}
              >
                <span className="text-lg">{emoji}</span>
                <span className="leading-tight text-center">{labelAr}</span>
                <span className="leading-tight text-center opacity-70">{labelEn}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Sinus */}
      <div className="space-y-2">
        <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">
          حساسية جيوب أنفية Sinus Sensitivity
        </p>
        <div className="grid grid-cols-3 gap-2">
          {SINUS_OPTIONS.map(({ value, emoji, labelEn, labelAr }) => {
            const active = activeUserData?.sinus_sensitivity === value;
            return (
              <button
                key={value}
                onClick={() => onUpdate("sinus_sensitivity", active ? null : value)}
                className={`flex flex-col items-center gap-1 py-2.5 rounded-none border text-[10px] font-body font-medium transition-all ${
                  active
                    ? "bg-primary/10 border-primary shadow-sm text-primary"
                    : "bg-secondary/40 border-border/50 text-muted-foreground hover:text-foreground"
                }`}
              >
                <span className="text-lg">{emoji}</span>
                <span className="leading-tight text-center">{labelAr}</span>
                <span className="leading-tight text-center opacity-70">{labelEn}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}