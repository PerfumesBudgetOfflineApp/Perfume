import { Wind, Flower2, TreePine } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

export default function EnhancedNotesDisplay({ perfume }) {
  const { isAr } = useLang();

  if (!perfume.top_notes && !perfume.heart_notes && !perfume.base_notes && !perfume.innovation_notes) {
    return null;
  }

  const notes = [
    {
      type: "top",
      label: isAr ? "مقدمة" : "Top Notes",
      icon: Wind,
      color: "sky",
      data: perfume.top_notes,
    },
    {
      type: "heart",
      label: isAr ? "قلب" : "Heart Notes",
      icon: Flower2,
      color: "rose",
      data: perfume.heart_notes,
    },
    {
      type: "base",
      label: isAr ? "أساس" : "Base Notes",
      icon: TreePine,
      color: "amber",
      data: perfume.base_notes,
    },
    {
      type: "innovation",
      label: isAr ? "مبتكرة" : "Innovation Notes",
      icon: Flower2,
      color: "emerald",
      data: perfume.innovation_notes,
    },
  ].filter((n) => n.data);

  return (
    <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
      <h2 className="font-heading font-semibold">
        {isAr ? "تركيب العطر" : "Fragrance Composition"}
      </h2>
      <div className="space-y-2">
        {notes.map((note) => {
          const Icon = note.icon;
          const notesArray = note.data
            .split(",")
            .map((n) => n.trim())
            .filter(Boolean);

          return (
            <div
              key={note.type}
              className={`flex items-start gap-3 bg-${note.color}-50 dark:bg-${note.color}-950/30 rounded-none px-4 py-3 border border-${note.color}-100 dark:border-${note.color}-900/50`}
            >
              <div className={`w-8 h-8 rounded-none bg-${note.color}-100 dark:bg-${note.color}-900/60 flex items-center justify-center flex-shrink-0 mt-0.5`}>
                <Icon className={`w-4 h-4 text-${note.color}-500`} />
              </div>
              <div className="flex-1">
                <p className={`text-[10px] font-body font-semibold text-${note.color}-500 uppercase tracking-widest mb-0.5`}>
                  {note.label}
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {notesArray.map((n) => (
                    <span
                      key={n}
                      className="text-sm font-body text-foreground/90 hover:text-primary hover:underline transition-colors cursor-pointer"
                    >
                      {n}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}