import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { accordColor } from "@/lib/accordColors";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { resolveUserMark } from "@/lib/exportSettings";
import { useLang } from "@/lib/LanguageContext";

const GOLD = "#C8A02E";

const PHASE = {
  top:        { ar: "مقدمة", en: "Top",        color: "#185FA5", bg: "#E6F1FB" },
  heart:      { ar: "قلب",      en: "Heart",      color: "#993556", bg: "#FBEAF0" },
  base:       { ar: "أساس",     en: "Base",       color: "#854F0B", bg: "#FAEEDA" },
  innovation: { ar: "مبتكرة",    en: "Innovation", color: "#1F7A52", bg: "#E3F4EC" },
};

// Value maps with emoji, mirroring the perfume page.
const IMPRESSION = { great: { e: "😍", ar: "رائع", en: "Great" }, neutral: { e: "😐", ar: "محايد", en: "Neutral" }, not_great: { e: "😕", ar: "ضعيف", en: "Not great" } };
const OTHER = { love_it: { e: "🥰", ar: "يحبّونه", en: "Love it" }, like_it: { e: "😍", ar: "يعجبهم", en: "Like it" }, neutral: { e: "😐", ar: "محايد", en: "Neutral" }, hate_it: { e: "😠", ar: "يكرهونه", en: "Hate it" } };
const RECOMMEND = { no: { e: "🚫", ar: "لا", en: "No" }, women: { e: "🌸", ar: "نساء", en: "Women" }, men: { e: "🔷", ar: "رجال", en: "Men" }, any: { e: "👥", ar: "للجميع", en: "Anyone" } };
const HEADACHE = { none: { ar: "لا", en: "None" }, weak: { ar: "ضعيف", en: "Weak" }, medium: { ar: "متوسط", en: "Medium" }, strong: { ar: "قوي", en: "Strong" } };
const SINUS = { yes: { ar: "نعم", en: "Yes" }, a_little: { ar: "قليلاً", en: "A little" }, no: { ar: "لا", en: "No" } };
const OCCASION = {
  daylight:     { e: "☀️", ar: "نهار",     en: "Day" },
  evening:      { e: "🌙", ar: "مساء",     en: "Evening" },
  wedding:      { e: "💍", ar: "زفاف",     en: "Wedding" },
  celebration:  { e: "🎉", ar: "احتفال",   en: "Celebration" },
  relax:        { e: "😌", ar: "استرخاء",  en: "Relax" },
  work:         { e: "💼", ar: "عمل",      en: "Work" },
  sport:        { e: "⚽", ar: "رياضة",    en: "Sport" },
  casual:       { e: "👕", ar: "عادي",     en: "Casual" },
  very_special: { e: "✨", ar: "خاص جداً", en: "Very Special" },
};

function Diamonds({ value = 0, size = 14 }) {
  const v = Math.max(0, Math.min(5, Math.round(value)));
  return <span style={{ color: GOLD, fontSize: size, letterSpacing: "1px" }}>{"■".repeat(v)}{"□".repeat(5 - v)}</span>;
}

const splitNotes = (csv) => (csv ? csv.split(",").map((s) => s.trim()).filter(Boolean) : []);
const parseOccasions = (ud) => {
  if (!ud) return [];
  if (ud.occasions) return ud.occasions.split(",").map((s) => s.trim()).filter(Boolean);
  const a = [];
  if (ud.occasion && ud.occasion !== "none") a.push(ud.occasion);
  if (ud.occasion2 && ud.occasion2 !== "none") a.push(ud.occasion2);
  return a;
};

export default function EnhancedExportDialog({
  perfume = {}, userDataP1 = null, userDataP2 = null,
  names = { person1: "Profile A", person2: "Profile B" }, allNoteRecords = [],
}) {
  const { isAr } = useLang();
  const [open, setOpen] = useState(false);
  const [exportUser, setExportUser] = useState("all");
  const [exportLang, setExportLang] = useState("mix");
  const [bgColor, setBgColor] = useState("#ffffff");
  const [userMark, setUserMark] = useState("🧴");

  useEffect(() => { resolveUserMark().then(setUserMark).catch(() => {}); }, []);

  // Language helpers. en → LTR + English only; ar → RTL + Arabic only;
  // mix → RTL + both.
  const cardDir = exportLang === "en" ? "ltr" : "rtl";
  const tx = (en, ar) => {
    if (exportLang === "en") return en || ar || "";
    if (exportLang === "ar") return ar || en || "";
    const a = ar || "", e = en || "";
    return a && e ? `${e} · ${a}` : (a || e);
  };

  // Robust note lookup (mirrors FragranceNotesGrid) so LINKED notes actually
  // resolve their image in the export — exact match, then cleaned exact, then
  // trailing-word match ("Italian Bergamot" → "Bergamot").
  const findNoteRec = (raw) => {
    if (!raw) return null;
    const lc = String(raw).toLowerCase().trim();
    if (!lc) return null;
    let rec = allNoteRecords.find((n) => (n.name || "").toLowerCase().trim() === lc || (n.name_ar || "").trim() === String(raw).trim());
    if (rec) return rec;
    if (lc.length > 28 || lc.split(/\s+/).length > 4) return null;
    const cleaned = lc.replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
    for (const n of allNoteRecords) {
      const full = (n.name || "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
      if (full && full === cleaned) return n;
    }
    for (const n of allNoteRecords) {
      const full = (n.name || "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
      if (!full || full.split(" ").length > 2) continue;
      if (cleaned === full || cleaned.endsWith(" " + full)) return n;
    }
    return null;
  };
  const noteImg = (name) => findNoteRec(name)?.image_url || null;

  // Note NAME label: English only in ar/en modes (per request); in mix add the
  // Arabic note name (from the record) WITHOUT a separating dot.
  const noteName = (name) => {
    if (exportLang === "mix") {
      const ar = findNoteRec(name)?.name_ar;
      return ar ? `${name} ${ar}` : name;
    }
    return name; // ar + en both show the (English) catalogue name
  };

  // Odor-family label split by script so the chosen language wins.
  const familyLabel = (f) => {
    const en = (String(f).match(/[A-Za-z][A-Za-z\s-]*/g) || []).join(" ").replace(/\s+/g, " ").trim();
    const ar = (String(f).match(/[\u0600-\u06FF][\u0600-\u06FF\s]*/g) || []).join(" ").replace(/\s+/g, " ").trim();
    if (exportLang === "en") return en || ar || f;
    if (exportLang === "ar") return ar || en || f;
    return [en, ar].filter(Boolean).join(" ") || f;
  };

  const personEntries = (() => {
    const p1 = { key: "person1", data: userDataP1, name: names?.person1 || "Profile A", color: "#185FA5", border: "#B5D4F4" };
    const p2 = { key: "person2", data: userDataP2, name: names?.person2 || "Profile B", color: "#993556", border: "#F4C0D1" };
    if (exportUser === "person1") return [p1];
    if (exportUser === "person2") return [p2];
    return [p1, p2].filter((e) => e.data);   // all: only persons with data
  })();
  const single = personEntries.length === 1;

  const families = splitNotes(perfume.odor_family);
  const related = splitNotes(perfume.related_perfume_names).slice(0, 5);
  const noteSections = [
    { phase: "top",        notes: splitNotes(perfume.top_notes) },
    { phase: "heart",      notes: splitNotes(perfume.heart_notes) },
    { phase: "base",       notes: splitNotes(perfume.base_notes) },
    { phase: "innovation", notes: splitNotes(perfume.innovation_notes) },
  ].filter((s) => s.notes.length);

  const handleExport = async () => {
    const element = document.getElementById("enhanced-export-card");
    if (!element) { toast.error(isAr ? "البطاقة غير موجودة" : "Card not found"); return; }
    try {
      const EXPORT_WIDTH = 720;
      const clone = element.cloneNode(true);
      const wrapper = document.createElement("div");
      wrapper.style.cssText = ["position: fixed", "top: 0", "left: 0", "z-index: -1", "opacity: 1", "pointer-events: none", "background: " + bgColor, "width: " + EXPORT_WIDTH + "px", "max-width: none", "max-height: none", "overflow: visible"].join("; ");
      clone.style.maxHeight = "none"; clone.style.overflow = "visible"; clone.style.width = EXPORT_WIDTH + "px";
      wrapper.appendChild(clone);
      document.body.appendChild(wrapper);
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const imgs = Array.from(clone.querySelectorAll("img"));
      await Promise.all(imgs.map((img) => (img.complete && img.naturalWidth > 0) ? Promise.resolve() : new Promise((res) => { img.onload = img.onerror = () => res(); setTimeout(res, 3000); })));
      await new Promise((r) => requestAnimationFrame(r));
      const w = clone.scrollWidth, h = clone.scrollHeight;
      const MAX = 1080;  // fixed longest-side cap (1080×1080 social size)
      // Advanced = supersample: render at higher internal resolution, then
      // downscale to the 1080 cap with high-quality smoothing → crisper colors
      // and edges at the same final size. Standard = direct render to the cap.
      const baseScale = MAX / Math.max(w, h);
      // Always supersample: render at high internal resolution then downscale to
      // the 1080 cap with high-quality smoothing for crisp colors and edges.
      const renderScale = Math.min(4, baseScale * 2.5);
      // useCORS:false + allowTaint:false so the canvas is NEVER tainted by
      // locally-uploaded perfume images / bundled note icons — otherwise
      // toBlob/toDataURL throws silently offline and nothing saves on the APK.
      const raw = await captureElement(clone, { backgroundColor: bgColor, scale: renderScale, useCORS: false, allowTaint: false, logging: false, width: w, height: h, windowWidth: w, windowHeight: h });
      document.body.removeChild(wrapper);

      // Downscale to <= 1080 longest side with high-quality smoothing.
      let out = raw;
      const longest = Math.max(raw.width, raw.height);
      if (longest > MAX) {
        const ratio = MAX / longest;
        out = document.createElement("canvas");
        out.width = Math.round(raw.width * ratio);
        out.height = Math.round(raw.height * ratio);
        const ctx = out.getContext("2d");
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(raw, 0, 0, out.width, out.height);
      }
      const nm = (perfume.name_en || perfume.name_ar || "perfume").toLowerCase().replace(/\s+/g, "").slice(0, 10);
      await saveCanvasAsImage(out, `${nm}-enhanced-${Date.now()}.png`);
      toast.success(isAr ? "تم التصدير" : "Exported");
      setOpen(false);
    } catch (e) { console.error(e); toast.error((isAr ? "فشل التصدير: " : "Export failed: ") + e.message); }
  };

  const Pill = ({ active, onClick, children }) => (
    <button onClick={onClick} className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${active ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>{children}</button>
  );

  // Note image: when present → just the image, transparent background, NO
  // border, sharp (square) corners. When absent → transparent empty box (keeps
  // grid alignment, no frame).
  const noteBox = (img) => (
    img
      ? <img src={img} alt="" style={{ width: "46px", height: "46px", objectFit: "contain", display: "block", margin: "0 auto", background: "transparent" }} />
      : <div style={{ width: "46px", height: "46px", margin: "0 auto", background: "transparent" }} />
  );

  const renderPerson = ({ key, data, name, color, border }) => {
    if (!data) return null;
    const occ = parseOccasions(data);
    const imp = data.impression && IMPRESSION[data.impression];
    const oth = data.other_rating && OTHER[data.other_rating];
    const rec = data.recommend_to && RECOMMEND[data.recommend_to];
    const phaseImp = [
      { v: data.note_top, ar: "مقدمة", en: "Top" },
      { v: data.note_heart, ar: "قلب", en: "Heart" },
      { v: data.note_base, ar: "أساس", en: "Base" },
    ].filter((p) => p.v);
    return (
      <div key={key} style={{ border: "1px solid rgba(0,0,0,0.08)", borderRadius: "10px", padding: "12px" }}>
        <p style={{ margin: "0 0 8px", fontSize: "14px", fontWeight: 600, color, borderBottom: `2px solid ${border}`, paddingBottom: "5px" }}>{name}</p>
        <div style={{ marginBottom: "8px" }}><Diamonds value={data.rating} size={15} /></div>
        {[
          { v: data.r_scent, en: "Scent", ar: "الرائحة" },
          { v: data.r_longevity, en: "Longevity", ar: "الثبات" },
          { v: data.r_sillage, en: "Sillage", ar: "الفوحان" },
          { v: data.r_bottle, en: "Bottle", ar: "الزجاجة" },
        ].filter((d) => d.v).map((d, i) => (
          <p key={i} style={{ margin: "0 0 2px", fontSize: "10px", color: "#6b7280", display: "flex", justifyContent: "space-between" }}>
            <span>{tx(d.en, d.ar)}</span> <Diamonds value={d.v} size={11} />
          </p>
        ))}
        <div style={{ borderTop: "1px solid rgba(0,0,0,0.08)", marginTop: "7px", paddingTop: "7px", display: "flex", flexDirection: "column", gap: "3px" }}>
          {imp && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Like", "الإعجاب")} {imp.e} {tx(imp.en, imp.ar)}</span>}
          {oth && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Others", "انطباع الآخرين")} {oth.e} {tx(oth.en, oth.ar)}</span>}
          {rec && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Recommend", "الترشيح")} {rec.e} {tx(rec.en, rec.ar)}</span>}
          {phaseImp.length > 0 && (
            <span style={{ fontSize: "10px", color: "#6b7280" }}>
              {tx("Phases", "المراحل")} {phaseImp.map((p, i) => <span key={i}>{tx(p.en, p.ar)} {p.v === "like" ? "👍" : "👎"}{i < phaseImp.length - 1 ? " " : ""}</span>)}
            </span>
          )}
          {occ.length > 0 && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Occasions", "المناسبات")} {occ.map((o, i) => { const c = OCCASION[o]; return <span key={i}>{c ? `${c.e} ${tx(c.en, c.ar)}` : o}{i < occ.length - 1 ? "، " : ""}</span>; })}</span>}
          {data.headache && HEADACHE[data.headache] && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Headache", "صداع")} {tx(HEADACHE[data.headache].en, HEADACHE[data.headache].ar)}</span>}
          {data.sinus_sensitivity && SINUS[data.sinus_sensitivity] && <span style={{ fontSize: "10px", color: "#6b7280" }}>{tx("Sinus", "جيوب")} {tx(SINUS[data.sinus_sensitivity].en, SINUS[data.sinus_sensitivity].ar)}</span>}
        </div>
        {!single && (data.review || data.personal_notes) && (
          <p style={{ margin: "8px 0 0", fontSize: "11px", lineHeight: 1.6, color: "#1f2937" }}>{data.review || data.personal_notes}</p>
        )}
      </div>
    );
  };

  const singleData = single ? personEntries[0]?.data : null;
  const singleReview = singleData && (singleData.review || singleData.personal_notes);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="flex-1 h-11 rounded-none font-body bg-transparent border border-[#C8A02E] text-[#7a6212] hover:bg-[#FBF6E6] shadow-none whitespace-normal leading-tight text-xs">
          {isAr ? "تصدير مطوّر" : "Advanced Export"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl w-[96vw] rounded-none p-3 sm:p-4 overflow-y-auto max-h-[92vh]">
        <DialogHeader>
          <DialogTitle className="font-heading text-base sm:text-lg">
            {isAr ? "تصدير مراجعة عطر مطوّر" : "Enhanced Perfume Review Export"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div className="flex gap-2">
            <Pill active={exportUser === "person1"} onClick={() => setExportUser("person1")}>{names.person1}</Pill>
            <Pill active={exportUser === "person2"} onClick={() => setExportUser("person2")}>{names.person2}</Pill>
            <Pill active={exportUser === "all"} onClick={() => setExportUser("all")}>{isAr ? "الكل" : "All"}</Pill>
          </div>
          <div className="flex gap-2 items-center">
            <span className="text-xs text-muted-foreground font-body shrink-0">{isAr ? "اللغة" : "Lang"}</span>
            <Pill active={exportLang === "ar"} onClick={() => setExportLang("ar")}>عربي</Pill>
            <Pill active={exportLang === "en"} onClick={() => setExportLang("en")}>English</Pill>
            <Pill active={exportLang === "mix"} onClick={() => setExportLang("mix")}>{isAr ? "مزيج" : "Mix"}</Pill>
          </div>
          <div className="flex gap-2 items-center">
            <span className="text-xs text-muted-foreground font-body shrink-0">{isAr ? "الخلفية" : "Bg"}</span>
            {["#ffffff", "#FAF7EF", "#F1EFE8", "#F0F9FF", "#F0FDF4", "#FEF3C7", "#FCE7F3", "#F3E8FF", "#ECFEFF", "#0F1115"].map((c) => (
              <button key={c} onClick={() => setBgColor(c)} className={`w-7 h-7 rounded-none border transition-all ${bgColor === c ? "ring-2 ring-primary border-primary" : "border-border"}`} style={{ background: c }} />
            ))}
          </div>

          {/* card */}
          <div className="border-2 border-primary/30 rounded-none overflow-x-auto">
            <div id="enhanced-export-card" dir={cardDir} style={{ background: bgColor, padding: "20px", fontFamily: "system-ui, sans-serif", minWidth: "320px" }}>

              {/* header */}
              <div style={{ display: "flex", gap: "16px", alignItems: "flex-start", borderBottom: "1px solid rgba(0,0,0,0.08)", paddingBottom: "14px", marginBottom: "14px" }}>
                <div style={{ width: "100px", height: "126px", flexShrink: 0 }}>
                  {perfume.image_url
                    ? <img src={perfume.image_url} alt="" style={{ width: "100%", height: "100%", objectFit: "contain", background: "transparent" }} />
                    : <div style={{ width: "100%", height: "100%", background: "#fff", border: `1.5px solid ${GOLD}`, borderRadius: "0" }} />}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <p style={{ margin: 0, fontSize: "20px", fontWeight: 600, color: "#1f2937" }}>{tx(perfume.name_en, perfume.name_ar)}</p>
                  {perfume.brand_name && <p style={{ margin: "4px 0 0", fontSize: "12px", color: GOLD, fontWeight: 500 }}>{perfume.brand_name}</p>}
                  <p style={{ margin: "6px 0 0", fontSize: "11px", color: "#6b7280" }}>{[perfume.concentration, perfume.gender, perfume.release_year || perfume.year].filter(Boolean).join(" · ")}</p>
                  {(perfume.about_en || perfume.about_ar) && <p style={{ margin: "8px 0 0", fontSize: "11px", lineHeight: 1.6, color: "#4b5563" }}>{tx(perfume.about_en, perfume.about_ar)}</p>}
                </div>
              </div>

              {/* notes + harmony */}
              <div style={{ display: "grid", gridTemplateColumns: "3fr 1fr", gap: "16px", marginBottom: "14px" }}>
                <div>
                  <p style={{ margin: "0 0 10px", fontSize: "10px", color: "#9ca3af", fontWeight: 700, textTransform: "uppercase" }}>{tx("Notes", "نوتات")}</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                    {noteSections.map(({ phase, notes }) => {
                      const ph = PHASE[phase];
                      return (
                        <div key={phase}>
                          <p style={{ margin: "0 0 7px", fontSize: "11px", color: ph.color, fontWeight: 600 }}>{tx(ph.en, ph.ar)}</p>
                          <div style={{ display: "flex", flexWrap: "wrap", gap: "12px" }}>
                            {notes.map((n, i) => (
                              <div key={i} style={{ textAlign: "center", width: "50px" }}>
                                {noteBox(noteImg(n))}
                                <p style={{ margin: "4px 0 0", fontSize: "9px", color: "#6b7280", lineHeight: 1.3 }} dir="ltr">{noteName(n)}</p>
                              </div>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                <div>
                  <p style={{ margin: "0 0 10px", fontSize: "10px", color: "#9ca3af", fontWeight: 700, textTransform: "uppercase" }}>{tx("Accord", "تناغم")}</p>
                  <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-around", gap: "4px", height: "120px" }}>
                    {families.slice(0, 5).map((f, i) => {
                      const c = accordColor(f), hh = 100 - i * 18;
                      return (
                        <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px", width: "54px" }}>
                          <span style={{ width: "10px", height: Math.max(28, hh) + "px", borderRadius: "0", background: c }} />
                          <span style={{ fontSize: "8px", color: c, maxWidth: "54px", textAlign: "center", lineHeight: 1.2, wordBreak: "break-word", whiteSpace: "normal" }}>{familyLabel(f)}</span>
                        </div>
                      );
                    })}
                  </div>
                  {/* Single-user review tucked under harmony to cut height */}
                  {single && singleReview && (
                    <p style={{ margin: "12px 0 0", fontSize: "10px", lineHeight: 1.6, color: "#1f2937" }}>{singleReview}</p>
                  )}
                </div>
              </div>

              {related.length > 0 && (
                <div style={{ marginBottom: "14px" }}>
                  <p style={{ margin: "0 0 6px", fontSize: "10px", color: "#9ca3af", fontWeight: 700, textTransform: "uppercase" }}>{tx("Remind me of", "يذكّرني في")}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "6px" }}>
                    {related.map((r, i) => <span key={i} style={{ fontSize: "11px", color: "#854F0B" }}>{r}{i < related.length - 1 ? " ·" : ""}</span>)}
                  </div>
                </div>
              )}

              <div style={{ display: "grid", gridTemplateColumns: single ? "1fr" : "1fr 1fr", gap: "12px" }}>
                {personEntries.map(renderPerson)}
              </div>

              {/* User mark footer */}
              <div style={{ marginTop: "14px", paddingTop: "10px", borderTop: "1px solid rgba(0,0,0,0.08)", textAlign: "center", fontSize: "12px", color: "#9ca3af" }}>
                {userMark}
              </div>

            </div>
          </div>

          <Button onClick={handleExport} className="w-full h-10 rounded-none font-body bg-gradient-to-r from-primary to-primary/70 text-primary-foreground">
            {isAr ? "تنزيل الصورة" : "Download Image"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
