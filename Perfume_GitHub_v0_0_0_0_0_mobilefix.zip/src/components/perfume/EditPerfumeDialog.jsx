import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Camera, Edit2, Trash2, X } from "lucide-react";
import { toast } from "sonner";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import NotesTagSearch from "@/components/maestro/NotesTagSearch";
import InnovationNotesSearch from "@/components/maestro/InnovationNotesSearch";
import OdorFamilySearch from "@/components/maestro/OdorFamilySearch";
import RelatedPerfumesField from "@/components/perfume/RelatedPerfumesField";
import PerfumerSearchTag from "@/components/maestro/PerfumerSearchTag";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";

// Type picker with search — same pattern as other search fields
function TypeSearch({ value, onChange, isAr }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const current = PERFUME_TYPES.find(t => t.value === value);
  const currentLabel = current ? (isAr ? current.label_ar : current.label_en) : null;

  const filtered = PERFUME_TYPES.filter(t => {
    if (!search) return true;
    const q = search.toLowerCase();
    return t.value.toLowerCase().includes(q)
        || (t.label_en || "").toLowerCase().includes(q)
        || (t.label_ar || "").includes(search);
  });

  return (
    <div className="space-y-1.5 relative">
      <label className="text-xs font-body font-medium text-muted-foreground uppercase">النوع Type</label>
      {currentLabel ? (
        <div className="flex items-center justify-between bg-primary/10 px-3 py-2 rounded-none">
          <span className="text-xs font-body">{currentLabel}</span>
          <button onClick={() => { onChange(""); setOpen(true); }} className="p-0.5 hover:bg-red-100 dark:hover:bg-red-900/30 rounded">
            <X className="w-3 h-3 text-red-500" />
          </button>
        </div>
      ) : (
        <button onClick={() => setOpen(o => !o)} className="w-full h-9 rounded-none border border-border bg-background text-left px-3 text-xs text-muted-foreground hover:bg-secondary transition-colors">
          + {isAr ? "اختر النوع" : "Select type"}
        </button>
      )}
      {open && !currentLabel && (
        <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-card border border-border rounded-none shadow-lg p-2 space-y-1.5">
          <Input autoFocus value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder={isAr ? "بحث عن النوع..." : "Search types..."} className="h-8 rounded-none text-xs" />
          <div className="max-h-[200px] overflow-y-auto space-y-1">
            {filtered.slice(0, 30).map(t => (
              <button key={t.value} onClick={() => { onChange(t.value); setOpen(false); setSearch(""); }}
                className="w-full text-left text-xs rounded-none transition-colors">
                <span className="font-medium">{t.label_en}</span>
                <span className="text-muted-foreground">&nbsp;&nbsp;{t.label_ar}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default function EditPerfumeDialog({ perfume, allPerfumes, allMainNotes }) {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [open, setOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  // Initialize data with all controlled fields as empty strings so React never
  // sees a controlled input flip from `undefined` (uncontrolled) to a value on
  // first effect run — that was the source of the "controlled input becoming
  // uncontrolled" warning.
  const EMPTY_PERFUME = {
    name_en: "", name_ar: "", about_en: "", about_ar: "",
    category: "", odor_family: "", type: "",
    ml: "", price: "", release_year: "",
    top_notes: "", heart_notes: "", base_notes: "", innovation_notes: "",
    brand_name: "",
    perfumer_ids: "", perfumer_names: "",
    related_perfume_ids: "", related_perfume_names: "",
    image_url: "",
  };
  const [data, setData] = useState(EMPTY_PERFUME);

  // Initialize data when dialog opens
  useEffect(() => {
    if (open && perfume) {
      setData({
        name_en: perfume.name_en || "",
        name_ar: perfume.name_ar || "",
        about_en: perfume.about_en || perfume.about || "",
        about_ar: perfume.about_ar || "",
        category: perfume.category || "",
        odor_family: perfume.odor_family || "",
        ml: perfume.ml ?? "",
        price: perfume.price ?? "",
        release_year: perfume.release_year ?? "",
        top_notes: perfume.top_notes || "",
        heart_notes: perfume.heart_notes || "",
        base_notes: perfume.base_notes || "",
        innovation_notes: perfume.innovation_notes || "",
        type: perfume.type || "",
        brand_name: perfume.brand_name || "",
        perfumer_ids: perfume.perfumer_ids || "",
        perfumer_names: perfume.perfumer_names || "",
        related_perfume_ids: perfume.related_perfume_ids || "",
        related_perfume_names: perfume.related_perfume_names || "",
        image_url: perfume.image_url || "",
      });
    }
  }, [open, perfume]);

  const categoryOptions = [...new Set(allMainNotes.map(n => n.category).filter(Boolean))].sort();
  const odorFamilyOptions = [...new Set(allMainNotes.map(n => n.odor_family).filter(Boolean))].sort();

  const handleSave = async () => {
    try {
      // Only send fields that have actually changed or have values
      const updateData = {};
      const fieldsToUpdate = ['name_en', 'name_ar', 'about_en', 'about_ar', 'category', 'odor_family', 'type', 'ml', 'price', 'release_year', 'top_notes', 'heart_notes', 'base_notes', 'innovation_notes', 'related_perfume_ids', 'related_perfume_names', 'brand_name', 'perfumer_ids', 'perfumer_names'];
      
      fieldsToUpdate.forEach(field => {
        if (data[field] !== undefined) {
          updateData[field] = data[field];
        }
      });

      if (data.image_url) updateData.image_url = data.image_url;

      await apphost.entities.Perfume.update(perfume.id, updateData);
      queryClient.invalidateQueries({ queryKey: ["perfume", perfume.id] });
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
      queryClient.invalidateQueries({ queryKey: ["all-perfumes-for-related"] });
      toast.success(isAr ? "تم حفظ العطر" : "Perfume saved");
      setOpen(false);
    } catch (error) {
      toast.error(isAr ? "فشل الحفظ" : "Save failed: " + error.message);
    }
  };

  const handleDelete = async () => {
    setIsDeleting(true);
    try {
      await apphost.entities.Perfume.delete(perfume.id);
      toast.success(isAr ? "تم حذف العطر" : "Perfume deleted");
      navigate("/perfumes");
    } catch (error) {
      toast.error(isAr ? "فشل الحذف" : "Delete failed: " + error.message);
    } finally {
      setIsDeleting(false);
      setDeleteConfirm(false);
    }
  };

  const handleCastAway = async () => {
    try {
      await apphost.entities.Perfume.update(perfume.id, { hidden: true });
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
      toast.success(isAr ? "نُقل إلى المهملات" : "Moved to Cast Away");
      setOpen(false);
      navigate("/perfumes");
    } catch (error) {
      toast.error(isAr ? "تعذّر النقل" : "Failed");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
         <Button className="w-full h-9 rounded-none font-body gap-1.5 text-[11px]" style={{ background: "#FBE4EC", color: "#9D2C5B" }}>
           <Edit2 className="w-4 h-4" /> {isAr ? "تعديل العطر" : "Edit Perfume"}
         </Button>
       </DialogTrigger>
       {/* Delete Confirmation Dialog */}
       <AlertDialog open={deleteConfirm} onOpenChange={setDeleteConfirm}>
         <AlertDialogContent className="rounded-none max-w-sm">
           <AlertDialogHeader>
             <AlertDialogTitle className="font-heading text-red-600">{isAr ? "تأكيد الحذف" : "Delete Perfume"}</AlertDialogTitle>
             <AlertDialogDescription className="font-body text-foreground/75">
               {isAr ? `هل أنت متأكد من حذف "${perfume.name_en || perfume.name_ar}"؟ هذا الإجراء لا يمكن التراجع عنه.` : `Are you sure you want to delete "${perfume.name_en || perfume.name_ar}"? This action cannot be undone.`}
             </AlertDialogDescription>
           </AlertDialogHeader>
           <AlertDialogFooter>
             <AlertDialogCancel className="font-body rounded-none">{isAr ? "إلغاء" : "Cancel"}</AlertDialogCancel>
             <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700 rounded-none font-body">
               {isDeleting ? (isAr ? "جاري الحذف..." : "Deleting...") : (isAr ? "حذف" : "Delete")}
             </AlertDialogAction>
           </AlertDialogFooter>
         </AlertDialogContent>
       </AlertDialog>
       <DialogContent className="w-[95vw] max-w-lg rounded-none h-[92vh] flex flex-col p-0 overflow-hidden">
         <DialogHeader className="px-5 pt-5 pb-3 border-b border-border/40 flex-shrink-0">
           <DialogTitle className="font-heading">{isAr ? "تعديل العطر" : "Edit Perfume"}</DialogTitle>
         </DialogHeader>
        <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
          {/* Image Upload */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">صورة العطر</label>
            {data.image_url || perfume.image_url ? (
              <div className="relative w-full h-32 rounded-none border border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
                <img src={data.image_url || perfume.image_url} alt="Perfume" className="w-full h-full object-cover" />
                <button onClick={() => setData({...data, image_url: ""})}
                  className="absolute top-2 right-2 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600 text-white text-xs font-bold">✕</button>
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 w-full h-32 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                <Camera className="w-5 h-5 text-muted-foreground" />
                <span className="text-sm font-body text-muted-foreground">اضغط لرفع صورة</span>
                <input type="file" accept="image/*,.pdf" onChange={async (e) => {
                  const file = e.target.files?.[0]; if (!file) return;
                  const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
                  if (!allowedTypes.includes(file.type)) { toast.error('صيغة غير مدعومة'); return; }
                  const maxSize = 5 * 1024 * 1024;
                  if (file.size > maxSize) { toast.error('حجم الملف كبير جداً'); return; }
                  try { const { file_url } = await apphost.integrations.Core.UploadFile({ file }); setData({...data, image_url: file_url}); toast.success('تم الرفع'); }
                  catch (error) { toast.error("فشل الرفع:" + error.message); }
                }} className="hidden" />
              </label>
            )}
          </div>

          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">الاسم (English)</label>
            <Input value={data.name_en} onChange={(e) => setData({...data, name_en: e.target.value})} placeholder="اسم العطر Perfume name" className="rounded-none font-body" />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">الاسم بالعربي</label>
            <Input value={data.name_ar} onChange={(e) => setData({...data, name_ar: e.target.value})} placeholder="اسم العطر" dir="rtl" className="rounded-none font-body" />
          </div>

          {/* About — merged bilingual field */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">عن العطر About</label>
            <div className="space-y-2">
              <Textarea value={data.about_en} onChange={(e) => setData({...data, about_en: e.target.value})} placeholder="عن العطر (إنجليزي)... About (English)..." className="min-h-[60px] font-body text-sm border rounded-none resize-none focus-visible:ring-1" />
              <Textarea value={data.about_ar} onChange={(e) => setData({...data, about_ar: e.target.value})} placeholder="عن العطر (العربي)..." className="min-h-[60px] font-body text-sm border rounded-none resize-none focus-visible:ring-1" dir="rtl" />
            </div>
          </div>

          {/* Category */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">الفئة</label>
            <select value={data.category} onChange={(e) => setData({...data, category: e.target.value})} className="w-full h-9 rounded-none border border-input bg-transparent px-3 text-sm font-body focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring">
              <option value="">— اختر فئة —</option>
              {categoryOptions.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>

          {/* Type — search */}
          <TypeSearch value={data.type} onChange={(v) => setData({...data, type: v})} isAr={isAr} />

          {/* Numbers */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">الحجم (ML)</label>
            <Input type="number" value={data.ml} onChange={(e) => setData({...data, ml: parseFloat(e.target.value) || 0})} placeholder="100" className="rounded-none font-body" />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">السعر</label>
            <Input type="number" step="0.01" value={data.price} onChange={(e) => setData({...data, price: parseFloat(e.target.value) || 0})} placeholder="99.99" className="rounded-none font-body" />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">سنة الإصدار</label>
            <Input type="number" value={data.release_year} onChange={(e) => setData({...data, release_year: parseInt(e.target.value) || 0})} placeholder="2020" className="rounded-none font-body" />
          </div>

          {/* Brand Edit */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">البراند</label>
            <Input value={data.brand_name} onChange={(e) => setData({...data, brand_name: e.target.value})} placeholder="اسم البراند Brand name" className="rounded-none font-body" />
          </div>

          {/* Notes */}
           <div className="space-y-1.5">
             <label className="text-xs font-body font-medium text-muted-foreground uppercase">{isAr ? "نوتات المقدمة" : "Top Notes"}</label>
             <NotesTagSearch id="top-notes" value={data.top_notes} onChange={(v) => {
               const unique = [...new Set(v.split(",").map(s => s.trim()).filter(Boolean))].join(", ");
               setData({...data, top_notes: unique});
             }} placeholder="ابحث عن نوتة Search note" noteCategory="main_note" />
           </div>

           <div className="space-y-1.5">
             <label className="text-xs font-body font-medium text-muted-foreground uppercase">{isAr ? "نوتات القلب" : "Heart Notes"}</label>
             <NotesTagSearch id="heart-notes" value={data.heart_notes} onChange={(v) => {
               const unique = [...new Set(v.split(",").map(s => s.trim()).filter(Boolean))].join(", ");
               setData({...data, heart_notes: unique});
             }} placeholder="ابحث عن نوتة Search note" noteCategory="main_note" />
           </div>

           <div className="space-y-1.5">
             <label className="text-xs font-body font-medium text-muted-foreground uppercase">{isAr ? "نوتات القاعدة" : "Base Notes"}</label>
             <NotesTagSearch id="base-notes" value={data.base_notes} onChange={(v) => {
               const unique = [...new Set(v.split(",").map(s => s.trim()).filter(Boolean))].join(", ");
               setData({...data, base_notes: unique});
             }} placeholder="ابحث عن نوتة Search note" noteCategory="main_note" />
           </div>

          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">✨ Innovation Notes</label>
            <InnovationNotesSearch value={data.innovation_notes} onChange={(v) => {
              const unique = [...new Set(v.split(",").map(s => s.trim()).filter(Boolean))].join(", ");
              setData({...data, innovation_notes: unique});
            }} />
          </div>

          {/* Odor Family — Searchable */}
          <div className="space-y-1.5 relative">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">العائلة العطرية</label>
            <OdorFamilySearch value={data.odor_family} onChange={(v) => setData({...data, odor_family: v})} placeholder="ابحث عن العائلة العطرية..." />
          </div>

          {/* Perfumer */}
          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">العطار Perfumer</label>
            <PerfumerSearchTag
              value={data.perfumer_ids || ""}
              namesValue={data.perfumer_names || ""}
              onChange={(ids, names) => { 
                const uniqueIds = [...new Set(ids.split(",").map(s => s.trim()).filter(Boolean))].join(",");
                const uniqueNames = [...new Set(names.split(",").map(s => s.trim()).filter(Boolean))].join(",");
                setData({...data, perfumer_ids: uniqueIds, perfumer_names: uniqueNames});
              }}
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-body font-medium text-muted-foreground uppercase">🔗 Related Perfumes</label>
            <RelatedPerfumesField
              relatedIds={data.related_perfume_ids}
              relatedNames={data.related_perfume_names}
              allPerfumes={allPerfumes}
              perfumeId={perfume.id}
              onChange={(ids, names) => {
                setData({...data, related_perfume_ids: ids, related_perfume_names: names});
              }}
            />
          </div>
        </div>

        {/* Footer buttons */}
         <div className="space-y-2 px-5 py-4 border-t border-border/40 flex-shrink-0">
           <div className="flex gap-2">
             <Button className="flex-1 h-10 rounded-none font-body" onClick={handleSave}>{isAr ? "حفظ" : "Save"}</Button>
             <Button variant="ghost" className="flex-1 h-10 rounded-none font-body" onClick={() => setOpen(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
           </div>
           <Button variant="ghost" className="w-full h-10 rounded-none font-body" style={{ color: "#d97706" }} onClick={handleCastAway}>
             {isAr ? "نقل إلى المهملات" : "Cast away"}
           </Button>
           <Button variant="ghost" className="w-full h-10 rounded-none font-body text-destructive hover:text-destructive gap-2" onClick={() => setDeleteConfirm(true)}>
             <Trash2 className="w-4 h-4" /> {isAr ? "حذف العطر" : "Delete Perfume"}
           </Button>
         </div>
      </DialogContent>
    </Dialog>
  );
}