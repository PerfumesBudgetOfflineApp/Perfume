import { useState, useMemo, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { accordColor } from "@/lib/accordColors";
import { toast } from "sonner";
import { captureElement } from "@/lib/captureCanvas";
import { saveCanvasAsImage } from "@/lib/exportHelper";
import { ExportHeader, ExportFooter } from "@/lib/exportHeader";
import BilingualText from "@/components/export/BilingualText";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";

export default function ExportReviewDialog({ perfume = {}, wearLogs = [], activeUserData = null, activePerson = "person1", userDataP1 = null, userDataP2 = null, purchaseRecords = [], allNoteRecords = [], allPerfumers = [] }) {
  const { names } = usePersonNames();
  const { isAr } = useLang();
  const [exportOpen, setExportOpen] = useState(false);
  const [selectedBgColor, setSelectedBgColor] = useState("#ffffff");
  const [userMark, setUserMark] = useState("🧴");
  const [userPhotoName, setUserPhotoName] = useState("");
  const [userPhotoUrl, setUserPhotoUrl] = useState("");
  const [exportOptions, setExportOptions] = useState({
    perfumeName: true,
    perfumeInfo: true,
    odorFamily: true,
    occasions: true,
    rating: true,
    userRating: true,
    userImpression: true,
    detailedRating: true,
    recommendOthers: true,
    notePhases: true,
    comment: true,
    notes: true,
    notes_images: true,
    health: true,
    wearCount: true,
    purchases: true,
    relatedPerfumes: true,
  });

  // Which person's data to include in the export: "all" | "person1" | "person2".
  // Defaults to the person currently active on the perfume page.
  const [exportUser, setExportUser] = useState(activePerson || "person1");

  // Export language: "ar" | "en" | "mix". Controls every BilingualText on the
  // card via the BT wrapper below, so the exported image honors one language
  // (no duplication / no Arabic-Latin collision) or both when "mix".
  const [exportLang, setExportLang] = useState("mix");
  const BT = (props) => <BilingualText {...props} lang={exportLang} />;

  // Resolve the list of (personKey, data, name) entries to render based on the
  // selected export user. "all" => both persons that actually have data.
  const personEntries = (() => {
    const p1 = { key: "person1", data: userDataP1, name: names?.person1 || "Profile A" };
    const p2 = { key: "person2", data: userDataP2, name: names?.person2 || "Profile B" };
    if (exportUser === "person1") return [p1];
    if (exportUser === "person2") return [p2];
    // all: only those with any data
    return [p1, p2].filter((e) => e.data);
  })();

  // Purchases for a given person (purchaseRecords carry a `person` field).
  const purchasesFor = (personKey) =>
    (purchaseRecords || []).filter((r) => !r.person || r.person === personKey);

  useEffect(() => {
    apphost.auth.me().then((u) => {
      if (u?.mark) setUserMark(u.mark);
      setUserPhotoName(u?.display_name || u?.full_name || (u?.email ? u.email.split("@")[0] : ""));
      setUserPhotoUrl(u?.profile_photo || "");
    }).catch(() => {});
  }, []);

  const colors = [
    { bg: "#ffffff", name: "White" },
    { bg: "#fffdf7", name: "Cream" },
    { bg: "#f0f9ff", name: "Blue" },
    { bg: "#f0fdf4", name: "Green" },
    { bg: "#fef3c7", name: "Yellow" },
    { bg: "#fce7f3", name: "Pink" },
    { bg: "#f3e8ff", name: "Purple" },
    { bg: "#fef2f2", name: "Rose" },
    { bg: "#ecfeff", name: "Cyan" },
    { bg: "#f5f5f4", name: "Stone" },
  ];

  // Robust note lookup (mirrors the enhanced export + perfume page) so notes
  // whose CSV value is bilingual ("Pine needles أشواك الصنوبر") still resolve
  // their record/image: exact → cleaned-exact → trailing-word match.
  const findNoteRec = useMemo(() => {
    return (raw) => {
      if (!raw) return null;
      const lc = String(raw).toLowerCase().trim();
      if (!lc) return null;
      let rec = allNoteRecords.find((n) => (n.name || "").toLowerCase().trim() === lc || (n.name_ar || "").trim() === String(raw).trim());
      if (rec) return rec;
      const cleaned = lc.replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
      if (cleaned) {
        for (const n of allNoteRecords) {
          const full = (n.name || "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
          if (full && full === cleaned) return n;
        }
        for (const n of allNoteRecords) {
          const full = (n.name || "").toLowerCase().replace(/[^a-z0-9 ]/g, "").replace(/\s+/g, " ").trim();
          if (!full || full.split(" ").length > 2) continue;
          if (cleaned === full || cleaned.endsWith(" " + full)) return n;
        }
      }
      return null;
    };
  }, [allNoteRecords]);

  const NOTES_CAP = 5;
  const getFragranceNotesByLayer = () => {
    const layers = { Top: [], Heart: [], Base: [], Innovation: [] };
    const overflow = [];
    [["Top", "top_notes"], ["Heart", "heart_notes"], ["Base", "base_notes"]].forEach(([L, f]) => {
      if (perfume[f]) {
        const arr = perfume[f].split(",").map(n => n.trim()).filter(Boolean);
        layers[L] = arr.slice(0, NOTES_CAP);
        if (arr.length > NOTES_CAP) overflow.push(...arr.slice(NOTES_CAP));
      }
    });
    if (perfume.innovation_notes) {
      layers.Innovation = perfume.innovation_notes.split(",").map(n => n.trim()).filter(Boolean);
    }
    return { layers, overflow };
  };

  const handleExport = async () => {
    const element = document.getElementById("review-export-card");
    if (!element) {
      toast.error((isAr ? "بطاقة التصدير غير موجودة" : "Export card not found"));
      return;
    }
    try {
      const perfumeName = (perfume.name_en || perfume.name_ar || "perfume").toLowerCase().replace(/\s+/g, "").slice(0, 8);

      // Use a FIXED export width (independent of the on-screen dialog width).
      // This avoids two issues:
      //   1. Dialog's max-width on small viewports squashes the layout, so on-screen
      //      offsetWidth understates the natural width and content gets clipped.
      //   2. Inconsistent export size across devices.
      const EXPORT_WIDTH = 800;

      // Clone into an off-screen wrapper so html2canvas captures the natural layout
      // (no parent overflow, no scroll, no RTL mirroring from dialog ancestors).
      const clone = element.cloneNode(true);
      const wrapper = document.createElement("div");
      wrapper.style.cssText = [
        "position: fixed",
        "top: 0",
        "left: 0",
        "z-index: -1",
        "opacity: 1",
        "pointer-events: none",
        "background: " + selectedBgColor,
        "width: " + EXPORT_WIDTH + "px",
        "max-width: none",
        "max-height: none",
        "overflow: visible",
      ].join("; ");

      // Force every inherited constraint off on the clone so the content
      // expands to its natural size.
      clone.style.maxHeight = "none";
      clone.style.overflow  = "visible";
      clone.style.width     = EXPORT_WIDTH + "px";

      wrapper.appendChild(clone);
      document.body.appendChild(wrapper);

      // Wait for layout AND images to settle. Two rAF flushes the layout, then
      // we wait for any <img> inside the clone to finish loading so html2canvas
      // doesn't capture a half-rendered tree (a frequent cause of "missing data").
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));
      const imgs = Array.from(clone.querySelectorAll("img"));
      await Promise.all(imgs.map((img) => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        return new Promise((res) => {
          img.onload = img.onerror = () => res();
          // Hard timeout: don't hang export forever on a slow image.
          setTimeout(res, 3000);
        });
      }));
      // One more rAF after images load
      await new Promise((r) => requestAnimationFrame(r));

      const fullHeight = clone.scrollHeight;
      const fullWidth  = clone.scrollWidth;

      const canvas = await captureElement(clone, {
        backgroundColor: selectedBgColor,
        scale: 3,
        useCORS: false,
        allowTaint: false,
        logging: false,
        width: fullWidth,
        height: fullHeight,
        windowWidth: fullWidth,
        windowHeight: fullHeight,
      });

      document.body.removeChild(wrapper);

      // Cap the longest side at 1080px with high-quality smoothing (supersampled
      // above, downscaled here → very crisp at the 1080 social cap).
      let outCanvas = canvas;
      const longest = Math.max(canvas.width, canvas.height);
      if (longest > 1080) {
        const ratio = 1080 / longest;
        outCanvas = document.createElement("canvas");
        outCanvas.width = Math.round(canvas.width * ratio);
        outCanvas.height = Math.round(canvas.height * ratio);
        const ctx = outCanvas.getContext("2d");
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(canvas, 0, 0, outCanvas.width, outCanvas.height);
      }

      const filename = `${perfumeName}-review-${new Date().getTime()}.png`;
      await saveCanvasAsImage(outCanvas, filename);

      toast.success("تم التصدير بنجاح");
      setExportOpen(false);
    } catch (error) {
      console.error("Export failed", error);
      toast.error("فشل التصدير:" + error.message);
    }
  };

  const toggleOption = (key) => {
    setExportOptions(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const selectedPerson = activePerson === "person1" ? names.person1 : names.person2;

  return (
    <Dialog open={exportOpen} onOpenChange={setExportOpen}>
      <DialogTrigger asChild>
        <Button className="flex-1 h-11 rounded-none font-body bg-transparent border border-[#C8A02E] text-[#7a6212] hover:bg-[#FBF6E6] shadow-none whitespace-normal leading-tight text-xs">
          {isAr ? "تصدير مراجعة" : "Export Review"}
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl w-[98vw] rounded-none p-4 overflow-y-auto max-h-[95vh]">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl">
            {isAr ? "تصدير مراجعتك" : "Export Your Review"}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Universal export branding toggles (User Mark / App Name / Date) */}
          <ExportOptionsBar userMarkAvailable={!!userMark} />

          {/* Which user's review to include */}
          <div className="space-y-2">
            <p className="text-xs font-body font-bold text-muted-foreground uppercase">{isAr ? "تصدير مراجعة" : "Whose review"}</p>
            <div className="flex gap-2">
              {[
                { val: "all", en: "All", ar: "الكل" },
                { val: "person1", en: names?.person1 || "Profile A", ar: names?.person1 || "ملف أ" },
                { val: "person2", en: names?.person2 || "Profile B", ar: names?.person2 || "ملف ب" },
              ].map(({ val, en, ar }) => (
                <button
                  key={val}
                  onClick={() => setExportUser(val)}
                  className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${
                    exportUser === val
                      ? "bg-primary text-primary-foreground shadow"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {isAr ? ar : en}
                </button>
              ))}
            </div>
          </div>

          {/* Export language: عربي / English / مزيج */}
          <div className="space-y-2">
            <p className="text-xs font-body font-bold text-muted-foreground uppercase">{isAr ? "لغة التصدير" : "Export language"}</p>
            <div className="flex gap-2">
              {[
                { val: "ar", label: "عربي" },
                { val: "en", label: "English" },
                { val: "mix", label: isAr ? "مزيج" : "Mix" },
              ].map(({ val, label }) => (
                <button
                  key={val}
                  onClick={() => setExportLang(val)}
                  className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${
                    exportLang === val
                      ? "bg-primary text-primary-foreground shadow"
                      : "bg-secondary text-muted-foreground"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Export Options */}
          <div className="space-y-2">
            <p className="text-xs font-body font-bold text-muted-foreground uppercase">{isAr ? "ما تريد تضمينه" : "What to include"}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { key: "perfumeName", label: isAr ? "📝 اسم العطر" : "📝 Name" },
                { key: "perfumeInfo", label: isAr ? "ℹ️ معلومات العطر" : "ℹ️ Info" },
                { key: "odorFamily", label: isAr ? "🎨 العائلة العطرية" : "🎨 Family" },
                { key: "occasions", label: isAr ? "📍 المناسبات" : "📍 Occasions" },
                { key: "rating", label: isAr ? "■ التقييم المشترك" : "■ Shared rating" },
                { key: "userRating", label: isAr ? "🎯 التقييم الشخصي" : "🎯 Personal rating" },
                { key: "userImpression", label: isAr ? "😊 الانطباع و التفاعل" : "😊 Impression" },
                { key: "detailedRating", label: isAr ? "🎯 تقييم تفصيلي" : "🎯 Detailed Rating" },
                { key: "recommendOthers", label: isAr ? "👥 ترشيح للآخرين" : "👥 Recommend" },
                { key: "notePhases", label: isAr ? "🌸 انطباع المراحل" : "🌸 Note Phases" },
                { key: "comment", label: isAr ? "💬 التعليق" : "💬 Comment" },
                { key: "notes", label: isAr ? "💭 ملاحظتك" : "💭 Your Thought" },
                { key: "notes_images", label: isAr ? "📝 نوتات بمراحلها" : "📝 Three-phase Notes" },
                { key: "health", label: isAr ? "💊 الصحة" : "💊 Health" },
                { key: "wearCount", label: isAr ? "👃 عدد مرات الارتداء" : "👃 Wear count" },
                { key: "purchases", label: isAr ? "🛒 سجل الشراء" : "🛒 Purchases" },
                { key: "relatedPerfumes", label: isAr ? "🔗 تذكرني عطور مقاربة" : "🔗 Remind me of" },
              ].map(({ key, label }) => (
                <button
                  key={key}
                  onClick={() => toggleOption(key)}
                  className={`flex items-center gap-2 p-2 rounded-none border text-xs font-body transition-all ${
                    exportOptions[key]
                      ? "bg-primary/10 border-primary text-primary"
                      : "bg-secondary/40 border-border text-muted-foreground"
                  }`}
                >
                  <div className={`w-4 h-4 rounded border flex items-center justify-center ${
                    exportOptions[key] ? "bg-primary border-primary" : "border-border"
                  }`}>
                    {exportOptions[key] && <div className="w-2 h-2 bg-white rounded-none" />}
                  </div>
                  {label}
                </button>
              ))}
            </div>
          </div>

          {/* Background Color Selection */}
          <div className="space-y-2">
            <p className="text-xs font-body font-bold text-muted-foreground uppercase">لون الخلفية</p>
            <div className="flex gap-2 flex-wrap">
              {colors.map((c) => (
                <button
                  key={c.bg}
                  onClick={() => setSelectedBgColor(c.bg)}
                  className={`w-12 h-12 rounded-none border-3 transition-all ${selectedBgColor === c.bg ? "border-primary shadow-lg ring-2 ring-primary/50" : "border-border"}`}
                  style={{ background: c.bg }}
                  title={c.name}
                />
              ))}
            </div>
          </div>

          {/* Preview Card */}
          <div className="border-2 border-primary/30 rounded-none overflow-hidden" id="review-export-wrapper">
            <div id="review-export-card" dir={exportLang === "en" ? "ltr" : "rtl"} style={{ 
              background: selectedBgColor,
              padding: "20px",
              color: "#1f2937",
              fontFamily: "'Montserrat', sans-serif",
            }}>
              {/* Header - Similar to PerfumeDetail */}
              <div style={{ marginBottom: "20px" }}>
                {/* Brand & Name */}
                {exportOptions.perfumeName && (
                  <div style={{ marginBottom: "12px" }}>
                    <p style={{ fontSize: "11px", color: "#d97706", margin: "0 0 4px", fontWeight: "600", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                      {perfume.brand_name}
                    </p>
                  </div>
                )}
                {perfume.name_en && (
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: "8px" }}>
                    <p style={{ fontSize: "20px", fontWeight: "800", margin: "0", color: "#0f172a" }}>
                      {perfume.name_en}
                    </p>
                    <ExportHeader userMark={userMark} inline />
                  </div>
                )}



                {/* Perfume Image & Brand - Row Layout */}
                <div style={{ display: "flex", alignItems: "flex-start", gap: "12px", marginBottom: "12px" }}>
                  {perfume.image_url && perfume.image_url !== "white" ? (
                    <img 
                      src={perfume.image_url} 
                      alt={perfume.name_en}
                      style={{ width: "104px", height: "104px", objectFit: "contain", flexShrink: 0, background: "transparent" }}
                    />
                  ) : (
                    <div style={{ width: "104px", height: "104px", flexShrink: 0, background: "#fff", border: "1.5px solid #C8A02E", borderRadius: "0" }} />
                  )}
                  {/* Your Thought next to image */}
                  {exportOptions.notes && perfume.personal_notes && (
                    <div style={{ flex: 1, display: "flex", flexDirection: "column", justifyContent: "flex-start" }}>
                      <p style={{ 
                        fontSize: "11px", 
                        color: "#4b5563",
                        margin: "0",
                        lineHeight: "1.5",
                        fontStyle: "italic"
                      }}>
                        {perfume.personal_notes}
                      </p>
                    </div>
                  )}
                </div>

                {/* Arabic Name before About */}
                {exportOptions.perfumeName && perfume.name_ar && (
                  <p style={{ fontSize: "16px", fontWeight: "700", margin: "0 0 12px", color: "#1f2937", direction: "rtl" }}>
                    {perfume.name_ar}
                  </p>
                )}

                {/* About - removed Your Thought from here */}
                {(perfume.about_en || perfume.about_ar) && (
                  <div style={{ padding: "10px", backgroundColor: "#f9fafb", borderRadius: "6px", marginBottom: "12px" }}>
                    {perfume.about_en && (
                      <p style={{ fontSize: "10px", color: "#6b7280", margin: "0 0 3px", lineHeight: "1.4" }}>
                        {perfume.about_en}
                      </p>
                    )}
                    {perfume.about_ar && (
                      <p style={{ fontSize: "10px", color: "#6b7280", margin: "0", direction: "rtl", lineHeight: "1.4" }}>
                        {perfume.about_ar}
                      </p>
                    )}
                  </div>
                )}
              </div>

              {/* Perfume Info - Chips style like PerfumeDetail */}
              {exportOptions.perfumeInfo && (perfume.type || perfume.gender || perfume.price_range || perfume.category || perfume.time_of_day || perfume.season || perfume.release_year || perfume.perfumer_names) && (
                <div style={{ display: "flex", alignItems: "center", gap: "8px", flexWrap: "wrap", marginBottom: "16px" }}>
                  {perfume.type && (() => {
                    const typeObj = PERFUME_TYPES.find(t => t.value === perfume.type);
                    const typeLabel = typeObj ? `${typeObj.label_ar}  ${perfume.type}` : perfume.type;
                    return (
                      <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                        {typeLabel}
                      </div>
                    );
                  })()}
                  {perfume.gender && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                      {perfume.gender === "Women" ? <BT en="Women" ar="نسائي" />
                       : perfume.gender === "Men" ? <BT en="Men" ar="رجالي" />
                       : perfume.gender === "Unisex" ? <BT en="Unisex" ar="للجنسين" />
                       : perfume.gender}
                    </div>
                  )}
                  {perfume.category && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                      الفئة {perfume.category}
                    </div>
                  )}
                  {perfume.time_of_day && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                      {perfume.time_of_day === "Day" ? <BT en="Day" ar="نهار" />
                       : perfume.time_of_day === "Night" ? <BT en="Night" ar="مسائي" />
                       : perfume.time_of_day === "All" ? <BT en="All" ar="الكل" />
                       : perfume.time_of_day}
                    </div>
                  )}
                  {perfume.season && (() => {
                    const seasonMap = {
                      "Spring": { en: "Spring", ar: "الربيع" },
                      "Summer": { en: "Summer", ar: "الصيف" },
                      "Fall":   { en: "Fall",   ar: "الخريف" },
                      "Winter": { en: "Winter", ar: "الشتاء" },
                      "All Seasons": { en: "All Seasons", ar: "كل الفصول" },
                    };
                    const m = seasonMap[perfume.season];
                    return (
                      <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                        {m ? <BT en={m.en} ar={m.ar} /> : perfume.season}
                      </div>
                    );
                  })()}
                  {perfume.release_year && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                      {perfume.release_year}
                    </div>
                  )}
                  {perfume.perfumer_names && (Array.isArray(perfume.perfumer_names) ? perfume.perfumer_names.join(",") : String(perfume.perfumer_names)).split(",").map((name, idx) => {
                    const trimmedName = name.trim();
                    const perfumerRecord = allPerfumers.find(p => p.name?.toLowerCase() === trimmedName.toLowerCase());
                    const arabicName = perfumerRecord?.name_ar || trimmedName;
                    return trimmedName ? (
                      <div key={idx} style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500", maxWidth: "150px", overflow: "hidden", textOverflow: "ellipsis" }}>
                        {arabicName} · {trimmedName}
                      </div>
                    ) : null;
                  })}
                  {perfume.price_range && (
                    <div style={{ display: "flex", alignItems: "center", gap: "6px", backgroundColor: "#f3f4f6", borderRadius: "20px", padding: "4px 12px", fontSize: "10px", fontWeight: "500" }}>
                      {perfume.price_range}
                    </div>
                  )}
                </div>
              )}

              {/* Odor Family — vertical bars (same design as enhanced export, sharp corners) */}
              {exportOptions.odorFamily && perfume.odor_family && (
                <div style={{ marginBottom: "16px" }}>
                  <p style={{ fontSize: "10px", fontWeight: "700", color: "#6b7280", margin: "0 0 8px", textTransform: "uppercase" }}>تناغم Accord</p>
                  <div style={{ display: "flex", alignItems: "flex-end", gap: "10px", height: "96px" }}>
                    {perfume.odor_family.split(",").map(f => f.trim()).filter(Boolean).slice(0, 6).map((f, idx) => {
                      const c = accordColor(f);
                      const hh = Math.max(26, 88 - idx * 14);
                      return (
                        <div key={idx} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "4px" }}>
                          <span style={{ width: "12px", height: hh + "px", borderRadius: "0", background: c }} />
                          <span style={{ fontSize: "9px", color: c, maxWidth: "60px", textAlign: "center", lineHeight: 1.2 }}>{f}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Related Perfumes */}
              {exportOptions.relatedPerfumes && perfume.related_perfume_ids && perfume.related_perfume_ids.trim() && (() => {
                const relatedIds = perfume.related_perfume_ids.split(",").map(id => id.trim()).filter(Boolean).slice(0, 5);
                const relatedNames = perfume.related_perfume_names ? perfume.related_perfume_names.split(",").map(n => n.trim()).filter(Boolean).slice(0, 5) : [];

                if (relatedNames.length === 0) return null;

                return (
                  <div style={{ marginBottom: "16px", paddingTop: "12px", borderTop: "1px solid #e5e7eb" }}>
                    <p style={{ fontSize: "10px", fontWeight: "700", color: "#6b7280", margin: "0 0 8px", textTransform: "uppercase" }}><BT en="Remind Me Of Similar Fragrances" ar="تذكرني في العطور عطور مقاربة" /></p>
                    <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                      {relatedNames.map((name, idx) => (
                        <span key={idx} style={{ fontSize: "11px", color: "#1f2937", fontWeight: "500", background: "#fffbeb", border: "1px solid #fcd34d", borderRadius: "8px", padding: "4px 10px", wordBreak: "break-word" }}>
                          {name}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              })()}

              {/* Occasions */}
              {exportOptions.occasions && perfume.occasions && (
                <div style={{ marginBottom: "16px" }}>
                  <p style={{ fontSize: "10px", fontWeight: "700", color: "#6b7280", margin: "0 0 8px", textTransform: "uppercase" }}><BT en="Best For" ar="مناسبات العطر" /></p>
                  <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                    {perfume.occasions.split(",").map((o, idx) => {
                      const occasionLabels = {
                        daylight:    { emoji: "☀️", en: "Day",         ar: "نهار" },
                        evening:     { emoji: "🌙", en: "Evening",     ar: "مساء" },
                        wedding:     { emoji: "💍", en: "Wedding",     ar: "زفاف" },
                        celebration: { emoji: "🎉", en: "Celebration", ar: "احتفال" },
                        relax:       { emoji: "😌", en: "Relax",       ar: "استرخاء" },
                        work:        { emoji: "💼", en: "Work",        ar: "عمل" },
                        sport:       { emoji: "⚽", en: "Sport",       ar: "رياضة" },
                        casual:      { emoji: "👕", en: "Casual",      ar: "عادي" },
                        very_special:{ emoji: "✨", en: "Very Special",ar: "خاص جداً" },
                      };
                      const oc = o.trim();
                      const cfg = occasionLabels[oc];
                      return oc ? (
                        <span key={idx} style={{ backgroundColor: "#f3f4f6", color: "#1f2937", border: "1px solid #e5e7eb", padding: "4px 10px", borderRadius: "14px", fontSize: "10px", fontWeight: "500", display: "inline-flex", alignItems: "center", gap: "4px" }}>
                          {cfg ? <>{cfg.emoji} <BT en={cfg.en} ar={cfg.ar} /></> : oc}
                        </span>
                      ) : null;
                    })}
                  </div>
                </div>
              )}

              {/* Rating Section */}
              <div style={{ marginBottom: "16px" }}>
                {exportOptions.rating && perfume.rating && (
                  <p style={{ fontSize: "16px", margin: "0", color: "#C8A02E", fontWeight: "700", letterSpacing: "2px" }}>
                    {"■".repeat(Math.round(perfume.rating))}{"□".repeat(5 - Math.round(perfume.rating))}
                  </p>
                )}
              </div>



              {/* Fragrance Notes by Layer - Images Only */}
              {exportOptions.notes_images && (() => {
                const { layers: notesByLayer, overflow: notesOverflow } = getFragranceNotesByLayer();
                const hasNotes = Object.values(notesByLayer).some(layer => layer.length > 0) || notesOverflow.length > 0;

                if (!hasNotes) return null;

                const layerLabels = {
                   Top:        { en: "Top",        ar: "مقدمة" },
                   Heart:      { en: "Heart",      ar: "قلب" },
                   Base:       { en: "Base",       ar: "أساس" },
                   Innovation: { en: "Innovation", ar: "مبتكرة" },
                 };

                const layerColors = {
                   Top: "#f59e0b",
                   Heart: "#ec4899",
                   Base: "#8b5cf6",
                   Innovation: "#10b981"
                 };

                return (
                  <div style={{ marginBottom: "12px", paddingTop: "10px", borderTop: "1px solid #e5e7eb" }}>
                    {Object.entries(notesByLayer).map(([layer, notes]) => 
                      notes.length > 0 ? (
                        <div key={layer} style={{ marginBottom: "10px" }}>
                          <p style={{ fontSize: "9px", fontWeight: "700", color: layerColors[layer], margin: "0 0 6px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                            <BT en={layerLabels[layer].en} ar={layerLabels[layer].ar} />
                          </p>
                          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(84px, 1fr))", gap: "8px" }}>
                              {notes.map((note) => {
                                const noteInfo = findNoteRec(note);
                                const isBanned = noteInfo?.is_allowed === false;
                                return (
                                  <div key={note} style={{ textAlign: "center", display: "flex", flexDirection: "column", alignItems: "center" }}>
                                    {noteInfo?.image_url ? (
                                      <img
                                        src={noteInfo.image_url}
                                        alt={note}
                                        style={{ width: "56px", height: "56px", objectFit: "contain", background: "transparent", marginBottom: "4px", border: isBanned ? "1px solid #dc2626" : "none" }}
                                      />
                                    ) : (
                                      <div style={{ width: "56px", height: "56px", background: "transparent", border: isBanned ? "1px solid #dc2626" : "none", marginBottom: "4px" }} />
                                    )}
                                  <p style={{
                                    fontSize: "8.5px",
                                    fontWeight: "600",
                                    margin: "0",
                                    color: isBanned ? "#dc2626" : "#1f2937",
                                    textDecoration: isBanned ? "line-through" : "none",
                                    lineHeight: 1.15,
                                    maxWidth: "84px",
                                    whiteSpace: "normal",
                                    wordBreak: "break-word",
                                    overflowWrap: "break-word",
                                    hyphens: "auto"
                                  }}>
                                    {note}
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      ) : null
                    )}
                    {notesOverflow.length > 0 && (
                      <div style={{ marginBottom: "10px" }}>
                        {notesByLayer.Innovation.length === 0 && (
                          <p style={{ fontSize: "9px", fontWeight: "700", color: "#10b981", margin: "0 0 4px", textTransform: "uppercase", letterSpacing: "0.05em" }}>
                            <BT en="Innovation" ar="مبتكرة" />
                          </p>
                        )}
                        <p dir="rtl" style={{ fontSize: "9.5px", color: "#1f2937", lineHeight: 1.5, margin: 0 }}>
                          {notesOverflow.join(" · ")}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })()}

              {/* Per-person review block(s) — side by side, no frames */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", marginTop: "14px", paddingTop: "12px", borderTop: "1px solid #e5e7eb" }}>
              {personEntries.map(({ key, data, name }) => {
                if (!data) return null;
                const impressionCfg = {
                  great:     { emoji: "😍", en: "Great",     ar: "رائع" },
                  neutral:   { emoji: "😐", en: "Neutral",   ar: "محايد" },
                  not_great: { emoji: "😕", en: "Not Great", ar: "سيء" },
                };
                const listCfg = {
                  favorite:  { emoji: "❤️", en: "Favorite",  ar: "مفضّل" },
                  recommend: { emoji: "👍", en: "Like",      ar: "أعجبني" },
                  dislike:   { emoji: "👎", en: "Dislike",   ar: "لم يعجبني" },
                };
                const imp = exportOptions.userImpression && data.impression ? impressionCfg[data.impression] : null;
                const lst = exportOptions.userImpression && data.list ? listCfg[data.list] : null;
                const rating = exportOptions.userRating ? (data.other_rating || data.rating) : null;
                const comment = exportOptions.comment ? (data.review || data.personal_notes) : null;
                const showHealth = exportOptions.health && (data.headache || data.sinus_sensitivity);
                const personPurchases = exportOptions.purchases ? purchasesFor(key) : [];
                const hasDetailed   = exportOptions.detailedRating  && (data.r_scent || data.r_longevity || data.r_sillage || data.r_bottle);
                const hasRecommend  = exportOptions.recommendOthers && data.recommend_to && data.recommend_to !== "none";
                const hasNotePhases = exportOptions.notePhases      && (data.note_top || data.note_heart || data.note_base);
                const hasAny = imp || lst || rating || comment || showHealth || personPurchases.length || hasDetailed || hasRecommend || hasNotePhases;
                if (!hasAny) return null;

                return (
                  <div key={key} style={{ minWidth: 0 }}>
                    <p style={{ fontSize: "12px", fontWeight: "700", color: "#374151", margin: "0 0 4px" }}>{name}</p>
                    {data.rating ? (
                      <p style={{ margin: "0 0 8px", color: "#C8A02E", fontWeight: 700, letterSpacing: "2px", fontSize: "15px" }}>
                        {"■".repeat(Math.round(data.rating))}{"□".repeat(Math.max(0, 5 - Math.round(data.rating)))}
                      </p>
                    ) : null}

                    {/* Impression + reaction + rating, inline */}
                    {(imp || lst || rating) && (
                      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", alignItems: "center", marginBottom: comment || showHealth || personPurchases.length || hasDetailed || hasRecommend || hasNotePhases ? "8px" : "0" }}>
                        {imp && (
                          <span style={{ fontSize: "11px", color: "#075985", background: "#f0f9ff", border: "1px solid #bae6fd", borderRadius: "12px", padding: "3px 10px" }}>
                            {imp.emoji} <BT en={imp.en} ar={imp.ar} />
                          </span>
                        )}
                        {lst && (
                          <span style={{ fontSize: "11px", color: "#9d174d", background: "#fdf2f8", border: "1px solid #fbcfe8", borderRadius: "12px", padding: "3px 10px" }}>
                            {lst.emoji} <BT en={lst.en} ar={lst.ar} />
                          </span>
                        )}
                      </div>
                    )}

                    {/* Detailed rating — Scent · Longevity · Sillage · Bottle */}
                    {hasDetailed && (
                      <div style={{ marginBottom: "8px" }}>
                        <p style={{ fontSize: "9px", fontWeight: "700", color: "#6b7280", margin: "0 0 6px", textTransform: "uppercase" }}>
                          🎯 <BT en="Detailed Rating" ar="تقييم تفصيلي" />
                        </p>
                        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "6px 12px" }}>
                          {[
                            { v: data.r_scent,     en: "Scent",     ar: "الرائحة" },
                            { v: data.r_longevity, en: "Longevity", ar: "الثبات"  },
                            { v: data.r_sillage,   en: "Sillage",   ar: "الفوحان" },
                            { v: data.r_bottle,    en: "Bottle",    ar: "الزجاجة" },
                          ].map((d, i) => d.v ? (
                            <div key={i} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "8px", padding: "3px 8px", background: "#fafaf7", border: "1px solid #eeece4", borderRadius: "8px" }}>
                              <span style={{ fontSize: "10px", color: "#374151", fontWeight: "500" }}>
                                <BT en={d.en} ar={d.ar} />
                              </span>
                              <span style={{ fontSize: "11px", color: "#C8A02E", fontWeight: "700", letterSpacing: "1px" }}>
                                {"■".repeat(Math.round(d.v))}{"□".repeat(Math.max(0, 5 - Math.round(d.v)))}
                              </span>
                            </div>
                          ) : null)}
                        </div>
                      </div>
                    )}

                    {/* Recommend to others — no / women / men / any */}
                    {hasRecommend && (() => {
                      const recCfg = {
                        no:    { emoji: "🚫", en: "No",           ar: "لا"           },
                        women: { emoji: "🌸", en: "Yes — Women",  ar: "نعم — نساء"   },
                        men:   { emoji: "🔷", en: "Yes — Men",    ar: "نعم — رجال"   },
                        any:   { emoji: "👥", en: "Yes — Anyone", ar: "نعم — للجميع" },
                      };
                      const r = recCfg[data.recommend_to];
                      if (!r) return null;
                      return (
                        <div style={{ marginBottom: "8px" }}>
                          <p style={{ fontSize: "9px", fontWeight: "700", color: "#6b7280", margin: "0 0 6px", textTransform: "uppercase" }}>
                            👥 <BT en="Recommend to Others" ar="ترشيح للآخرين" />
                          </p>
                          <span style={{ display: "inline-block", fontSize: "11px", color: "#065f46", background: "#ecfdf5", border: "1px solid #a7f3d0", borderRadius: "12px", padding: "3px 10px" }}>
                            {r.emoji} <BT en={r.en} ar={r.ar} />
                          </span>
                        </div>
                      );
                    })()}

                    {/* Note Phases — top · heart · base impressions */}
                    {hasNotePhases && (
                      <div style={{ marginBottom: "8px" }}>
                        <p style={{ fontSize: "9px", fontWeight: "700", color: "#6b7280", margin: "0 0 6px", textTransform: "uppercase" }}>
                          🌸 <BT en="Note Phases" ar="انطباع المراحل" />
                        </p>
                        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                          {[
                            { v: data.note_top,   en: "Top",   ar: "افتتاحية", color: "#f59e0b", bg: "#fffbeb", border: "#fcd34d" },
                            { v: data.note_heart, en: "Heart", ar: "قلب",      color: "#ec4899", bg: "#fdf2f8", border: "#fbcfe8" },
                            { v: data.note_base,  en: "Base",  ar: "قاعدة",     color: "#8b5cf6", bg: "#f5f3ff", border: "#ddd6fe" },
                          ].map((d, i) => d.v ? (
                            <span key={i} style={{ fontSize: "10px", color: d.color, background: d.bg, border: `1px solid ${d.border}`, borderRadius: "10px", padding: "3px 9px", fontWeight: "600" }}>
                              <BT en={d.en} ar={d.ar} /> {d.v === "like" ? "👍" : "👎"}
                            </span>
                          ) : null)}
                        </div>
                      </div>
                    )}

                    {/* Comment */}
                    {comment && (
                      <p style={{ fontSize: "11px", color: "#4b5563", fontStyle: "italic", lineHeight: "1.5", margin: "0 0 8px" }}>“{comment}”</p>
                    )}

                    {/* Health */}
                    {showHealth && (
                      <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginBottom: personPurchases.length ? "8px" : "0" }}>
                        {data.headache && (
                          <span style={{ fontSize: "9px", color: "#7f1d1d", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "2px 8px" }}>
                            🤕 <BT en="Headache" ar="صداع" />: {data.headache === "none" ? <BT en="None" ar="لا" /> : data.headache === "weak" ? <BT en="Weak" ar="ضعيف" /> : data.headache === "medium" ? <BT en="Medium" ar="متوسط" /> : <BT en="Strong" ar="قوي" />}
                          </span>
                        )}
                        {data.sinus_sensitivity && (
                          <span style={{ fontSize: "9px", color: "#7f1d1d", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "2px 8px" }}>
                            😠 <BT en="Sinus" ar="جيوب" />: {data.sinus_sensitivity === "no" ? <BT en="No" ar="لا" /> : data.sinus_sensitivity === "a_little" ? <BT en="A Little" ar="قليلاً" /> : <BT en="Yes" ar="نعم" />}
                          </span>
                        )}
                      </div>
                    )}

                    {/* Purchases */}
                    {personPurchases.length > 0 && (
                      <div>
                        <p style={{ fontSize: "8px", fontWeight: "700", color: "#6b7280", margin: "0 0 4px", textTransform: "uppercase" }}>🛒 <BT en="Purchases" ar="المشتريات" /></p>
                        <div style={{ display: "flex", gap: "6px", flexWrap: "wrap" }}>
                          {personPurchases.slice(0, 6).map((pr, i) => (
                            <span key={i} style={{ fontSize: "9px", color: "#1f2937", background: "#f9fafb", border: "1px solid #e5e7eb", borderRadius: "10px", padding: "2px 8px" }}>
                              {pr.purchase_date ? String(pr.purchase_date).split("T")[0] : ""}{pr.ml ? ` · ${pr.ml}ml` : ""}{pr.cost ? ` · ${pr.cost}` : ""}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
              </div>

              {/* Wear Count (kept as optional, separate line) */}
              {exportOptions.wearCount && wearLogs.length > 0 && (
                <p style={{ fontSize: "12px", color: "#059669", margin: "10px 0 0", fontWeight: "600" }}>
                  <BT
                    en={`Worn ${wearLogs.length} time${wearLogs.length !== 1 ? "s" : ""}`}
                    ar={`تم ارتداؤه ${wearLogs.length} مرة`}
                    separator=" · "
                  />
                </p>
              )}
              </div>

              {/* Bottom signature: photo + name, date, app name (when enabled) */}
              <ExportFooter compact photoName={userPhotoName} photoUrl={userPhotoUrl} />
              </div>

              {/* Download Button */}
              <Button 
              onClick={handleExport} 
              className="w-full h-11 rounded-none font-body text-base font-bold bg-gradient-to-r from-primary to-primary/80 hover:shadow-xl"
              >
              {isAr ? "تحميل" : "Download"}
              </Button>
              </div>
              </DialogContent>
              </Dialog>
  );
}