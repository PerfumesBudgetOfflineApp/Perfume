import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useCurrency } from "@/lib/useCurrency";

export default function UserTotals({ person, label }) {
  const { formatPrice } = useCurrency();
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes", person],
    queryFn: () => apphost.entities.UserPerfume.filter({ person }),
    enabled: !!person,
  });

  const totalSampleMl = userPerfumes.reduce((sum, u) => sum + (u.sample_ml || 0), 0);
  const totalSampleCost = userPerfumes.reduce((sum, u) => sum + (u.sample_cost || 0), 0);
  const costPerMl = totalSampleMl > 0 ? (totalSampleCost / totalSampleMl).toFixed(2) : null;

  return (
    <div className="space-y-1.5">
      {label && <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold px-1">{label}</p>}
      <div className="grid grid-cols-3 gap-2 border border-border/40 rounded-none p-2">
        <div className="bg-secondary/40 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">ML</p>
          <p className="text-sm font-body font-bold text-primary">{totalSampleMl}ml</p>
        </div>
        <div className="bg-secondary/40 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">التكلفة Cost</p>
          <p className="text-sm font-body font-bold text-primary">{formatPrice(totalSampleCost.toFixed(0))}</p>
        </div>
        <div className="bg-secondary/40 rounded-none p-2">
          <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">التكلفة للمل Cost/ml</p>
          <p className="text-sm font-body font-bold text-primary">{costPerMl ? formatPrice(costPerMl) : "—"}</p>
        </div>
      </div>
    </div>
  );
}