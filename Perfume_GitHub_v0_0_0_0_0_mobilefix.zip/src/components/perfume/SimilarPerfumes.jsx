import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";

export default function SimilarPerfumes({ perfume, isAr }) {
  const [expanded, setExpanded] = useState(false);

  const { data: allPerfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const similar = useMemo(() => {
    if (!perfume || !allPerfumes.length) return [];

    const currentNotes = new Set(
      [
        ...(perfume.top_notes?.split(",") || []),
        ...(perfume.heart_notes?.split(",") || []),
        ...(perfume.base_notes?.split(",") || []),
      ]
        .map((n) => n.trim().toLowerCase())
        .filter(Boolean)
    );

    if (currentNotes.size === 0) return [];

    const scored = allPerfumes
      .filter((p) => p.id !== perfume.id && p.brand_name !== perfume.brand_name)
      .map((p) => {
        const otherNotes = new Set(
          [
            ...(p.top_notes?.split(",") || []),
            ...(p.heart_notes?.split(",") || []),
            ...(p.base_notes?.split(",") || []),
          ]
            .map((n) => n.trim().toLowerCase())
            .filter(Boolean)
        );

        const intersection = [...currentNotes].filter((n) => otherNotes.has(n));
        const score = intersection.length / Math.max(currentNotes.size, otherNotes.size);
        return { perfume: p, score, matches: intersection.length };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);

    return scored.slice(0, 6);
  }, [perfume, allPerfumes]);

  if (similar.length === 0) return null;

  const displayCount = expanded ? similar.length : 2;

  return (
    <div className="bg-white rounded-none p-5 shadow-sm space-y-3">
      <div className="mb-2">
        <h3 className="font-heading font-semibold text-sm">{isAr ? "تذكرني في العطور عطور مقاربة" : "Remind Me Of Similar Fragrances"}</h3>
      </div>

      <div className="space-y-2">
        {similar.slice(0, displayCount).map((item) => (
          <Link
            key={item.perfume.id}
            to={`/perfume?id=${item.perfume.id}`}
            className="flex items-center gap-3 p-3 rounded-none border border-border/50 bg-secondary/20 hover:bg-secondary/40 transition-colors group"
          >
            {item.perfume.image_url && (
              <div className="w-12 h-12 rounded-none overflow-hidden flex-shrink-0 bg-white border border-border/30">
                <img
                  src={item.perfume.image_url}
                  alt={item.perfume.name_en}
                  className="w-full h-full object-contain"
                />
              </div>
            )}

            <div className="flex-1 min-w-0">
              <button
                onClick={() => {}}
                className="text-left w-full group-hover:opacity-70 transition-opacity"
              >
                <p className="font-body text-xs text-muted-foreground uppercase tracking-widest">
                  {item.perfume.brand_name}
                </p>
                <p className="font-heading font-semibold text-sm line-clamp-1">
                  {item.perfume.name_en || item.perfume.name_ar}
                </p>
              </button>
            </div>

            <div className="text-right flex-shrink-0">
              <span className="inline-block text-primary rounded-none text-xs font-body font-medium">
                {Math.round(item.score * 100)}%
              </span>
              <p className="text-[10px] text-muted-foreground mt-0.5">
                {item.matches} {isAr ? "نوتة" : "note"}{item.matches !== 1 ? "s" : ""}
              </p>
            </div>
          </Link>
        ))}
      </div>

      {similar.length > 2 && (
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full py-2 text-xs font-body font-medium text-primary hover:text-primary/80 transition-colors"
        >
          {expanded ? (isAr ? "إخفاء" : "Show Less") : `${isAr ? "عرض" : "Show"} ${similar.length - 2} ${isAr ? "أخرى" : "More"}`}
        </button>
      )}
    </div>
  );
}