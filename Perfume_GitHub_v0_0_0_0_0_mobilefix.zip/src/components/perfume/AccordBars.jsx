/**
 * AccordBars.jsx — "البصمة" accord display (Option 3).
 *
 * Renders a perfume's scent accords using the official catalogue colors and
 * percentages. The dominant accord is shown as a large colored band; the
 * rest follow as small tinted chips. Bilingual (EN + AR) with NO separator
 * dot between the two languages, per the project language rule.
 *
 * Input: `accords` string in catalogue form "a75:100;a35:80;a59:72;..."
 *        (accord_id:percent, already sorted descending).
 * Lookup: src/data/builtin_database/accords_builtin.json  →  id -> {en, ar, bar, font}
 */
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { useLang } from "@/lib/LanguageContext";

function parseAccords(raw = "") {
  return String(raw)
    .split(";")
    .map((e) => {
      const [id, pct] = e.split(":");
      const ref = ACCORDS[id];
      if (!ref) return null;
      const n = parseInt(pct, 10);
      return { id, pct: Number.isFinite(n) ? n : 0, ...ref };
    })
    .filter(Boolean);
}

export default function AccordBars({ accords }) {
  const { isAr, isMixed } = useLang();
  const list = parseAccords(accords);
  if (!list.length) return null;

  // العائلة العطرية تُعرض دائماً ثنائية اللغة (إنجليزي ثم عربي) بمسافة، بلا نقطة.
  // الإنجليزيّ بأحرف كبيرة (GREEN, FRESH SPICY)، والعربيّ كما هو.
  const label = (a) => {
    const en = String(a.en || "").toUpperCase();
    return a.ar ? `${en} ${a.ar}` : en;
  };
  const [top, ...rest] = list;
  const heading = isAr ? "العائلة العطرية" : isMixed ? "العائلة العطرية Odor Family" : "Odor Family";

  return (
    <div className="bg-card rounded-none px-5 py-4 shadow-sm">
      <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest mb-3">
        {heading}
      </p>

      {/* Dominant accord — colored band */}
      <div
        className="flex items-center gap-2 rounded-none px-4 py-2.5 mb-2"
        style={{ background: top.bar, color: top.font }}
        dir={isAr ? "rtl" : "ltr"}
      >
        <span className="text-sm font-body font-semibold">{label(top)}</span>
        <span className="text-xs font-body opacity-90" style={{ marginInlineStart: "auto" }}>
          {top.pct}%
        </span>
      </div>

      {/* Remaining accords — tinted chips */}
      {rest.length > 0 && (
        <div className="flex flex-wrap gap-2" dir={isAr ? "rtl" : "ltr"}>
          {rest.map((a) => (
            <span
              key={a.id}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-none text-xs font-body font-medium text-foreground/85"
              style={{ background: a.bar + "1F", border: `0.5px solid ${a.bar}66` }}
            >
              <span className="w-2 h-2 rounded-none flex-shrink-0" style={{ background: a.bar }} />
              {label(a)}
              <span className="opacity-60">{a.pct}%</span>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
