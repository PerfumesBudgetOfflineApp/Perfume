import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { apphost } from "@/api/apphostClient";

// Each layer matches a field in the perfume record. The user chooses
// which layer each note belongs to when creating/editing a perfume.
const LAYERS = [
  { key: "top_notes",        label: "Top",        labelAr: "مقدمة",  color: "text-sky-600 dark:text-sky-400" },
  { key: "heart_notes",      label: "Heart",      labelAr: "قلب",    color: "text-rose-600 dark:text-rose-400" },
  { key: "base_notes",       label: "Base",       labelAr: "أساس",   color: "text-amber-700 dark:text-amber-400" },
  { key: "innovation_notes", label: "Innovation", labelAr: "مبتكرة", color: "text-emerald-700 dark:text-emerald-400" },
];

// أعلى حدّ لكلّ طبقة هرمية؛ ما زاد يُحوَّل نصّاً إلى قسم «مبتكرة».
const CAP = 5;
const CAPPED = new Set(["top_notes", "heart_notes", "base_notes"]);

const dropAl = (s) => (s || "").trim().replace(/^ال/, "");

// تطبيع للمطابقة يدعم العربية والإنجليزية: إزالة التشكيل والتطويل، توحيد
// الألف/الياء/التاء المربوطة، إسقاط «ال» التعريف، وإبقاء الحروف العربية
// واللاتينية والأرقام. يحلّ مشكلة عدم ظهور صورة النوتة العربية وفتحها.
const normKey = (s) => (s || "")
  .toLowerCase()
  .replace(/[\u064B-\u0652\u0670\u0640]/g, "")
  .replace(/[إأآٱ]/g, "ا")
  .replace(/ى/g, "ي")
  .replace(/ة/g, "ه")
  .replace(/(^|\s)ال/g, "$1")
  .replace(/[^a-z0-9\u0600-\u06FF ]/g, "")
  .replace(/\s+/g, " ")
  .trim();

export default function FragranceNotesGrid({ perfume, isAr }) {
  const navigate = useNavigate();
  const [textView, setTextView] = useState(false);

  // Collect ALL referenced note names
  const allNames = LAYERS.flatMap(({ key }) =>
    (perfume[key] || "").split(",").map(s => s.trim()).filter(Boolean)
  );

  const { data: noteRecords = [] } = useQuery({
    queryKey: ["fragrance-notes-by-name", allNames.join(",")],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 10,
    enabled: allNames.length > 0,
  });

  // فهرس مطبَّع بالاسم الإنجليزي والعربي معاً (غير حسّاس لـ«ال» ولا للتشكيل).
  const noteByNorm = {};
  noteRecords.forEach((n) => {
    [n.name, n.name_ar].forEach((nm) => {
      const k = normKey(nm);
      if (k && !(k in noteByNorm)) noteByNorm[k] = n;
    });
  });

  const findNote = (rawName) => {
    const k = normKey(rawName);
    if (!k) return null;
    if (noteByNorm[k]) return noteByNorm[k];
    // تجاهل النصوص الطويلة/الجُملية — ليست نوتة واحدة
    if (k.length > 28 || k.split(" ").length > 4) return null;
    // مطابقة الكلمة الأخيرة (مثل "Italian Bergamot" → "Bergamot")
    for (const n of noteRecords) {
      for (const nm of [n.name, n.name_ar]) {
        const full = normKey(nm);
        if (!full || full.split(" ").length > 2) continue;
        if (k === full || k.endsWith(" " + full)) return n;
      }
    }
    return null;
  };

  // مطابقة مؤكَّدة للتنقّل فقط: تطابق تامّ بعد التطبيع (إنجليزي أو عربي).
  const findNoteExact = (rawName) => {
    const k = normKey(rawName);
    if (!k) return null;
    return noteByNorm[k] || null;
  };

  const hasAny = LAYERS.some(({ key }) => !!perfume[key]);
  if (!hasAny) return null;

  // ما يفيض عن الحدّ في الطبقات الهرمية يُجمَع ويُعرَض نصّاً في «مبتكرة».
  const overflowNames = [];

  return (
    <div className="space-y-5 py-2">
      {/* العنوان + مثلّث التبديل بين الصور والنص */}
      <div className="flex items-center justify-center relative">
        <h2 className="font-heading font-semibold text-center" style={{ color: "#9a7b1f" }}>
          {isAr ? "هرم النوتات Pyramid" : "Pyramid هرم النوتات"}
        </h2>
        <button
          onClick={() => setTextView(v => !v)}
          className="absolute left-0 flex items-center justify-center w-6 h-6 hover:opacity-70 transition-opacity"
          title={isAr ? (textView ? "صور" : "نص") : (textView ? "Images" : "Text")}
        >
          <span style={{ width: 0, height: 0, borderRight: "6px solid transparent", borderLeft: "6px solid transparent", borderBottom: "10px solid #C8A02E" }} />
        </button>
      </div>

      {LAYERS.map(({ key, label, labelAr, color }) => {
        const all = (perfume[key] || "").split(",").map(s => s.trim()).filter(Boolean);
        let noteNames = all;
        if (CAPPED.has(key) && all.length > CAP) {
          noteNames = all.slice(0, CAP);
          overflowNames.push(...all.slice(CAP));
        }
        const isInnov = key === "innovation_notes";
        const showOverflow = isInnov && overflowNames.length > 0;
        if (!noteNames.length && !showOverflow) return null;

        return (
          <div key={key} className="space-y-2">
            <p className="text-[11px] font-body font-bold tracking-widest text-center" style={{ color: "#9a7b1f" }}>
              {labelAr} <span style={{ color: "#cbb67a" }}>{label}</span>
            </p>

            {noteNames.length > 0 && (textView ? (
              <p dir="rtl" className={`text-sm font-body text-center leading-relaxed uppercase ${color}`}>
                {noteNames.map((name, i) => {
                  const record = findNote(name);
                  const ar = record?.name_ar ? dropAl(record.name_ar) : "";
                  return (
                    <span key={name}>
                      {i > 0 && <span style={{ color: "#cbb67a" }}> · </span>}
                      {name}{ar && <span className="text-muted-foreground"> {ar}</span>}
                    </span>
                  );
                })}
              </p>
            ) : (
              <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-6 gap-2">
                {noteNames.map(name => {
                  const record = findNote(name);
                  const isBanned = record?.is_allowed === false;
                  const textClass = isBanned ? "text-red-600 dark:text-red-400" : color;
                  const ar = record?.name_ar ? dropAl(record.name_ar) : "";
                  const hasImg = !!record?.image_url;
                  const border = isBanned ? "1px solid rgba(220,38,38,0.7)" : "1px solid #C8A02E";

                  return (
                    <button
                      key={name}
                      onClick={() => {
                        const target = findNoteExact(name);
                        return target
                          ? navigate(`/note?id=${target.id}`)
                          : navigate(`/note?name=${encodeURIComponent(name)}`);
                      }}
                      className="flex flex-col gap-1 text-left hover:opacity-80 transition-opacity group"
                    >
                      {hasImg ? (
                        <img
                          src={record.image_url}
                          alt={name}
                          loading="lazy"
                          decoding="async"
                          className="w-full aspect-square object-contain"
                          style={{ background: "transparent", border }}
                        />
                      ) : (
                        <div
                          className="w-full aspect-square"
                          style={{ background: "transparent" }}
                        />
                      )}
                      <p className={`text-[9px] font-body font-semibold text-center leading-tight uppercase ${textClass} group-hover:underline ${isBanned ? "line-through decoration-red-500" : ""}`}>
                        {name}{ar && <span className="block text-muted-foreground normal-case">{ar}</span>}
                      </p>
                    </button>
                  );
                })}
              </div>
            ))}

            {showOverflow && (
              <p dir="rtl" className={`text-xs font-body text-center leading-relaxed uppercase ${color}`}>
                {overflowNames.map((name, i) => {
                  const record = findNote(name);
                  const ar = record?.name_ar ? dropAl(record.name_ar) : "";
                  return (
                    <span key={`ov-${name}-${i}`}>
                      {i > 0 && <span style={{ color: "#cbb67a" }}> · </span>}
                      {name}{ar && <span className="text-muted-foreground"> {ar}</span>}
                    </span>
                  );
                })}
              </p>
            )}
          </div>
        );
      })}
    </div>
  );
}
