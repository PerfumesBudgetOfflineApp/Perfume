import { useState, useMemo } from "react";
import { X } from "lucide-react";

export default function RelatedPerfumesField({
  relatedIds,
  relatedNames,
  allPerfumes,
  perfumeId,
  onChange,
}) {
  const [searchInput, setSearchInput] = useState("");
  const [showDropdown, setShowDropdown] = useState(false);

  const selectedIds = (relatedIds || "").split(",").map(s => s.trim()).filter(Boolean);

  const filteredPerfumes = useMemo(() => {
    if (!searchInput.trim()) return [];
    const q = searchInput.toLowerCase();
    const selectedStr = selectedIds.map(String);
    return allPerfumes.filter(p =>
      String(p.id) !== String(perfumeId) &&
      !selectedStr.includes(String(p.id)) &&
      (
        (p.name_en || "").toLowerCase().includes(q) ||
        (p.name_ar || "").toLowerCase().includes(q) ||
        (p.name || "").toLowerCase().includes(q) ||
        (p.brand_name || "").toLowerCase().includes(q)
      )
    ).slice(0, 8);
  }, [allPerfumes, searchInput, selectedIds, perfumeId]);

  const handleAdd = (perfume) => {
    const newIds = [...selectedIds, perfume.id].join(",");
    const newNames = [...(relatedNames || "").split(",").map(s => s.trim()).filter(Boolean), perfume.name_en || perfume.name_ar].join(",");
    onChange(newIds, newNames);
    setSearchInput("");
    setShowDropdown(false);
  };

  const handleRemove = (id) => {
    const newIds = selectedIds.filter(sid => sid !== id);
    const selectedNames = (relatedNames || "").split(",").map(s => s.trim()).filter(Boolean);
    const idx = selectedIds.indexOf(id);
    const newNames = idx !== -1 ? selectedNames.filter((_, i) => i !== idx) : selectedNames;
    onChange(newIds.join(","), newNames.join(","));
  };

  return (
    <div className="space-y-2">
      <div className="relative">
        <input
          type="text"
          placeholder="ابحث عن عطر للربط... Search perfume to link..."
          value={searchInput}
          onChange={(e) => {
            setSearchInput(e.target.value);
            setShowDropdown(true);
          }}
          onFocus={() => setShowDropdown(true)}
          onBlur={() => setTimeout(() => setShowDropdown(false), 150)}
          className="w-full h-9 rounded-none border border-input px-3 text-sm font-body focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring"
        />
      </div>

      {/* Related perfumes chips */}
      {selectedIds.map((id) => {
        const relPerfume = allPerfumes.find(p => String(p.id) === String(id));
        return (
          <div key={id} className="flex items-center gap-2 p-2 bg-secondary/40 rounded-none">
            <div className="flex-1 min-w-0">
              <p className="text-xs font-body font-semibold truncate">{relPerfume?.name_en || relPerfume?.name_ar || id}</p>
              {relPerfume?.brand_name && <p className="text-[10px] text-muted-foreground">{relPerfume.brand_name}</p>}
            </div>
            <button
              type="button"
              onClick={() => handleRemove(id)}
              className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        );
      })}

      {/* Dropdown suggestions */}
      {showDropdown && filteredPerfumes.length > 0 && (
        <div className="bg-card border border-border rounded-none shadow-lg z-20 max-h-40 overflow-y-auto">
          {filteredPerfumes.map((p) => (
            <button
              key={p.id}
              type="button"
              onMouseDown={() => handleAdd(p)}
              className="w-full flex items-center gap-3 px-3 py-2 hover:bg-secondary text-sm font-body border-b border-border/50 last:border-b-0"
            >
              <div className="flex-1 min-w-0">
                <p className="font-semibold truncate">{p.name_en || p.name_ar}</p>
                {p.brand_name && <p className="text-xs text-muted-foreground">{p.brand_name}</p>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}