import { useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";

import { toast } from "sonner";
import PerfumerSearchTag from "@/components/maestro/PerfumerSearchTag";

export default function PerfumersSection({ perfume }) {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const queryClient = useQueryClient();

  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["perfumers-all"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const linkedIds = useMemo(
    () => (Array.isArray(perfume.perfumer_ids) ? perfume.perfumer_ids.join(",") : String(perfume.perfumer_ids || "")).split(",").map(s => s.trim()).filter(Boolean),
    [perfume.perfumer_ids]
  );

  // أسماء العطّارين المكتوبة على العطر (perfumer_names) — للربط بالاسم عند غياب
  // المعرّفات (perfumer_ids)، تماماً كما في صفحة البراند. يحلّ مشكلة عدم ظهور
  // العطّارة المرتبطة بالاسم فقط (مثل عطّار التطبيق Attara على عطر Aaatar).
  const linkedNames = useMemo(
    () => (Array.isArray(perfume.perfumer_names) ? perfume.perfumer_names.join(",") : String(perfume.perfumer_names || "")).split(",").map(s => s.trim()).filter(Boolean),
    [perfume.perfumer_names]
  );

  const linkedPerfumers = useMemo(() => {
    const out = [];
    const seen = new Set();
    // 1) بالمعرّف
    linkedIds.forEach((pid) => {
      const p = allPerfumers.find((x) => String(x.id) === String(pid));
      if (p && !seen.has(p.id)) { seen.add(p.id); out.push(p); }
    });
    // 2) بالاسم (إن لم يُربط بالمعرّف) — مطابقة غير حسّاسة للحالة
    const byName = {};
    allPerfumers.forEach((p) => { if (p.name) byName[String(p.name).toLowerCase().trim()] = p; });
    linkedNames.forEach((name) => {
      const rec = byName[name.toLowerCase()];
      if (rec && !seen.has(rec.id)) { seen.add(rec.id); out.push(rec); }
    });
    return out;
  }, [linkedIds, linkedNames, allPerfumers]);

  const handleChange = async (ids, names) => {
    try {
      await apphost.entities.Perfume.update(perfume.id, {
        name_en: perfume.name_en || perfume.name || "",
        perfumer_ids: ids,
        perfumer_names: names,
      });
      queryClient.invalidateQueries({ queryKey: ["perfume", perfume.id] });
      toast.success("تم التحديث");
    } catch (error) {
      toast.error("فشل التحديث");
    }
  };

  return (
    <div className="space-y-3 py-2">
      <p className="text-xs font-body font-bold uppercase tracking-widest px-1 text-violet-600 dark:text-violet-400">{isAr ? "من ابتكر هذا العطر" : "Who Created This Perfume"}</p>

      {/* Linked perfumers display */}
      {linkedPerfumers.length > 0 && (
        <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-6 gap-2">
          {linkedPerfumers.map(p => {
            const isFemale = p.gender === "Female";
            return (
              <button
                key={p.id}
                onClick={() => navigate(`/perfumer?id=${p.id}`)}
                className="flex flex-col items-center gap-1 hover:opacity-80 transition-opacity"
              >
                <div className="w-full aspect-square rounded-none overflow-hidden bg-white flex items-center justify-center"
                  style={{ border: "1px solid rgba(212,175,55,0.35)" }}>
                  {p.photo_url ? (
                    <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover"
                      onError={(e) => { e.currentTarget.style.display = "none"; }} />
                  ) : (
                    <div className="w-full h-full bg-white" />
                  )}
                </div>
                <div className="text-center space-y-0.5">
                  <p className={`text-[10px] font-body font-semibold leading-tight line-clamp-2 ${isFemale ? "text-pink-500" : "text-blue-700 dark:text-blue-400"}`}>{p.name}</p>
                  {p.name_ar && <p className={`text-[9px] font-body leading-tight ${isFemale ? "text-pink-400" : "text-blue-600 dark:text-blue-500"}`} dir="rtl">{p.name_ar}</p>}
                </div>
              </button>
            );
          })}
        </div>
      )}

      {/* Search to link/unlink */}
      <PerfumerSearchTag
        value={perfume.perfumer_ids || ""}
        namesValue={perfume.perfumer_names || ""}
        onChange={handleChange}
      />
    </div>
  );
}