import { cn } from "@/lib/utils";

/**
 * StarRating — نُغيّر الشكل من نجمة إلى معيّن (دايموند) ذهبي
 * مع الحفاظ على نفس الـAPI القديم حتى لا تتأثر أيّ صفحة تستخدمه.
 * الممتلئ = ذهبي مصمت، الفارغ = إطار ذهبي مجوّف.
 */
const GOLD = "var(--brand)";

function DiamondIcon({ filled, sizeClass }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={cn(sizeClass)}
      aria-hidden="true"
    >
      <rect
        x="3.5"
        y="3.5"
        width="17"
        height="17"
        fill={filled ? GOLD : "none"}
        stroke={GOLD}
        strokeWidth={filled ? 0 : 1.5}
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function StarRating({ rating = 0, onChange, size = "md" }) {
  const sizeClass = size === "sm" ? "w-3 h-3" : size === "lg" ? "w-6 h-6" : "w-5 h-5";

  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map((idx) => (
        <button
          key={idx}
          type="button"
          onClick={() => onChange?.(idx === rating ? 0 : idx)}
          className={cn(
            "transition-all duration-150",
            onChange ? "cursor-pointer hover:scale-110" : "cursor-default"
          )}
        >
          <DiamondIcon filled={idx <= rating} sizeClass={sizeClass} />
        </button>
      ))}
    </div>
  );
}
