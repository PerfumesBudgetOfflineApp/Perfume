import { useState } from "react";

/**
 * BrandLogo — shows the brand's logo image. If there is no logo (or it fails
 * to load), renders nothing at all — clean and empty, no letters, no icon.
 *
 * Logo source priority:
 *   1. brand.logo_url               (user-uploaded / edited)
 *   2. brand.perfumappdatabase_logo (built-in catalogue logo)
 */
export default function BrandLogo({
  brand = {},
  crossOrigin,
  imgClassName = "w-full h-full object-contain",
  imgStyle,
  initialsSize = 18,
}) {
  const src = brand.logo_url || brand.perfumappdatabase_logo || "";
  const [failed, setFailed] = useState(false);

  if (src && !failed) {
    return (
      <img
        src={src}
        alt={brand.name || "brand"}
        loading="lazy"
        referrerPolicy="no-referrer"
        crossOrigin={crossOrigin}
        onError={() => setFailed(true)}
        className={imgClassName}
        style={imgStyle}
      />
    );
  }

  // لا شعار: فارغ نظيف تماماً — بلا حرف وبلا أيقونة
  return null;
}
