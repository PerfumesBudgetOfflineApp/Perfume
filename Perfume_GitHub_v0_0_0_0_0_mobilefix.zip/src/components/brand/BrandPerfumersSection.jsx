import { useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import PerfumerSearchTag from "@/components/maestro/PerfumerSearchTag";

export default function BrandPerfumersSection({ brand }) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["perfumers-all"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  // name → perfumer record (for matching auto-linked names from the imported dataset)
  const byName = useMemo(() => {
    const m = {};
    allPerfumers.forEach(p => { if (p.name) m[p.name.trim().toLowerCase()] = p; });
    return m;
  }, [allPerfumers]);

  // Unified list: manually-linked IDs + auto-linked names (from brand.perfumer_names).
  const unifiedPerfumers = useMemo(() => {
    const seen = new Set();
    const out = [];
    // 1) manually linked by id
    (Array.isArray(brand.perfumer_ids) ? brand.perfumer_ids.join(",") : String(brand.perfumer_ids || "")).split(",").map(s => s.trim()).filter(Boolean).forEach(pid => {
      const p = allPerfumers.find(x => String(x.id) === String(pid));
      if (p && !seen.has(p.id)) { seen.add(p.id); out.push(p); }
    });
    // 2) auto-linked by name (imported perfumer_names) — match to DB record if found,
    //    otherwise show as a name-only chip
    (Array.isArray(brand.perfumer_names) ? brand.perfumer_names.join(",") : String(brand.perfumer_names || "")).split(",").map(s => s.trim()).filter(Boolean).forEach(name => {
      const rec = byName[name.toLowerCase()];
      if (rec) {
        if (!seen.has(rec.id)) { seen.add(rec.id); out.push(rec); }
      } else {
        const key = "name:" + name.toLowerCase();
        if (!seen.has(key)) { seen.add(key); out.push({ id: key, name, name_ar: "", _nameOnly: true }); }
      }
    });
    return out;
  }, [brand.perfumer_ids, brand.perfumer_names, allPerfumers, byName]);

  const handleChange = async (ids, names) => {
    await apphost.entities.PerfumeBrand.update(brand.id, {
      perfumer_ids: ids,
      perfumer_names: names,
    });
    queryClient.invalidateQueries({ queryKey: ["brand", brand.id] });
    toast.success("تم التحديث");
  };

  return (
    <div className="bg-card rounded-none p-5 shadow-sm space-y-4">
      <div>
        <h2 className="font-heading font-semibold text-sm">عطّارون مرتبطون بهذه الدار</h2>
      </div>

      {unifiedPerfumers.length > 0 && (
        <div className="grid grid-cols-4 sm:grid-cols-5 gap-3">
          {unifiedPerfumers.map(p => {
            const isFemale = p.gender === "Female";
            return (
              <button
                key={p.id}
                onClick={() => !p._nameOnly && navigate(`/perfumer?id=${p.id}`)}
                className="flex flex-col items-center gap-1.5 hover:opacity-80 transition-opacity"
              >
                {/* smaller photo — square with gold frame */}
                <div className="w-12 h-12 rounded-none overflow-hidden bg-white flex items-center justify-center shadow-sm flex-shrink-0"
                  style={{ border: "1.5px solid #d4af37" }}>
                  {p.photo_url ? (
                    <img src={p.photo_url} alt={p.name} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-white" />
                  )}
                </div>
                {/* bigger name */}
                <div className="text-center space-y-0.5">
                  <p className={`text-[12px] font-body font-bold leading-tight line-clamp-2 ${isFemale ? "text-pink-500" : "text-blue-700 dark:text-blue-400"}`}>{p.name}</p>
                  {p.name_ar && <p className={`text-[10px] font-body leading-tight ${isFemale ? "text-pink-400" : "text-blue-600 dark:text-blue-500"}`} dir="rtl">{p.name_ar}</p>}
                </div>
              </button>
            );
          })}
        </div>
      )}

      <PerfumerSearchTag
        value={brand.perfumer_ids || ""}
        namesValue={brand.perfumer_names || ""}
        onChange={handleChange}
      />
    </div>
  );
}
