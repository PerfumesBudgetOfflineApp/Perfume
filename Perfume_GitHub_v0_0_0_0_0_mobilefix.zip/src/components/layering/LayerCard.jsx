import { Layers, Trash2, CalendarDays } from "lucide-react";
import { Button } from "@/components/ui/button";

const PERSON_STYLES = {
  person1: "bg-primary/10 text-primary",
  person2: "bg-violet-100 text-violet-600",
  both: "bg-secondary text-foreground",
};

export default function LayerCard({ layer, names, onDelete, onLogWear, onRateUpdate }) {
  const personLabel = layer.person === "both" ? "Both" : layer.person === "person2" ? names.person2 : names.person1;

  // Support both new multi-perfume format and legacy 2-perfume format
  const perfumeList = layer.perfume_names
    ? layer.perfume_names.split(",").map((n, i) => {
        const brands = layer.perfume_brands ? layer.perfume_brands.split(",") : [];
        return { name: n.trim(), brand: brands[i]?.trim() || "" };
      })
    : [
        { name: layer.perfume1_name, brand: layer.perfume1_brand },
        { name: layer.perfume2_name, brand: layer.perfume2_brand },
      ];

  return (
    <div className="bg-card rounded-none border border-border/60 p-4 space-y-3">
      {/* Header */}
      <div className="flex items-start justify-between gap-2">
        <div className="flex-1 min-w-0">
          {layer.name && (
            <p className="text-sm font-body font-semibold truncate mb-1">{layer.name}</p>
          )}
          {/* Perfume list */}
          <div className="flex items-start gap-1.5 flex-wrap">
            {perfumeList.map((p, i) => (
              <div key={i} className="flex items-center gap-1">
                {i > 0 && <Layers className="w-2.5 h-2.5 text-primary/60 flex-shrink-0" />}
                <div className="flex items-baseline gap-1">
                  <span className="text-xs font-body font-medium text-foreground/90">{p.name}</span>
                  {p.brand && <span className="text-[9px] text-muted-foreground font-body">({p.brand})</span>}
                </div>
              </div>
            ))}
          </div>
          {perfumeList.length > 2 && (
            <p className="text-[10px] text-primary font-body mt-0.5">{perfumeList.length}-perfume blend</p>
          )}
        </div>
        <button onClick={onDelete} className="text-muted-foreground hover:text-destructive transition-colors flex-shrink-0 mt-0.5">
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Notes */}
      {layer.notes && (
        <p className="text-xs font-body text-muted-foreground italic leading-relaxed">"{layer.notes}"</p>
      )}

      {/* Meta row */}
      <div className="flex items-center gap-2 flex-wrap">
        <span className={`text-[10px] px-2 py-0.5 rounded-none font-body font-medium ${PERSON_STYLES[layer.person] || PERSON_STYLES.person1}`}>
          {personLabel}
        </span>
        {layer.wear_count > 0 && (
          <span className="text-[10px] text-muted-foreground font-body flex items-center gap-0.5">
            <CalendarDays className="w-3 h-3" /> {layer.wear_count}× worn
          </span>
        )}
        {layer.last_worn && (
          <span className="text-[10px] text-muted-foreground font-body">last: {layer.last_worn}</span>
        )}
      </div>

      {/* Rating + Log */}
      <div className="flex items-center justify-between">
        <div className="flex gap-0.5">
          {[1, 2, 3, 4, 5].map((s) => (
            <button key={s} onClick={() => onRateUpdate(layer.rating === s ? 0 : s)}
              className={`text-base transition-all ${s <= (layer.rating || 0) ? "text-primary" : "text-border hover:text-primary/40"}`}>{s <= (layer.rating || 0) ? "■" : "□"}</button>
          ))}
        </div>
        <Button size="sm" variant="outline" className="rounded-none font-body text-[10px] h-7 px-3 gap-1" onClick={onLogWear}>
          <CalendarDays className="w-3 h-3" /> Log Wear
        </Button>
      </div>
    </div>
  );
}