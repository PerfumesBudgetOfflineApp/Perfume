import { Toaster } from "@/components/ui/toaster"
import { Toaster as SonnerToaster } from "sonner"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, useLocation, Navigate, Outlet } from 'react-router-dom';
import { getSecureStorage } from '@/lib/storageEncryption';
import { useEffect, lazy, Suspense } from 'react';
import PageNotFound from './lib/PageNotFound';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);
  return null;
}
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import { LanguageProvider } from '@/lib/LanguageContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from './components/layout/AppLayout';
const Home = lazy(() => import('./pages/Home'));
const Perfumes = lazy(() => import('./pages/Perfumes'));
const Explore = lazy(() => import('./pages/Explore'));
const HeadacheGuide = lazy(() => import('./pages/HeadacheGuide'));
const FlaconGuide = lazy(() => import('./pages/FlaconGuide'));
const AccordsGuide = lazy(() => import('./pages/AccordsGuide'));
const PerfumeIndex = lazy(() => import('./pages/PerfumeIndex'));
const AddPerfume = lazy(() => import('./pages/AddPerfume'));
const Lists = lazy(() => import('./pages/Lists'));
const Brands = lazy(() => import('./pages/Brands'));
const PerfumeDetail = lazy(() => import('./pages/PerfumeDetail'));

const WearHistory = lazy(() => import('./pages/WearHistory'));
const Statistics = lazy(() => import('./pages/Statistics'));
const Goals = lazy(() => import('./pages/Goals'));
const Layering = lazy(() => import('./pages/Layering'));
const Blog = lazy(() => import('./pages/Blog'));
const BlogDetail = lazy(() => import('./pages/BlogDetail'));
const AppInfo = lazy(() => import('./pages/AppInfo'));
const Compare = lazy(() => import('./pages/Compare'));
const Backup = lazy(() => import('./pages/Backup'));
const CollectionView = lazy(() => import('./pages/CollectionView'));
const BrandCollectionDetail = lazy(() => import('./pages/BrandCollectionDetail'));
const OwnerGroupDetail = lazy(() => import('./pages/OwnerGroupDetail'));
const Samples = lazy(() => import('./pages/Samples'));
const Quotes = lazy(() => import('./pages/Quotes'));
const QuoteDetail = lazy(() => import('./pages/QuoteDetail'));
const CastAway = lazy(() => import('./pages/CastAway'));
const Classify = lazy(() => import('./pages/Classify'));
const NotesAccord = lazy(() => import('./pages/NotesAccord'));
const BrandDetail = lazy(() => import('./pages/BrandDetail'));
const Perfumers = lazy(() => import('./pages/Perfumers'));
const PerfumersIndex = lazy(() => import('./pages/PerfumersIndex'));
const PerfumerDetail = lazy(() => import('./pages/PerfumerDetail'));
const CreateSamplePage = lazy(() => import('./pages/CreateSamplePage'));
const AddPerfumer = lazy(() => import('./pages/AddPerfumer'));
const Notes = lazy(() => import('./pages/Notes'));
const NotesIndex = lazy(() => import('./pages/NotesIndex'));
const NoteDetail = lazy(() => import('./pages/NoteDetail'));
const OccasionView = lazy(() => import('./pages/OccasionView'));
const MakePerfumePage = lazy(() => import('./pages/MakePerfume'));
const TopRated = lazy(() => import('./pages/TopRated'));
const PerfumeCulture = lazy(() => import('./pages/PerfumeCulture'));
const Glossary = lazy(() => import('./pages/Glossary'));
// تحميل كسول لصفحة المصنفات (/timelines): لا تُحمَّل ضمن الحزمة الأولى ولا تبطئ الإقلاع.
const GlossaryTimelines = lazy(() => import('./pages/GlossaryTimelines'));
const ReadingGuide = lazy(() => import('./pages/ReadingGuide'));
const GlossaryTermDetail = lazy(() => import('./pages/GlossaryTermDetail'));
const At = lazy(() => import('./pages/At'));
const Budget = lazy(() => import('./pages/Budget'));
const MarketingCardPage = lazy(() => import('./pages/MarketingCardPage'));
const MonthlyAnalysis = lazy(() => import('./pages/MonthlyAnalysis'));
const CollectionSearch = lazy(() => import('./pages/CollectionSearch'));
const StoreDetail = lazy(() => import('./pages/StoreDetail'));
const AddEditBudgetEntries = lazy(() => import('./pages/AddEditBudgetEntries'));
const Maestro = lazy(() => import('./pages/Maestro'));
const DBViewer = lazy(() => import('./pages/DBViewer'));
const MaestroBrands = lazy(() => import('./pages/maestro/MaestroBrands'));
const MaestroPerfumes = lazy(() => import('./pages/maestro/MaestroPerfumes'));
const MaestroNotes = lazy(() => import('./pages/maestro/MaestroNotes'));
const MaestroPerfumers = lazy(() => import('./pages/maestro/MaestroPerfumers'));
const MaestroQuotes = lazy(() => import('./pages/maestro/MaestroQuotes'));
const MaestroGlossary = lazy(() => import('./pages/maestro/MaestroGlossary'));
const MaestroStores = lazy(() => import('./pages/maestro/MaestroStores'));
const MaestroCategories = lazy(() => import('./pages/maestro/MaestroCategories'));
const MaestroBulkAddBrands = lazy(() => import('./pages/maestro/MaestroBulkAddBrands'));
const MaestroBulkAddPerfumes = lazy(() => import('./pages/maestro/MaestroBulkAddPerfumes'));
const MaestroBulkAddNotes = lazy(() => import('./pages/maestro/MaestroBulkAddNotes'));
const MaestroBulkAddPerfumers = lazy(() => import('./pages/maestro/MaestroBulkAddPerfumers'));
const MaestroBulkAddQuotes = lazy(() => import('./pages/maestro/MaestroBulkAddQuotes'));
const MaestroBulkAddGlossary = lazy(() => import('./pages/maestro/MaestroBulkAddGlossary'));
const MaestroBulkAddStores = lazy(() => import('./pages/maestro/MaestroBulkAddStores'));
const MaestroOdorFamilies = lazy(() => import('./pages/maestro/MaestroOdorFamilies'));
const MaestroEnums = lazy(() => import('./pages/maestro/MaestroEnums'));
const MaestroWisdom = lazy(() => import('./pages/maestro/MaestroWisdom'));
const MaestroAppFeatures = lazy(() => import('./pages/maestro/MaestroAppFeatures'));
const Shopping = lazy(() => import('./pages/Shopping'));
const ShopReportPage = lazy(() => import('./pages/ShopReportPage'));
const ShopProductDetail = lazy(() => import('./pages/ShopProductDetail'));
const IncompleteWisdom = lazy(() => import('./pages/IncompleteWisdom'));
const Bookmarks = lazy(() => import('./pages/Bookmarks'));
const ShopCategoryDetail = lazy(() => import('./pages/ShopCategoryDetail'));
const HeadacheSensitivity = lazy(() => import('./pages/HeadacheSensitivity'));
const SinusSensitivity = lazy(() => import('./pages/SinusSensitivity'));
const Wishlist = lazy(() => import('./pages/Wishlist'));
const MyPerfumes = lazy(() => import('./pages/MyPerfumes'));
const ProcessDashboard = lazy(() => import('./pages/ProcessDashboard'));
const ProcessDetail = lazy(() => import('./pages/ProcessDetail'));
const AddProcess = lazy(() => import('./pages/AddProcess'));
const NewCollection = lazy(() => import('./pages/NewCollection'));
const Recommendations = lazy(() => import('./pages/Recommendations'));
const ProcessBackup = lazy(() => import('./pages/ProcessBackup'));
import AutoSeedSplash from './components/layout/AutoSeedSplash';


const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  const routeFallback = (
    <div className="fixed inset-0 flex items-center justify-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
    </div>
  );
  return (
    <Suspense fallback={routeFallback}>
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Perfumes />} />
        <Route path="/home" element={<Home />} />
        <Route path="/perfumes" element={<Perfumes />} />
        <Route path="/explore" element={<Explore />} />
        <Route path="/guide" element={<FlaconGuide />} />
        <Route path="/accords-guide" element={<AccordsGuide />} />
        <Route path="/perfume-index" element={<PerfumeIndex />} />
        <Route path="/progress" element={<Statistics />} />
        <Route path="/add" element={<AddPerfume />} />
        <Route path="/lists" element={<Lists />} />
        <Route path="/brands" element={<Brands />} />
        <Route path="/perfume" element={<PerfumeDetail />} />
        <Route path="/wear" element={<WearHistory />} />
        <Route path="/goals" element={<Goals />} />
        <Route path="/layering" element={<Layering />} />
        <Route path="/blog" element={<Blog />} />
        <Route path="/blog-detail" element={<BlogDetail />} />
        <Route path="/app-info" element={<AppInfo />} />
        <Route path="/backup" element={<Backup />} />
        <Route path="/compare" element={<Compare />} />
        <Route path="/collection-view" element={<CollectionView />} />
        <Route path="/brand-collection" element={<BrandCollectionDetail />} />
        <Route path="/owner-group" element={<OwnerGroupDetail />} />
        <Route path="/samples" element={<Samples />} />
        <Route path="/quotes" element={<Quotes />} />
        <Route path="/quote" element={<QuoteDetail />} />
        <Route path="/cast-away" element={<CastAway />} />
        <Route path="/classify" element={<Classify />} />
        <Route path="/notes-accord" element={<NotesAccord />} />
        <Route path="/brand" element={<BrandDetail />} />
        <Route path="/perfumers" element={<Perfumers />} />
        <Route path="/add-perfumer" element={<AddPerfumer />} />
        <Route path="/perfumers-index" element={<PerfumersIndex />} />
        <Route path="/perfumer" element={<PerfumerDetail />} />
        <Route path="/create-sample" element={<CreateSamplePage />} />
        <Route path="/notes" element={<Notes />} />
        <Route path="/notes-index" element={<NotesIndex />} />
        <Route path="/note" element={<NoteDetail />} />
        <Route path="/occasion" element={<OccasionView />} />
        <Route path="/make-perfume" element={<MakePerfumePage />} />
        <Route path="/top-rated" element={<TopRated />} />
        <Route path="/perfume-culture" element={<PerfumeCulture />} />
        <Route path="/glossary" element={<Glossary />} />
        <Route path="/timelines" element={<Suspense fallback={<div className="px-5 pt-12 text-center text-sm font-body text-muted-foreground">…</div>}><GlossaryTimelines /></Suspense>} />
        <Route path="/glossary/timelines" element={<Suspense fallback={<div className="px-5 pt-12 text-center text-sm font-body text-muted-foreground">…</div>}><GlossaryTimelines /></Suspense>} />
        <Route path="/reading-guide" element={<ReadingGuide />} />
        <Route path="/glossary-term" element={<GlossaryTermDetail />} />
        <Route path="/at" element={<At />} />
        <Route path="/budget" element={<Budget />} />
        <Route path="/marketing-card" element={<MarketingCardPage />} />
        <Route path="/monthly-analysis" element={<MonthlyAnalysis />} />
        <Route path="/store" element={<StoreDetail />} />
        <Route path="/collection-search" element={<CollectionSearch />} />
        <Route path="/budget-entries" element={<AddEditBudgetEntries />} />
        <Route path="/admin/db-viewer" element={<DBViewer />} />
        <Route element={<MaestroGate />}>
          <Route path="/maestro" element={<Maestro />} />
          <Route path="/maestro/db-viewer" element={<DBViewer />} />
          <Route path="/maestro/brands" element={<MaestroBrands />} />
          <Route path="/maestro/perfumes" element={<MaestroPerfumes />} />
          <Route path="/maestro/notes" element={<MaestroNotes />} />
          <Route path="/maestro/perfumers" element={<MaestroPerfumers />} />
          <Route path="/maestro/quotes" element={<MaestroQuotes />} />
          <Route path="/maestro/glossary" element={<MaestroGlossary />} />
          <Route path="/maestro/perfume-stores" element={<MaestroStores />} />
          <Route path="/maestro/categories" element={<MaestroCategories />} />
          <Route path="/maestro/brands/bulk-add" element={<MaestroBulkAddBrands />} />
          <Route path="/maestro/perfumes/bulk-add" element={<MaestroBulkAddPerfumes />} />
          <Route path="/maestro/notes/bulk-add" element={<MaestroBulkAddNotes />} />
          <Route path="/maestro/perfumers/bulk-add" element={<MaestroBulkAddPerfumers />} />
          <Route path="/maestro/quotes/bulk-add" element={<MaestroBulkAddQuotes />} />
          <Route path="/maestro/glossary/bulk-add" element={<MaestroBulkAddGlossary />} />
          <Route path="/maestro/perfume-stores/bulk-add" element={<MaestroBulkAddStores />} />
          <Route path="/maestro/odor-families" element={<MaestroOdorFamilies />} />
          <Route path="/maestro/enums" element={<MaestroEnums />} />
          <Route path="/maestro/wisdom" element={<MaestroWisdom />} />
          <Route path="/maestro/app-features" element={<MaestroAppFeatures />} />
        </Route>
        <Route path="/shopping" element={<Shopping />} />
        <Route path="/shop-report" element={<ShopReportPage />} />
        <Route path="/shop-product" element={<ShopProductDetail />} />
        <Route path="/shop-category/:categoryId" element={<ShopCategoryDetail />} />
        <Route path="/incomplete-wisdom" element={<IncompleteWisdom />} />
        <Route path="/notebook" element={<Bookmarks />} />
        <Route path="/bookmarks" element={<Navigate to="/notebook" replace />} />
        <Route path="/headache" element={<HeadacheSensitivity />} />
        <Route path="/headache-guide" element={<HeadacheGuide />} />
        <Route path="/sinus" element={<SinusSensitivity />} />
        <Route path="/wishlist" element={<Wishlist />} />
        <Route path="/my-perfumes" element={<MyPerfumes />} />
        <Route path="/new-collection" element={<NewCollection />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/process" element={<ProcessDashboard />} />
        <Route path="/process/:id" element={<ProcessDetail />} />
        <Route path="/add-process" element={<AddProcess />} />
        <Route path="/process-backup" element={<ProcessBackup />} />
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
    </Suspense>
  );
};


// تعطيل كامل للمايسترو: لا تُفتح مساراته إلا إذا فعّله المستخدم من الإعدادات.
function MaestroGate() {
  return getSecureStorage("showMaestroNav", false) ? <Outlet /> : <Navigate to="/" replace />;
}

function App() {

  return (
    <LanguageProvider>
      <AuthProvider>
        <QueryClientProvider client={queryClientInstance}>
          <AutoSeedSplash>
            <Router>
              <ScrollToTop />
              <AuthenticatedApp />
            </Router>
            <Toaster />
            <SonnerToaster
              position="top-center"
              richColors
              closeButton
              toastOptions={{ style: { fontFamily: "var(--font-body)" } }}
            />
          </AutoSeedSplash>
        </QueryClientProvider>
      </AuthProvider>
    </LanguageProvider>
  )
}

export default App