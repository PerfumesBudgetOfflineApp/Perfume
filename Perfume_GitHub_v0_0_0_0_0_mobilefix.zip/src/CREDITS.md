# Credits & Attribution — Perfume Vault

Perfume Vault is built on top of excellent open-source projects and data sources. We deeply appreciate and acknowledge all contributors and creators.

---

## 🎯 Core Framework & Libraries

### Frontend Framework
- **React** — Facebook/Meta
  - License: MIT
  - https://react.dev
  - Powers all UI rendering and component system

- **React Router** — Remix Software
  - License: MIT
  - https://reactrouter.com
  - Client-side routing and navigation

- **Vite** — Evan You & Contributors
  - License: MIT
  - https://vitejs.dev
  - Build tool and dev server

---

## 🎨 UI & Styling

### Component Library
- **shadcn/ui** — Shadcn
  - License: MIT
  - https://ui.shadcn.com
  - Pre-built, accessible React components

- **TailwindCSS** — Tailwind Labs
  - License: MIT
  - https://tailwindcss.com
  - Utility-first CSS framework

### Icons
- **Lucide React** — Lucide Contributors
  - License: ISC
  - https://lucide.dev
  - Beautiful SVG icon library (all icons used locally)

### Animations & Effects
- **Framer Motion** — Framer
  - License: MIT
  - https://www.framer.com/motion
  - Declarative animations and gestures

- **Canvas Confetti** — Kirill Vasiltsov
  - License: ISC
  - Celebration effects and confetti animations

### Image Processing
- **html2canvas** — Niklas von Hertzen
  - License: MIT
  - Screenshot and canvas rendering

- **jsPDF** — ParaPDF
  - License: Apache-2.0
  - PDF generation for exports

---

## 📊 Data Management & State

- **TanStack Query (React Query)** — TanStack
  - License: MIT
  - https://tanstack.com/query
  - Server state management and data fetching

- **React Hook Form** — Bill
  - License: MIT
  - https://react-hook-form.com
  - Performant form validation

- **Zod** — Collin Fahy
  - License: MIT
  - TypeScript-first schema validation

---

## 📱 Drag & Drop, Touch, Utilities

- **@hello-pangea/dnd** — Alex Reardon
  - License: Apache-2.0
  - Beautiful drag-and-drop for lists

- **date-fns** — Sasha Koss
  - License: MIT
  - https://date-fns.org
  - Date manipulation library

- **moment.js** — Moment.js Contributors
  - License: MIT
  - Date parsing and formatting

- **Lodash** — John-David Dalton
  - License: MIT
  - Utility functions for arrays and objects

- **React Markdown** — Espen Hovlandssand
  - License: MIT
  - Render markdown in React

---

## 🗺️ Maps & Visualization

- **React Leaflet** — PaulLeCam
  - License: MIT
  - Maps integration (if needed)

- **Recharts** — Rchen
  - License: MIT
  - https://recharts.org
  - React charting library for analytics

- **Three.js** — Mr. Doob & Contributors
  - License: MIT
  - 3D graphics (if interactive models used)

---

## 🔌 Backend & Infrastructure

- **Base44 SDK** — Base44
  - Proprietary with SDK License
  - https://base44.app
  - Backend-as-a-Service platform, database, auth, functions

- **Deno** — Ryan Dahl & Contributors
  - License: MIT
  - https://deno.com
  - Secure JavaScript/TypeScript runtime for serverless functions

---

## 📝 Fonts

### Google Fonts
- **Playfair Display**
  - Designer: Claus Eggers Sørensen
  - License: Open Font License (OFL)
  - Elegant serif font for headings

- **Montserrat**
  - Designer: Julieta Ulanovsky
  - License: Open Font License (OFL)
  - Modern sans-serif for body text

---

## 🌍 Data Sources & References

### Perfume Database
- **FragranceBuy.ca** — Public data
- **Fragrantica.com** — Publicly available fragrance information
- **Noteworthyology** — Educational fragrance notes
- **Perfume Industry Sources** — Brand and perfumer information

### Fragrance Notes & Families
- **Fragrantica** — Comprehensive notes database
- **Basenotes** — Community fragrance data
- **Perfume Industry Standards** — IFRA, fragrance families

### Perfumer Information
- **Public biographies** and historical records
- **Brand official websites**
- **Industry publications** and databases

---

## 🎓 Inspiration & Resources

- **Fragrantica.com** — Community and education
- **Basenotes.com** — Fragrance discussions and education
- **The Perfumed Court** — Niche fragrance education
- **Fragrance Industry Publications** — Technical and creative inspiration

---

## 🙏 Special Thanks

### Design & UX
- Inspiration from modern SaaS design patterns
- Color theory and accessibility principles
- Mobile-first responsive design practices

### Accessibility
- WCAG 2.1 guidelines implementation
- Screen reader testing
- Keyboard navigation patterns

### Localization
- Bilingual design (English & Arabic)
- RTL layout support
- Cultural sensitivity in UI/UX

---

## 📦 Package Dependencies

Full list of npm packages and versions:

```json
{
  "dependencies": {
    "@base44/sdk": "^0.8.27",
    "@base44/vite-plugin": "^1.0.15",
    "@hello-pangea/dnd": "^17.0.0",
    "@hookform/resolvers": "^4.1.2",
    "@radix-ui/*": "^1.x (multiple packages)",
    "@stripe/react-stripe-js": "^3.0.0",
    "@stripe/stripe-js": "^5.2.0",
    "@tanstack/react-query": "^5.84.1",
    "canvas-confetti": "^1.9.4",
    "class-variance-authority": "^0.7.1",
    "date-fns": "^3.6.0",
    "framer-motion": "^11.16.4",
    "html2canvas": "^1.4.1",
    "jspdf": "^4.0.0",
    "lodash": "^4.17.21",
    "lucide-react": "^0.475.0",
    "moment": "^2.30.1",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "react-hook-form": "^7.54.2",
    "react-leaflet": "^4.2.1",
    "react-markdown": "^9.0.1",
    "react-quill": "^2.0.0",
    "react-router-dom": "^6.26.0",
    "recharts": "^2.15.4",
    "tailwindcss": "^3.x",
    "zod": "^3.24.2"
  }
}
```

See `package.json` for complete, up-to-date versions.

---

## 📜 License Compliance

Each dependency maintains its own license. Common licenses used:

- **MIT** — Permissive, allows modification and distribution with attribution
- **Apache 2.0** — Permissive, patent protection included
- **ISC** — Simplified MIT license
- **OFL (Open Font License)** — Fonts may be freely used and modified

All licenses are respected. No conflicting dependencies are included.

---

## 🔗 Open Source Contribution

We benefit from the incredible open-source community. If you enjoy this app, consider:

1. ⭐ Starring projects you love on GitHub
2. 🤝 Contributing bug fixes and features
3. 📝 Reporting issues responsibly
4. 💬 Engaging in community discussions

---

## 📋 Attribution Requirements

If you fork or modify this project, you must:

✅ Retain all original copyright notices  
✅ Include the LICENSE.md file  
✅ Include the CREDITS.md file  
✅ List modifications prominently  
✅ Provide attribution to original creators  

---

## 🆘 License Questions

For licensing questions or inquiries about commercial use:
- See [LICENSE.md](./LICENSE.md)
- Contact original creators for permissions

---

**Last Updated:** May 12, 2026  
**Version:** 1.0  
**Maintained By:** Perfume Vault Team