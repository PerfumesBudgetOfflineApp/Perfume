# Deployment Guide — Base44 Setup

Complete step-by-step guide to deploy Perfume Vault to Base44.

---

## Prerequisites

- ✅ Base44 account created
- ✅ App ID from Base44 dashboard
- ✅ Node.js 18+
- ✅ Git & GitHub account (optional, for syncing)

---

## Step 1: Create Base44 App

1. Login to [Base44 Dashboard](https://dashboard.base44.app)
2. Click **"Create New App"**
3. Enter app name: `Perfume Vault` (or your choice)
4. Select **React** as template
5. Copy your **App ID** (you'll need this)

---

## Step 2: Setup Environment

Create `.env.local` in your project root:

```env
VITE_BASE44_APP_ID=your-app-id-from-step-1
VITE_BASE44_FUNCTIONS_VERSION=production
VITE_BASE44_APP_BASE_URL=https://your-app-name.base44.app
```

**Note:** Replace `your-app-name` with your actual Base44 app subdomain.

---

## Step 3: Build & Deploy

### Option A: Direct Upload (Recommended)

```bash
# Build the app
npm run build

# The build folder is ready to upload to Base44
# Go to Base44 Dashboard → Your App → Settings → Upload Files
# Drag & drop the entire `dist` folder
```

### Option B: GitHub Sync (Advanced)

1. Push your code to GitHub
2. In Base44 Dashboard → **Integrations** → **GitHub**
3. Connect your GitHub repo
4. Select `dist` folder for deployment
5. Auto-deploys on every push to `main` branch

---

## Step 4: Initialize Database

After deployment, your app is live but empty. Initialize it:

### Access Maestro Mode

1. Open your deployed app
2. Go to **Settings** (gear icon, top right)
3. Toggle **"Maestro Mode"** to ON
4. Refresh page
5. You'll see a **"Maestro"** tab in navigation

### Run Seed Functions (In Order)

In **Settings → Maestro Mode**, run these in sequence:

#### 1️⃣ Seed Shop Categories
- Initializes store category system
- Time: ~5 seconds

#### 2️⃣ Seed Built-in Perfumes
- Loads 130,000+ fragrances
- Includes brands, notes, collections
- **⏱️ Time: 2-5 minutes** (be patient!)
- Status indicator shows progress

#### 3️⃣ Seed Perfumers
- Adds 1000+ renowned perfumers
- Time: ~1 minute

#### 4️⃣ Seed Wisdom & Quotes
- Loads inspirational quotes
- Time: ~10 seconds

#### 5️⃣ Seed Timeline (Optional)
- Historical data about fragrances
- Time: ~2 minutes

---

## Step 5: Verify Setup

After seeding:

1. ✅ Go to **Perfumes** tab
2. ✅ Search for "Dior" or any famous brand
3. ✅ You should see results immediately
4. ✅ Go to **Brands** — browse available brands
5. ✅ Go to **Perfumers** — see creator profiles
6. ✅ Go to **Notes** — explore fragrance notes

If data appears → **Deployment successful!** 🎉

---

## Step 6: Add Users

### If App is Private
1. Settings → **Invite Users**
2. Enter email addresses
3. Send invitations
4. Users join and create profiles

### If App is Public
- Anyone can access via shared link
- Each user gets their own profiles (person1, person2)
- Data is isolated per user

---

## Step 7: Customize (Optional)

### Change App Colors
- Edit `index.css`
- Modify CSS variables (`--primary`, `--secondary`, etc.)
- Redeploy

### Update Branding
- Edit `index.html` title & description
- Change favicon in `index.html`
- Update in `tailwind.config.js`

### Add Custom Perfumes
- Go to **Maestro Mode** → **Perfumes**
- Use **Bulk Add** for CSV/JSON import
- Or add manually

---

## Step 8: GitHub Backup (Optional)

To sync your code with GitHub for version control:

```bash
# Initialize Git (if not already)
git init
git add .
git commit -m "Initial commit: Perfume Vault"
git remote add origin https://github.com/your-username/perfume-vault.git
git push -u origin main
```

Then in Base44 Dashboard:
- **Integrations** → **GitHub**
- Connect repo
- Enable auto-deployment

---

## Common Issues & Solutions

### ❌ "App Not Found"
- Verify App ID in `.env.local`
- Check that your app is created in Base44 dashboard
- Redeploy files to correct app

### ❌ Seeding Takes Too Long
- Normal! "Seed Built-in Perfumes" processes 130K items
- Don't refresh page during seeding
- Monitor browser console for errors

### ❌ "No Perfumes Found"
- Verify seeding completed
- Check browser console for errors
- Manually run seed functions again from Maestro Mode

### ❌ Mobile App Looks Broken
- Clear browser cache
- Try incognito/private mode
- Check that app is deployed to correct URL

### ❌ Language Switching Not Working
- Settings → Language
- Refresh page
- Check that translations are loaded (see `data/translations/`)

---

## Performance Tips

1. **Cache & CDN** — Base44 auto-handles static assets
2. **Database Indexes** — Already optimized for common queries
3. **Image Compression** — Upload optimized images (~100KB max per image)
4. **Pagination** — Built-in for large datasets

---

## Security Checklist

- ✅ Auth enabled (no public access to data by default)
- ✅ RLS applied to user-personal data (UserPerfume, BudgetExpense, etc.)
- ✅ Built-in data readable by all (Perfume, Brand, Note, etc.)
- ✅ No sensitive API keys in frontend code
- ✅ Token managed by Base44 SDK automatically

---

## Monitoring & Maintenance

### Monitor App Health
- Base44 Dashboard → **Analytics** → View usage stats
- Check function execution logs
- Monitor error rates

### Backup Your Data
- Go to **Settings** → **Backup / Restore**
- Download JSON backup monthly
- Store in Google Drive or similar

### Update Code
1. Make changes locally
2. Test with `npm run dev`
3. Build: `npm run build`
4. Re-upload to Base44 (or auto-deploys via GitHub)

---

## Next Steps

1. ✅ Users set up profiles in Settings
2. ✅ Start adding personal perfume data
3. ✅ Enable Maestro Mode for advanced features
4. ✅ Customize colors/branding if desired
5. ✅ Set up regular backups

---

## Support

- 📖 See [README.md](./README.md) for general info
- 🗺️ See [ROADMAP.md](./ROADMAP.md) for upcoming features
- 🆘 Base44 Help: [https://base44.app/docs](https://base44.app/docs)

---

**Deployment completed!** Your Perfume Vault is now live and ready for use. 🎉