# App Roadmap & To-Do List

## 🚀 Big Goal: Standalone Android App (Google Play)
Make the app fully independent — no Base44 subscription needed, data stored on user's device, free on Google Play.

---

## 📋 Migration To-Do List

### Step 1: Local Database Layer (IndexedDB)
- [ ] Create `lib/localDB.js` — IndexedDB wrapper with same API as Base44 entities
- [ ] Migrate all entities: Perfume, UserPerfume, PerfumeBrand, WearLog, BudgetExpense, BudgetIncome, BudgetAllocation, Goals, BlogPost, etc.
- [ ] Replace all `base44.entities.X.list/create/update/delete` calls across every page
- [ ] Test data persistence across page reloads

### Step 2: Remove Authentication Dependency
- [ ] Replace Base44 auth with local profile setup (no login needed)
- [ ] Store user profile (name, photo, settings) in IndexedDB / localStorage
- [ ] Remove `AuthProvider` / `useAuth` dependencies

### Step 3: Remove Backend Functions
- [ ] Replace `base44.integrations.Core.InvokeLLM` (AI features) — either remove or use a free AI API key stored locally
- [ ] Replace `base44.integrations.Core.UploadFile` — use local file storage / base64
- [ ] Remove all backend function calls (`base44.functions.invoke`)

### Step 4: PWA Setup
- [ ] Create `public/manifest.json` with app name, icons, theme colors
- [ ] Add service worker for offline asset caching
- [ ] Test "Add to Home Screen" on Android

### Step 5: Capacitor Setup (APK Build)
- [ ] Install Capacitor: `npm install @capacitor/core @capacitor/android`
- [ ] Initialize Capacitor project
- [ ] Build React app: `npm run build`
- [ ] Add Android platform: `npx cap add android`
- [ ] Sync: `npx cap sync`
- [ ] Open in Android Studio and build APK

### Step 6: Google Play
- [ ] Create Google Play Developer account ($25 one-time fee)
- [ ] Prepare store listing (screenshots, description, icon)
- [ ] Sign the APK
- [ ] Submit for review

---

## 🔄 Current Status
- [x] App fully built on Base44 (React + cloud database)
- [x] Backup/restore page exists (JSON export)
- [ ] Local database layer — **NEXT UP**

---

## 📝 Notes
- Reuse ~80% of existing React component code
- Only the data layer needs to change (Base44 SDK → IndexedDB)
- AI features (InvokeLLM) can be kept with a user-provided API key or removed
- Target: Free app, no subscription, data on device only