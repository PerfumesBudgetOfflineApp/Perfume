import { ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import MakePerfumeComponent from "@/components/notes/MakePerfume";
import AIRecommendations from "@/components/notes/AIRecommendations";

export default function MakePerfumePage() {
  const navigate = useNavigate();

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-gradient-to-br from-purple-900 to-indigo-950 pt-14 pb-6 px-5">
        <Button variant="ghost" size="icon" className="absolute top-10 left-4 rounded-none text-white hover:bg-white/20" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="text-center text-white space-y-1 mt-2">
          <div className="w-12 h-12 bg-white/20 rounded-none flex items-center justify-center mx-auto mb-3">
            <span className="text-2xl">✨</span>
          </div>
          <h1 className="font-heading text-2xl font-bold">المازج The Mixer</h1>
          <p className="text-purple-200 text-sm font-body">صمّم مزجات و احصل على توصيات ذكية Design blends & get AI-powered recommendations</p>
        </div>
      </div>

      <div className="px-4 pt-4">
        <Tabs defaultValue="mixer">
          <TabsList className="w-full bg-secondary/50 p-1 rounded-none grid grid-cols-2 mb-4">
            <TabsTrigger value="mixer" className="rounded-none text-xs font-body gap-1.5 data-[state=active]:bg-card data-[state=active]:shadow-sm">
              🧪 Mixer
            </TabsTrigger>
            <TabsTrigger value="ai" className="rounded-none text-xs font-body gap-1.5 data-[state=active]:bg-card data-[state=active]:shadow-sm">
              🤖 AI Recommendations
            </TabsTrigger>
          </TabsList>
          <TabsContent value="mixer">
            <MakePerfumeComponent />
          </TabsContent>
          <TabsContent value="ai">
            <AIRecommendations />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}