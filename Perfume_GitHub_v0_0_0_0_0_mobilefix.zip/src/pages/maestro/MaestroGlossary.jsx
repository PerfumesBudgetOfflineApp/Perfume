import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search, Layers } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

export default function MaestroGlossary() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItem, setNewItem] = useState({});
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["maestro-glossary"],
    queryFn: () => apphost.entities.GlossaryTerm.list("term_en"),
  });

  const filtered = items.filter(
    (g) => g.term_en?.toLowerCase().includes(search.toLowerCase()) || g.term_ar?.includes(search)
  );
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const getEdit = (g) => localEdits[g.id] ?? g;
  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({ ...prev, [id]: { ...(prev[id] ?? items.find((g) => String(g.id) === String(id))), [field]: value } }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.GlossaryTerm.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-glossary"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف؟" : "Delete?")) return;
    await apphost.entities.GlossaryTerm.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-glossary"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newItem.term_en) { toast.error((isAr ? "المصطلح الإنجليزي مطلوب" : "English term required")); return; }
    await apphost.entities.GlossaryTerm.create({ ...newItem, is_default: true });
    qc.invalidateQueries({ queryKey: ["maestro-glossary"] });
    setNewItem({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">📚 {isAr ? "مصطلحات المسرد" : "Glossary Terms"}</h1>
          <p className="text-xs text-muted-foreground">{items.length} {isAr ? "مصطلح" : "terms"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث..." : "Search..."} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/glossary/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center gap-2 mb-3 justify-center flex-wrap">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i)} className={`w-7 h-7 rounded-none text-xs ${page === i ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>{i + 1}</button>
          ))}
        </div>
      )}

      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة مصطلح" : "Add Term"}</p>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder={isAr ? "المصطلح بالإنجليزية" : "Term (EN)*"} value={newItem.term_en || ""} onChange={(e) => setNewItem({ ...newItem, term_en: e.target.value })} className="rounded-none h-9 text-xs" />
            <Input placeholder="المصطلح (عربي)" value={newItem.term_ar || ""} onChange={(e) => setNewItem({ ...newItem, term_ar: e.target.value })} className="rounded-none h-9 text-xs" dir="rtl" />
          </div>
          <Textarea placeholder="Meaning / Definition" value={newItem.meaning || ""} onChange={(e) => setNewItem({ ...newItem, meaning: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
          <Input placeholder={isAr ? "وسوم مفصولة بفاصلة" : "Tags (comma-separated)"} value={newItem.tags || ""} onChange={(e) => setNewItem({ ...newItem, tags: e.target.value })} className="rounded-none h-9 text-xs" />
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>{isAr ? "إضافة" : "Add"}</Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-3">
          {paginated.map((item) => {
            const edit = getEdit(item);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(item);
            return (
              <div key={item.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-body font-semibold">{item.term_en}</p>
                    <p className="text-xs text-muted-foreground" dir="rtl">{item.term_ar}</p>
                  </div>
                  <button onClick={() => handleDelete(item.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المصطلح بالإنجليزية" : "Term EN"}</p>
                    <Input value={edit.term_en || ""} onChange={(e) => setEdit(item.id, "term_en", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">المصطلح عربي</p>
                    <Input value={edit.term_ar || ""} onChange={(e) => setEdit(item.id, "term_ar", e.target.value)} className="h-8 rounded-none text-xs" dir="rtl" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المعنى" : "Meaning"}</p>
                    <Textarea value={edit.meaning || ""} onChange={(e) => setEdit(item.id, "meaning", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "وسوم" : "Tags"}</p>
                    <Input value={edit.tags || ""} onChange={(e) => setEdit(item.id, "tags", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الصورة" : "Image URL"}</p>
                    <Input value={edit.image_url || ""} onChange={(e) => setEdit(item.id, "image_url", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                </div>
                <Button onClick={() => handleSave(item.id)} disabled={!isDirty || saving[item.id]} className="w-full h-8 rounded-none text-xs" variant={isDirty ? "default" : "outline"}>
                  <Save className="w-3 h-3 mr-1" />
                  {saving[item.id] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ" : "💾 Save")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}