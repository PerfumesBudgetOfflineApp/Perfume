import { useState, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search, Layers, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";
import ImageUploadButton from "@/components/ui/ImageUploadButton";
import InnovationNotesSearch from "@/components/maestro/InnovationNotesSearch";
import MainNotesSearch from "@/components/maestro/MainNotesSearch";
import PerfumerSearchTag from "@/components/maestro/PerfumerSearchTag";

const GENDERS = ["Men", "Women", "Unisex"];
const SEASONS = ["Spring", "Summer", "Fall", "Winter", "All Seasons"];
const TIMES = ["Day", "Night", "All"];

function BrandSearchInCard({ brands, value, onChange }) {
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const selected = brands.find(b => String(b.id) === String(value));
  const filtered = useMemo(() => {
    if (!search) return brands.slice(0, 6);
    return brands.filter(b => b.name?.toLowerCase().includes(search.toLowerCase())).slice(0, 6);
  }, [brands, search]);

  return (
    <div className="relative">
      <div className="flex items-center gap-1.5 h-8 rounded-none border border-input bg-transparent px-2 text-xs cursor-pointer hover:bg-secondary/50 transition-colors"
        onClick={() => setOpen(!open)}>
        <Search className="w-3 h-3 text-muted-foreground flex-shrink-0" />
        <span className={selected ? "text-foreground" : "text-muted-foreground"}>{selected ? selected.name : "Select brand..."}</span>
      </div>
      {open && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-48 overflow-y-auto">
          <div className="p-1.5 border-b border-border">
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={isAr ? "ابحث عن براند" : "Search brand..."} className="h-6 rounded-none text-xs" autoFocus onClick={e => e.stopPropagation()} />
          </div>
          {filtered.map(b => (
            <button key={b.id} className={`w-full text-left px-2.5 py-1.5 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 ${value === b.id ? "text-primary font-semibold" : ""}`}
              onClick={() => { onChange(b.id, b.name); setOpen(false); setSearch(""); }}>
              {b.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function BrandSearchFilter({ brands, filterBrand, setFilterBrand, isAr }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const filtered = useMemo(() => {
    if (!search) return brands.slice(0, 8);
    return brands.filter(b => b.name?.toLowerCase().includes(search.toLowerCase())).slice(0, 8);
  }, [brands, search]);
  const selected = brands.find(b => String(b.id) === String(filterBrand));

  return (
    <div className="relative mb-3">
      <div
        className="flex items-center gap-2 h-9 rounded-none border border-input bg-transparent px-3 text-xs cursor-pointer"
        onClick={() => setOpen(!open)}
      >
        <Search className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
        <span className={selected ? "text-foreground" : "text-muted-foreground"}>
          {selected ? selected.name : (isAr ? "كل الشركات" : "All brands")}
        </span>
        {filterBrand && (
          <button className="ml-auto text-muted-foreground hover:text-foreground" onClick={(e) => { e.stopPropagation(); setFilterBrand(""); setSearch(""); }}>✕</button>
        )}
      </div>
      {open && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-20 max-h-52 overflow-y-auto">
          <div className="p-2 border-b border-border">
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={isAr ? "بحث الشركة..." : "Search brand..."} className="h-7 rounded-none text-xs" onClick={e => e.stopPropagation()} autoFocus />
          </div>
          <button className="w-full text-left px-3 py-2 text-xs font-body hover:bg-secondary border-b border-border/30 text-muted-foreground" onClick={() => { setFilterBrand(""); setSearch(""); setOpen(false); }}>
            {isAr ? "كل الشركات" : "All brands"}
          </button>
          {filtered.map(b => (
            <button key={b.id} className={`w-full text-left px-3 py-2 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 ${filterBrand === b.id ? "text-primary font-semibold" : ""}`}
              onClick={() => { setFilterBrand(b.id); setSearch(""); setOpen(false); }}>
              {b.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export default function MaestroPerfumes() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [filterBrand, setFilterBrand] = useState("");
  const [brandSearch, setBrandSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newPerfume, setNewPerfume] = useState({});
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["maestro-perfumes"],
    queryFn: () => apphost.entities.Perfume.list("name"),
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["maestro-brands-list"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: allNotes = [] } = useQuery({
    queryKey: ["maestro-notes-list"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "sub_notes" }),
  });

  const { data: lowNotes = [] } = useQuery({
    queryKey: ["maestro-low-notes-list"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "low_notes" }),
  });

  const filtered = perfumes.filter((p) => {
    const matchSearch =
      p.name?.toLowerCase().includes(search.toLowerCase()) ||
      p.brand_name?.toLowerCase().includes(search.toLowerCase());
    const matchBrand = !filterBrand || p.brand_id === filterBrand || p.brand_name === filterBrand;
    return matchSearch && matchBrand;
  });

  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const getEdit = (p) => localEdits[p.id] ?? p;

  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({
      ...prev,
      [id]: { ...(prev[id] ?? perfumes.find((p) => String(p.id) === String(id))), [field]: value },
    }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.Perfume.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-perfumes"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف هذا العطر؟" : "Delete this perfume?")) return;
    await apphost.entities.Perfume.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-perfumes"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newPerfume.name || !newPerfume.brand_name) { toast.error((isAr ? "الاسم و البراند مطلوبان" : "Name & brand required")); return; }
    await apphost.entities.Perfume.create({ ...newPerfume, is_default: true, discontinued: false, list: "none" });
    qc.invalidateQueries({ queryKey: ["maestro-perfumes"] });
    setNewPerfume({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🌹 {isAr ? "كتالوج العطور" : "Perfumes Catalog"}</h1>
          <p className="text-xs text-muted-foreground">{perfumes.length} {isAr ? "عطر" : "perfumes"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث..." : "Search..."} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/perfumes/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {/* Searchable brand filter */}
      <BrandSearchFilter
        brands={brands}
        filterBrand={filterBrand}
        setFilterBrand={(v) => { setFilterBrand(v); setPage(0); }}
        isAr={isAr}
      />

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center gap-2 mb-3 justify-center">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i)} className={`w-7 h-7 rounded-none text-xs font-body ${page === i ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>
              {i + 1}
            </button>
          ))}
        </div>
      )}
      <p className="text-[10px] text-muted-foreground text-center mb-3">{isAr ? `عرض ${paginated.length} من ${filtered.length}` : `Showing ${paginated.length} of ${filtered.length}`}</p>

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة عطر جديد" : "Add New Perfume"}</p>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder={isAr ? "الاسم بالإنجليزية" : "Name (EN)*"} value={newPerfume.name || ""} onChange={(e) => setNewPerfume({ ...newPerfume, name: e.target.value })} className="rounded-none h-9 text-xs" />
            <Input placeholder="الاسم (عربي)" value={newPerfume.name_ar || ""} onChange={(e) => setNewPerfume({ ...newPerfume, name_ar: e.target.value })} className="rounded-none h-9 text-xs" dir="rtl" />
          </div>
          <BrandSearchInCard
            brands={brands}
            value={newPerfume.brand_id || ""}
            onChange={(v, name) => setNewPerfume({ ...newPerfume, brand_id: v, brand_name: name })}
          />
          <div className="grid grid-cols-2 gap-2">
            <Select value={newPerfume.type || ""} onValueChange={(v) => setNewPerfume({ ...newPerfume, type: v })}>
              <SelectTrigger className="rounded-none h-9 text-xs"><SelectValue placeholder={isAr ? "النوع" : "Type"} /></SelectTrigger>
              <SelectContent>{PERFUME_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.value} · {t.label_ar}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={newPerfume.gender || ""} onValueChange={(v) => setNewPerfume({ ...newPerfume, gender: v })}>
              <SelectTrigger className="rounded-none h-9 text-xs"><SelectValue placeholder={isAr ? "الفئة" : "Gender"} /></SelectTrigger>
              <SelectContent>{GENDERS.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
            </Select>
            <div className="col-span-1 space-y-1">
              <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات المقدمة" : "Top Notes"}</p>
              <MainNotesSearch value={newPerfume.top_notes || ""} onChange={(v) => setNewPerfume({ ...newPerfume, top_notes: v })} placeholder={isAr ? "نوتات المقدمة" : "Top Notes..."} />
            </div>
            <div className="col-span-1 space-y-1">
              <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات القلب" : "Heart Notes"}</p>
              <MainNotesSearch value={newPerfume.heart_notes || ""} onChange={(v) => setNewPerfume({ ...newPerfume, heart_notes: v })} placeholder={isAr ? "نوتات القلب" : "Heart Notes..."} />
            </div>
            <div className="col-span-2 space-y-1">
              <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات القاعدة" : "Base Notes"}</p>
              <MainNotesSearch value={newPerfume.base_notes || ""} onChange={(v) => setNewPerfume({ ...newPerfume, base_notes: v })} placeholder={isAr ? "نوتات القاعدة" : "Base Notes..."} />
            </div>
            <div className="col-span-2 space-y-1">
              <p className="text-[9px] text-muted-foreground">✨ Innovation Notes (Sub/Low)</p>
              <InnovationNotesSearch value={newPerfume.innovation_notes || ""} onChange={(v) => setNewPerfume({ ...newPerfume, innovation_notes: v })} />
            </div>
            <Input placeholder={isAr ? "سنة الإصدار" : "Release Year"} type="number" value={newPerfume.release_year || ""} onChange={(e) => setNewPerfume({ ...newPerfume, release_year: Number(e.target.value) })} className="rounded-none h-9 text-xs" />
            <Input placeholder={isAr ? "رابط الصورة" : "Image URL"} value={newPerfume.image_url || ""} onChange={(e) => setNewPerfume({ ...newPerfume, image_url: e.target.value })} className="rounded-none h-9 text-xs" />
            <Textarea placeholder={isAr ? "الوصف" : "Description"} value={newPerfume.description || ""} onChange={(e) => setNewPerfume({ ...newPerfume, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[50px] col-span-2" />
          </div>
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>
            {isAr ? "إضافة عطر" : "Add Perfume"}
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {paginated.map((perfume) => {
            const edit = getEdit(perfume);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(perfume);
            return (
              <div key={perfume.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {perfume.image_url && <img src={perfume.image_url} className="w-8 h-8 rounded-none object-cover" alt="" />}
                    <div>
                      <p className="text-sm font-body font-semibold">{perfume.name}</p>
                      <p className="text-[10px] text-muted-foreground">{perfume.brand_name} · {perfume.type}</p>
                    </div>
                  </div>
                  <button onClick={() => handleDelete(perfume.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none transition-colors">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم بالإنجليزية" : "Name EN"}</p>
                    <Input value={edit.name || ""} onChange={(e) => setEdit(perfume.id, "name", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">الاسم عربي</p>
                    <Input value={edit.name_ar || ""} onChange={(e) => setEdit(perfume.id, "name_ar", e.target.value)} className="h-8 rounded-none text-xs" dir="rtl" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "البراند" : "Brand"}</p>
                    <BrandSearchInCard
                      brands={brands}
                      value={edit.brand_id || ""}
                      onChange={(v, name) => { setEdit(perfume.id, "brand_id", v); setEdit(perfume.id, "brand_name", name); }}
                    />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "النوع" : "Type"}</p>
                    <Select value={edit.type || ""} onValueChange={(v) => setEdit(perfume.id, "type", v)}>
                      <SelectTrigger className="h-8 rounded-none text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{PERFUME_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.value} · {t.label_ar}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الفئة" : "Gender"}</p>
                    <Select value={edit.gender || ""} onValueChange={(v) => setEdit(perfume.id, "gender", v)}>
                      <SelectTrigger className="h-8 rounded-none text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{GENDERS.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الموسم" : "Season"}</p>
                    <Select value={edit.season || ""} onValueChange={(v) => setEdit(perfume.id, "season", v)}>
                      <SelectTrigger className="h-8 rounded-none text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{SEASONS.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "وقت اليوم" : "Time of Day"}</p>
                    <Select value={edit.time_of_day || ""} onValueChange={(v) => setEdit(perfume.id, "time_of_day", v)}>
                      <SelectTrigger className="h-8 rounded-none text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>{TIMES.map((t) => <SelectItem key={t} value={t}>{t}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "سنة الإصدار" : "Release Year"}</p>
                    <Input type="number" value={edit.release_year || ""} onChange={(e) => setEdit(perfume.id, "release_year", Number(e.target.value))} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                   <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الصورة" : "Image URL"}</p>
                   <div className="flex gap-1.5 items-center">
                     <Input value={edit.image_url || ""} onChange={(e) => setEdit(perfume.id, "image_url", e.target.value)} className="h-8 rounded-none text-xs flex-1" />
                     <ImageUploadButton onUploaded={(url) => setEdit(perfume.id, "image_url", url)} />
                   </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "نوتات المقدمة" : "Top Notes"}</p>
                    <MainNotesSearch value={edit.top_notes || ""} onChange={(v) => setEdit(perfume.id, "top_notes", v)} placeholder={isAr ? "نوتات المقدمة" : "Top Notes..."} />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "نوتات القلب" : "Heart Notes"}</p>
                    <MainNotesSearch value={edit.heart_notes || ""} onChange={(v) => setEdit(perfume.id, "heart_notes", v)} placeholder={isAr ? "نوتات القلب" : "Heart Notes..."} />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "نوتات القاعدة" : "Base Notes"}</p>
                    <MainNotesSearch value={edit.base_notes || ""} onChange={(v) => setEdit(perfume.id, "base_notes", v)} placeholder={isAr ? "نوتات القاعدة" : "Base Notes..."} />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">✨ Innovation Notes (Sub/Low Combined)</p>
                    <div className="space-y-2">
                      {/* Display selected notes */}
                      <div className="flex flex-wrap gap-1 items-center bg-secondary/30 rounded-none p-2 min-h-[32px]">
                        {(edit.innovation_notes || "").split(",").map(s => s.trim()).filter(Boolean).map(note => (
                          <span key={note} className="inline-flex items-center gap-1 text-foreground text-[9px] rounded-none">
                            {note}
                            <button type="button" onClick={() => {
                              const notes = (edit.innovation_notes || "").split(",").map(s => s.trim()).filter(n => n !== note);
                              setEdit(perfume.id, "innovation_notes", notes.join(", "));
                            }} className="ml-0.5 hover:opacity-60"><X className="w-2.5 h-2.5" /></button>
                          </span>
                        ))}
                        {(edit.innovation_notes || "").split(",").map(s => s.trim()).filter(Boolean).length === 0 && (
                          <span className="text-[9px] text-muted-foreground">{isAr ? "لم تُختر نوتات" : "No notes selected"}</span>
                        )}
                      </div>
                      {/* Searchable input */}
                      <InnovationNotesSearch perfumeId={perfume.id} edit={edit} setEdit={setEdit} allNotes={allNotes} lowNotes={lowNotes} />
                    </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الوصف" : "Description"}</p>
                    <Textarea value={edit.description || ""} onChange={(e) => setEdit(perfume.id, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[50px]" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">About (EN)</p>
                    <Textarea value={edit.about || ""} onChange={(e) => setEdit(perfume.id, "about", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" />
                  </div>
                  <div className="col-span-2">
                     <p className="text-[9px] text-muted-foreground mb-1">عن العطر (عربي)</p>
                     <Textarea value={edit.about_ar || ""} onChange={(e) => setEdit(perfume.id, "about_ar", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" dir="rtl" />
                   </div>
                   <div className="col-span-2">
                     <p className="text-[9px] text-muted-foreground mb-1">👃 العطار Perfumer</p>
                     <PerfumerSearchTag
                       value={edit.perfumer_ids || ""}
                       namesValue={edit.perfumer_names || ""}
                       onChange={(ids, names) => { setEdit(perfume.id, "perfumer_ids", ids); setEdit(perfume.id, "perfumer_names", names); }}
                     />
                   </div>
                  </div>

                <Button
                  onClick={() => handleSave(perfume.id)}
                  disabled={!isDirty || saving[perfume.id]}
                  className="w-full h-8 rounded-none text-xs"
                  variant={isDirty ? "default" : "outline"}
                >
                  <Save className="w-3 h-3 mr-1" />
                  {saving[perfume.id] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ التعديلات" : "💾 Save Changes")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}