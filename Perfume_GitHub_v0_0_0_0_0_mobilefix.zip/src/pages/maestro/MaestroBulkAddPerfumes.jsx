import { useState, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, CheckCircle2, Search, Upload } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";
import MainNotesSearch from "@/components/maestro/MainNotesSearch";
import InnovationNotesSearch from "@/components/maestro/InnovationNotesSearch";

const GENDERS = ["Men", "Women", "Unisex"];

function BrandSearchInRow({ brands, value, onChange, disabled, isAr }) {
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const selected = brands.find(b => String(b.id) === String(value));
  const filtered = useMemo(() => {
    if (!search) return brands.slice(0, 6);
    return brands.filter(b => b.name?.toLowerCase().includes(search.toLowerCase())).slice(0, 6);
  }, [brands, search]);
  if (disabled) return <div className="h-9 rounded-none border border-input px-3 flex items-center text-xs text-muted-foreground bg-secondary/30">{selected?.name || (isAr ? "تم الاختيار" : "Selected")}</div>;
  return (
    <div className="relative col-span-2">
      <div className="flex items-center gap-1.5 h-9 rounded-none border border-input bg-transparent px-2 text-xs cursor-pointer hover:bg-secondary/50"
        onClick={() => setOpen(!open)}>
        <Search className="w-3 h-3 text-muted-foreground flex-shrink-0" />
        <span className={selected ? "text-foreground" : "text-muted-foreground"}>{selected ? selected.name : (isAr ? "اختر الشركة*" : "Select Brand*")}</span>
      </div>
      {open && (
        <div className="absolute top-full left-0 right-0 bg-card border border-border rounded-none mt-1 shadow-lg z-30 max-h-44 overflow-y-auto">
          <div className="p-1.5 border-b border-border">
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder={isAr ? "بحث الشركة..." : "Search brand..."} className="h-6 rounded-none text-xs" autoFocus onClick={e => e.stopPropagation()} />
          </div>
          {filtered.map(b => (
            <button key={b.id} className={`w-full text-left px-2.5 py-1.5 text-xs font-body hover:bg-secondary border-b border-border/30 last:border-b-0 ${value === b.id ? "text-primary font-semibold" : ""}`}
              onClick={() => { onChange(b.id, b.name); setOpen(false); setSearch(""); }}>
              {b.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

const emptyPerfume = () => ({ name: "", name_ar: "", brand_id: "", brand_name: "", type: "", gender: "", top_notes: "", heart_notes: "", base_notes: "", innovation_notes: "", description: "", collection_id: "", collection_name: "" });

export default function MaestroBulkAddPerfumes() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [rows, setRows] = useState(() => Array.from({ length: 20 }, emptyPerfume));
  const [savedRows, setSavedRows] = useState({});
  const [saving, setSaving] = useState({});

  const { data: brands = [] } = useQuery({
    queryKey: ["maestro-brands-list"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: allCollections = [] } = useQuery({
    queryKey: ["maestro-collections-list"],
    queryFn: () => apphost.entities.PerfumeCollection.list("name"),
  });

  const setField = (idx, field, val) => {
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleSaveRow = async (idx) => {
    const row = rows[idx];
    if (!row.name || !row.brand_name) { toast.error(isAr ? "الاسم و الشركة مطلوبان" : "Name & brand required"); return; }
    setSaving((p) => ({ ...p, [idx]: true }));
    await apphost.entities.Perfume.create({ ...row, is_default: true, discontinued: false, list: "none" });
    setSaving((p) => ({ ...p, [idx]: false }));
    setSavedRows((p) => ({ ...p, [idx]: true }));
    qc.invalidateQueries({ queryKey: ["maestro-perfumes"] });
    toast.success(isAr ? `تم حفظ السطر ${idx + 1} بنجاح في قاعدة بيانات التطبيق` : `Row ${idx + 1} saved successfully to app database`);
  };

  const handleSaveAll = async () => {
    const valid = rows.filter((r, i) => r.name && r.brand_name && !savedRows[i]);
    if (!valid.length) { toast.error(isAr ? "لا توجد صفوف جديدة للحفظ" : "No new rows to save"); return; }
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].name && rows[i].brand_name && !savedRows[i]) await handleSaveRow(i);
    }
    toast.success(isAr ? "تم حفظ جميع العطور بنجاح" : "All perfumes saved successfully");
  };

  const handleJsonImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const text = await file.text();
      const data = JSON.parse(text);
      const items = Array.isArray(data) ? data : [data];
      
      let imported = 0;
      for (const item of items) {
        if (item.name || item.name_en) {
          await apphost.entities.Perfume.create({
            ...item,
            name_en: item.name || item.name_en,
            is_default: true,
            discontinued: false,
            list: "none",
          });
          imported++;
        }
      }
      qc.invalidateQueries({ queryKey: ["maestro-perfumes"] });
      toast.success(isAr ? `تم استيراد ${imported} عطر` : `Imported ${imported} perfumes`);
      e.target.value = "";
    } catch (err) {
      toast.error(isAr ? "خطأ في الملف" : "Invalid JSON file");
    }
  };

  const addRow = () => setRows((p) => [...p, emptyPerfume()]);
  const removeRow = (idx) => setRows((p) => p.filter((_, i) => i !== idx));

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro/perfumes" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🌹 {isAr ? "إضافة عطور دفعة واحدة" : "Bulk Add Perfumes"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "أضف حتى 20 عطر مرة واحدة إلى قاعدة بيانات التطبيق" : "Add up to 20 perfumes at once to the app database"}</p>
        </div>
      </div>

      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-none p-3 mb-4">
        <p className="text-xs text-amber-800 dark:text-amber-300 font-body">
          {isAr ? "⚠️ كل عطر يُحفظ مباشرة في قاعدة بيانات التطبيق بمجرد الضغط على زر الحفظ" : "⚠️ Each perfume is saved directly to the built-in app database when you click Save"}
        </p>
      </div>

      <div className="flex gap-2 mb-4">
        <Button className="flex-1 rounded-none" onClick={handleSaveAll}>
          <Save className="w-4 h-4 mr-2" />
          {isAr ? "حفظ الجميع" : "Save All"}
        </Button>
        <label className="flex-1">
          <Button type="button" variant="outline" className="w-full rounded-none" asChild>
            <div className="cursor-pointer">
              <Upload className="w-4 h-4 mr-2" />
              {isAr ? "استيراد JSON" : "Import JSON"}
            </div>
          </Button>
          <input type="file" accept=".json" onChange={handleJsonImport} className="hidden" />
        </label>
      </div>

      <div className="space-y-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`border rounded-none p-4 space-y-2 transition-colors ${savedRows[idx] ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700" : "bg-card border-border/50"}`}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-body font-bold text-muted-foreground">#{idx + 1}</span>
                {savedRows[idx] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {savedRows[idx] && <span className="text-[10px] text-emerald-600 font-body font-semibold">{isAr ? "تم الحفظ في قاعدة البيانات" : "Saved to database"}</span>}
              </div>
              <button onClick={() => removeRow(idx)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input placeholder={isAr ? "الاسم (إنجليزي)*" : "Name (EN)*"} value={row.name} onChange={(e) => setField(idx, "name", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "الاسم (عربي)" : "Name (AR)"} value={row.name_ar} onChange={(e) => setField(idx, "name_ar", e.target.value)} className="h-9 rounded-none text-xs" dir="rtl" disabled={savedRows[idx]} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <BrandSearchInRow
                brands={brands}
                value={row.brand_id || ""}
                onChange={(v, name) => { setField(idx, "brand_id", v); setField(idx, "brand_name", name); }}
                disabled={savedRows[idx]}
                isAr={isAr}
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Select value={row.type || ""} onValueChange={(v) => setField(idx, "type", v)} disabled={savedRows[idx]}>
                <SelectTrigger className="rounded-none h-9 text-xs"><SelectValue placeholder={isAr ? "النوع" : "Type"} /></SelectTrigger>
                <SelectContent>{PERFUME_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.value} · {t.label_ar}</SelectItem>)}</SelectContent>
              </Select>
              <Select value={row.gender || ""} onValueChange={(v) => setField(idx, "gender", v)} disabled={savedRows[idx]}>
                <SelectTrigger className="rounded-none h-9 text-xs"><SelectValue placeholder={isAr ? "الفئة" : "Gender"} /></SelectTrigger>
                <SelectContent>{GENDERS.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}</SelectContent>
              </Select>
              <div className="col-span-1 space-y-1">
                <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات القمة" : "Top Notes"}</p>
                <MainNotesSearch value={row.top_notes} onChange={(v) => setField(idx, "top_notes", v)} placeholder={isAr ? "نوتات القمة..." : "Top Notes..."} disabled={savedRows[idx]} />
              </div>
              <div className="col-span-1 space-y-1">
                <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات القلب" : "Heart Notes"}</p>
                <MainNotesSearch value={row.heart_notes} onChange={(v) => setField(idx, "heart_notes", v)} placeholder={isAr ? "نوتات القلب..." : "Heart Notes..."} disabled={savedRows[idx]} />
              </div>
              <div className="col-span-2 space-y-1">
                <p className="text-[9px] text-muted-foreground">{isAr ? "نوتات القاعدة" : "Base Notes"}</p>
                <MainNotesSearch value={row.base_notes} onChange={(v) => setField(idx, "base_notes", v)} placeholder={isAr ? "نوتات القاعدة..." : "Base Notes..."} disabled={savedRows[idx]} />
              </div>
              <div className="col-span-2 space-y-1">
                <p className="text-[9px] text-muted-foreground">{isAr ? "✨ نوتات ابتكارية (Sub/Low)" : "✨ Innovation Notes (Sub/Low)"}</p>
                <InnovationNotesSearch value={row.innovation_notes} onChange={(v) => setField(idx, "innovation_notes", v)} disabled={savedRows[idx]} />
              </div>
              <Textarea placeholder={isAr ? "الوصف" : "Description"} value={row.description} onChange={(e) => setField(idx, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[48px] col-span-2" disabled={savedRows[idx]} />
              {/* Collection — only shows collections for the selected brand */}
              {row.brand_id && (
                <div className="col-span-2">
                  <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المجموعة (اختياري)" : "Collection (optional)"}</p>
                  <select
                    value={row.collection_id || ""}
                    onChange={e => {
                      const col = allCollections.find(c => String(c.id) === String(e.target.value));
                      setField(idx, "collection_id", e.target.value);
                      setField(idx, "collection_name", col?.name || "");
                    }}
                    disabled={savedRows[idx]}
                    className="w-full h-9 rounded-none border border-input bg-transparent px-2 text-xs font-body"
                  >
                    <option value="">{isAr ? "— بدون مجموعة" : "— No Collection"}</option>
                    {allCollections.filter(c => c.brand_id === row.brand_id).map(c => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>
              )}
            </div>
            {!savedRows[idx] && (
              <Button size="sm" className="w-full h-8 rounded-none text-xs" onClick={() => handleSaveRow(idx)} disabled={saving[idx]}>
                <Save className="w-3 h-3 mr-1" />
                {saving[idx] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ هذا السطر" : "💾 Save this row")}
              </Button>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full mt-4 rounded-none" onClick={addRow}>
        {isAr ? "إضافة سطر جديد" : "Add Row"}
      </Button>
    </div>
  );
}