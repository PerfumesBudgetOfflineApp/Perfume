import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Trash2, Save } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

// These are stored in localStorage as custom lists that can be used as suggestions
// in notes, perfumes, etc. They're not entities — they're managed reference lists.
const STORAGE_KEY_FAMILIES = "maestro_odor_families";
const STORAGE_KEY_CATEGORIES = "maestro_note_categories";

const DEFAULT_FAMILIES = [
  "Fresh منعش", "Floral زهري", "Oriental شرقي", "Woody خشبي",
  "Gourmand حلوي", "Citrus حمضي", "Aromatic عطري", "Fougère فوجير",
  "Chypre شيبر", "Aquatic مائي", "Green أخضر", "Spicy بهاري",
  "Musky مسكي", "Powdery بودري", "Leather جلدي", "Smoky دخاني",
];

const DEFAULT_CATEGORIES = [
  "Floral زهري", "Citrus حمضي", "Woody خشبي", "Spicy بهاري",
  "Resinous راتنجي", "Fruity فاكهي", "Herbal عشبي", "Animalic حيواني",
  "Balsamic بلسمي", "Marine بحري", "Earthy ترابي", "Sweet حلو",
];

const loadList = (key, defaults) => {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : defaults;
  } catch { return defaults; }
};

const saveList = (key, list) => localStorage.setItem(key, JSON.stringify(list));

const ListEditor = ({ title, storageKey, defaults, isAr }) => {
   const [items, setItems] = useState(() => loadList(storageKey, defaults));
   const [newItem, setNewItem] = useState("");
   const [dirty, setDirty] = useState(false);
   const [editIdx, setEditIdx] = useState(null);
   const [editVal, setEditVal] = useState("");

   const add = () => {
     if (!newItem.trim()) return;
     const updated = [...items, newItem.trim()];
     setItems(updated);
     setNewItem("");
     setDirty(true);
   };

   const remove = (i) => {
     const updated = items.filter((_, idx) => idx !== i);
     setItems(updated);
     setDirty(true);
   };

   const startEdit = (i) => {
     setEditIdx(i);
     setEditVal(items[i]);
   };

   const saveEdit = (i) => {
     if (!editVal.trim()) return;
     const updated = [...items];
     updated[i] = editVal.trim();
     setItems(updated);
     setEditIdx(null);
     setDirty(true);
   };

   const handleSave = () => {
     saveList(storageKey, items);
     setDirty(false);
     toast.success(isAr ? "تم الحفظ" : "Saved");
   };

   const resetToDefault = () => {
     setItems(defaults);
     setDirty(true);
   };

  return (
    <div className="bg-card border border-border/50 rounded-none p-4 space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-body font-semibold">{title}</p>
        <div className="flex gap-2">
          <button onClick={resetToDefault} className="text-[10px] text-muted-foreground hover:text-foreground underline underline-offset-2">
            {isAr ? "إعادة الافتراضي" : "Reset"}
          </button>
          <Button size="sm" className="h-7 rounded-none text-xs" onClick={handleSave} disabled={!dirty}>
            <Save className="w-3 h-3 mr-1" />{isAr ? "حفظ" : "Save"}
          </Button>
        </div>
      </div>

      <div className="flex gap-2">
        <Input
          placeholder={isAr ? "أضف قيمة جديدة..." : "Add new value..."}
          value={newItem}
          onChange={(e) => setNewItem(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
          className="h-8 rounded-none text-xs flex-1"
        />
        <Button size="sm" className="h-8 rounded-none" onClick={add}>
          Add</Button>
      </div>

      <div className="flex flex-wrap gap-1.5">
         {items.map((item, i) => (
           <div key={i} className="flex items-center gap-1 bg-secondary/70 rounded-none pl-2.5 pr-1 py-0.5 group">
             {editIdx === i ? (
               <input
                 value={editVal}
                 onChange={(e) => setEditVal(e.target.value)}
                 onBlur={() => saveEdit(i)}
                 onKeyDown={(e) => {
                   if (e.key === "Enter") saveEdit(i);
                   if (e.key === "Escape") setEditIdx(null);
                 }}
                 autoFocus
                 className="bg-transparent outline-none text-[10px] font-body w-20"
               />
             ) : (
               <span
                 onClick={() => startEdit(i)}
                 className="text-[10px] font-body cursor-pointer hover:opacity-75"
               >
                 {item}
               </span>
             )}
             <button onClick={() => remove(i)} className="hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100">
               <Trash2 className="w-3 h-3" />
             </button>
           </div>
         ))}
       </div>

      <p className="text-[10px] text-muted-foreground">{items.length} {isAr ? "قيمة" : "values"}</p>
    </div>
  );
};

export default function MaestroOdorFamilies() {
  const { isAr } = useLang();

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🎨 {isAr ? "العائلات و التصنيفات العطرية" : "Odor Families & Categories"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "قوائم الاختيار للنوتات العطرية" : "Suggestion lists for fragrance notes"}</p>
        </div>
      </div>

      <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-none p-3 mb-5">
        <p className="text-[10px] text-blue-700 dark:text-blue-300 font-body">
          {isAr
            ? "هذه القوائم تُحفظ محلياً كاقتراحات مساعدة عند إدخال النوتات العطرية. القيم بصيغة: EN AR"
            : "These lists are saved locally as suggestions when entering fragrance notes. Format: EN · AR"}
        </p>
      </div>

      <div className="space-y-4">
        <ListEditor
          title={isAr ? "🌸 العائلات العطرية (Odor Families)" : "🌸 Odor Families"}
          storageKey={STORAGE_KEY_FAMILIES}
          defaults={DEFAULT_FAMILIES}
          isAr={isAr}
        />
        <ListEditor
          title={isAr ? "🏷️ التصنيفات (Categories)" : "🏷️ Categories"}
          storageKey={STORAGE_KEY_CATEGORIES}
          defaults={DEFAULT_CATEGORIES}
          isAr={isAr}
        />
      </div>
    </div>
  );
}