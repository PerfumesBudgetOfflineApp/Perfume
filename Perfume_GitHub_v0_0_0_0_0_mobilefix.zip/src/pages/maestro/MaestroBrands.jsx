import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search, Layers, ChevronLeft, ChevronRight, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import ImageUploadButton from "@/components/ui/ImageUploadButton";

export default function MaestroBrands() {
  
  const navigate = useNavigate();
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newBrand, setNewBrand] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  const { data: brands = [], isLoading } = useQuery({
    queryKey: ["maestro-brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("-created_date"),
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes-main"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "main_note" }, "-created_date", 500),
  });

  const [noteSearch, setNoteSearch] = useState({});
  const [showNoteSearch, setShowNoteSearch] = useState({});
  const [showOwnerSearch, setShowOwnerSearch] = useState({});
  const [ownerSearch, setOwnerSearch] = useState({});

  const filtered = brands.filter(
    (b) =>
      b.name?.toLowerCase().includes(search.toLowerCase()) ||
      b.name_ar?.includes(search) ||
      b.country?.toLowerCase().includes(search.toLowerCase())
  );

  const totalPages = Math.ceil(filtered.length / itemsPerPage);
  const startIdx = (currentPage - 1) * itemsPerPage;
  const paginatedBrands = filtered.slice(startIdx, startIdx + itemsPerPage);

  const getEdit = (brand) => localEdits[brand.id] ?? brand;

  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({
      ...prev,
      [id]: { ...(prev[id] ?? brands.find((b) => String(b.id) === String(id))), [field]: value },
    }));
  };

  const addSignatureNote = (brandId, noteId, noteName) => {
    const edit = localEdits[brandId] ?? brands.find((b) => String(b.id) === String(brandId));
    const ids = (edit.signature_notes_ids || "").split(",").filter(Boolean);
    const names = (edit.signature_notes_names || "").split(",").filter(Boolean);
    if (!ids.includes(noteId)) {
      setEdit(brandId, "signature_notes_ids", [...ids, noteId].join(","));
      setEdit(brandId, "signature_notes_names", [...names, noteName].join(","));
    }
    setShowNoteSearch((prev) => ({ ...prev, [brandId]: false }));
    setNoteSearch((prev) => ({ ...prev, [brandId]: "" }));
  };

  const removeSignatureNote = (brandId, noteId) => {
    const edit = localEdits[brandId] ?? brands.find((b) => String(b.id) === String(brandId));
    const ids = (edit.signature_notes_ids || "").split(",").filter(Boolean).filter((id) => id !== noteId);
    const names = (edit.signature_notes_names || "").split(",").filter(Boolean);
    const noteNames = notes.find((n) => String(n.id) === String(noteId))?.name || "";
    const idx = notes.findIndex((n) => String(n.id) === String(noteId));
    const filteredNames = names.filter((_, i) => {
      const allNotes = notes.map((n) => n.name);
      return allNotes[i] !== noteNames;
    });
    setEdit(brandId, "signature_notes_ids", ids.join(","));
    setEdit(brandId, "signature_notes_names", ids.map((id) => notes.find((n) => String(n.id) === String(id))?.name || "").filter(Boolean).join(","));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.PerfumeBrand.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-brands"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "هل أنت متأكد من الحذف؟" : "Delete this brand?")) return;
    await apphost.entities.PerfumeBrand.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-brands"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAddBrand = async () => {
    if (!newBrand.name) { toast.error((isAr ? "الاسم مطلوب" : "Name required")); return; }
    await apphost.entities.PerfumeBrand.create({ ...newBrand, is_default: true, in_business: true });
    qc.invalidateQueries({ queryKey: ["maestro-brands"] });
    setNewBrand({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🏛️ {isAr ? "شركات العطور" : "Perfume Brands"}</h1>
          <p className="text-xs text-muted-foreground">{filtered.length}/{brands.length} {isAr ? "شركة" : "brands"} • {isAr ? "صفحة" : "Page"} {currentPage}/{totalPages}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={isAr ? "بحث..." : "Search..."}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 rounded-none h-9"
          />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/brands/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة براند جديد" : "Add New Brand"}</p>
          <div className="grid grid-cols-2 gap-2">
            <Input placeholder={isAr ? "الاسم بالإنجليزية" : "Name (EN)"} value={newBrand.name || ""} onChange={(e) => setNewBrand({ ...newBrand, name: e.target.value })} className="rounded-none h-9 text-xs" />
            <Input placeholder="الاسم (عربي)" value={newBrand.name_ar || ""} onChange={(e) => setNewBrand({ ...newBrand, name_ar: e.target.value })} className="rounded-none h-9 text-xs" dir="rtl" />
            <Input placeholder={isAr ? "البلد" : "Country"} value={newBrand.country || ""} onChange={(e) => setNewBrand({ ...newBrand, country: e.target.value })} className="rounded-none h-9 text-xs" />
            <Input placeholder={isAr ? "سنة التأسيس" : "Year Founded"} type="number" value={newBrand.year_established || ""} onChange={(e) => setNewBrand({ ...newBrand, year_established: Number(e.target.value) })} className="rounded-none h-9 text-xs" />
            <Input placeholder={isAr ? "الموقع" : "Website"} value={newBrand.website || ""} onChange={(e) => setNewBrand({ ...newBrand, website: e.target.value })} className="rounded-none h-9 text-xs col-span-2" />
            <Input placeholder={isAr ? "الشركة القابضة/الأم" : "Parent Company / Holding"} value={newBrand.owned_by || ""} onChange={(e) => setNewBrand({ ...newBrand, owned_by: e.target.value, parent_company: e.target.value })} className="rounded-none h-9 text-xs col-span-2" />
            <Textarea placeholder={isAr ? "الوصف بالإنجليزية" : "Description (EN)"} value={newBrand.description || ""} onChange={(e) => setNewBrand({ ...newBrand, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px] col-span-2" />
            <Textarea placeholder="الوصف (عربي)" value={newBrand.description_ar || ""} onChange={(e) => setNewBrand({ ...newBrand, description_ar: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px] col-span-2" dir="rtl" />
          </div>
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAddBrand}>
            {isAr ? "إضافة" : "Add Brand"}
          </Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
        </div>
      ) : (
        <div className="space-y-3">
          {paginatedBrands.map((brand) => {
            const edit = getEdit(brand);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(brand);
            return (
              <div key={brand.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {brand.logo_url && <img src={brand.logo_url} className="w-8 h-8 rounded-none object-cover" alt="" />}
                    <div>
                      <p className="text-sm font-body font-semibold">{brand.name}</p>
                      <p className="text-[10px] text-muted-foreground">{brand.country} · {brand.year_established}</p>
                    </div>
                  </div>
                  <button onClick={() => handleDelete(brand.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none transition-colors">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم بالإنجليزية" : "Name EN"}</p>
                    <Input value={edit.name || ""} onChange={(e) => setEdit(brand.id, "name", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">الاسم عربي</p>
                    <Input value={edit.name_ar || ""} onChange={(e) => setEdit(brand.id, "name_ar", e.target.value)} className="h-8 rounded-none text-xs" dir="rtl" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "البلد" : "Country"}</p>
                    <Input value={edit.country || ""} onChange={(e) => setEdit(brand.id, "country", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "السنة" : "Year"}</p>
                    <Input type="number" value={edit.year_established || ""} onChange={(e) => setEdit(brand.id, "year_established", Number(e.target.value))} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الموقع" : "Website"}</p>
                    <Input value={edit.website || ""} onChange={(e) => setEdit(brand.id, "website", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الشركة القابضة/الأم" : "Parent Company / Holding"}</p>
                    <div className="relative">
                      {edit.owned_by ? (
                        <div className="flex items-center justify-between bg-primary/10 px-2 py-1.5 rounded-none h-8">
                          <button
                            onClick={() => {
                              // navigate to that owner brand if exists in DB
                              const ownerBrand = brands.find(b => b.name && b.name.toLowerCase() === edit.owned_by.toLowerCase());
                              if (ownerBrand) navigate(`/brand?id=${ownerBrand.id}`);
                            }}
                            className="text-xs text-foreground hover:underline truncate text-left flex-1"
                          >
                            {edit.owned_by}
                          </button>
                          <button onClick={() => setEdit(brand.id, "owned_by", "")} className="p-0.5 hover:bg-red-100 dark:hover:bg-red-900/30 rounded">
                            <X className="w-3 h-3 text-red-500" />
                          </button>
                        </div>
                      ) : (
                        <button
                          onClick={() => setShowOwnerSearch((prev) => ({ ...prev, [brand.id]: !prev[brand.id] }))}
                          className="w-full h-8 rounded-none border border-border bg-background text-left px-2 text-xs text-muted-foreground hover:bg-secondary transition-colors"
                        >
                          + {isAr ? "اختر البراند المالك" : "Select Owner Brand"}
                        </button>
                      )}
                      {showOwnerSearch[brand.id] && !edit.owned_by && (
                        <div className="absolute top-8 left-0 right-0 z-50 bg-card border border-border rounded-none shadow-lg p-2 space-y-1.5">
                          <Input
                            placeholder={isAr ? "بحث عن براند..." : "Search brands..."}
                            value={ownerSearch[brand.id] || ""}
                            onChange={(e) => setOwnerSearch((prev) => ({ ...prev, [brand.id]: e.target.value }))}
                            className="h-7 rounded-none text-xs"
                            autoFocus
                          />
                          <div className="max-h-[180px] overflow-y-auto space-y-1">
                            {brands
                              .filter((b) => {
                                if (String(b.id) === String(brand.id)) return false;
                                const searchVal = (ownerSearch[brand.id] || "").toLowerCase();
                                if (!searchVal) return true;
                                return (b.name || "").toLowerCase().includes(searchVal) || (b.name_ar || "").includes(searchVal);
                              })
                              .slice(0, 15)
                              .map((b) => (
                                <button
                                  key={b.id}
                                  onClick={() => {
                                    setEdit(brand.id, "owned_by", b.name);
                                    setEdit(brand.id, "parent_company", b.name);
                                    setShowOwnerSearch((prev) => ({ ...prev, [brand.id]: false }));
                                    setOwnerSearch((prev) => ({ ...prev, [brand.id]: "" }));
                                  }}
                                  className="w-full text-left text-xs rounded-none transition-colors truncate"
                                >
                                  <span className="font-medium">{b.name}</span>
                                  {b.name_ar && <span className="text-muted-foreground"> · {b.name_ar}</span>}
                                </button>
                              ))}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="col-span-2">
                   <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الشعار" : "Logo URL"}</p>
                   <div className="flex gap-1.5 items-center">
                     <Input value={edit.logo_url || ""} onChange={(e) => setEdit(brand.id, "logo_url", e.target.value)} className="h-8 rounded-none text-xs flex-1" />
                     <ImageUploadButton onUploaded={(url) => setEdit(brand.id, "logo_url", url)} options={{ maxWidth: 400, maxHeight: 400, quality: 0.85 }} />
                   </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">🌹 {isAr ? "النوتات الموقعة (العطرية المشهورة)" : "Signature Notes"}</p>
                    <div className="space-y-2">
                      {(edit.signature_notes_names || "").split(",").filter(Boolean).map((name, idx) => {
                        const ids = (edit.signature_notes_ids || "").split(",").filter(Boolean);
                        return (
                          <div key={idx} className="flex items-center justify-between bg-primary/10 px-2 py-1.5 rounded-none">
                            <span className="text-xs text-foreground">{name}</span>
                            <button onClick={() => removeSignatureNote(brand.id, ids[idx])} className="p-0.5 hover:bg-red-100 dark:hover:bg-red-900/30 rounded transition-colors">
                              <X className="w-3 h-3 text-red-500" />
                            </button>
                          </div>
                        );
                      })}
                      <div className="relative">
                        <button
                          onClick={() => setShowNoteSearch((prev) => ({ ...prev, [brand.id]: !prev[brand.id] }))}
                          className="w-full h-8 rounded-none border border-border bg-background text-left px-2 text-xs text-muted-foreground hover:bg-secondary transition-colors"
                        >
                          + {isAr ? "أضف نوتة" : "Add Note"}
                        </button>
                        {showNoteSearch[brand.id] && (
                          <div className="absolute top-8 left-0 right-0 z-50 bg-card border border-border rounded-none shadow-lg p-2 space-y-1.5">
                            <Input
                              placeholder={isAr ? "بحث عن نوتة..." : "Search notes..."}
                              value={noteSearch[brand.id] || ""}
                              onChange={(e) => setNoteSearch((prev) => ({ ...prev, [brand.id]: e.target.value }))}
                              className="h-7 rounded-none text-xs"
                            />
                            <div className="max-h-[150px] overflow-y-auto space-y-1">
                              {notes
                                .filter((n) => {
                                  const searchVal = noteSearch[brand.id] || "";
                                  const existingIds = (edit.signature_notes_ids || "").split(",").filter(Boolean);
                                  return !existingIds.includes(n.id) && (n.name.toLowerCase().includes(searchVal.toLowerCase()) || n.name.includes(searchVal));
                                })
                                .slice(0, 10)
                                .map((note) => (
                                  <button
                                    key={note.id}
                                    onClick={() => addSignatureNote(brand.id, note.id, note.name)}
                                    className="w-full text-left text-xs rounded-none transition-colors truncate"
                                  >
                                    {note.name}
                                  </button>
                                ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">About (English)</p>
                    <Textarea value={edit.description || ""} onChange={(e) => setEdit(brand.id, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[80px]" placeholder="Brand description / history (English)" />
                  </div>
                  <div className="col-span-2">
                    <p className="text-[9px] text-muted-foreground mb-1">الوصف (عربي)</p>
                    <Textarea value={edit.description_ar || ""} onChange={(e) => setEdit(brand.id, "description_ar", e.target.value)} className="rounded-none text-xs resize-none min-h-[80px]" placeholder="وصف/تاريخ البراند بالعربية" dir="rtl" />
                  </div>
                </div>

                <Button
                  onClick={() => handleSave(brand.id)}
                  disabled={!isDirty || saving[brand.id]}
                  className="w-full h-8 rounded-none text-xs"
                  variant={isDirty ? "default" : "outline"}
                >
                  <Save className="w-3 h-3 mr-1" />
                  {saving[brand.id] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ التعديلات" : "💾 Save Changes")}
                </Button>
              </div>
            );
          })}
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
          <button
            onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
            disabled={currentPage === 1}
            className="p-2 hover:bg-secondary rounded-none disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
          </button>
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? `صفحة ${currentPage} من ${totalPages}` : `Page ${currentPage} of ${totalPages}`}
          </p>
          <button
            onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
            disabled={currentPage === totalPages}
            className="p-2 hover:bg-secondary rounded-none disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <ChevronRight className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
          </button>
        </div>
      )}
    </div>
  );
}