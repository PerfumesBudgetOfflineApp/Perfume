import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

export default function MaestroWisdom() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItem, setNewItem] = useState({});
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 50;

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["maestro-wisdom"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
  });

  const filtered = items.filter((w) =>
    w.text_en?.toLowerCase().includes(search.toLowerCase()) ||
    w.text_ar?.includes(search) ||
    w.author?.toLowerCase().includes(search.toLowerCase())
  );
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const getEdit = (w) => localEdits[w.id] ?? w;
  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({ ...prev, [id]: { ...(prev[id] ?? items.find((w) => String(w.id) === String(id))), [field]: value } }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.Wisdom.update(id, { ...data, is_default: true });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["maestro-wisdom"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف؟" : "Delete?")) return;
    await apphost.entities.Wisdom.delete(id);
    qc.invalidateQueries({ queryKey: ["maestro-wisdom"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newItem.text_en && !newItem.text_ar) { toast.error((isAr ? "النص مطلوب" : "Text required")); return; }
    await apphost.entities.Wisdom.create({ ...newItem, is_default: true });
    qc.invalidateQueries({ queryKey: ["maestro-wisdom"] });
    setNewItem({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">💡 {isAr ? "الحكم و المواعظ" : "Wisdom & Insights"}</h1>
          <p className="text-xs text-muted-foreground">{items.length} {isAr ? "حكمة" : "wisdom"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث..." : "Search..."} value={search} onChange={(e) => { setSearch(e.target.value); setPage(0); }} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
      </div>

      {totalPages > 1 && (
        <div className="flex items-center gap-2 mb-3 justify-center flex-wrap">
          {Array.from({ length: totalPages }).map((_, i) => (
            <button key={i} onClick={() => setPage(i)} className={`w-7 h-7 rounded-none text-xs ${page === i ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"}`}>{i + 1}</button>
          ))}
        </div>
      )}

      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة حكمة" : "Add Wisdom"}</p>
          <Textarea placeholder={isAr ? "النص بالإنجليزية" : "Text (EN)"} value={newItem.text_en || ""} onChange={(e) => setNewItem({ ...newItem, text_en: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" />
          <Textarea placeholder="النص (عربي)" value={newItem.text_ar || ""} onChange={(e) => setNewItem({ ...newItem, text_ar: e.target.value })} className="rounded-none text-xs resize-none min-h-[60px]" dir="rtl" />
          <Input placeholder={isAr ? "المؤلف" : "Author"} value={newItem.author || ""} onChange={(e) => setNewItem({ ...newItem, author: e.target.value })} className="rounded-none h-9 text-xs" />
          <Input placeholder={isAr ? "الفئة اختياري" : "Category (optional)"} value={newItem.category || ""} onChange={(e) => setNewItem({ ...newItem, category: e.target.value })} className="rounded-none h-9 text-xs" />
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>{isAr ? "إضافة" : "Add"}</Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-3">
          {paginated.map((item) => {
            const edit = getEdit(item);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(item);
            return (
              <div key={item.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <p className="text-xs font-body text-muted-foreground italic line-clamp-2 flex-1">"{item.text_en || item.text_ar}"</p>
                  <button onClick={() => handleDelete(item.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none flex-shrink-0">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>
                <div className="space-y-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "النص بالإنجليزية" : "Text EN"}</p>
                    <Textarea value={edit.text_en || ""} onChange={(e) => setEdit(item.id, "text_en", e.target.value)} className="rounded-none text-xs resize-none min-h-[50px]" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">النص عربي</p>
                    <Textarea value={edit.text_ar || ""} onChange={(e) => setEdit(item.id, "text_ar", e.target.value)} className="rounded-none text-xs resize-none min-h-[50px]" dir="rtl" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "المؤلف" : "Author"}</p>
                      <Input value={edit.author || ""} onChange={(e) => setEdit(item.id, "author", e.target.value)} className="h-8 rounded-none text-xs" />
                    </div>
                    <div>
                      <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الفئة" : "Category"}</p>
                      <Input value={edit.category || ""} onChange={(e) => setEdit(item.id, "category", e.target.value)} className="h-8 rounded-none text-xs" placeholder="finance, life..." />
                    </div>
                  </div>
                </div>
                <Button onClick={() => handleSave(item.id)} disabled={!isDirty || saving[item.id]} className="w-full h-8 rounded-none text-xs" variant={isDirty ? "default" : "outline"}>
                  <Save className="w-3 h-3 mr-1" />
                  {saving[item.id] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ" : "💾 Save")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}