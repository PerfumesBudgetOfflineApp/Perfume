import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, Search, Layers } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";
import ImageUploadButton from "@/components/ui/ImageUploadButton";

export default function MaestroStores() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [saving, setSaving] = useState({});
  const [localEdits, setLocalEdits] = useState({});
  const [showAddForm, setShowAddForm] = useState(false);
  const [newItem, setNewItem] = useState({});

  const { data: items = [], isLoading } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("name"),
  });

  const filtered = items.filter((s) => s.name?.toLowerCase().includes(search.toLowerCase()));

  const getEdit = (s) => localEdits[s.id] ?? s;
  const setEdit = (id, field, value) => {
    setLocalEdits((prev) => ({ ...prev, [id]: { ...(prev[id] ?? items.find((s) => String(s.id) === String(id))), [field]: value } }));
  };

  const handleSave = async (id) => {
    const data = localEdits[id];
    if (!data) return;
    setSaving((p) => ({ ...p, [id]: true }));
    await apphost.entities.ShopBrand.update(id, { ...data });
    setSaving((p) => ({ ...p, [id]: false }));
    qc.invalidateQueries({ queryKey: ["shop-brands"] });
    toast.success(isAr ? "تم التعديل بنجاح في قاعدة بيانات التطبيق" : "Updated successfully in app database");
  };

  const handleDelete = async (id) => {
    if (!confirm(isAr ? "حذف؟" : "Delete?")) return;
    await apphost.entities.ShopBrand.delete(id);
    qc.invalidateQueries({ queryKey: ["shop-brands"] });
    toast.success(isAr ? "تم الحذف" : "Deleted");
  };

  const handleAdd = async () => {
    if (!newItem.name) { toast.error((isAr ? "الاسم مطلوب" : "Name required")); return; }
    await apphost.entities.ShopBrand.create({ ...newItem, type: "perfume_store", person: "family" });
    qc.invalidateQueries({ queryKey: ["shop-brands"] });
    setNewItem({});
    setShowAddForm(false);
    toast.success(isAr ? "تمت الإضافة" : "Added");
  };

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">🏪 {isAr ? "متاجر العطور" : "Perfume Stores"}</h1>
          <p className="text-xs text-muted-foreground">{items.length} {isAr ? "متجر" : "stores"}</p>
        </div>
      </div>

      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
          <Input placeholder={isAr ? "بحث..." : "Search..."} value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9 rounded-none h-9" />
        </div>
        <Button size="sm" className="rounded-none" onClick={() => setShowAddForm(!showAddForm)}>
          {isAr ? "إضافة" : "Add"}
        </Button>
        <Link to="/maestro/perfume-stores/bulk-add">
          <Button size="sm" variant="outline" className="rounded-none">
            <Layers className="w-4 h-4 mr-1" />{isAr ? "إضافة 20" : "Add 20"}
          </Button>
        </Link>
      </div>

      {showAddForm && (
        <div className="bg-primary/5 border border-primary/20 rounded-none p-4 mb-4 space-y-2">
          <p className="text-sm font-body font-semibold">{isAr ? "إضافة متجر" : "Add Store"}</p>
          <Input placeholder={isAr ? "اسم المتجر" : "Store Name*"} value={newItem.name || ""} onChange={(e) => setNewItem({ ...newItem, name: e.target.value })} className="rounded-none h-9 text-xs" />
          <Input placeholder={isAr ? "الموقع" : "Website"} value={newItem.website || ""} onChange={(e) => setNewItem({ ...newItem, website: e.target.value })} className="rounded-none h-9 text-xs" />
          <Input placeholder={isAr ? "رابط الشعار" : "Logo URL"} value={newItem.logo_url || ""} onChange={(e) => setNewItem({ ...newItem, logo_url: e.target.value })} className="rounded-none h-9 text-xs" />
          <Textarea placeholder={isAr ? "الوصف" : "Description"} value={newItem.description || ""} onChange={(e) => setNewItem({ ...newItem, description: e.target.value })} className="rounded-none text-xs resize-none min-h-[50px]" />
          <Button className="w-full rounded-none h-9 text-xs" onClick={handleAdd}>{isAr ? "إضافة" : "Add"}</Button>
        </div>
      )}

      {isLoading ? (
        <div className="flex justify-center py-12"><div className="w-8 h-8 border-4 border-primary/20 border-t-primary rounded-full animate-spin" /></div>
      ) : (
        <div className="space-y-3">
          {filtered.map((item) => {
            const edit = getEdit(item);
            const isDirty = JSON.stringify(edit) !== JSON.stringify(item);
            return (
              <div key={item.id} className="bg-card border border-border/50 rounded-none p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {item.logo_url && <img src={item.logo_url} className="w-8 h-8 rounded-none object-cover" alt="" />}
                    <p className="text-sm font-body font-semibold">{item.name}</p>
                  </div>
                  <button onClick={() => handleDelete(item.id)} className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                    <Trash2 className="w-3.5 h-3.5 text-red-500" />
                  </button>
                </div>
                <div className="space-y-2">
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الاسم" : "Name"}</p>
                    <Input value={edit.name || ""} onChange={(e) => setEdit(item.id, "name", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الموقع" : "Website"}</p>
                    <Input value={edit.website || ""} onChange={(e) => setEdit(item.id, "website", e.target.value)} className="h-8 rounded-none text-xs" />
                  </div>
                  <div>
                   <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "رابط الشعار" : "Logo URL"}</p>
                   <div className="flex gap-1.5 items-center">
                     <Input value={edit.logo_url || ""} onChange={(e) => setEdit(item.id, "logo_url", e.target.value)} className="h-8 rounded-none text-xs flex-1" />
                     <ImageUploadButton onUploaded={(url) => setEdit(item.id, "logo_url", url)} options={{ maxWidth: 400, maxHeight: 400, quality: 0.85 }} />
                   </div>
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "الوصف" : "Description"}</p>
                    <Textarea value={edit.description || ""} onChange={(e) => setEdit(item.id, "description", e.target.value)} className="rounded-none text-xs resize-none min-h-[50px]" />
                  </div>
                  <div>
                    <p className="text-[9px] text-muted-foreground mb-1">{isAr ? "النوتات" : "Notes"}</p>
                    <Textarea value={edit.notes || ""} onChange={(e) => setEdit(item.id, "notes", e.target.value)} className="rounded-none text-xs resize-none min-h-[40px]" />
                  </div>
                </div>
                <Button onClick={() => handleSave(item.id)} disabled={!isDirty || saving[item.id]} className="w-full h-8 rounded-none text-xs" variant={isDirty ? "default" : "outline"}>
                  <Save className="w-3 h-3 mr-1" />
                  {saving[item.id] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ" : "💾 Save")}
                </Button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}