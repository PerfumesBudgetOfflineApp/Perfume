import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Save, Trash2, CheckCircle2 } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

const emptyItem = () => ({ term_en: "", term_ar: "", meaning: "", tags: "" });

export default function MaestroBulkAddGlossary() {
  const { isAr } = useLang();
  const qc = useQueryClient();
  const [rows, setRows] = useState(() => Array.from({ length: 20 }, emptyItem));
  const [savedRows, setSavedRows] = useState({});
  const [saving, setSaving] = useState({});

  const setField = (idx, field, val) => {
    setRows((prev) => prev.map((r, i) => i === idx ? { ...r, [field]: val } : r));
  };

  const handleSaveRow = async (idx) => {
    const row = rows[idx];
    if (!row.term_en) { toast.error(isAr ? "المصطلح الإنجليزي مطلوب" : "English term is required"); return; }
    setSaving((p) => ({ ...p, [idx]: true }));
    await apphost.entities.GlossaryTerm.create({ ...row, is_default: true });
    setSaving((p) => ({ ...p, [idx]: false }));
    setSavedRows((p) => ({ ...p, [idx]: true }));
    qc.invalidateQueries({ queryKey: ["maestro-glossary"] });
    toast.success(isAr ? `تم حفظ السطر ${idx + 1} بنجاح في قاعدة بيانات التطبيق` : `Row ${idx + 1} saved successfully to app database`);
  };

  const handleSaveAll = async () => {
    const valid = rows.filter((r, i) => r.term_en && !savedRows[i]);
    if (!valid.length) { toast.error(isAr ? "لا توجد صفوف جديدة للحفظ" : "No new rows to save"); return; }
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].term_en && !savedRows[i]) await handleSaveRow(i);
    }
    toast.success(isAr ? "تم الحفظ بنجاح" : "All saved successfully");
  };

  const addRow = () => setRows((p) => [...p, emptyItem()]);
  const removeRow = (idx) => setRows((p) => p.filter((_, i) => i !== idx));

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      <div className="flex items-center gap-3 mb-4">
        <Link to="/maestro/glossary" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Link>
        <div>
          <h1 className="font-heading text-xl font-bold">📚 {isAr ? "إضافة مصطلحات دفعة واحدة" : "Bulk Add Glossary Terms"}</h1>
          <p className="text-xs text-muted-foreground">{isAr ? "أضف حتى 20 مصطلح مرة واحدة" : "Add up to 20 terms at once"}</p>
        </div>
      </div>

      <Button className="w-full mb-4 rounded-none" onClick={handleSaveAll}>
        <Save className="w-4 h-4 mr-2" />
        {isAr ? "حفظ جميع الصفوف الجديدة" : "Save All New Rows"}
      </Button>

      <div className="space-y-4">
        {rows.map((row, idx) => (
          <div key={idx} className={`border rounded-none p-4 space-y-2 transition-colors ${savedRows[idx] ? "bg-emerald-50 dark:bg-emerald-900/20 border-emerald-300 dark:border-emerald-700" : "bg-card border-border/50"}`}>
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-body font-bold text-muted-foreground">#{idx + 1}</span>
                {savedRows[idx] && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
                {savedRows[idx] && <span className="text-[10px] text-emerald-600 font-body font-semibold">{isAr ? "تم الحفظ في قاعدة البيانات" : "Saved to database"}</span>}
              </div>
              <button onClick={() => removeRow(idx)} className="p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none">
                <Trash2 className="w-3.5 h-3.5 text-red-400" />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input placeholder={isAr ? "المصطلح (إنجليزي)*" : "Term (EN)*"} value={row.term_en} onChange={(e) => setField(idx, "term_en", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
              <Input placeholder={isAr ? "المصطلح (عربي)" : "Term (AR)"} value={row.term_ar} onChange={(e) => setField(idx, "term_ar", e.target.value)} className="h-9 rounded-none text-xs" dir="rtl" disabled={savedRows[idx]} />
            </div>
            <Textarea placeholder={isAr ? "التعريف / المعنى" : "Meaning / Definition"} value={row.meaning} onChange={(e) => setField(idx, "meaning", e.target.value)} className="rounded-none text-xs resize-none min-h-[60px]" disabled={savedRows[idx]} />
            <Input placeholder={isAr ? "الوسوم (مفصولة بفاصلة)" : "Tags (comma-separated)"} value={row.tags} onChange={(e) => setField(idx, "tags", e.target.value)} className="h-9 rounded-none text-xs" disabled={savedRows[idx]} />
            {!savedRows[idx] && (
              <Button size="sm" className="w-full h-8 rounded-none text-xs" onClick={() => handleSaveRow(idx)} disabled={saving[idx]}>
                <Save className="w-3 h-3 mr-1" />
                {saving[idx] ? (isAr ? "جاري الحفظ..." : "Saving...") : (isAr ? "💾 حفظ هذا السطر" : "💾 Save this row")}
              </Button>
            )}
          </div>
        ))}
      </div>

      <Button variant="outline" className="w-full mt-4 rounded-none" onClick={addRow}>
        {isAr ? "إضافة سطر جديد" : "Add Row"}
      </Button>
    </div>
  );
}