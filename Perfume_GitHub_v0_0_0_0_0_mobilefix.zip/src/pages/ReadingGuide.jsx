import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

/**
 * ReadingGuide — "موجِّهة القراءة / A Reading Guide".
 *
 * Clean GitHub edition: a GENERIC, ready-to-update introduction to the two
 * built-in knowledge features — Stories and the Vocabulary glossary — without
 * any project-specific catalogue content. Replace the copy below with your own
 * once you populate the stories and glossary.
 *
 * Linked from: the Glossary page header, and a text link in settings.
 */

const GOLD = "var(--brand)";

function Q({ children, dir }) {
  return (
    <p dir={dir} style={{ borderInlineStart: `2px solid ${GOLD}66`, paddingInlineStart: 12, margin: "10px 0", color: "#6b7280", fontStyle: "italic", lineHeight: 1.9 }}>
      {children}
    </p>
  );
}
function H({ children, dir }) {
  return <h2 dir={dir} className="font-heading" style={{ color: GOLD, fontSize: 16, fontWeight: 700, margin: "22px 0 8px" }}>{children}</h2>;
}
function P({ children, dir }) {
  return <p dir={dir} className="font-body" style={{ fontSize: 13.5, lineHeight: 2, color: "var(--tw-prose, inherit)", margin: "0 0 10px" }}>{children}</p>;
}
function LI({ children, dir }) {
  return <li dir={dir} className="font-body" style={{ fontSize: 13, lineHeight: 1.95, marginBottom: 6 }}>{children}</li>;
}

export default function ReadingGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  return (
    <div className="px-5 pt-12 pb-20 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-5">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-heading text-2xl font-bold" style={{ color: GOLD }}>
          {isAr ? "موجِّهة القراءة" : "A Reading Guide"}
        </h1>
      </div>

      {/* ───────────── Arabic ───────────── */}
      <section dir="rtl" className="mb-12">
        <P dir="rtl">كيف تدخل هذا العالم — فهرس سردي للقصص و المصطلحات.</P>
        <Q dir="rtl">هذا ليس فهرسا تراجعه، بل عتبة تعبرها. ما بين يديك ليس قاعدة بيانات بل عالم يمشى فيه على المهل، فاختر بابا و ادخل.</Q>

        <H dir="rtl">ما الذي ينتظرك</H>
        <P dir="rtl">خلف هذه الواجهة الهادئة يقبع عالمان متجاوران:</P>
        <P dir="rtl"><b>القصص</b> — مقالات سردية قصيرة بلغتين، مكتوبة لا لتعلمك بل لتدهشك. القصة في حركات قصيرة يفصل بينها خط، تبدأ بسؤال أو مشهد ثم تتسع ثم تنصف الطرفين. ليست دعاية و لا وعظا، بل دهشة صادقة.</P>
        <P dir="rtl"><b>المصطلحات</b> — معجم موجز بلغتين، كل تعريف جملة واحدة تكفي لتفهم و تثير الفضول لتعرف أكثر. المصطلح ضوء سريع، و القصة غرفة عميقة.</P>

        <H dir="rtl">كيف تقرأ</H>
        <P dir="rtl">لا تقرأ بالترتيب كأنه كتاب مدرسي، بل تجول كما تتجول في متحف: قف عند ما يناديك، و تجاوز ما لا يناديك اليوم. و إن أردت خيطا يقودك، فالخطوط الزمنية تنسج سلاسل تقرأ في تتابع — كأنك تنصت إلى محادثة طويلة عبر الزمن.</P>
        <P dir="rtl">و السر الأجمل أن المصطلحات و القصص خيطان في نسيج واحد: اقرأ المصطلح ليضيء لك، ثم القصة لتعمق المعنى.</P>

        <Q dir="rtl">العالم هنا لا ينفد. كل قصة باب إلى أخرى، و كل مصطلح خيط يجر خيطا. لا يطلب منك أن تنهيه، بل أن تعود إليه. فابدأ من حيث ناداك قلبك.</Q>
      </section>

      <div style={{ height: 1, background: `${GOLD}40`, margin: "8px 0 28px" }} />

      {/* ───────────── English ───────────── */}
      <section dir="ltr" className="mb-10">
        <P dir="ltr">How to enter this world — a narrative index to the stories and the glossary.</P>
        <Q dir="ltr">This is not an index to consult; it is a threshold to cross. What you hold is less a database than a world to wander slowly. Pick a door and step in.</Q>

        <H dir="ltr">What awaits you</H>
        <P dir="ltr">Behind this quiet interface lie two neighboring worlds.</P>
        <P dir="ltr"><b>The stories</b> — short narrative pieces, each in two languages, written not to instruct you but to astonish you. A story moves in short movements divided by a line: it opens on a question or a scene, widens, and weighs both sides. Never advertising, never preaching — only genuine wonder.</P>
        <P dir="ltr"><b>The glossary</b> — a brief bilingual lexicon. Each definition is a single short sentence, enough to understand and enough to make you curious for more. A term is a quick light; a story is a deep room.</P>

        <H dir="ltr">How to read</H>
        <P dir="ltr">Do not read in order, like a textbook. Wander as you would a museum: stop at whatever calls to you, and pass by what does not call today. And if you want a thread to follow, the timelines weave series meant to be read in sequence — like listening in on a long conversation across time.</P>
        <P dir="ltr">The loveliest secret is that the terms and the stories are threads in one weave: read the term to light the way, then the story to deepen it.</P>

        <Q dir="ltr">The world here does not run out. Every story is a door to another, and every term a thread that pulls a thread. You are not asked to finish it, only to return to it. So begin wherever your heart called you.</Q>
      </section>

      {/* CTAs into the two worlds */}
      <div className="flex flex-wrap gap-3 pt-2">
        <Link to="/glossary" className="flex-1 min-w-[140px] text-center px-4 py-2.5 rounded-none font-body text-sm font-semibold" style={{ background: GOLD, color: "#fff" }}>
          {isAr ? "ادخل المسرد" : "Enter the glossary"}
        </Link>
        <Link to="/glossary?tab=story" className="flex-1 min-w-[140px] text-center px-4 py-2.5 rounded-none font-body text-sm font-semibold border" style={{ borderColor: `${GOLD}`, color: GOLD }}>
          {isAr ? "ادخل القصص" : "Enter the stories"}
        </Link>
      </div>
    </div>
  );
}
