import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { ArrowLeft, Calendar } from "lucide-react";
import { LineChart, Line, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from "recharts";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { Input } from "@/components/ui/input";
import SettingsSheet from "@/components/layout/SettingsSheet";

const TRANSLATIONS = {
  en: {
    title: "📊 Monthly Analysis",
    monthlyBreakdown: "Monthly Breakdown",
    expensesVsObligations: "Expenses vs Obligations",
    categoryTrends: "Category Trends",
    comparison: "Monthly Comparison",
    total: "Total",
    expenses: "Expenses",
    obligations: "Obligations",
    recurring: "Recurring",
    purchases: "Purchases",
    noData: "No data available",
    selectMonths: "Select Range"
  },
  ar: {
    title: "📊 التحليل الشهري",
    monthlyBreakdown: "توزيع شهري",
    expensesVsObligations: "المصاريف مقابل الالتزامات",
    categoryTrends: "اتجاهات الفئات",
    comparison: "المقارنة الشهرية",
    total: "الإجمالي",
    expenses: "المصاريف",
    obligations: "الالتزامات",
    recurring: "متكرر",
    purchases: "مشتريات",
    noData: "لا توجد بيانات",
    selectMonths: "اختر النطاق"
  }
};

export default function MonthlyAnalysis() {
  const { lang, isAr } = useLang();
  const t = TRANSLATIONS[isAr ? 'ar' : 'en'];
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const [selectedPerson, setSelectedPerson] = useState("all");
  const [startMonth, setStartMonth] = useState("2025-05");
  const [endMonth, setEndMonth] = useState("2026-05");

  const { data: expenses = [] } = useQuery({
    queryKey: ["budget-expenses"],
    queryFn: () => apphost.entities.BudgetExpense.list("-date"),
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-purchase_date"),
  });

  const { data: obligations = [] } = useQuery({
    queryKey: ["budget-obligations"],
    queryFn: () => apphost.entities.BudgetObligation.list("-end_date"),
  });

  const { data: recurring = [] } = useQuery({
    queryKey: ["recurring-expenses"],
    queryFn: () => apphost.entities.RecurringExpense.list("-start_date"),
  });

  // Filter by person
  const filterByPerson = (arr) => {
    if (selectedPerson === "all") return arr;
    if (selectedPerson === "together") return arr;
    return arr.filter(item => item.person === selectedPerson || item.person === "family");
  };

  // Generate monthly data
  const monthlyData = useMemo(() => {
    const data = {};
    const months = [];

    // Generate months in range
    const start = new Date(startMonth + "-01");
    const end = new Date(endMonth + "-01");
    let current = new Date(start);

    while (current <= end) {
      const monthKey = current.toISOString().slice(0, 7);
      months.push(monthKey);
      data[monthKey] = { month: monthKey, expenses: 0, purchases: 0, obligations: 0, recurring: 0, categories: {} };
      current.setMonth(current.getMonth() + 1);
    }

    // Process expenses
    filterByPerson(expenses).forEach(exp => {
      const monthKey = exp.date.slice(0, 7);
      if (data[monthKey]) {
        data[monthKey].expenses += exp.amount || 0;
        const cat = exp.category || "other";
        data[monthKey].categories[cat] = (data[monthKey].categories[cat] || 0) + (exp.amount || 0);
      }
    });

    // Process purchases
    filterByPerson(purchases).forEach(p => {
      const monthKey = p.purchase_date.slice(0, 7);
      if (data[monthKey]) {
        data[monthKey].purchases += p.cost || 0;
        data[monthKey].categories.perfume = (data[monthKey].categories.perfume || 0) + (p.cost || 0);
      }
    });

    // Process obligations (monthly payment)
    filterByPerson(obligations).forEach(obl => {
      if (!obl.start_date || !obl.end_date) return;
      const startMonth = obl.start_date.slice(0, 7);
      const endMonth = obl.end_date.slice(0, 7);
      for (const m in data) {
        if (m >= startMonth && m <= endMonth) {
          data[m].obligations += obl.monthly_payment || 0;
        }
      }
    });

    // Process recurring
    filterByPerson(recurring).forEach(rec => {
      if (!rec.start_date) return;
      const startMonth = rec.start_date.slice(0, 7);
      const endMonth = rec.end_date ? rec.end_date.slice(0, 7) : "2099-12";
      if (rec.is_active) {
        for (const m in data) {
          if (m >= startMonth && m <= endMonth) {
            if (rec.frequency === "monthly") {
              data[m].recurring += rec.amount || 0;
            } else if (rec.frequency === "weekly") {
              data[m].recurring += (rec.amount * 4.33) || 0;
            } else if (rec.frequency === "daily") {
              data[m].recurring += (rec.amount * 30) || 0;
            }
          }
        }
      }
    });

    return months.map(m => ({
      ...data[m],
      total: (data[m].expenses + data[m].purchases + data[m].obligations + data[m].recurring),
      label: m.slice(5) // MM only
    }));
  }, [expenses, purchases, obligations, recurring, selectedPerson, startMonth, endMonth]);

  // Category breakdown for all months
  const categoryTotals = useMemo(() => {
    const cats = {};
    monthlyData.forEach(month => {
      Object.entries(month.categories).forEach(([cat, amount]) => {
        cats[cat] = (cats[cat] || 0) + amount;
      });
    });
    return cats;
  }, [monthlyData]);

  const hasData = monthlyData.some(m => m.total > 0);

  return (
    <div className={`px-3 pt-10 pb-4 space-y-3 min-h-screen flex flex-col ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link to="/budget" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <h1 className="font-heading text-2xl font-bold">{t.title}</h1>
        <SettingsSheet>
          <button className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors">
            <Calendar className="w-4 h-4 text-foreground/60" />
          </button>
        </SettingsSheet>
      </div>

      {/* Filters */}
      <div className="space-y-3 bg-secondary/30 rounded-none p-3">
        <div className="flex gap-2">
          {[
            { val: "all", label: "All" },
            { val: "person1", label: names.person1 || "A" },
            { val: "person2", label: names.person2 || "B" },
            { val: "family", label: "👨‍👩‍👧‍👦" },
            { val: "together", label: "👥" },
          ].map(({ val, label }) => (
            <button
              key={val}
              onClick={() => setSelectedPerson(val)}
              className={`flex-1 rounded-none text-xs font-body transition-all ${
 selectedPerson === val
 ? " text-primary-foreground "
 : " text-muted-foreground"
 }`}
            >
              {label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
            <label className="text-[10px] text-muted-foreground font-body uppercase">{isAr ? "من" : "From"}</label>
            <Input
              type="month"
              value={startMonth}
              onChange={(e) => setStartMonth(e.target.value)}
              className="h-8 rounded-none text-xs"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] text-muted-foreground font-body uppercase">To</label>
            <Input
              type="month"
              value={endMonth}
              onChange={(e) => setEndMonth(e.target.value)}
              className="h-8 rounded-none text-xs"
            />
          </div>
        </div>
      </div>

      {!hasData ? (
        <p className="text-center text-xs text-muted-foreground py-8">{t.noData}</p>
      ) : (
        <>
          {/* Monthly Breakdown Chart */}
          <div className="bg-card rounded-none p-2 border border-border/50">
            <p className="text-xs font-body font-semibold mb-2">{t.monthlyBreakdown}</p>
            <ResponsiveContainer width="100%" height={200}>
              <ComposedChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="label" stroke="var(--color-muted-foreground)" style={{ fontSize: "10px" }} />
                <YAxis stroke="var(--color-muted-foreground)" style={{ fontSize: "10px" }} />
                <Tooltip formatter={(v) => `${v.toFixed(0)} ${currency}`} />
                <Legend />
                <Bar dataKey="expenses" fill="#ef4444" name={t.expenses} />
                <Bar dataKey="purchases" fill="#f97316" name={t.purchases} />
                <Bar dataKey="obligations" fill="#f59e0b" name={t.obligations} />
                <Bar dataKey="recurring" fill="#84cc16" name={t.recurring} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {/* Trend Line Chart */}
          <div className="bg-card rounded-none p-2 border border-border/50">
            <p className="text-xs font-body font-semibold mb-2">{t.expensesVsObligations}</p>
            <ResponsiveContainer width="100%" height={180}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="label" stroke="var(--color-muted-foreground)" style={{ fontSize: "10px" }} />
                <YAxis stroke="var(--color-muted-foreground)" style={{ fontSize: "10px" }} />
                <Tooltip formatter={(v) => `${v.toFixed(0)} ${currency}`} />
                <Legend />
                <Line type="monotone" dataKey="total" stroke="var(--color-primary)" strokeWidth={2} name={t.total} />
                <Line type="monotone" dataKey="obligations" stroke="var(--color-destructive)" strokeWidth={2} name={t.obligations} />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-red-100/50 dark:bg-red-900/20 rounded-none p-2">
              <p className="text-[9px] text-red-700 dark:text-red-300 font-body">Total Expenses</p>
              <p className="text-sm font-bold text-red-600 dark:text-red-400">
                {monthlyData.reduce((sum, m) => sum + m.expenses, 0).toFixed(0)} {currency}
              </p>
            </div>
            <div className="bg-orange-100/50 dark:bg-orange-900/20 rounded-none p-2">
              <p className="text-[9px] text-orange-700 dark:text-orange-300 font-body">{isAr ? "إجمالي الالتزامات" : "Total Obligations"}</p>
              <p className="text-sm font-bold text-orange-600 dark:text-orange-400">
                {monthlyData.reduce((sum, m) => sum + m.obligations, 0).toFixed(0)} {currency}
              </p>
            </div>
            <div className="bg-amber-100/50 dark:bg-amber-900/20 rounded-none p-2">
              <p className="text-[9px] text-amber-700 dark:text-amber-300 font-body">{isAr ? "إجمالي المشتريات" : "Total Purchases"}</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400">
                {monthlyData.reduce((sum, m) => sum + m.purchases, 0).toFixed(0)} {currency}
              </p>
            </div>
            <div className="bg-green-100/50 dark:bg-green-900/20 rounded-none p-2">
              <p className="text-[9px] text-green-700 dark:text-green-300 font-body">{isAr ? "إجمالي المتكرّر" : "Total Recurring"}</p>
              <p className="text-sm font-bold text-green-600 dark:text-green-400">
                {monthlyData.reduce((sum, m) => sum + m.recurring, 0).toFixed(0)} {currency}
              </p>
            </div>
          </div>

          {/* Category Breakdown */}
          {Object.keys(categoryTotals).length > 0 && (
            <div className="bg-card rounded-none p-2 border border-border/50">
              <p className="text-xs font-body font-semibold mb-2">{t.categoryTrends}</p>
              <div className="space-y-2">
                {Object.entries(categoryTotals)
                  .sort(([, a], [, b]) => b - a)
                  .map(([cat, amount]) => (
                    <div key={cat} className="flex items-center justify-between text-xs font-body">
                      <span className="text-muted-foreground capitalize">{cat}</span>
                      <span className="font-semibold">{amount.toFixed(0)} {currency}</span>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* Detailed Monthly Table */}
          <div className="bg-card rounded-none overflow-hidden border border-border/50 flex-1">
            <div className="overflow-x-auto h-full">
              <table className="w-full text-[11px] font-body">
                <thead>
                  <tr className="bg-secondary/50 border-b border-border/50">
                    <th className="px-2 py-1 text-left">{isAr ? "الشهر" : "Month"}</th>
                    <th className="px-2 py-1 text-right">{t.expenses}</th>
                    <th className="px-2 py-1 text-right">{t.purchases}</th>
                    <th className="px-2 py-1 text-right">{t.obligations}</th>
                    <th className="px-2 py-1 text-right">{t.total}</th>
                  </tr>
                </thead>
                <tbody>
                  {monthlyData.map((month) => (
                    <tr key={month.month} className="border-b border-border/50 hover:bg-secondary/30">
                      <td className="px-2 py-1">{month.month}</td>
                      <td className="px-2 py-1 text-right">{month.expenses.toFixed(0)}</td>
                      <td className="px-2 py-1 text-right">{month.purchases.toFixed(0)}</td>
                      <td className="px-2 py-1 text-right">{month.obligations.toFixed(0)}</td>
                      <td className="px-2 py-1 text-right font-semibold">{month.total.toFixed(0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}