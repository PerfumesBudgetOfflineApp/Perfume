import { useState, useMemo } from "react";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Heart, ThumbsDown, ThumbsUp, ShoppingBag, Package, Droplets, Trash2, List, Pencil, UserCircle2, BookOpen } from "lucide-react";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import { Link } from "react-router-dom";
import WearReminders from "@/components/shared/WearReminders";

const QUICK_TAGS = [
  { value: "favorite", label: "Favorites", icon: Heart, color: "text-rose-500", bg: "bg-rose-50 border-rose-200" },
  { value: "recommend", label: "Recommend", icon: ThumbsUp, color: "text-emerald-600", bg: "bg-emerald-50 border-emerald-200" },
  { value: "dislike", label: "Dislike", icon: ThumbsDown, color: "text-slate-500", bg: "bg-slate-50 border-slate-200" },
];

const COLLECTION_LISTS = [
  { value: "own", label: "Own", icon: Package, color: "text-primary", bg: "bg-primary/5 border-primary/20" },
  { value: "wishlist", label: "Wishlist", icon: ShoppingBag, color: "text-amber-600", bg: "bg-amber-50 border-amber-200" },
];

const EMOJI_PRESETS = ["📋", "⭐", "🌹", "💎", "🎁", "🌙", "☀️", "🔥", "💧", "🌿", "🎵", "✈️", "🏠", "💼", "🎯"];

export default function Lists() {
  const qc = useQueryClient();
   const { names, profiles } = usePersonNames();
   const { isAr } = useLang();
   const [activeSection, setActiveSection] = useState("tags");
  const [activeTag, setActiveTag] = useState("favorite");
  const [activeCollection, setActiveCollection] = useState("own");
  const [activeCustomList, setActiveCustomList] = useState(null);
  const [createListOpen, setCreateListOpen] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [newListIcon, setNewListIcon] = useState("📋");
  const [editListOpen, setEditListOpen] = useState(false);
  const [editingList, setEditingList] = useState(null);
  const [addPerfumeOpen, setAddPerfumeOpen] = useState(false);
  const [perfumeSearch, setPerfumeSearch] = useState("");

  // الكتالوج الكامل يُجلب فقط لمنتقي «إضافة عطر» وعند البحث — لا عند فتح الصفحة.
  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
    enabled: !!perfumeSearch.trim(),
  });

  const { data: customLists = [], isLoading: loadingLists } = useQuery({
    queryKey: ["custom-lists"],
    queryFn: () => apphost.entities.CustomList.list("name"),
  });

  const createListMutation = useMutation({
    mutationFn: (data) => apphost.entities.CustomList.create(data),
    onSuccess: (newList) => {
      qc.invalidateQueries({ queryKey: ["custom-lists"] });
      setActiveCustomList(newList.id);
      setActiveSection("custom");
      setCreateListOpen(false);
      setNewListName("");
      setNewListIcon("📋");
      toast.success((isAr ? "أُنشئت القائمة" : "List created"));
    },
  });

  const updateListMutation = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.CustomList.update(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["custom-lists"] });
      setEditListOpen(false);
      toast.success((isAr ? "حُدّثت القائمة" : "List updated"));
    },
  });

  const deleteListMutation = useMutation({
    mutationFn: (id) => apphost.entities.CustomList.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["custom-lists"] });
      setActiveCustomList(null);
      setActiveSection("tags");
      toast.success((isAr ? "حُذفت القائمة" : "List deleted"));
    },
  });

  // Per-person splits using UserPerfume
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: userGlossaryTerms = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });

  const glossaryFavorites = userGlossaryTerms.filter((r) => r.reaction === "favorite");

  // معرّفات عطور المجموعة فقط (من UserPerfume + القوائم) ثم نجلبها بالمعرّف — بلا تحميل 130 ألف.
  const collectionIds = useMemo(() => {
    const set = new Set();
    userPerfumes.forEach((u) => { if (u.perfume_id) set.add(String(u.perfume_id)); });
    customLists.forEach((l) => (l.perfume_ids || "").split(",").forEach((id) => { const t = id.trim(); if (t) set.add(t); }));
    return [...set];
  }, [userPerfumes, customLists]);

  const { data: collectionPerfumes = [], isLoading: colLoading } = useQuery({
    queryKey: ["collection-perfumes", collectionIds.join(",")],
    queryFn: () => apphost.entities.Perfume.getMany(collectionIds),
    enabled: collectionIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });

  const byId = useMemo(() => {
    const m = new Map();
    collectionPerfumes.forEach((p) => m.set(String(p.id), p));
    return m;
  }, [collectionPerfumes]);

  const getPersonTagPerfumes = (tag, person) =>
    userPerfumes.filter((u) => u.person === person && u.list === tag).map((u) => byId.get(String(u.perfume_id))).filter(Boolean);

  const getPersonCollectionPerfumes = (tag, person) =>
    userPerfumes.filter((u) => u.person === person && u.list === tag).map((u) => byId.get(String(u.perfume_id))).filter(Boolean);

  const getCustomListPerfumes = (list) => {
    if (!list?.perfume_ids) return [];
    return list.perfume_ids.split(",").map((id) => byId.get(id.trim())).filter(Boolean);
  };

  const togglePerfumeInCustomList = (list, perfume) => {
    const ids = list.perfume_ids ? list.perfume_ids.split(",").map((id) => id.trim()).filter(Boolean) : [];
    const newIds = ids.includes(perfume.id) ? ids.filter((id) => id !== perfume.id) : [...ids, perfume.id];
    updateListMutation.mutate({ id: list.id, data: { ...list, perfume_ids: newIds.join(",") } });
  };

  const currentCustomList = customLists.find((l) => String(l.id) === String(activeCustomList));
  // مُنتقي «إضافة عطر»: لا نعرض الـ130 ألف افتراضياً — نطلب البحث أولاً.
  const filteredPerfumes = perfumeSearch
    ? perfumes.filter((p) => p.name?.toLowerCase().includes(perfumeSearch.toLowerCase()) || p.brand_name?.toLowerCase().includes(perfumeSearch.toLowerCase()))
    : [];

  return (
    <div className="min-h-screen pb-24">
      {/* Header */}
      <div className="px-4 pt-12 pb-2">
        <BackButton fallback="/" />
        <div className="flex items-center justify-between mb-3">
          <h1 className="font-heading text-2xl font-bold">{isAr ? 'القوائم' : 'Lists'}</h1>
          <Button size="sm" onClick={() => setCreateListOpen(true)} className="h-8 rounded-none text-xs gap-1.5">
            New List
          </Button>
        </div>
        {/* Section switcher — يلتفّ على عدّة أسطر بدل سكرول أفقي */}
        <div className="flex flex-wrap gap-2 pb-1">
        <SectionPill active={activeSection === "tags"} onClick={() => setActiveSection("tags")} icon={<Heart className="w-3.5 h-3.5" />} label="Tags" />
        <SectionPill active={activeSection === "collection"} onClick={() => setActiveSection("collection")} icon={<Package className="w-3.5 h-3.5" />} label="Collection" />
        {customLists.map((list) => (
          <SectionPill
            key={list.id}
            active={activeSection === "custom" && activeCustomList === list.id}
            onClick={() => { setActiveSection("custom"); setActiveCustomList(list.id); }}
            icon={<span className="text-sm">{list.icon || "📋"}</span>}
            label={list.name}
          />
        ))}
        </div>
      </div>

      {/* Content — تدفّق طبيعي للصفحة بلا سكرول داخلي */}
      <div className="px-4 pb-4 space-y-5">

      {/* تذكير ارتداء العطر */}
      <WearReminders />

      {/* Tags section */}
      {activeSection === "tags" && (
        <div className="space-y-5">
          <div className="flex flex-wrap gap-2">
            {QUICK_TAGS.map(({ value, label, icon: TagIcon, color, bg }) => {
              const count = getPersonTagPerfumes(value, "person1").length + getPersonTagPerfumes(value, "person2").length;
              return (
                <button
                  key={value}
                  onClick={() => setActiveTag(value)}
                  className={`flex-1 min-w-[calc(33.333%-8px)] flex flex-col items-center gap-1.5 py-3 rounded-none border text-center transition-all ${activeTag === value ? `${bg} border-2 shadow-sm` : "bg-secondary/40 border-border/50"}`}
                >
                  <TagIcon className={`w-5 h-5 ${activeTag === value ? color : "text-muted-foreground"}`} />
                  <span className={`text-xs font-body font-semibold ${activeTag === value ? color : "text-muted-foreground"}`}>{label}</span>
                  <span className="text-[10px] font-body text-muted-foreground">{count}</span>
                </button>
              );
            })}
          </div>
          {/* Person 1 */}
          <PersonListSection
            name={names.person1}
            color={profiles?.person1?.color || "#10b981"}
            perfumes={getPersonTagPerfumes(activeTag, "person1")}
            isLoading={colLoading}
            label={QUICK_TAGS.find(t => t.value === activeTag)?.label}
          />
          {/* Separator */}
          <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
          {/* Person 2 */}
          <PersonListSection
            name={names.person2}
            color={profiles?.person2?.color || "#8b5cf6"}
            perfumes={getPersonTagPerfumes(activeTag, "person2")}
            isLoading={colLoading}
            label={QUICK_TAGS.find(t => t.value === activeTag)?.label}
          />
        </div>
      )}

      {/* Collection section */}
      {activeSection === "collection" && (
        <div className="space-y-5">
          <div className="grid grid-cols-2 gap-2">
            {COLLECTION_LISTS.map(({ value, label, icon: ColIcon, color, bg }) => {
              const count = getPersonCollectionPerfumes(value, "person1").length + getPersonCollectionPerfumes(value, "person2").length;
              return (
                <button
                  key={value}
                  onClick={() => setActiveCollection(value)}
                  className={`flex flex-col items-center gap-1.5 py-3 rounded-none border text-center transition-all ${activeCollection === value ? `${bg} border-2 shadow-sm` : "bg-secondary/40 border-border/50"}`}
                >
                  <ColIcon className={`w-5 h-5 ${activeCollection === value ? color : "text-muted-foreground"}`} />
                  <span className={`text-xs font-body font-semibold ${activeCollection === value ? color : "text-muted-foreground"}`}>{label}</span>
                  <span className="text-[10px] font-body text-muted-foreground">{count}</span>
                </button>
              );
            })}
          </div>
          {/* Person 1 */}
          <PersonListSection
            name={names.person1}
            color={profiles?.person1?.color || "#10b981"}
            perfumes={getPersonCollectionPerfumes(activeCollection, "person1")}
            isLoading={colLoading}
            label={COLLECTION_LISTS.find(c => c.value === activeCollection)?.label}
          />
          {/* Separator */}
          <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
          {/* Person 2 */}
          <PersonListSection
            name={names.person2}
            color={profiles?.person2?.color || "#8b5cf6"}
            perfumes={getPersonCollectionPerfumes(activeCollection, "person2")}
            isLoading={colLoading}
            label={COLLECTION_LISTS.find(c => c.value === activeCollection)?.label}
          />
        </div>
      )}

      {/* Custom list section */}
      {activeSection === "custom" && currentCustomList && (
        <div className="space-y-4">
          <div className="flex items-center justify-between bg-card border border-border/60 rounded-none px-4 py-3">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">{currentCustomList.icon || "📋"}</span>
              <div>
                <p className="font-heading font-semibold text-sm">{currentCustomList.name}</p>
                <p className="text-[11px] text-muted-foreground font-body">{getCustomListPerfumes(currentCustomList).length} perfumes</p>
              </div>
            </div>
            <div className="flex gap-2">
              <button onClick={() => { setEditingList(currentCustomList); setEditListOpen(true); }} className="w-8 h-8 rounded-none bg-secondary flex items-center justify-center hover:bg-accent transition-colors">
                <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
              <button onClick={() => setAddPerfumeOpen(true)} className="flex items-center gap-1.5 px-3 h-8 rounded-none bg-primary/10 text-primary text-xs font-body font-medium hover:bg-primary/20 transition-colors">
                Add
              </button>
            </div>
          </div>
          <PerfumeGrid perfumes={getCustomListPerfumes(currentCustomList)} label={currentCustomList.name} isLoading={false}
            renderExtra={(p) => (
              <button onClick={() => togglePerfumeInCustomList(currentCustomList, p)} className="absolute top-1.5 right-1.5 w-6 h-6 rounded-none bg-destructive/90 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity z-10">
                <Trash2 className="w-3 h-3" />
              </button>
            )}
          />
        </div>
      )}

      {/* Empty custom list state */}
      {activeSection === "custom" && !currentCustomList && (
        <div className="text-center py-16 space-y-3">
          <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <List className="w-8 h-8 text-primary/30" />
          </div>
          <p className="text-muted-foreground font-body text-sm">{isAr ? "لم تُختر قائمة" : "No custom list selected"}</p>
        </div>
      )}

      {/* No custom lists yet */}
      {activeSection === "custom" && customLists.length === 0 && (
        <div className="text-center py-10 space-y-3">
          <p className="text-muted-foreground font-body text-sm">{isAr ? "أنشئ أول قائمة مخصّصة" : "Create your first custom list"}</p>
          <Button size="sm" onClick={() => setCreateListOpen(true)} className="rounded-none gap-1.5">
            New List
          </Button>
        </div>
      )}

      {/* Create list dialog */}
      <Dialog open={createListOpen} onOpenChange={setCreateListOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading flex items-center gap-2">
              <UserCircle2 className="w-5 h-5 text-primary" /> Create New List
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Preview */}
            <div className="flex items-center gap-3 bg-secondary/50 rounded-none px-4 py-3">
              <span className="text-2xl">{newListIcon}</span>
              <p className="font-heading font-semibold text-sm text-foreground">{newListName || "List name..."}</p>
            </div>
            <Input value={newListName} onChange={(e) => setNewListName(e.target.value)} placeholder="اسم القائمة... / List name..." className="rounded-none font-body" />
            <div className="flex gap-2 flex-wrap">
              {EMOJI_PRESETS.map((e) => (
                <button key={e} onClick={() => setNewListIcon(e)}
                  className={`w-9 h-9 rounded-none text-lg transition-all ${newListIcon === e ? "bg-primary/10 ring-2 ring-primary" : "bg-secondary hover:bg-accent"}`}>
                  {e}
                </button>
              ))}
            </div>
            <Button className="w-full rounded-none" disabled={!newListName.trim() || createListMutation.isPending}
              onClick={() => createListMutation.mutate({ name: newListName.trim(), icon: newListIcon, perfume_ids: "" })}>
              {createListMutation.isPending ? "Creating..." : "Create List"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit list dialog */}
      <Dialog open={editListOpen} onOpenChange={setEditListOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading">تعديل القائمة Edit List</DialogTitle>
          </DialogHeader>
          {editingList && (
            <div className="space-y-4">
              <div className="flex gap-2 flex-wrap">
                {EMOJI_PRESETS.map((e) => (
                  <button key={e} onClick={() => setEditingList({ ...editingList, icon: e })}
                    className={`w-9 h-9 rounded-none text-lg transition-all ${editingList.icon === e ? "bg-primary/10 ring-2 ring-primary" : "bg-secondary hover:bg-accent"}`}>
                    {e}
                  </button>
                ))}
              </div>
              <Input value={editingList.name} onChange={(e) => setEditingList({ ...editingList, name: e.target.value })}
                placeholder="اسم القائمة... / List name..." className="rounded-none font-body" />
              <div className="flex gap-2">
                <Button variant="destructive" className="flex-1 rounded-none" onClick={() => deleteListMutation.mutate(editingList.id)}>
                  Delete List
                </Button>
                <Button className="flex-1 rounded-none" disabled={!editingList.name.trim() || updateListMutation.isPending}
                  onClick={() => updateListMutation.mutate({ id: editingList.id, data: { name: editingList.name, icon: editingList.icon } })}>
                  Save
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Glossary Favourites section */}
      {activeSection === "tags" && glossaryFavorites.length > 0 && (
        <div className="space-y-3 pt-2">
          <div className="h-px bg-gradient-to-r from-transparent via-border to-transparent" />
          <div className="flex items-center gap-2">
            <BookOpen className="w-4 h-4 text-emerald-600" />
            <p className="text-sm font-body font-semibold text-emerald-700 dark:text-emerald-400">{isAr ? "مفضّلة المعجم" : "Glossary Favourites"}</p>
            <span className="text-[10px] text-muted-foreground font-body">· {glossaryFavorites.length}</span>
          </div>
          <div className="space-y-2">
            {glossaryFavorites.map((r) => (
              <Link
                key={r.id}
                to={`/glossary-term?id=${r.term_id}`}
                className="flex items-baseline gap-3 border-2 border-emerald-200 dark:border-emerald-800 bg-emerald-50/50 dark:bg-emerald-950/20 px-4 py-3 hover:bg-emerald-100 dark:hover:bg-emerald-900/20 transition-colors"
                style={{ borderRadius: 0 }}
              >
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 600,
                    fontStyle: "italic",
                    color: "#b8960c",
                    fontSize: "0.95rem",
                  }}
                >
                  {r.term_en}
                </span>
                {r.term_ar && (
                  <span className="font-heading text-sm text-emerald-700 dark:text-emerald-400" dir="rtl">{r.term_ar}</span>
                )}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Add perfume to custom list dialog */}
      <Dialog open={addPerfumeOpen} onOpenChange={setAddPerfumeOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="font-heading">إضافة عطور Add Perfumes</DialogTitle>
          </DialogHeader>
          <Input value={perfumeSearch} onChange={(e) => setPerfumeSearch(e.target.value)} placeholder="بحث... / Search..." className="rounded-none font-body" />
          <div className="overflow-y-auto space-y-1.5 flex-1 mt-2">
            {filteredPerfumes.map((p) => {
              const ids = currentCustomList?.perfume_ids ? currentCustomList.perfume_ids.split(",").map(id => id.trim()).filter(Boolean) : [];
              const inList = ids.includes(p.id);
              return (
                <button key={p.id} onClick={() => togglePerfumeInCustomList(currentCustomList, p)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-none text-left transition-all ${inList ? "bg-primary/10 border border-primary/20" : "bg-secondary/50 hover:bg-secondary"}`}>
                  {p.image_url ? (
                    <img src={p.image_url} alt={p.name} className="w-8 h-8 rounded-none object-cover flex-shrink-0" />
                  ) : (
                    <div className="w-8 h-8 rounded-none bg-secondary flex items-center justify-center flex-shrink-0">
                      <Droplets className="w-4 h-4 text-primary/40" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-body font-semibold truncate">{p.name}</p>
                    <p className="text-[10px] text-muted-foreground font-body truncate">{p.brand_name}</p>
                  </div>
                  {inList && <span className="text-primary text-xs font-body font-bold flex-shrink-0">✓</span>}
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      </div>{/* end scrollable */}
    </div>
  );
}

function SectionPill({ active, onClick, icon, label }) {
  return (
    <button onClick={onClick}
      className={`flex-shrink-0 flex items-center gap-1.5 rounded-none text-xs font-body font-medium transition-all ${active ? " text-primary-foreground " : " text-muted-foreground hover:text-foreground"}`}>
      {icon}{label}
    </button>
  );
}

function PersonListSection({ name, color, perfumes, isLoading, label }) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <div className="w-2.5 h-2.5 rounded-none flex-shrink-0" style={{ backgroundColor: color }} />
        <p className="text-xs font-body font-semibold text-foreground">{name}</p>
        <span className="text-[10px] text-muted-foreground font-body">· {perfumes.length}</span>
      </div>
      <PerfumeGrid perfumes={perfumes} label={label} isLoading={isLoading} />
    </div>
  );
}

function PerfumeGrid({ perfumes, label, isLoading, renderExtra }) {
  if (isLoading) return (
    <div className="flex justify-center py-16">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );
  if (perfumes.length === 0) return (
    <div className="text-center py-16 space-y-3">
      <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
        <Droplets className="w-8 h-8 text-primary/30" />
      </div>
      <p className="text-muted-foreground font-body text-sm">{`لا عطور في ${label} بعد No perfumes in ${label} yet`}</p>
    </div>
  );
  return (
    <div className="space-y-2">
      <p className="text-xs text-muted-foreground font-body">{perfumes.length} perfumes</p>
      <div className="grid grid-cols-2 gap-3">
        {perfumes.map((p) => (
          <div key={p.id} className="relative group">
            <PerfumeCard perfume={p} />
            {renderExtra?.(p)}
          </div>
        ))}
      </div>
    </div>
  );
}