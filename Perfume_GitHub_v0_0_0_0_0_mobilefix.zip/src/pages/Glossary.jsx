import { useState, useRef, useEffect } from "react";
import { compareGlossary } from "@/lib/sortName";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Search, X, ImagePlus, Download, AArrowUp, AArrowDown } from "lucide-react";
import { toast } from "sonner";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Link } from "react-router-dom";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import Pagination from "@/components/shared/Pagination";
import { useLang } from "@/lib/LanguageContext";
import { getSecureStorage, setSecureStorage } from "@/lib/storageEncryption";

/**
 * Glossary & Tales (معجم و حكايا)
 *
 * Two-tab layout:
 *   - Vocabulary (term): Quick perfumery vocabulary — "The Language of"
 *   - Stories (story): Bedtime stories of perfume houses — literary, narrative
 *
 * Entries are distinguished by `entry_type`: "term" | "story"
 */
export default function Glossary() {
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState(() => {
    // Honor ?tab=story|term. Default landing is the Vocabulary (term) tab,
    // so the "Glossary" link shows vocabulary and the "Story" link (?tab=story)
    // shows stories.
    const t = new URLSearchParams(window.location.search).get("tab");
    // legacy ?tab=s/era/symbolism removed (Perfume Era & Marking Meaning features deleted)
    if (t === "story") return "story";
    return "term";
  }); // "term" | "story" | "era"
  const [sortOrder, setSortOrder] = useState(() => {
    const saved = getSecureStorage("glossarySettings", null);
    return saved ? saved.sortOrder || "alpha_asc" : "alpha_asc";
  });
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({
    term_en: "",
    term_ar: "",
    meaning: "",
    meaning_ar: "",
    tags: "",
    image_url: "",
    entry_type: "term",
  });
  const [uploadingImg, setUploadingImg] = useState(false);
  const imgRef = useRef();

  // ── @-tags input (individual chips) ──────────────────────────────────
  // Tags are stored in form.tags as a comma-separated string (unchanged data
  // shape), but entered/displayed as individual chips. Each chip is a future
  // "@word" mention link (the @ page is planned). The user adds one word at a
  // time; the system splits/dedupes — no need to type commas or spaces.
  const [tagInput, setTagInput] = useState("");
  // Tags are split and rendered as chips. Dedupe defensively: pre-292 seed
  // data shipped some entries with duplicate tags (e.g. "music, ..., music")
  // which broke React's unique-key contract when rendered as <span key={t}>.
  const tagList = (() => {
    const raw = (form.tags || "").split(",").map((t) => t.trim()).filter(Boolean);
    const seen = new Set();
    return raw.filter((t) => {
      const k = t.toLowerCase();
      if (seen.has(k)) return false;
      seen.add(k);
      return true;
    });
  })();
  const addTag = (raw) => {
    const word = (raw || "").trim().replace(/^@+/, ""); // strip leading @ if user typed it
    if (!word) return;
    if (tagList.some((t) => t.toLowerCase() === word.toLowerCase())) { setTagInput(""); return; }
    setForm((f) => ({ ...f, tags: [...tagList, word].join(", ") }));
    setTagInput("");
  };
  const removeTag = (word) => {
    setForm((f) => ({ ...f, tags: tagList.filter((t) => t !== word).join(", ") }));
  };

  const { data: terms = [], isLoading } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.GlossaryTerm.create({ ...data, is_user: true }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      setAddOpen(false);
      setTagInput("");
      setForm({
        term_en: "",
        term_ar: "",
        meaning: "",
        meaning_ar: "",
        tags: "",
        image_url: "",
        entry_type: activeTab,
      });
    },
  });

  // Filter by active tab + search
  // Default entry_type for legacy entries: "term"
  const filtered = terms.filter((t) => {
    const q = search.toLowerCase();
    const matchesSearch =
      String(t.term_en || "").toLowerCase().includes(q) ||
      String(t.term_ar || "").includes(search) ||
      String(t.meaning || "").toLowerCase().includes(q) ||
      String(t.meaning_ar || "").includes(search) ||
      String(t.tags || "").toLowerCase().includes(q);
    // تبويب المهملات: نعرض كل المخفيّات (قصص ومفردات معاً)
    if (activeTab === "trash") return t.hidden && matchesSearch;
    // التبويبات العادية: نستبعد المخفيّات
    if (t.hidden) return false;
    const entryType = t.entry_type || "term";
    if (entryType !== activeTab) return false;
    return matchesSearch;
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortOrder === "alpha_asc") return compareGlossary(a, b, 1);
    if (sortOrder === "alpha_desc") return compareGlossary(a, b, -1);
    if (sortOrder === "newest") return new Date(b.created_date) - new Date(a.created_date);
    if (sortOrder === "oldest") return new Date(a.created_date) - new Date(b.created_date);
    return 0;
  });

  // Pagination (50 per page)
  const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  useEffect(() => { setPage(1); }, [activeTab, search, sortOrder]);
  useEffect(() => { if (page > pageCount) setPage(1); }, [page, pageCount]);
  const pagedTerms = sorted.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  useEffect(() => {
    const handler = () => {
      const saved = getSecureStorage("glossarySettings", null);
      if (saved) setSortOrder(saved.sortOrder || "alpha_asc");
    };
    window.addEventListener("glossarySettingsChanged", handler);
    return () => window.removeEventListener("glossarySettingsChanged", handler);
  }, []);

  const handleImgUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingImg(true);
    const { file_url } = await apphost.integrations.Core.UploadFile({ file });
    setForm((f) => ({ ...f, image_url: file_url }));
    setUploadingImg(false);
  };

  const openAddDialog = () => {
    setForm((f) => ({ ...f, entry_type: activeTab }));
    setAddOpen(true);
  };

  // استعادة مدخل من المهملات
  const restoreMutation = useMutation({
    mutationFn: (id) => apphost.entities.GlossaryTerm.update(id, { hidden: false }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      toast.success(isAr ? "تمت الاستعادة" : "Restored");
    },
  });

  return (
    <div className="px-4 pt-12 pb-20 space-y-4">
      {/* Header row: back arrow + actions on one line (title below) */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/" />
        <div className="flex items-center gap-2">
          <Link
            to="/reading-guide"
            className="flex items-center text-[10px] font-body font-medium rounded-none text-amber-700 transition-colors"
            title={isAr ? "موجِّهة القراءة" : "Reading Guide"}
          >
            {isAr ? "موجِّهة" : "Guide"}
          </Link>
          <Link
            to="/at"
            className="flex items-center gap-1 text-[10px] font-body font-medium rounded-none text-amber-700 transition-colors"
            title={isAr ? "كلّ المَنشنات" : "All mentions"}
          >
            @
          </Link>
          {activeTab !== "symbolism" && (
          <button
            type="button"
            onClick={() => {
              const list = sorted.filter((t) => (activeTab === "story" ? t.entry_type === "story" : (t.entry_type || "term") === "term"));
              if (list.length === 0) {
                toast.error(isAr ? "لا عناصر للتصدير" : "Nothing to export");
                return;
              }
              import("@/lib/glossaryExport").then(({ exportTermList }) => {
                exportTermList(list, {
                  title: activeTab === "story" ? "Stories" : "Glossary",
                });
              });
            }}
            className="flex items-center gap-1 text-[10px] font-body font-medium rounded-none text-muted-foreground transition-colors"
            title={isAr ? "تصدير PDF" : "Export PDF"}
          >
            <Download className="w-3 h-3" /> PDF
          </button>
          )}
          {activeTab !== "era" && activeTab !== "symbolism" && (
          <Button
            onClick={openAddDialog}
            size="sm"
            variant="ghost"
            className="rounded-none text-emerald-600 hover:bg-emerald-600/10 hover:text-emerald-700 text-xs px-3"
          >
            {isAr ? "إضافة" : "Add"}
          </Button>
          )}
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* Title on the next line */}
      <h1
        style={{
          fontFamily: "'Playfair Display', serif",
          fontSize: "1.05rem",
          fontWeight: 700,
                    color: "#059669",
          letterSpacing: "0.02em",
          lineHeight: 1.1,
        }}
      >
        {isAr ? "معجم و حكايا" : "Glossary & Tales"}
      </h1>

      {/* Tabs: Stories Vocabulary (بلا أيقونات) */}
      <div className="flex gap-2 border-b border-border/60">
        <button
          onClick={() => setActiveTab("story")}
          className={`px-3 py-2 text-sm font-body font-medium transition-colors border-b-2 ${
            activeTab === "story"
              ? "border-emerald-600 text-emerald-700 dark:text-emerald-400"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "قصص" : "Stories"}
        </button>
        <button
          onClick={() => setActiveTab("term")}
          className={`px-3 py-2 text-sm font-body font-medium transition-colors border-b-2 ${
            activeTab === "term"
              ? "border-emerald-600 text-emerald-700 dark:text-emerald-400"
              : "border-transparent text-muted-foreground hover:text-foreground"
          }`}
        >
          {isAr ? "مفردات" : "Vocabulary"}
        </button>
      </div>

      {(
       <>
      {/* Tab description — bilingual, fit-to-screen, multi-line for stories */}
      {activeTab === "trash" ? (
        <p className="text-[10px] tracking-[0.18em] text-amber-600/70 dark:text-amber-400/60 font-body uppercase">
          {isAr ? "المخفيّ من القصص و المفردات — اضغط للاستعادة" : "Hidden stories & vocabulary — tap to restore"}
        </p>
      ) : activeTab === "term" ? (
        <p className="text-[10px] tracking-[0.18em] text-emerald-600/70 dark:text-emerald-400/60 font-body uppercase">
          {isAr ? "لغة" : "Language"}
        </p>
      ) : (
        <div className="text-emerald-600/70 dark:text-emerald-400/60 font-body leading-relaxed space-y-0.5">
          <p
            className="text-[11px] tracking-tight"
            dir="ltr"
            style={{ unicodeBidi: "isolate" }}
          >
            A stories to read.. listen.. write.. share.. think.. enjoy..
          </p>
          <p
            className="text-[11px] tracking-tight"
            dir="rtl"
            style={{ unicodeBidi: "isolate" }}
          >
            قصص للقراءة.. استماع.. للكتابة.. مشاركة.. تأمل.. للاستمتاع..
          </p>
        </div>
      )}

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={
            activeTab === "term"
              ? "ابحث في المفردات... / Search vocabulary..."
              : "ابحث في القصص... / Search stories..."
          }
          className="pl-9 rounded-none h-10 font-body text-sm"
        />
      </div>

      {/* Sort controls — moved here from the user menu */}
      <div className="flex items-center gap-1.5 flex-wrap">
        <span className="text-[10px] text-muted-foreground font-body uppercase tracking-wider mr-1">
          {isAr ? "ترتيب" : "Sort"}
        </span>
        {[
          { value: "alpha_asc", en: "Alphabetical", ar: "أبجدي", Icon: AArrowUp },
          { value: "alpha_desc", en: "Descend", ar: "معكوس", Icon: AArrowDown },
          { value: "newest", en: "Newest", ar: "الأحدث" },
          { value: "oldest", en: "Oldest", ar: "الأقدم" },
        ].map(({ value, en, ar, Icon }) => (
          <button
            key={value}
            onClick={() => {
              setSortOrder(value);
              const cur = getSecureStorage("glossarySettings", {}) || {};
              setSecureStorage("glossarySettings", { ...cur, sortOrder: value });
            }}
            className={
              Icon
                ? // Alphabetical / Descend: transparent, blends with the page; only the active one tints
                  `flex items-center gap-1 px-2 py-1 text-[11px] font-body font-medium bg-transparent transition-colors ${
                    sortOrder === value ? "text-primary" : "text-muted-foreground hover:text-foreground"
                  }`
                : ` rounded-none text-[11px] font-body font-medium transition-colors ${
 sortOrder === value
 ? " text-white"
 : " text-muted-foreground "
 }`
            }
            title={isAr ? ar : en}
          >
            {Icon ? <Icon className="w-4 h-4" /> : (isAr ? ar : en)}
          </button>
        ))}
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-emerald-300 border-t-emerald-600 rounded-full animate-spin" />
        </div>
      )}

      {/* Empty */}
      {!isLoading && sorted.length === 0 && (
        <div className="text-center py-16 space-y-3">
          <p className="font-heading text-lg text-muted-foreground">
            {activeTab === "trash"
              ? isAr ? "المهملات فارغة" : "Nothing cast out"
              : activeTab === "term"
              ? isAr
                ? "لا مصطلحات بعد"
                : "No terms yet"
              : isAr
              ? "لا قصص بعد"
              : "No stories yet"}
          </p>
          {activeTab !== "trash" && (
          <Button onClick={openAddDialog} className="rounded-none bg-emerald-600 hover:bg-emerald-700 text-white">
            {activeTab === "term"
              ? isAr
                ? "إضافة مصطلح"
                : "Add Term"
              : isAr
              ? "إضافة قصة"
              : "Add Story"}
          </Button>
          )}
        </div>
      )}

      {/* List — clean ruled layout: no card, no background, no box border.
          Only the distinctive title color + a thin separator line between
          entries (gold for stories, green for terms — matching the text). */}
      <div>
        {pagedTerms.map((term) => {
          const isTrash = activeTab === "trash";
          const isStory = isTrash ? term.entry_type === "story" : activeTab === "story";
          const accent = isTrash ? "#b45309" : isStory ? "#a16207" : "#047857"; // amber | gold | emerald
          return (
            <div key={term.id} className="relative group flex items-center">
              <Link
                to={`/glossary-term?id=${term.id}`}
                className="flex-1 px-1 py-3 flex items-baseline gap-3 transition-opacity hover:opacity-70"
                style={{ borderBottom: `1px solid ${accent}59` }}
              >
                <span
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    fontWeight: 600,
                                        color: accent,
                    fontSize: "1rem",
                  }}
                >
                  {term.term_en}
                </span>
                {term.term_ar && (
                  <span
                    className="font-heading text-sm"
                    style={{ color: accent }}
                    dir="rtl"
                  >
                    {term.term_ar}
                  </span>
                )}
                {isTrash && (
                  <span className="text-[9px] text-muted-foreground/60 font-body ml-auto">
                    {term.entry_type === "story" ? (isAr ? "قصة" : "story") : (isAr ? "مفردة" : "term")}
                  </span>
                )}
              </Link>
              {isTrash && (
                <button
                  onClick={() => restoreMutation.mutate(term.id)}
                  title={isAr ? "استعادة" : "Restore"}
                  className="absolute right-1 text-[10px] font-body text-amber-600 hover:text-amber-700 px-1.5 py-1"
                >
                  {isAr ? "استعادة" : "Restore"}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Page switcher (50 per page) */}
      <Pagination
        page={page}
        pageCount={pageCount}
        onChange={setPage}
        totalItems={sorted.length}
        pageSize={PAGE_SIZE}
      />
       </>
      )}

      {/* Add dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading" style={{ color: "#b8960c" }}>
              {form.entry_type === "story"
                ? isAr
                  ? "قصة جديدة"
                  : "New Story"
                : isAr
                ? "مصطلح جديد"
                : "New Term"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {/* Entry type toggle */}
            <div className="flex gap-2 p-1 bg-secondary/40 rounded-none">
              <button
                onClick={() => setForm((f) => ({ ...f, entry_type: "term" }))}
                className={`flex-1 text-xs font-body rounded-none transition-all ${
 form.entry_type === "term"
 ? " text-white font-semibold "
 : "text-muted-foreground"
 }`}
              >
                {isAr ? "مصطلح" : "Term"}
              </button>
              <button
                onClick={() => setForm((f) => ({ ...f, entry_type: "story" }))}
                className={`flex-1 text-xs font-body rounded-none transition-all ${
 form.entry_type === "story"
 ? " text-white font-semibold "
 : "text-muted-foreground"
 }`}
              >
                {isAr ? "قصة" : "Story"}
              </button>
            </div>

            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                {form.entry_type === "story"
                  ? isAr
                    ? "اسم القصّة (إنجليزي) *"
                    : "Story title (English) *"
                  : isAr
                  ? "المصطلح (إنجليزي) *"
                  : "Term (English) *"}
              </label>
              <Input
                value={form.term_en}
                onChange={(e) => setForm({ ...form, term_en: e.target.value })}
                placeholder={form.entry_type === "story" ? (isAr ? "اسم القصّة" : "Story title") : "Word"}
                className="rounded-none font-body"
              />
            </div>
            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                {form.entry_type === "story"
                  ? isAr
                    ? "اسم القصّة (عربي)"
                    : "Story title (Arabic)"
                  : isAr
                  ? "المصطلح (عربي)"
                  : "Term (Arabic)"}
              </label>
              <Input
                value={form.term_ar}
                onChange={(e) => setForm({ ...form, term_ar: e.target.value })}
                placeholder={form.entry_type === "story" ? (isAr ? "اسم القصّة بالعربي" : "Story title") : "مفردة"}
                className="rounded-none font-body text-right"
                dir="rtl"
              />
            </div>
            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                {form.entry_type === "story"
                  ? isAr ? "القصة (إنجليزي)" : "Story (English)"
                  : isAr ? "المعنى (إنجليزي)" : "Meaning (English)"}
              </label>
              <Textarea
                value={form.meaning}
                onChange={(e) => setForm({ ...form, meaning: e.target.value })}
                placeholder={
                  form.entry_type === "story"
                    ? (isAr ? "النص الإنجليزي للقصة..." : "English story text...")
                    : (isAr ? "التعريف بالإنجليزية" : "Definition in English")
                }
                className={`rounded-none font-body resize-none ${
                  form.entry_type === "story" ? "min-h-[160px]" : "min-h-[70px]"
                }`}
                dir="ltr"
              />
            </div>
            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                {form.entry_type === "story"
                  ? isAr ? "القصة (عربي)" : "Story (Arabic)"
                  : isAr ? "المعنى (عربي)" : "Meaning (Arabic)"}
              </label>
              <Textarea
                value={form.meaning_ar}
                onChange={(e) => setForm({ ...form, meaning_ar: e.target.value })}
                placeholder={
                  form.entry_type === "story"
                    ? (isAr ? "النص العربي للقصة..." : "Arabic story text...")
                    : (isAr ? "التعريف بالعربية" : "Definition in Arabic")
                }
                className={`rounded-none font-body resize-none text-right ${
                  form.entry_type === "story" ? "min-h-[160px]" : "min-h-[70px]"
                }`}
                dir="rtl"
              />
            </div>
            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                @
              </label>
              {/* Chips for already-added tags */}
              {tagList.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mb-2">
                  {tagList.map((t) => (
                    <span
                      key={t}
                      className="inline-flex items-center gap-1 rounded-none text-emerald-700 dark:text-emerald-400 text-[11px] font-body"
                    >
                      <span dir="auto">@{t}</span>
                      <button
                        type="button"
                        onClick={() => removeTag(t)}
                        className="text-emerald-700/70 hover:text-emerald-900 dark:hover:text-emerald-200 leading-none"
                        aria-label={isAr ? "حذف" : "Remove"}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                </div>
              )}
              <Input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === "," || e.key === " ") {
                    e.preventDefault();
                    addTag(tagInput);
                  } else if (e.key === "Backspace" && !tagInput && tagList.length) {
                    removeTag(tagList[tagList.length - 1]);
                  }
                }}
                onBlur={() => addTag(tagInput)}
                placeholder={isAr ? "اكتب كلمة ثم Enter" : "Type a word, then Enter"}
                className="rounded-none font-body"
                dir="auto"
              />
            </div>
            <div>
              <label className="text-xs font-body text-muted-foreground mb-1 block">
                {isAr ? "صورة (اختياري)" : "Image (optional)"}
              </label>
              <input ref={imgRef} type="file" accept="image/*" className="hidden" onChange={handleImgUpload} />
              {form.image_url ? (
                <div className="relative">
                  <img src={form.image_url} alt="preview" className="w-full h-28 object-cover rounded-none" />
                  <button
                    type="button"
                    onClick={() => setForm((f) => ({ ...f, image_url: "" }))}
                    className="absolute top-1.5 right-1.5 bg-black/50 text-white rounded-none w-5 h-5 flex items-center justify-center hover:bg-black/80"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => imgRef.current?.click()}
                  disabled={uploadingImg}
                  className="w-full h-16 border-2 border-dashed border-emerald-300 rounded-none flex items-center justify-center gap-2 text-sm font-body text-emerald-600 hover:border-emerald-500 hover:bg-emerald-50 transition-colors"
                >
                  <ImagePlus className="w-4 h-4" />
                  {uploadingImg ? (isAr ? "جارٍ الرفع..." : "Uploading...") : isAr ? "إضافة صورة" : "Add Image"}
                </button>
              )}
            </div>
            <Button
              className={`w-full rounded-none text-white ${
                form.entry_type === "story"
                  ? "bg-amber-600 hover:bg-amber-700"
                  : "bg-emerald-600 hover:bg-emerald-700"
              }`}
              disabled={!form.term_en.trim() || createMutation.isPending}
              onClick={() => {
                // Commit any word still in the tag input box
                const pending = tagInput.trim().replace(/^@+/, "");
                const finalTags = pending && !tagList.some((t) => t.toLowerCase() === pending.toLowerCase())
                  ? [...tagList, pending].join(", ")
                  : form.tags;
                createMutation.mutate({ ...form, tags: finalTags });
              }}
            >
              {createMutation.isPending
                ? isAr
                  ? "جارٍ الإضافة..."
                  : "Adding..."
                : form.entry_type === "story"
                ? isAr
                  ? "إضافة قصة"
                  : "Add Story"
                : isAr
                ? "إضافة مصطلح"
                : "Add Term"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
