import { getAppName } from "@/lib/useAppName";
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { useCurrency } from "@/lib/useCurrency";
import { usePersonNames } from "@/lib/usePersonNames";
import StatisticsExportDialog from "@/components/statistics/StatisticsExportDialog";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import CopyMenu from "@/components/shared/CopyMenu";

/**
 * Statistics — a quick "where I stand" snapshot of the user's library and
 * activity. Bilingual headings; numbers stay in numerals.
 *
 * Sections (in order):
 *   1. Collection — perfumes owned, brands, samples, decants, total bottle ml
 *   2. Activity — wear logs total, last 30/90 days, most-worn perfume
 *   3. Money — total spent, this year, average per bottle, top spend month
 *   4. Tastes — favorite brands, disliked brands, most-used notes
 *   5. Engagement — quotes interacted with, blog posts, glossary terms touched
 *
 * Includes a Copy button (plain-text bilingual snapshot) for sharing.
 */

// ── helpers ────────────────────────────────────────────────────────────────
function StatCard({ icon, labelEn, labelAr, value, hint }) {
  return (
    <div className="flex flex-col items-center text-center px-2 py-3">
      {icon && <span className="text-xl leading-none mb-1">{icon}</span>}
      <p className="text-xl font-heading font-bold tabular-nums">{value}</p>
      <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-body mt-1" dir="ltr">{labelEn}</p>
      <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-body" dir="rtl">{labelAr}</p>
      {hint && <p className="text-[9px] text-muted-foreground font-body mt-0.5">{hint}</p>}
    </div>
  );
}

function SectionHeader({ en, ar, emoji, first = false }) {
  return (
    <>
      {!first && (
        <div
          aria-hidden="true"
          className="h-px my-5"
          style={{ background: "rgba(200, 160, 46, 0.4)" }}
        />
      )}
      <div className="flex items-baseline gap-2 mt-2 mb-1 px-1">
        {emoji && <span className="text-base">{emoji}</span>}
        <h2 className="font-heading font-semibold text-sm" dir="ltr">{en}</h2>
        <h2 className="font-heading font-semibold text-sm text-foreground/80" dir="rtl">{ar}</h2>
      </div>
    </>
  );
}

function TopList({ items, emptyLabelEn = "No data yet", emptyLabelAr = "لا بيانات بعد" }) {
  if (!items || items.length === 0) {
    return (
      <p className="text-xs text-muted-foreground font-body italic text-center py-2" dir="auto">
        {emptyLabelEn} {emptyLabelAr}
      </p>
    );
  }
  return (
    <ul className="space-y-1.5 list-none p-0 m-0">
      {items.map((it, i) => (
        <li key={i} className="flex items-center justify-between text-xs font-body py-1.5 border-b border-border/30 last:border-b-0">
          <span className="flex items-center gap-2 min-w-0">
            <span className="text-muted-foreground tabular-nums">{String(i + 1).padStart(2, "0")}</span>
            <span className="truncate">{it.label}</span>
          </span>
          <span className="font-semibold tabular-nums text-foreground/80 flex-shrink-0">{it.value}</span>
        </li>
      ))}
    </ul>
  );
}

// ── page ───────────────────────────────────────────────────────────────────
export default function Statistics() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { formatPrice } = useCurrency();
  const { names } = usePersonNames();

  // تصفية حسب الشخص: all | family | person1 | person2
  const [scope, setScope] = useState("all");
  const [exportOpen, setExportOpen] = useState(false);

  // Data
  const { data: perfumes = [] }       = useQuery({ queryKey: ["perfumes"],     queryFn: () => apphost.entities.Perfume.list("-created_date") });
  const { data: brands = [] }         = useQuery({ queryKey: ["all-brands"],       queryFn: () => apphost.entities.PerfumeBrand.list("-created_date") });
  const { data: userPerfumes = [] }   = useQuery({ queryKey: ["all-user-perfumes"],queryFn: () => apphost.entities.UserPerfume.list("-created_date") });
  const { data: wearLogs = [] }       = useQuery({ queryKey: ["all-wear-logs"],    queryFn: () => apphost.entities.WearLog.list("-created_date") });
  const { data: purchases = [] }      = useQuery({ queryKey: ["all-purchases"],    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date") });
  const { data: userBrands = [] }     = useQuery({ queryKey: ["all-user-brands"],  queryFn: () => apphost.entities.UserBrand.list("-created_date") });
  const { data: userQuotes = [] }     = useQuery({ queryKey: ["all-user-quotes"],  queryFn: () => apphost.entities.UserQuote.list("-created_date") });
  // بيانات الميزانية
  const { data: incomes = [] }        = useQuery({ queryKey: ["budget-incomes"],   queryFn: () => apphost.entities.BudgetIncome.list("-date") });
  const { data: expenses = [] }       = useQuery({ queryKey: ["budget-expenses"],  queryFn: () => apphost.entities.BudgetExpense.list("-date") });
  const { data: obligations = [] }    = useQuery({ queryKey: ["budget-obligations"], queryFn: () => apphost.entities.BudgetObligation.list("-created_date") });
  const { data: savingsGoals = [] }   = useQuery({ queryKey: ["savings-goals"],    queryFn: () => apphost.entities.SavingsGoal.list("-target_date") });

  // مطابقة الشخص: "all" يقبل الجميع، غير ذلك يطابق الشخص أو "family"
  const matchScope = (personField) => {
    if (scope === "all") return true;
    if (scope === "family") return personField === "family";
    return personField === scope || personField === "family";
  };

  // نسخ مفلترة حسب الشخص المختار
  const fUserPerfumes = useMemo(() => userPerfumes.filter((u) => matchScope(u.person)), [userPerfumes, scope]);
  const fWearLogs = useMemo(() => wearLogs.filter((w) => matchScope(w.person)), [wearLogs, scope]);
  const fPurchases = useMemo(() => purchases.filter((p) => matchScope(p.person)), [purchases, scope]);

  // ── حسابات الميزانية (مفلترة) ──
  const monthKey = new Date().toISOString().slice(0, 7);
  const fIncomes = incomes.filter((i) => matchScope(i.person) && (i.date || "").startsWith(monthKey));
  const fExpenses = expenses.filter((e) => matchScope(e.person) && (e.date || "").startsWith(monthKey));
  const fObligations = obligations.filter((o) => matchScope(o.person) && o.status === "active");
  const fSavings = savingsGoals.filter((g) => g.is_active && (scope === "all" || g.person === scope || g.person === "family"));

  const fMonthPurchases = purchases.filter((p) => matchScope(p.person) && (p.purchase_date || "").startsWith(monthKey));
  const monthlyPurchases = fMonthPurchases.reduce((s, p) => s + (p.cost || 0), 0);

  const monthlyIncome = fIncomes.reduce((s, i) => s + (i.amount || 0), 0);
  // المصاريف الشهرية = مصاريف الميزانية + مشتريات العطور هذا الشهر (مطابقةً لصفحة الميزانية)
  const monthlyExpense = fExpenses.reduce((s, e) => s + (e.amount || 0), 0) + monthlyPurchases;
  const monthlyObligations = fObligations.reduce((s, o) => s + (o.monthly_payment || 0), 0);
  const netMonthly = monthlyIncome - monthlyExpense - monthlyObligations;
  const totalSaved = fSavings.reduce((s, g) => s + (g.current_amount || 0), 0);
  const totalSavingsTarget = fSavings.reduce((s, g) => s + (g.target_amount || 0), 0);
  const yearProjection = netMonthly * 12;

  // Indexes
  const perfumeById = useMemo(() => {
    const m = {};
    for (const p of perfumes) m[String(p.id)] = p;
    return m;
  }, [perfumes]);

  const brandById = useMemo(() => {
    const m = {};
    for (const b of brands) m[String(b.id)] = b;
    return m;
  }, [brands]);

  // ── 1. Collection ──
  const ownedPerfumes = useMemo(() => {
    const ids = new Set(fUserPerfumes.map((u) => String(u.perfume_id)));
    return Array.from(ids).map((id) => perfumeById[id]).filter(Boolean);
  }, [fUserPerfumes, perfumeById]);

  const samples = useMemo(() => fPurchases.filter((p) => (p.type || "").toLowerCase() === "sample").length, [fPurchases]);
  const decants = useMemo(() => fPurchases.filter((p) => (p.type || "").toLowerCase() === "decant").length, [fPurchases]);
  const bottles = useMemo(() => fPurchases.filter((p) => (p.type || "").toLowerCase().includes("bottle") || (p.type || "").toLowerCase() === "full").length, [fPurchases]);

  const totalMl = useMemo(() => fPurchases.reduce((sum, p) => sum + (Number(p.ml) || 0), 0), [fPurchases]);
  const uniqueBrandsOwned = useMemo(() => {
    const set = new Set();
    for (const p of ownedPerfumes) if (p.brand_id) set.add(String(p.brand_id));
    return set.size;
  }, [ownedPerfumes]);

  // ── 2. Activity ──
  const now = Date.now();
  const days30 = now - 30 * 86400_000;
  const days90 = now - 90 * 86400_000;
  const wears30 = useMemo(() => fWearLogs.filter((w) => new Date(w.wear_date || w.date || w.created_date).getTime() >= days30).length, [fWearLogs, days30]);
  const wears90 = useMemo(() => fWearLogs.filter((w) => new Date(w.wear_date || w.date || w.created_date).getTime() >= days90).length, [fWearLogs, days90]);

  const topWornPerfumes = useMemo(() => {
    const counts = {};
    for (const w of fWearLogs) {
      const id = String(w.perfume_id || "");
      if (!id) continue;
      counts[id] = (counts[id] || 0) + 1;
    }
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([id, c]) => {
        const p = perfumeById[id];
        const label = p ? (p.name_en || p.name_ar || "—") : "—";
        return { label, value: c };
      });
  }, [fWearLogs, perfumeById]);

  // ── 3. Money ──
  const totalSpent = useMemo(() => fPurchases.reduce((sum, p) => sum + (Number(p.cost) || 0), 0), [fPurchases]);
  const yearNow = new Date().getFullYear();
  const spentThisYear = useMemo(() =>
    fPurchases
      .filter((p) => p.purchase_date && new Date(p.purchase_date).getFullYear() === yearNow)
      .reduce((sum, p) => sum + (Number(p.cost) || 0), 0)
  , [fPurchases, yearNow]);

  const avgPerBottle = useMemo(() => {
    const bottlePurchases = fPurchases.filter((p) => (p.type || "").toLowerCase().includes("bottle") || (p.type || "").toLowerCase() === "full");
    if (bottlePurchases.length === 0) return 0;
    const sum = bottlePurchases.reduce((s, p) => s + (Number(p.cost) || 0), 0);
    return Math.round(sum / bottlePurchases.length);
  }, [fPurchases]);

  // ── 4. Tastes ──
  const topBrandsByOwnership = useMemo(() => {
    const counts = {};
    for (const p of ownedPerfumes) {
      const bid = String(p.brand_id || "");
      if (!bid) continue;
      counts[bid] = (counts[bid] || 0) + 1;
    }
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([bid, c]) => {
        const b = brandById[bid];
        return { label: b?.name || "—", value: c };
      });
  }, [ownedPerfumes, brandById]);

  const favBrands = useMemo(() => userBrands.filter((u) => u.favorite || u.fav_brands_p1 || u.fav_brands_p2).length, [userBrands]);

  // Top notes by ownership (using top/heart/base note strings)
  const topNotes = useMemo(() => {
    const counts = {};
    for (const p of ownedPerfumes) {
      const allNotes = [
        ...(p.top_notes   || "").split(",").map((s) => s.trim()),
        ...(p.heart_notes || "").split(",").map((s) => s.trim()),
        ...(p.base_notes  || "").split(",").map((s) => s.trim()),
      ].filter(Boolean);
      for (const n of allNotes) {
        counts[n] = (counts[n] || 0) + 1;
      }
    }
    return Object.entries(counts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([n, c]) => ({ label: n, value: c }));
  }, [ownedPerfumes]);

  // ── 5. Engagement ──
  const quotesLiked     = userQuotes.filter((q) => q.reaction === "like").length;
  const quotesFavorited = userQuotes.filter((q) => q.favorite).length;
  const quotesWithThoughts = userQuotes.filter((q) => q.thought && q.thought.trim()).length;

  // ── Copy ──
  const buildSnapshot = () => {
    const ln = (label, val) => (val === undefined || val === null || val === "") ? null : `${label}: ${val}`;
    const sec = (title, items) => {
      const filtered = items.filter(Boolean);
      if (filtered.length === 0) return "";
      return [title, ...filtered, ""].join("\n");
    };
    const collection = sec("── Collection المجموعة ──", [
      ln("Perfumes owned العطور المملوكة",       ownedPerfumes.length),
      ln("Brands العلامات",                       uniqueBrandsOwned),
      ln("Bottles القوارير",                      bottles),
      ln("Decants التقسيمات",                     decants),
      ln("Samples العينات",                       samples),
      ln("Total ml المجموع بالمل",                 totalMl),
    ]);
    const activity = sec("── Activity النشاط ──", [
      ln("Total wears مرات الارتداء",             wearLogs.length),
      ln("Last 30 days آخر 30 يوم",              wears30),
      ln("Last 90 days آخر 90 يوم",              wears90),
    ]);
    const money = sec("── Money المالية ──", [
      ln("Total spent إجمالي الإنفاق",            formatPrice(totalSpent)),
      ln(`Spent in ${yearNow} إنفاق ${yearNow}`,    formatPrice(spentThisYear)),
      ln("Avg per bottle متوسط القارورة",         formatPrice(avgPerBottle)),
    ]);
    const tastes = sec("── Tastes الأذواق ──", [
      "Top brands أفضل العلامات:",
      ...topBrandsByOwnership.slice(0, 5).map((b, i) => `  ${i + 1}. ${b.label} (${b.value})`),
      "",
      "Top notes أهم النوتات:",
      ...topNotes.slice(0, 5).map((n, i) => `  ${i + 1}. ${n.label} (${n.value})`),
    ]);
    const engagement = sec("── Engagement التفاعل ──", [
      ln("Quotes liked إعجابات",                  quotesLiked),
      ln("Quotes favorited مفضلة",                quotesFavorited),
      ln("Thoughts written أفكار",                quotesWithThoughts),
    ]);
    return [`${getAppName().name_en} Progress تقدم`, "", collection, activity, money, tastes, engagement]
      .filter(Boolean).join("\n").trim();
  };

  const snapshotText = buildSnapshot();

  return (
    <div className="flex flex-col min-h-screen pb-8">
      {/* Header */}
      <div className="flex-shrink-0 px-4 pt-12 pb-3 bg-background border-b border-border/40">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost" size="icon"
              onClick={() => navigate(-1)}
              className="rounded-none -ml-2 h-8 w-8"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <div>
              <h1 className="font-heading text-lg font-bold leading-tight" dir={isAr ? "rtl" : "ltr"}>{isAr ? "تقدم" : "Progress"}</h1>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setExportOpen(true)}
              className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors"
              title={isAr ? "تصدير التقرير" : "Export report"}
            >
              <Download className="w-4 h-4 text-foreground/70" />
            </button>
            <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
          </div>
        </div>

        {/* شريط التصفية: الكل · العائلة · شخص أ · شخص ب */}
        <div className="flex flex-wrap gap-x-4 gap-y-1 mt-3">
          {[
            { v: "all", l: isAr ? "👥 الكل" : "👥 All" },
            { v: "family", l: isAr ? "🏠 العائلة" : "🏠 Family" },
            { v: "person1", l: names.person1 || "A" },
            { v: "person2", l: names.person2 || "B" },
          ].map((o) => (
            <button
              key={o.v}
              onClick={() => setScope(o.v)}
              className={`text-xs font-body py-1 transition-colors truncate ${scope === o.v ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground"}`}
            >
              {o.l}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-4 space-y-3">
        {/* 1. Collection */}
        <SectionHeader en="Collection" ar="المجموعة" emoji="🧴" first />
        <div className="grid grid-cols-2 gap-2">
          <StatCard icon="🌸" labelEn="Perfumes owned" labelAr="العطور المملوكة" value={ownedPerfumes.length} />
          <StatCard icon="🏷️" labelEn="Brands"          labelAr="العلامات"        value={uniqueBrandsOwned} />
          <StatCard icon="🍶" labelEn="Bottles"         labelAr="القوارير"        value={bottles} />
          <StatCard icon="🧪" labelEn="Decants"         labelAr="التقسيمات"       value={decants} />
          <StatCard icon="💧" labelEn="Samples"         labelAr="العينات"         value={samples} />
          <StatCard icon="📐" labelEn="Total ml"        labelAr="المجموع (مل)"     value={totalMl.toLocaleString()} />
        </div>

        {/* 2. Activity */}
        <SectionHeader en="Activity" ar="النشاط" emoji="📅" />
        <div className="grid grid-cols-3 gap-2">
          <StatCard labelEn="All time"    labelAr="الإجمالي"  value={fWearLogs.length} hint={isAr ? "ارتداءات" : "wears"} />
          <StatCard labelEn="Last 30d"    labelAr="آخر ٣٠ يوم" value={wears30} />
          <StatCard labelEn="Last 90d"    labelAr="آخر ٩٠ يوم" value={wears90} />
        </div>
        <div className="py-2">
          <div className="flex items-baseline justify-between mb-2">
            <p className="text-xs font-heading font-semibold" dir="ltr">{isAr ? "الأكثر ارتداءً" : "Most worn perfumes"}</p>
            <p className="text-[10px] text-muted-foreground font-body" dir="rtl">الأكثر ارتداءً</p>
          </div>
          <TopList items={topWornPerfumes} />
        </div>

        {/* 3. Money */}
        <SectionHeader en="Money" ar="المالية" emoji="💰" />
        <div className="grid grid-cols-2 gap-2">
          <StatCard icon="💵" labelEn="Total spent"     labelAr="الإنفاق الكلي"   value={formatPrice(totalSpent)} />
          <StatCard icon="📆" labelEn={`Spent ${yearNow}`} labelAr={`إنفاق ${yearNow}`} value={formatPrice(spentThisYear)} />
          <StatCard icon="🏷️" labelEn="Avg bottle"      labelAr="متوسط القارورة"  value={formatPrice(avgPerBottle)} />
          <StatCard icon="🛒" labelEn="Total purchases" labelAr="عدد المشتريات"   value={fPurchases.length} />
        </div>

        {/* قسم الميزانية الشهرية */}
        <SectionHeader en="Monthly Budget" ar="الميزانية الشهرية" emoji="📊" />
        <div className="grid grid-cols-2 gap-2">
          <StatCard icon="💵" labelEn="Income" labelAr="الدخل" value={formatPrice(monthlyIncome)} color="emerald" />
          <StatCard icon="💸" labelEn="Expenses" labelAr="المصاريف" value={formatPrice(monthlyExpense)} color="rose" />
          <StatCard icon="📋" labelEn="Obligations" labelAr="الالتزامات" value={formatPrice(monthlyObligations)} color="amber" />
          <StatCard icon={netMonthly >= 0 ? "📈" : "📉"} labelEn="Net / month" labelAr="الصافي شهرياً" value={formatPrice(netMonthly)} color={netMonthly >= 0 ? "primary" : "rose"} />
        </div>

        {/* التوقعات المستقبلية */}
        <SectionHeader en="Forecast" ar="التوقعات" emoji="🔮" />
        <div className="py-2 space-y-2">
          <div className="flex items-center justify-between text-sm font-body">
            <span className="text-muted-foreground">{isAr ? "متوقع خلال سنة" : "Projected over a year"}</span>
            <span className={`font-bold ${yearProjection >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatPrice(yearProjection)}</span>
          </div>
          <div className="flex items-center justify-between text-sm font-body">
            <span className="text-muted-foreground">{isAr ? "متوقع خلال 6 أشهر" : "Projected over 6 months"}</span>
            <span className={`font-bold ${netMonthly >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{formatPrice(netMonthly * 6)}</span>
          </div>
          <p className="text-[10px] text-muted-foreground font-body pt-1 border-t border-border/30">
            {isAr ? "بناءً على متوسط هذا الشهر" : "Based on this month's average"}
          </p>
        </div>

        {/* الادخار */}
        {(totalSavingsTarget > 0 || totalSaved > 0) && (
          <>
            <SectionHeader en="Savings" ar="الادخار" emoji="🎯" />
            <div className="py-2 space-y-2">
              <div className="flex items-center justify-between text-sm font-body">
                <span className="text-muted-foreground">{isAr ? "المُدخر" : "Saved"}</span>
                <span className="font-bold text-emerald-600">{formatPrice(totalSaved)}</span>
              </div>
              <div className="flex items-center justify-between text-sm font-body">
                <span className="text-muted-foreground">{isAr ? "المستهدف" : "Target"}</span>
                <span className="font-bold">{formatPrice(totalSavingsTarget)}</span>
              </div>
              {totalSavingsTarget > 0 && (
                <div className="w-full h-2 bg-secondary rounded-none overflow-hidden mt-1">
                  <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600" style={{ width: `${Math.min(100, (totalSaved / totalSavingsTarget) * 100)}%` }} />
                </div>
              )}
            </div>
          </>
        )}

        {/* 4. Tastes */}
        <SectionHeader en="Tastes" ar="الأذواق" emoji="🎨" />
        <div className="py-2">
          <div className="flex items-baseline justify-between mb-2">
            <p className="text-xs font-heading font-semibold">{isAr ? "أبرز البراندات" : "Top brands"}</p>
            <p className="text-[10px] text-muted-foreground font-body" dir="rtl">أبرز العلامات</p>
          </div>
          <TopList items={topBrandsByOwnership} />
        </div>
        <div className="py-2">
          <div className="flex items-baseline justify-between mb-2">
            <p className="text-xs font-heading font-semibold">{isAr ? "أبرز النوتات" : "Top notes"}</p>
            <p className="text-[10px] text-muted-foreground font-body" dir="rtl">أهم النوتات</p>
          </div>
          <TopList items={topNotes} />
        </div>

        {/* 5. Engagement */}
        <SectionHeader en="Engagement" ar="التفاعل" emoji="✨" />
        <div className="grid grid-cols-3 gap-2">
          <StatCard labelEn="Likes"     labelAr="إعجابات"  value={quotesLiked} />
          <StatCard labelEn="Favorites" labelAr="مفضلة"    value={quotesFavorited} />
          <StatCard labelEn="Thoughts"  labelAr="أفكار"    value={quotesWithThoughts} />
        </div>

        {/* زر النسخ — أسفل الصفحة، بلا إطار/خلفية */}
        <div className="flex justify-center pt-3">
          <CopyMenu
            entity="perfume"
            size="icon"
            dbText={snapshotText}
            fullText={snapshotText}
          />
        </div>

        {/* Footer */}
        <div className="text-center pt-4 opacity-60">
          <span className="text-[10px] font-body text-muted-foreground">
            {isAr ? "تُحدّث تلقائياً مع كل تفاعل" : "Updates automatically as you use the app"}
          </span>
        </div>
      </div>

      <StatisticsExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        isAr={isAr}
        fmt={formatPrice}
        appName="Process"
        scopeLabel={scope === "all" ? (isAr ? "الكل" : "All") : scope === "family" ? (isAr ? "العائلة" : "Family") : scope === "person1" ? (names.person1 || "A") : (names.person2 || "B")}
        stats={{
          ownedPerfumes: ownedPerfumes.length,
          totalSpent,
          totalWears: fWearLogs.length,
          totalPurchases: fPurchases.length,
          monthlyIncome,
          monthlyExpense,
          monthlyObligations,
          netMonthly,
          yearProjection,
          totalSaved,
          totalSavingsTarget,
        }}
      />
    </div>
  );
}
