import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, useLocation } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { exportSingleTerm, exportSingleTermImage } from "@/lib/glossaryExport";
import { toast } from "sonner";
import UserContentControls from "@/components/shared/UserContentControls";
import InteractionBar from "@/components/shared/InteractionBar";
import ZoomableImage from "@/components/shared/ZoomableImage";
import StoryFooter from "@/components/shared/StoryFooter";
import ExportOptionsDialog from "@/components/export/ExportOptionsDialog";
import { useReadingPrefs } from "@/lib/useReadingPrefs";
import { ReadingLangToggle, FontSizeControl } from "@/components/shared/ReadingControls";
import { compareGlossary } from "@/lib/sortName";

/**
 * GlossaryTermDetail
 *
 * Renders two styles:
 *  - term: compact dictionary entry
 *  - story: literary bedtime-reading layout (large serif, indents, sections by ---)
 *
 * User interactions (UserGlossaryTerm):
 *   - reaction: like / dislike / wtf / favorite / none
 *   - thought: optional free-text the user writes about the term/story
 */
export default function GlossaryTermDetail() {
  const navigate = useNavigate();
  const location = useLocation();
  const cameFromActivities = location.state?.from === "activities";
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");
  const { lang: readingLang, fontScale } = useReadingPrefs(); // 'ar' | 'en' | 'both'
  const params = new URLSearchParams(window.location.search);
  const termId = params.get("id");

  const { data: terms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });

  const { data: userReactions = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });

  const term = terms.find((t) => String(t.id) === String(termId));
  const myReaction = userReactions.find((r) => r.term_id === termId);

  const reactMutation = useMutation({
    mutationFn: async ({ reaction }) => {
      if (myReaction) {
        if (myReaction.reaction === reaction) {
          return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction: "none" });
        }
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction });
      }
      return apphost.entities.UserGlossaryTerm.create({
        term_id: termId,
        term_en: term?.term_en || "",
        term_ar: term?.term_ar || "",
        reaction,
      });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-glossary-terms"] }),
  });

  const thoughtMutation = useMutation({
    mutationFn: async ({ newThought }) => {
      if (myReaction) {
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { thought: newThought });
      }
      return apphost.entities.UserGlossaryTerm.create({
        term_id: termId,
        term_en: term?.term_en || "",
        term_ar: term?.term_ar || "",
        thought: newThought,
      });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["user-glossary-terms"] });
      setThoughtOpen(false);
      toast.success(isAr ? "تم حفظ الخاطرة" : "Thought saved");
    },
  });

  const openThoughtEditor = () => {
    setThoughtDraft(myReaction?.thought || "");
    setThoughtOpen(true);
  };

  // ── Edit / delete / hide the glossary entry itself ──
  const editMutation = useMutation({
    mutationFn: async (fields) => {
      const clean = {};
      ["term_en", "term_ar", "meaning", "meaning_ar", "tags", "image_url", "entry_type"].forEach((k) => {
        if (fields[k] !== undefined) clean[k] = fields[k];
      });
      return apphost.entities.GlossaryTerm.update(term.id, clean);
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["glossary-terms"] }),
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      // User-created entries are deleted outright; built-in entries are
      // flagged hidden so a re-seed can restore them and nothing breaks.
      if (term.is_user) {
        return apphost.entities.GlossaryTerm.delete(term.id);
      }
      return apphost.entities.GlossaryTerm.update(term.id, { hidden: true });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["glossary-terms"] });
      navigate(term?.entry_type === "story" ? "/glossary?tab=story" : "/glossary");
    },
  });

  if (!termId) {
    navigate("/glossary");
    return null;
  }

  if (terms.length > 0 && !term) {
    return (
      <div className="px-4 pt-12 pb-20 text-center">
        <p className="text-muted-foreground font-body">
          {isAr ? "غير موجود." : "Term not found."}
        </p>
        <button
          onClick={() => navigate("/glossary")}
          className="text-primary text-sm mt-2 font-body underline"
        >
          {isAr ? "العودة" : "Back"}
        </button>
      </div>
    );
  }

  const entryType = term?.entry_type || "term";
  const isStory = entryType === "story";
  const currentReaction = myReaction?.reaction || "none";

  // All stories, sorted the same way the Stories tab shows them (English
  // alphabetical for both languages) so the footer's Previous / Next walks them
  // in the listed order.
  const sortedStories = terms
    .filter((t) => t.entry_type === "story")
    .sort((a, b) => compareGlossary(a, b, 1));

  const sortedTerms = terms
    .filter((t) => (t.entry_type || "term") === "term")
    .sort((a, b) => compareGlossary(a, b, 1));

  // For stories: render the meaning as book-like text with section breaks
  const renderStoryBody = (text) => {
    if (!text) return null;
    // Split by --- (used as section dividers) or by blank lines
    const sections = text.split(/\n\s*---+\s*\n/);
    // Strip the section header markers — we enter each language directly
    // without "English Version 🇬🇧" / "النسخة العربية 🇸🇦" labels.
    const SECTION_MARKERS = [
      /^\s*English Version[\s🇬🇧]*\s*$/im,
      /^\s*النسخة العربية[\s🇸🇦]*\s*$/im,
    ];
    return sections.map((section, sIdx) => {
      // Drop the first paragraph of each section if it is just a language marker.
      let body = section;
      for (const marker of SECTION_MARKERS) {
        body = body.replace(marker, "");
      }
      const paragraphs = body
        .split(/\n\s*\n/)
        .map((p) => p.trim())
        .filter(Boolean);
      if (paragraphs.length === 0) return null;
      return (
        <div key={sIdx}>
          {paragraphs.map((para, pIdx) => {
            const sp = para.indexOf(" ");
            const firstWord = sp > 0 ? para.slice(0, sp) : para;
            const rest = sp > 0 ? para.slice(sp) : "";
            return (
              <p
                key={pIdx}
                className="font-body leading-loose mb-5"
                style={{
                  fontFamily: "'Cormorant Garamond', 'Amiri', Georgia, serif",
                  fontSize: `${(16 * fontScale).toFixed(1)}px`,
                  color: "#1c1917",
                  textAlign: "justify",
                  wordSpacing: "0.05em",
                }}
                dir="auto"
              >
                <span style={{ color: "#9D174D", fontWeight: 700 }}>{firstWord}</span>{rest}
              </p>
            );
          })}
        </div>
      );
    });
  };

  return (
    <div
      className={`pt-12 pb-20 space-y-6 ${
        isStory ? "px-6 max-w-2xl mx-auto" : "px-4 max-w-lg mx-auto"
      }`}
    >
      {/* Back */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => {
            // يحترم آخر صفحة زرتها (مثلاً الرجوع لخطّ التصنيف في /timelines)؛
            // وإن لم يوجد سجلّ تنقّل يرجع لتبويب المعجم المناسب.
            if (typeof window !== "undefined" && window.history.length > 1) navigate(-1);
            else if (cameFromActivities) navigate("/");
            else navigate(`/glossary?tab=${isStory ? "story" : "term"}`);
          }}
          className="flex items-center gap-1.5 text-sm font-body text-muted-foreground hover:text-foreground transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          {cameFromActivities ? (isAr ? "النشاطات" : "Activities") : (isStory ? (isAr ? "القصص" : "Stories") : (isAr ? "المعجم" : "Glossary"))}
        </button>
      </div>

      {term && (
        <>
          {/* ═══ STORY MODE ═══ */}
          {isStory ? (
            <div className="space-y-6">
              {/* رأس القصة: مبدّل اللغة أعلى الصفحة قبل العنوان، ثمّ عنوان ثنائي مصغّر بلا مائل */}
              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                const bothLangs = hasEnField && hasArField;
                return (
                  <div className="space-y-2">
                    {/* خيارات اللغة أعلى جدول العنوان */}
                    {bothLangs && <ReadingLangToggle accent="amber" />}
                    {/* جدول العنوان — صندوق ذهبي بخلفية بيضاء، اللغتان أعلى اليسار */}
                    <div className="bg-white dark:bg-transparent px-5 py-4" dir="ltr" style={{ borderRadius: 0, border: "1px solid #C8A02E", textAlign: "left" }}>
                      {term.term_en && (
                        <div style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.3rem", fontWeight: 700, color: "#9a7b1f", lineHeight: 1.2 }}>
                          {term.term_en}
                        </div>
                      )}
                      {term.term_ar && (
                        <div style={{ fontFamily: "'Amiri', serif", fontSize: "1.25rem", fontWeight: 700, color: "#9D174D", lineHeight: 1.4, marginTop: 2 }}>
                          {term.term_ar}
                        </div>
                      )}
                    </div>
                  </div>
                );
              })()}

              {/* Story body — العربية في الأعلى افتراضياً، ثمّ الإنجليزية */}
              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                const legacyCombined =
                  term.meaning && !hasArField && /[\u0600-\u06FF]/.test(term.meaning);
                if (legacyCombined) {
                  return <article className="space-y-2">{renderStoryBody(term.meaning)}</article>;
                }
                const bothLangs = hasEnField && hasArField;
                if (!bothLangs) {
                  return <article className="space-y-2" dir={hasArField ? "rtl" : undefined}>{hasArField ? renderStoryBody(term.meaning_ar) : renderStoryBody(term.meaning)}</article>;
                }
                const lang = readingLang;
                return (
                  <>
                    {(lang === "ar" || lang === "both") && (
                      <article className="space-y-2" dir="rtl">
                        {renderStoryBody(term.meaning_ar)}
                        {(term.image_url_ar || (lang === "ar" && term.image_url)) && (
                          <ZoomableImage src={term.image_url_ar || term.image_url} alt={term.term_ar} caption={term.image_caption || ""} />
                        )}
                      </article>
                    )}
                    {lang === "both" && <div className="my-8" />}
                    {(lang === "en" || lang === "both") && (
                      <article className="space-y-2">
                        {renderStoryBody(term.meaning)}
                        {(term.image_url_en || (lang === "en" && term.image_url)) && (
                          <ZoomableImage src={term.image_url_en || term.image_url} alt={term.term_en} caption={term.image_caption || ""} />
                        )}
                      </article>
                    )}
                  </>
                );
              })()}

              {/* Image — تظهر فقط إذا لم تُعرض صور خاصة باللغة أعلاه */}
              {term.image_url && !term.image_url_en && !term.image_url_ar && (
                <ZoomableImage
                  src={term.image_url}
                  alt={term.term_en}
                  caption={term.image_caption || ""}
                />
              )}

              {/* Tags moved below — they now sit above the prev/next navigation */}

              {/* End spacing — clean, no decorative dingbat */}
              <div className="pt-4" />
            </div>
          ) : (
            /* ═══ TERM MODE (original layout) ═══ */
            <>
              {/* خيارات اللغة أعلى الصندوق */}
              {(() => {
                const bothLangs = !!(term.meaning_ar && term.meaning_ar.trim()) && !!(term.meaning && term.meaning.trim());
                return bothLangs ? <div className="mb-2"><ReadingLangToggle accent="amber" /></div> : null;
              })()}
              <div
                className="bg-white dark:bg-transparent px-5 py-5 space-y-3"
                style={{ borderRadius: 0, border: "1px solid #C8A02E" }}
              >
                <div className="flex flex-wrap items-baseline gap-x-3 gap-y-1">
                  {term.term_en && (
                    <span style={{ fontFamily: "'Playfair Display', serif", fontSize: "1.05rem", fontWeight: 700, color: "#9a7b1f", letterSpacing: "0.02em" }}>
                      {term.term_en}
                    </span>
                  )}
                  {term.term_ar && (
                    <span className="text-base" dir="rtl" style={{ fontFamily: "'Amiri', serif", fontWeight: 700, color: "#9D174D" }}>
                      {term.term_ar}
                    </span>
                  )}
                </div>
                <div style={{ height: 1, background: "linear-gradient(90deg, transparent, #C8A02E, transparent)" }} />

              {(() => {
                const hasArField = !!(term.meaning_ar && term.meaning_ar.trim());
                const hasEnField = !!(term.meaning && term.meaning.trim());
                const bothLangs = hasEnField && hasArField;
                const lang = readingLang;
                const para = (text, dir) => (
                  <p className="font-body text-foreground/80 leading-relaxed pt-1" dir={dir} style={{ fontSize: `${(13 * fontScale).toFixed(1)}px`, ...(dir === "rtl" ? { textAlign: "right" } : {}) }}>
                    {text}
                  </p>
                );
                if (!bothLangs) {
                  const m = hasArField ? term.meaning_ar : term.meaning;
                  return m ? para(m, hasArField ? "rtl" : "ltr") : null;
                }
                return (
                  <>
                    {(lang === "ar" || lang === "both") && para(term.meaning_ar, "rtl")}
                    {lang === "both" && <div className="my-4" />}
                    {(lang === "en" || lang === "both") && para(term.meaning, "ltr")}
                  </>
                );
              })()}

              {term.image_url && (
                <ZoomableImage
                  src={term.image_url}
                  alt={term.term_en}
                  caption={term.image_caption || ""}
                />
              )}

              {/* Tags moved below — they now sit above the prev/next navigation */}
              </div>
            </>
          )}

          {/* Unified interaction bar: reactions + notebook (single row, no WTF) */}
          <InteractionBar
            reaction={currentReaction}
            hasThought={!!myReaction?.thought}
            showWtf={true}
            center={true}
            onReact={(kind) => reactMutation.mutate({ reaction: kind })}
            onThought={openThoughtEditor}
            bookmark={{
              item_type: isStory ? "story" : "glossary",
              item_id: termId,
              title_en: term.term_en || "",
              title_ar: term.term_ar || "",
              subtitle: isStory ? (isAr ? "قصة" : "Story") : (isAr ? "مصطلح" : "Term"),
              path: `/glossary-term?id=${termId}`,
            }}
          />

          {/* خيارات التصدير في نافذة منبثقة بدل المصفوفة المضمّنة */}
          <div className="flex justify-center pt-1">
            <ExportOptionsDialog userMarkAvailable={true} />
          </div>

          {/* Copy / export — outside the box, right after the reactions row */}
          <StoryFooter
            term={term}
            showNav={false}
            topBorder={false}
            accentColor={isStory ? "amber" : "emerald"}
            onExportPdf={(lang) => exportSingleTerm(term, myReaction, { lang: lang || "both" })}
            onExportImg={(lang) => exportSingleTermImage(term, { lang: lang || "both" })}
          />

          {/* Existing thought display */}
          {myReaction?.thought && (
            <div className="p-3 mt-1 space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                {isAr ? "فكرتي" : "My thought"}
              </p>
              <p className="text-sm font-body" dir="auto">
                {myReaction.thought}
              </p>
              <button
                onClick={openThoughtEditor}
                className="text-[10px] text-muted-foreground hover:underline font-body"
              >
                {isAr ? "تعديل" : "Edit"}
              </button>
            </div>
          )}

          {/* Edit / delete the entry — full editor with confirmation lives here */}
          <UserContentControls
            kind="glossary"
            entry={term}
            isUser={!!term.is_user}
            onSave={(fields) => editMutation.mutateAsync(fields)}
            onDelete={() => deleteMutation.mutateAsync()}
          />

          {/* تكبير/تصغير الخطّ — صندوق خاصّ بإطار شفّاف وبلا خلفية، فوق جدول الوسوم */}
          <div className="border border-transparent bg-transparent rounded-none py-1">
            <FontSizeControl accent={isStory ? "amber" : "emerald"} />
          </div>

          {/* Navigation — moved to the very bottom of the page. Hashtags sit above prev/next, using the page color. */}
          <StoryFooter
            term={term}
            stories={isStory ? sortedStories : sortedTerms}
            showActions={false}
            tags={term.tags || ""}
            accentColor={isStory ? "amber" : "emerald"}
          />
        </>
      )}

      {!term && (
        <div className="flex items-center justify-center py-20">
          <div className="w-6 h-6 border-2 border-emerald-300 border-t-emerald-600 rounded-full animate-spin" />
        </div>
      )}

      {/* Thought editor — works for both terms and stories */}
      <Dialog open={thoughtOpen} onOpenChange={setThoughtOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isAr ? "أضف فكرتك" : "Add your thought"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Textarea
              value={thoughtDraft}
              onChange={(e) => setThoughtDraft(e.target.value)}
              placeholder={isAr ? "ماذا تفكر بهذا؟" : "What do you think about this?"}
              className="rounded-none font-body text-xs min-h-[110px] resize-none"
              dir="auto"
            />
            <div className="flex gap-2">
              <Button
                className="flex-1 h-10 rounded-none"
                onClick={() => thoughtMutation.mutate({ newThought: thoughtDraft.trim() })}
                disabled={thoughtMutation.isPending}
              >
                {thoughtMutation.isPending
                  ? isAr ? "جارٍ..." : "Saving..."
                  : isAr ? "حفظ" : "Save"}
              </Button>
              {myReaction?.thought && (
                <Button
                  variant="outline"
                  className="h-10 rounded-none"
                  onClick={() => thoughtMutation.mutate({ newThought: "" })}
                >
                  {isAr ? "حذف" : "Delete"}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
