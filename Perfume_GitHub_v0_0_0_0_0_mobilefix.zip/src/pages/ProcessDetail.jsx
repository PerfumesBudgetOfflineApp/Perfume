import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft, Trash2, Edit, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { initDB, processes, steps } from '@/lib/indexedDB';
import { downloadBlob } from '@/lib/exportHelper';
import { toast } from 'sonner';

export default function ProcessDetail() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const processId = parseInt(searchParams.get('id'));
  
  const [process, setProcess] = useState(null);
  const [processList, setProcessList] = useState([]);
  const [stepsList, setStepsList] = useState([]);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [newStep, setNewStep] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        await initDB();
        const allProcs = await processes.getAll();
        setProcessList(allProcs);
        
        const currentProcess = allProcs.find(p => String(p.id) === String(processId));
        if (currentProcess) {
          setProcess(currentProcess);
          setEditForm(currentProcess);
          const procSteps = await steps.getByProcess(processId);
          setStepsList(procSteps.sort((a, b) => a.order - b.order));
        }
      } catch (error) {
        console.error('Failed to load:', error);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [processId]);

  const handleUpdateProcess = async () => {
    try {
      await processes.update(processId, editForm);
      setProcess(editForm);
      setEditing(false);
      toast.success('تم تحديث العملية');
    } catch (error) {
      toast.error('فشل التحديث');
    }
  };

  const handleAddStep = async () => {
    if (!newStep.trim()) return;
    try {
      const step = {
        process_id: processId,
        title: newStep,
        completed: false,
        order: stepsList.length + 1,
        created_date: new Date()
      };
      await steps.add(step);
      setStepsList([...stepsList, step]);
      setNewStep('');
      toast.success('تمت إضافة الخطوة');
    } catch (error) {
      toast.error('فشلت إضافة الخطوة');
    }
  };

  const handleDeleteStep = async (stepId) => {
    try {
      await steps.delete(stepId);
      setStepsList(stepsList.filter(s => s.id !== stepId));
      toast.success('تم حذف الخطوة');
    } catch (error) {
      toast.error('فشل الحذف');
    }
  };

  const handleStatusChange = async (newStatus) => {
    try {
      await processes.update(processId, { status: newStatus });
      setProcess({ ...process, status: newStatus });
      setEditForm({ ...editForm, status: newStatus });
      toast.success('تم تحديث الحالة');
    } catch (error) {
      toast.error('فشل التحديث');
    }
  };

  const handleExport = async () => {
    const data = {
      process,
      steps: stepsList
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    await downloadBlob(blob, `${process.name}-${new Date().toISOString().split('T')[0]}.json`);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!process) {
    return (
      <div className="px-4 pt-12">
        <div className="text-center py-16">
          <p className="text-muted-foreground">العملية غير موجودة</p>
        </div>
      </div>
    );
  }

  return (
    <div className="px-4 pt-12 pb-8 max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/process')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-2xl font-bold">{process.name}</h1>
      </div>

      {/* Info Box */}
      {!editing ? (
        <div className="bg-secondary/50 rounded-none p-6 space-y-4">
          <div>
            <p className="text-xs text-muted-foreground mb-1">الوصف</p>
            <p className="text-sm">{process.description || 'بدون وصف'}</p>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-xs text-muted-foreground mb-1">الحالة</p>
              <div className="flex gap-2 flex-wrap">
                {process.status === 'active' ? (
                  <Button size="sm" variant="outline" onClick={() => handleStatusChange('paused')} className="text-xs">
                    🟢 نشطة
                  </Button>
                ) : process.status === 'paused' ? (
                  <Button size="sm" variant="outline" onClick={() => handleStatusChange('active')} className="text-xs">
                    ⏸️ موقوفة
                  </Button>
                ) : (
                  <span className="text-xs text-emerald-600 rounded-none">مكتملة</span>
                )}
              </div>
            </div>
            <div>
              <p className="text-xs text-muted-foreground mb-1">التقدم</p>
              <div className="space-y-1">
                <div className="w-full bg-secondary rounded-none h-2">
                  <div
                    className="bg-amber-500 h-2 rounded-none transition-all"
                    style={{ width: `${process.progress || 0}%` }}
                  />
                </div>
                <p className="text-xs">{process.progress || 0}%</p>
              </div>
            </div>
          </div>
          <div className="flex gap-2 pt-2">
            <Button size="sm" variant="outline" className="flex-1 text-xs" onClick={() => setEditing(true)}>
              <Edit className="w-3 h-3 mr-1" /> تعديل
            </Button>
            <Button size="sm" variant="outline" className="flex-1 text-xs" onClick={handleExport}>
              <Download className="w-3 h-3 mr-1" /> تصدير
            </Button>
          </div>
        </div>
      ) : (
        <div className="bg-secondary/50 rounded-none p-6 space-y-4">
          <div>
            <label className="text-xs text-muted-foreground block mb-2">الاسم</label>
            <Input
              value={editForm.name}
              onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
              className="rounded-none h-10 text-sm"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-2">الوصف</label>
            <Textarea
              value={editForm.description || ''}
              onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
              className="rounded-none text-sm min-h-[80px]"
            />
          </div>
          <div>
            <label className="text-xs text-muted-foreground block mb-2">التقدم (%)</label>
            <Input
              type="number"
              value={editForm.progress || 0}
              onChange={(e) => setEditForm({ ...editForm, progress: parseInt(e.target.value) })}
              min="0"
              max="100"
              className="rounded-none h-10 text-sm"
            />
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="flex-1" onClick={handleUpdateProcess}>حفظ</Button>
            <Button size="sm" variant="outline" className="flex-1" onClick={() => setEditing(false)}>إلغاء</Button>
          </div>
        </div>
      )}

      {/* Steps */}
      <div className="space-y-4">
        <h2 className="font-heading text-lg font-semibold">الخطوات ({stepsList.length})</h2>
        <div className="space-y-2">
          {stepsList.map(step => (
            <div key={step.id} className="bg-card rounded-none p-4 flex items-center gap-3 border border-border">
              <input
                type="checkbox"
                checked={step.completed}
                className="w-5 h-5 rounded cursor-pointer"
              />
              <span className={step.completed ? 'line-through text-muted-foreground text-sm flex-1' : 'text-sm flex-1'}>
                {step.title}
              </span>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleDeleteStep(step.id)}
                className="text-red-500 hover:text-red-600"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          ))}
        </div>

        {/* Add Step */}
        <div className="flex gap-2">
          <Input
            value={newStep}
            onChange={(e) => setNewStep(e.target.value)}
            placeholder="أضف خطوة جديدة..."
            className="rounded-none h-11 text-sm"
          />
          <Button onClick={handleAddStep} className="px-6">
            Add</Button>
        </div>
      </div>
    </div>
  );
}