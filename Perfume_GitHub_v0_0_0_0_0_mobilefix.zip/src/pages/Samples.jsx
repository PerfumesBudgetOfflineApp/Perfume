import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Droplets, ChevronRight } from "lucide-react";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { useLang } from "@/lib/LanguageContext";
import { cn } from "@/lib/utils";
import SamplesExportDialog from "@/components/samples/SamplesExportDialog";

export default function Samples() {
  const urlParams = new URLSearchParams(window.location.search);
  const defaultPerson = urlParams.get("person") || "all";
  const [activePerson, setActivePerson] = useState(defaultPerson);
  const [sortBy, setSortBy] = useState("newest");
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();
  const { formatPrice } = useCurrency();
  const { isAr } = useLang();

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
  });

  const personData = activePerson === "all" ? userPerfumes : userPerfumes.filter((u) => u.person === activePerson);
  const personPurchases = activePerson === "all" ? purchases : purchases.filter((p) => p.person === activePerson);
  
  const sortedPurchases = useMemo(() => {
    const sorted = [...personPurchases];
    if (sortBy === "newest") sorted.sort((a, b) => new Date(b.purchase_date) - new Date(a.purchase_date));
    else if (sortBy === "oldest") sorted.sort((a, b) => new Date(a.purchase_date) - new Date(b.purchase_date));
    else if (sortBy === "highest") sorted.sort((a, b) => b.cost - a.cost);
    else if (sortBy === "lowest") sorted.sort((a, b) => a.cost - b.cost);
    return sorted;
  }, [personPurchases, sortBy]);
  
  const samplePurchases = sortedPurchases.filter((p) => p.type === "sample");
  const bottlePurchases = sortedPurchases.filter((p) => p.type === "bottle");
  
  const totalSampleVolume = samplePurchases.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalSampleCost = samplePurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  
  const totalBottleVolume = bottlePurchases.reduce((sum, p) => sum + (p.ml || 0), 0);
  const totalBottleCost = bottlePurchases.reduce((sum, p) => sum + (p.cost || 0), 0);
  
  const combinedTotalVolume = totalSampleVolume + totalBottleVolume;
  const combinedTotalCost = totalSampleCost + totalBottleCost;
  const avgCostPerMl = combinedTotalVolume > 0 ? (combinedTotalCost / combinedTotalVolume).toFixed(2) : 0;

  return (
    <div className="pb-4">
      {/* Header */}
      <div className="px-4 pt-12 pb-4 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center hover:bg-accent transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h1 className="font-heading text-xl font-bold">{isAr ? "قائمة العينات" : "Sample List"}</h1>
            <p className="text-xs text-muted-foreground font-body">
              {activePerson === "all" ? (isAr ? "جميع الملفات" : "All Profiles") : activePerson === "person1" ? names.person1 : names.person2}
            </p>
          </div>
        </div>
        <SamplesExportDialog
          purchases={personPurchases}
          personName={activePerson === "all" ? (isAr ? "جميع الملفات" : "All Profiles") : (activePerson === "person1" ? names.person1 : names.person2)}
          profiles={profiles}
        />
      </div>

      {/* Person Selector */}
      <div className="px-4 flex gap-2 mb-3">
        {["person1", "person2", "all"].map((person) => (
          <button
            key={person}
            onClick={() => setActivePerson(person)}
            className={cn(
              "flex-1 py-2.5 rounded-none text-sm font-body font-medium transition-all border",
              activePerson === person
                ? "bg-primary text-primary-foreground border-primary shadow"
                : "bg-secondary/50 border-border/50 text-muted-foreground hover:text-foreground"
            )}
          >
            {person === "person1" ? names.person1 : person === "person2" ? names.person2 : "All"}
          </button>
        ))}
      </div>

      {/* Sort Options */}
      <div className="px-4 mb-5 flex gap-2">
        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="flex-1 px-3 py-2 rounded-none border border-input bg-transparent text-xs font-body"
        >
          <option value="newest">{isAr ? "الأحدث" : "Newest"}</option>
          <option value="oldest">{isAr ? "الأقدم" : "Oldest"}</option>
          <option value="highest">{isAr ? "الأعلى سعر" : "Highest Cost"}</option>
          <option value="lowest">{isAr ? "الأقل سعر" : "Lowest Cost"}</option>
        </select>
      </div>



      {/* Stats */}
      <div className="px-4 mb-5 space-y-3">
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-card rounded-none p-3 text-center border border-border/60">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "إجمالي العناصر" : "Total Items"}</p>
            <p className="font-heading font-semibold text-sm">{personPurchases.length}</p>
          </div>
          <div className="bg-card rounded-none p-3 text-center border border-border/60">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "الحجم الكلي" : "Total Volume"}</p>
            <p className="font-heading font-semibold text-sm">{combinedTotalVolume}ml</p>
          </div>
          <div className="bg-card rounded-none p-3 text-center border border-border/60">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
            <p className="font-heading font-semibold text-sm">{formatPrice(combinedTotalCost.toFixed(0))}</p>
          </div>
          <div className="bg-card rounded-none p-3 text-center border border-border/60">
            <p className="text-[10px] text-muted-foreground font-body mb-1 uppercase tracking-wider">{isAr ? "التكلفة للمل" : "Cost/ml"}</p>
            <p className="font-heading font-semibold text-sm">{formatPrice(avgCostPerMl)}</p>
          </div>
        </div>

        {/* Samples Stats */}
        <div className="bg-gradient-to-r from-blue-500/10 to-blue-400/5 rounded-none p-3 border border-blue-200/30">
          <p className="text-[10px] text-blue-700 font-body mb-2 uppercase tracking-wider font-semibold">💧 Samples</p>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "الحجم" : "Volume"}</p>
              <p className="font-heading font-semibold text-xs">{totalSampleVolume}ml</p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "التكلفة" : "Cost"}</p>
              <p className="font-heading font-semibold text-xs">{formatPrice(totalSampleCost.toFixed(0))}</p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "العناصر" : "Items"}</p>
              <p className="font-heading font-semibold text-xs">{samplePurchases.length}</p>
            </div>
          </div>
        </div>

        {/* Bottles Stats */}
        <div className="bg-gradient-to-r from-amber-500/10 to-amber-400/5 rounded-none p-3 border border-amber-200/30">
          <p className="text-[10px] text-amber-700 font-body mb-2 uppercase tracking-wider font-semibold">🍾 Bottles</p>
          <div className="grid grid-cols-3 gap-2">
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "الحجم" : "Volume"}</p>
              <p className="font-heading font-semibold text-xs">{totalBottleVolume}ml</p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "التكلفة" : "Cost"}</p>
              <p className="font-heading font-semibold text-xs">{formatPrice(totalBottleCost.toFixed(0))}</p>
            </div>
            <div>
              <p className="text-[9px] text-muted-foreground font-body mb-0.5">{isAr ? "العناصر" : "Items"}</p>
              <p className="font-heading font-semibold text-xs">{bottlePurchases.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Purchases List */}
      <div className="px-4 space-y-4">
        {/* Samples Section */}
        {samplePurchases.length > 0 && (
          <div className="space-y-2">
            <h2 className="font-heading font-semibold text-sm text-blue-700 px-1">💧 Samples ({samplePurchases.length})</h2>
            {samplePurchases.map((purchase) => (
              <div
                key={purchase.id}
                onClick={() => navigate(`/perfume?id=${purchase.perfume_id}`)}
                className="bg-card rounded-none p-4 border border-border/60 space-y-2 cursor-pointer hover:border-primary/50 hover:shadow-md transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-heading font-semibold text-sm">{purchase.perfume_name}</p>
                    <p className="text-xs text-muted-foreground font-body">{purchase.brand_name}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <Droplets className="w-4 h-4 text-blue-500" />
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2 text-xs font-body">
                  <div>
                    <p className="text-muted-foreground">{isAr ? "الحجم" : "Volume"}</p>
                    <p className="font-medium">{purchase.ml}ml</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التكلفة" : "Cost"}</p>
                    <p className="font-medium text-[11px]">{formatPrice(purchase.cost.toFixed(0))}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التكلفة للمل" : "Cost/ml"}</p>
                    <p className="font-medium text-[11px]">{formatPrice((purchase.cost / purchase.ml).toFixed(2))}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التاريخ" : "Date"}</p>
                    <p className="font-medium text-[10px]">{new Date(purchase.purchase_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Bottles Section */}
        {bottlePurchases.length > 0 && (
          <div className="space-y-2">
            <h2 className="font-heading font-semibold text-sm text-amber-700 px-1">🍾 Bottles ({bottlePurchases.length})</h2>
            {bottlePurchases.map((purchase) => (
              <div
                key={purchase.id}
                onClick={() => navigate(`/perfume?id=${purchase.perfume_id}`)}
                className="bg-card rounded-none p-4 border border-border/60 space-y-2 cursor-pointer hover:border-primary/50 hover:shadow-md transition-all"
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <p className="font-heading font-semibold text-sm">{purchase.perfume_name}</p>
                    <p className="text-xs text-muted-foreground font-body">{purchase.brand_name}</p>
                  </div>
                  <div className="flex items-center gap-2 flex-shrink-0">
                    <span className="text-lg">🍾</span>
                    <ChevronRight className="w-4 h-4 text-muted-foreground" />
                  </div>
                </div>
                <div className="grid grid-cols-4 gap-2 text-xs font-body">
                  <div>
                    <p className="text-muted-foreground">{isAr ? "الحجم" : "Volume"}</p>
                    <p className="font-medium">{purchase.ml}ml</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التكلفة" : "Cost"}</p>
                    <p className="font-medium text-[11px]">{formatPrice(purchase.cost.toFixed(0))}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التكلفة للمل" : "Cost/ml"}</p>
                    <p className="font-medium text-[11px]">{formatPrice((purchase.cost / purchase.ml).toFixed(2))}</p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">{isAr ? "التاريخ" : "Date"}</p>
                    <p className="font-medium text-[10px]">{new Date(purchase.purchase_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {personPurchases.length === 0 && (
          <p className="text-sm text-muted-foreground font-body text-center py-8">{isAr ? "لا مشتريات بعد" : "No purchases yet"}</p>
        )}
      </div>
    </div>
  );
}