import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, useSearchParams, Link } from "react-router-dom";
import { ChevronLeft, Edit, Archive, ArchiveX, Trash2, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import MediaSection, { MediaViewer } from "@/components/blog/MediaSection";
import SearchableEntityPicker from "@/components/blog/SearchableEntityPicker";
import BlogExportDialog from "@/components/blog/BlogExportDialog";
import InteractionBar from "@/components/shared/InteractionBar";
import { toast } from "sonner";
import { useLang } from "@/lib/LanguageContext";
import DetailFooter from "@/components/shared/DetailFooter";
import { usePersonNames } from "@/lib/usePersonNames";
import { useContentEncryption } from "@/lib/useContentEncryption";

const TYPE_LABEL = {
  memo: "📝 Memo",
  not_set: "Not Set",
  perfume: "🌹 Perfume",
  music: "🎵 Music",
  tv: "📺 TV",
  films: "🎬 Films",
  idea: "💡 Idea",
  poetry: "✍️ Poetry",
  thought: "💭 Thought",
  knowledge: "🧠 Knowledge",
  concept: "🔮 Concept",
};

const EMPTY_FORM = {
  title: "",
  body: "",
  entry_type: "",
  tags: "",
  media_urls: "",
  media_links: "",
  linked_perfume_id: "",
  linked_perfume_name: "",
  linked_brand_id: "",
  linked_brand_name: "",
  linked_perfumer_id: "",
  linked_perfumer_name: "",
  linked_notes: "",
  person: "person1",
};

export default function BlogDetail() {
  const { isAr } = useLang();
  const [searchParams] = useSearchParams();
  const postId = searchParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { names } = usePersonNames();
  const { encryptFields, decryptFields, userId } = useContentEncryption();

  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [exportPost, setExportPost] = useState(null);
  const [showLinks, setShowLinks] = useState(false);
  const [thoughtOpen, setThoughtOpen] = useState(false);
  const [thoughtDraft, setThoughtDraft] = useState("");

  const { data: post, isLoading } = useQuery({
    queryKey: ["blog-post", postId, userId],
    queryFn: async () => {
      const data = postId ? await apphost.entities.BlogPost.filter({ id: postId }) : [];
      if (data?.[0]) {
        return await decryptFields(data[0], ['title', 'body', 'personal_notes']);
      }
      return data?.[0] || null;
    },
    enabled: !!postId && !!userId,
  });

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: perfumers = [] } = useQuery({
    queryKey: ["perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("-created_date"),
  });

  const { data: allPosts = [] } = useQuery({
    queryKey: ["blog-posts-all", userId],
    queryFn: async () => {
      const raw = await apphost.entities.BlogPost.list("-created_date");
      return Promise.all(raw.map(async (bp) => {
        try { return await decryptFields(bp, ['title']); } catch { return bp; }
      }));
    },
    enabled: !!userId,
  });

  const { data: notes = [] } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  // التفاعلات والفكرة — كصفحة المعجم، مخزّنة في UserGlossaryTerm بمعرّف blog:{id}
  const blogKey = post ? `blog:${post.id}` : null;
  const { data: userReactions = [] } = useQuery({
    queryKey: ["user-glossary-terms"],
    queryFn: () => apphost.entities.UserGlossaryTerm.list("-created_date"),
  });
  const myReaction = blogKey ? userReactions.find((r) => r.term_id === blogKey) : null;
  const currentReaction = myReaction?.reaction && myReaction.reaction !== "none" ? myReaction.reaction : "none";

  const reactMutation = useMutation({
    mutationFn: async ({ reaction }) => {
      if (myReaction) {
        if (myReaction.reaction === reaction) return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction: "none" });
        return apphost.entities.UserGlossaryTerm.update(myReaction.id, { reaction });
      }
      return apphost.entities.UserGlossaryTerm.create({ term_id: blogKey, term_en: post?.title || "", term_ar: "", reaction });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ["user-glossary-terms"] }),
  });
  const thoughtMutation = useMutation({
    mutationFn: async ({ newThought }) => {
      if (myReaction) return apphost.entities.UserGlossaryTerm.update(myReaction.id, { thought: newThought });
      return apphost.entities.UserGlossaryTerm.create({ term_id: blogKey, term_en: post?.title || "", term_ar: "", thought: newThought });
    },
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ["user-glossary-terms"] }); setThoughtOpen(false); },
  });
  const openThought = () => { setThoughtDraft(myReaction?.thought || ""); setThoughtOpen(true); };

  const updateMutation = useMutation({
    mutationFn: async (data) => {
      if (!postId) throw new Error("Post ID is missing");
      const encrypted = await encryptFields(data, ['title', 'body', 'personal_notes']);
      return apphost.entities.BlogPost.update(postId, encrypted);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["blog-post", postId] });
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
      setIsEditing(false);
      toast.success(isAr ? "تم حفظ التعديلات" : "Changes saved");
    },
  });

  const deleteMutation = useMutation({
    mutationFn: () => apphost.entities.BlogPost.delete(postId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
      toast.success(isAr ? "تم الحذف" : "Deleted");
      navigate("/blog");
    },
  });

  const archiveMutation = useMutation({
    mutationFn: () => apphost.entities.BlogPost.update(postId, { archived: true }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["blog-post", postId] });
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
      toast.success(isAr ? "تمت الأرشفة" : "Archived");
      navigate("/blog");
    },
  });

  const unarchiveMutation = useMutation({
    mutationFn: () => apphost.entities.BlogPost.update(postId, { archived: false }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["blog-post", postId] });
      queryClient.invalidateQueries({ queryKey: ["blog-posts"] });
    },
  });

  if (isLoading) return <div className="flex items-center justify-center h-screen"><div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" /></div>;
  if (!postId) return (
    <div className="flex flex-col items-center justify-center h-screen gap-4">
      <p className="text-muted-foreground">{isAr ? "لا معرّف للمدخل" : "No post ID provided"}</p>
      <Button onClick={() => navigate("/blog")} className="rounded-none">{isAr ? "عودة للمفكرة" : "Back to Blog"}</Button>
    </div>
  );
  if (!post) return (
    <div className="flex flex-col items-center justify-center h-screen gap-4">
      <p className="text-muted-foreground">{isAr ? "المدخل غير موجود" : "Entry not found"}</p>
      <Button onClick={() => navigate("/blog")} className="rounded-none">{isAr ? "عودة للمفكرة" : "Back to Blog"}</Button>
    </div>
  );

  const personName = post.person === "person2" ? names.person2 : names.person1;
  const tags = post.tags ? post.tags.split(",").map((t) => t.trim()).filter(Boolean) : [];

  // Get navigation posts
  const sortedPosts = allPosts.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));

  // Get linked data — بالمعرّف أولاً، ثمّ بالاسم احتياطياً (النموذج المدمج يخزّن
  // الأسماء فقط بلا معرّفات؛ كما أنّ نوتة المثال اسمها ثنائيّ «Cheerful بشاشة»).
  const _norm = (s) => String(s || "").trim().toLowerCase();
  const linkedPerfume = post.linked_perfume_id
    ? perfumes.find((p) => String(p.id) === String(post.linked_perfume_id))
    : (post.linked_perfume_name ? perfumes.find((p) => _norm(p.name_en) === _norm(post.linked_perfume_name) || _norm(p.name) === _norm(post.linked_perfume_name) || _norm(p.name_ar) === _norm(post.linked_perfume_name)) : null);
  const linkedBrand = post.linked_brand_id
    ? brands.find((b) => String(b.id) === String(post.linked_brand_id))
    : (post.linked_brand_name ? brands.find((b) => _norm(b.name) === _norm(post.linked_brand_name) || _norm(b.name_ar) === _norm(post.linked_brand_name)) : null);
  const linkedPerfumer = post.linked_perfumer_id
    ? perfumers.find((p) => String(p.id) === String(post.linked_perfumer_id))
    : (post.linked_perfumer_name ? perfumers.find((p) => _norm(p.name) === _norm(post.linked_perfumer_name) || _norm(p.name_ar) === _norm(post.linked_perfumer_name)) : null);
  const linkedNotes = post.linked_notes ? post.linked_notes.split(",").map((n) => n.trim()).filter(Boolean).map((noteName) => {
    const q = _norm(noteName);
    // مطابقة مرنة: مساواة، أو بداية بالكلمة (للأسماء ثنائيّة اللغة «Cheerful بشاشة»)، أو احتواء كلمة.
    return notes.find((n) => {
      const nm = _norm(n.name);
      return nm === q || nm.startsWith(q + " ") || nm.split(/\s+/).includes(q) || nm.includes(q);
    });
  }).filter(Boolean) : [];

  const handleEdit = () => {
    setForm(post);
    setIsEditing(true);
  };

  const handleSave = async () => {
    updateMutation.mutate(form);
  };

  // Detect if title is Arabic (RTL)
  const isArabic = /[\u0600-\u06FF]/.test(post.title);

  return (
    <div className="px-4 pt-4 pb-8 max-w-2xl mx-auto">
      {/* Header — back only; bookmark + edit live at the bottom now */}
      {!isEditing && (
        <div className="flex items-center justify-between mb-6">
          <button
            onClick={() => navigate("/blog")}
            className="flex items-center gap-2 text-primary hover:underline font-body text-sm"
          >
            <ChevronLeft className="w-4 h-4" /> {isAr ? "رجوع" : "Back"}
          </button>
        </div>
      )}

      {isEditing ? (
        /* Edit Mode */
        <div className="space-y-4">
          <Input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder={isAr ? "العنوان" : "Title"}
            className="font-heading text-xl rounded-none h-10"
          />
          <div className="grid grid-cols-3 gap-2">
            {Object.entries(TYPE_LABEL).map(([k, v]) => (
              <button
                key={k}
                onClick={() => {
                  const types = form.entry_type ? form.entry_type.split(",").map(t => t.trim()) : [];
                  if (types.includes(k)) {
                    setForm({ ...form, entry_type: types.filter(t => t !== k).join(",") });
                  } else {
                    setForm({ ...form, entry_type: [...types, k].join(",") });
                  }
                }}
                className={`py-2 rounded-none text-xs font-body font-medium transition-all ${
                  (form.entry_type || "").split(",").map(t => t.trim()).includes(k)
                    ? "bg-primary text-primary-foreground shadow"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {v}
              </button>
            ))}
          </div>
          <Textarea
            value={form.body}
            onChange={(e) => setForm({ ...form, body: e.target.value })}
            placeholder={isAr ? "اكتب مدخلك" : "Write your entry..."}
            className="min-h-64 rounded-none font-body text-sm"
          />
          <Input
            value={form.tags}
            onChange={(e) => setForm({ ...form, tags: e.target.value })}
            placeholder={isAr ? "وسوم مفصولة بفاصلة" : "Tags (comma-separated)"}
            className="rounded-none h-10 font-body text-sm"
          />
          <MediaSection
            mediaUrls={form.media_urls}
            mediaLinks={form.media_links}
            onMediaChange={(urls, links) => setForm({ ...form, media_urls: urls, media_links: links })}
          />

          {/* Link Items */}
          <button
            type="button"
            onClick={() => setShowLinks(!showLinks)}
            className="w-full flex items-center justify-between rounded-none transition-colors text-xs font-body font-medium"
          >
            <span>🔗 Link Items</span>
            <ChevronDown className={`w-4 h-4 transition-transform ${showLinks ? "rotate-180" : ""}`} />
          </button>

          {showLinks && (
            <div className="space-y-2 border border-border/50 rounded-none p-3 bg-secondary/20">
              <SearchableEntityPicker
                label="Brand"
                placeholder={isAr ? "ابحث عن براندات" : "Search brands..."}
                getLabel={(item) => item.name}
                getValue={(item) => item.id}
                searchFn={async (q) => {
                  const results = await apphost.entities.PerfumeBrand.filter({ name: { $regex: q, $options: "i" } }, "name", 15);
                  return results.filter(b => b.name);
                }}
                selectedId={form.linked_brand_id}
                selectedLabel={form.linked_brand_name}
                onSelect={(id, name) => { setForm({ ...form, linked_brand_id: id, linked_brand_name: name }); }}
                onClear={() => { setForm({ ...form, linked_brand_id: "", linked_brand_name: "" }); }}
              />

              <SearchableEntityPicker
                label="Perfume"
                placeholder="ابحث عن عطر... / Search perfumes..."
                getLabel={(item) => `${item.name_en || item.name_ar || "??"} · ${item.brand_name || "??"}`}
                getValue={(item) => item.id}
                searchFn={async (q) => {
                  const results = await apphost.entities.Perfume.filter({ 
                    $or: [
                      { name_en: { $regex: q, $options: "i" } },
                      { name_ar: { $regex: q, $options: "i" } },
                      { brand_name: { $regex: q, $options: "i" } }
                    ]
                  }, "name_en", 15);
                  return results.filter(p => p.name_en || p.name_ar || p.brand_name);
                }}
                selectedId={form.linked_perfume_id}
                selectedLabel={form.linked_perfume_name}
                onSelect={(id, name) => { 
                  setForm({ ...form, linked_perfume_id: id, linked_perfume_name: name });
                }}
                onClear={() => { setForm({ ...form, linked_perfume_id: "", linked_perfume_name: "" }); }}
              />

              <SearchableEntityPicker
                label="Perfumer"
                placeholder={isAr ? "ابحث عن معطّرين" : "Search perfumers..."}
                getLabel={(item) => item.name}
                getValue={(item) => item.id}
                searchFn={async (q) => {
                  const filtered = perfumers.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
                  return filtered.slice(0, 15);
                }}
                selectedId={form.linked_perfumer_id}
                selectedLabel={form.linked_perfumer_name}
                onSelect={(id, name) => { setForm({ ...form, linked_perfumer_id: id, linked_perfumer_name: name }); }}
                onClear={() => { setForm({ ...form, linked_perfumer_id: "", linked_perfumer_name: "" }); }}
              />

              <SearchableEntityPicker
                label="Notes"
                placeholder={isAr ? "ابحث عن نوتات" : "Search notes..."}
                getLabel={(item) => item.name}
                getValue={(item) => item.name}
                searchFn={async (q) => {
                  const filtered = notes.filter(n => n.name.toLowerCase().includes(q.toLowerCase()));
                  return filtered.slice(0, 15);
                }}
                isMulti={true}
                currentValue={form.linked_notes}
                onSelect={(value) => {
                  const current = form.linked_notes ? form.linked_notes.split(",").map(n => n.trim()).filter(Boolean) : [];
                  if (!current.includes(value)) {
                    setForm({ ...form, linked_notes: [...current, value].join(", ") });
                  }
                }}
                onRemove={(value) => {
                  const current = form.linked_notes ? form.linked_notes.split(",").map(n => n.trim()).filter(Boolean) : [];
                  setForm({ ...form, linked_notes: current.filter(n => n !== value).join(", ") });
                }}
              />
            </div>
          )}

          <div className="flex gap-2">
            <Button onClick={handleSave} className="flex-1 rounded-none">حفظ Save</Button>
            <Button onClick={() => { setIsEditing(false); setForm(post); }} variant="outline" className="flex-1 rounded-none">إلغاء Cancel</Button>
          </div>
        </div>
      ) : (
        /* View Mode */
        <div className="space-y-5">
          {/* العنوان فقط بالأعلى — نمط التطبيق: إنجليزيّ ذهبي / عربيّ وردي */}
          <h1 dir="auto" style={{
            fontFamily: isArabic ? "'Amiri', serif" : "'Playfair Display', serif",
            fontSize: "1.65rem", fontWeight: 700,
            color: isArabic ? "#9D174D" : "#9a7b1f",
            lineHeight: 1.3, textAlign: isArabic ? "right" : "left",
          }}>{post.title}</h1>
          <p className={`text-[15px] font-body leading-[1.9] whitespace-pre-wrap text-foreground/85 ${isArabic ? "text-right tracking-normal" : "text-left tracking-wide"}`} style={{ wordSpacing: isArabic ? "0.05em" : "normal" }}>{post.body}</p>
          <MediaViewer mediaUrls={post.media_urls} mediaLinks={post.media_links} bodyText={post.body} />

          {/* الوسوم @ + التصنيف — وسط، نمط التطبيق */}
          {(tags.length > 0 || post.entry_type) && (
            <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 justify-center pt-1">
              {post.entry_type && post.entry_type.split(",").map((t) => TYPE_LABEL[t.trim()] || t.trim()).filter(Boolean).map((label) => (
                <span key={label} className="text-[11px] font-body" style={{ color: "#9a7b1f" }}>{label}</span>
              ))}
              {tags.map((tag) => (
                <Link key={tag} to={`/at?name=${encodeURIComponent(tag)}`} className="text-xs font-body text-primary hover:underline" dir="auto">@{tag}</Link>
              ))}
            </div>
          )}

          {/* التفاعلات — كصفحة المعجم (إعجاب/إعجاب/عدم إعجاب/مذهل + فكرة). البوك مارك بالأسفل */}
          <InteractionBar
            reaction={currentReaction}
            hasThought={!!myReaction?.thought}
            showWtf={true}
            center={true}
            onReact={(kind) => reactMutation.mutate({ reaction: kind })}
            onThought={openThought}
          />

          {/* تصدير */}
          <div className="flex justify-center">
            <button onClick={() => setExportPost(post)} className="text-xs font-body text-amber-700 hover:underline">
              {isAr ? "تصدير" : "Export"}
            </button>
          </div>

          {/* محرّر الفكرة (سطري) */}
          {thoughtOpen && (
            <div className="space-y-2">
              <textarea value={thoughtDraft} onChange={(e) => setThoughtDraft(e.target.value)} dir="auto" rows={3}
                placeholder={isAr ? "اكتب فكرتك.." : "Write your thought.."}
                className="w-full text-sm font-body p-3 rounded-none border border-amber-300/60 bg-white dark:bg-transparent focus:outline-none focus:border-amber-500" />
              <div className="flex gap-3 justify-center">
                <button onClick={() => thoughtMutation.mutate({ newThought: thoughtDraft })} className="text-xs font-body text-amber-700 hover:underline">{isAr ? "حفظ" : "Save"}</button>
                <button onClick={() => setThoughtOpen(false)} className="text-xs font-body text-muted-foreground hover:underline">{isAr ? "إلغاء" : "Cancel"}</button>
              </div>
            </div>
          )}
          {myReaction?.thought && !thoughtOpen && (
            <div className="p-3 space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "فكرتي" : "My thought"}</p>
              <p className="text-sm font-body" dir="auto">{myReaction.thought}</p>
              <button onClick={openThought} className="text-[10px] text-muted-foreground hover:underline font-body">{isAr ? "تعديل" : "Edit"}</button>
            </div>
          )}

          {/* جدول واحد: ارتباط + معلومات (مدموجان) — بطاقة بيضاء بحدّ ذهبي مربّع */}
          <div className="bg-white dark:bg-transparent rounded-none p-4 space-y-3" style={{ border: "1px solid #C8A02E" }}>
            <p className="text-xs font-heading font-semibold text-center" style={{ color: "#9a7b1f" }}>{isAr ? "ارتباط ومعلومات" : "Related & Info"}</p>

            {(linkedBrand || linkedPerfume || linkedPerfumer || linkedNotes.length > 0) && (
              <div className="space-y-2">
                {linkedBrand && (<><LinkedItemRow item={linkedBrand} type="brand" /><div style={{ height: 1, background: "#C8A02E", opacity: 0.4 }} /></>)}
                {linkedPerfume && (<><LinkedItemRow item={linkedPerfume} type="perfume" /><div style={{ height: 1, background: "#C8A02E", opacity: 0.4 }} /></>)}
                {linkedPerfumer && (<><LinkedItemRow item={linkedPerfumer} type="perfumer" /><div style={{ height: 1, background: "#C8A02E", opacity: 0.4 }} /></>)}
                {linkedNotes.map((note, idx) => (
                  <div key={note.id || idx}>
                    <LinkedItemRow item={note} type="note" />
                    {idx < linkedNotes.length - 1 && <div style={{ height: 1, background: "#C8A02E", opacity: 0.4, marginTop: 8 }} />}
                  </div>
                ))}
                <div style={{ height: 1, background: "#C8A02E", opacity: 0.4 }} />
              </div>
            )}

            {/* صفوف المعلومات */}
            <div className="space-y-1 text-[11px] font-body text-muted-foreground" dir={isAr ? "rtl" : "ltr"}>
              {post.entry_type && (
                <div className="flex justify-between gap-3">
                  <span>{isAr ? "التصنيف" : "Classification"}</span>
                  <span className="font-semibold text-foreground text-right">{post.entry_type.split(",").map((t) => TYPE_LABEL[t.trim()] || t.trim()).join(isAr ? "، " : ", ")}</span>
                </div>
              )}
              {personName && (
                <div className="flex justify-between gap-3">
                  <span>{isAr ? "الكاتب" : "Author"}</span>
                  <span className="font-semibold text-foreground text-right">{personName}</span>
                </div>
              )}
              <div className="flex justify-between gap-3">
                <span>{isAr ? "التاريخ" : "Date"}</span>
                <span className="text-right">{new Date(post.created_date).toLocaleDateString(isAr ? "ar" : "en-US", { year: "numeric", month: "short", day: "numeric" })}</span>
              </div>
            </div>
          </div>

          {/* الأسفل: تعديل + أرشفة/استرجاع + حذف */}
          <div className="flex items-center justify-center gap-5 pt-1">
            <button onClick={handleEdit} className="flex items-center gap-1 text-xs font-body text-muted-foreground hover:text-amber-700 transition-colors">
              <Edit className="w-4 h-4" /> {isAr ? "تعديل" : "Edit"}
            </button>
            {!post.archived ? (
              <button onClick={() => archiveMutation.mutate()} className="flex items-center gap-1 text-xs font-body text-muted-foreground hover:text-foreground transition-colors">
                <Archive className="w-4 h-4" /> {isAr ? "أرشفة" : "Archive"}
              </button>
            ) : (
              <button onClick={() => unarchiveMutation.mutate()} className="flex items-center gap-1 text-xs font-body text-muted-foreground hover:text-foreground transition-colors">
                <ArchiveX className="w-4 h-4" /> {isAr ? "استرجاع" : "Restore"}
              </button>
            )}
            <button onClick={() => deleteMutation.mutate()} className="flex items-center gap-1 text-xs font-body text-rose-600 hover:underline transition-colors">
              <Trash2 className="w-4 h-4" /> {isAr ? "حذف" : "Delete"}
            </button>
          </div>

          {/* Footer: نسخ + دفتر (بوك مارك) + سابق/تالٍ — في الأسفل */}
          <DetailFooter
            items={sortedPosts}
            currentId={post.id}
            pathFor={(p) => `/blog-detail?id=${p.id}`}
            labelFor={(p) => (p.title || "").slice(0, 24)}
            copyText={`${post.title || ""}\n\n${post.body || ""}`}
            bookmark={{
              item_type: "blog",
              item_id: post.id,
              title_en: post.title || "",
              title_ar: "",
              subtitle: post.entry_type || "",
              path: `/blog-detail?id=${post.id}`,
            }}
          />
        </div>
      )}

      <BlogExportDialog post={post} open={!!exportPost} onClose={() => setExportPost(null)} personName={personName} />
    </div>
  );
}

function LinkedItemRow({ item, type }) {
  const { isAr } = useLang();
  let href = "#";
  let title = "";
  let titleAr = "";
  let image = "";
  let bio = "";
  let bioAr = "";
  let typeLabel = "";
  let typeAr = "";

  if (type === "brand") {
    href = `/brand?id=${item.id}`;
    title = item.name;
    titleAr = item.name_ar;
    image = item.logo_url;
    bio = item.description;
    bioAr = item.description_ar;
    typeLabel = "Brand";
    typeAr = "ماركة";
  } else if (type === "perfume") {
    href = `/perfume?id=${item.id}`;
    title = item.name_en || item.name_ar;
    titleAr = item.name_ar || item.name_en;
    image = item.image_url;
    bio = item.about_en;
    bioAr = item.about_ar;
    typeLabel = "Perfume";
    typeAr = "عطر";
  } else if (type === "perfumer") {
    href = `/perfumer?id=${item.id}`;
    title = item.name;
    titleAr = item.name_ar;
    image = item.photo_url;
    bio = item.bio;
    typeLabel = "Perfumer";
    typeAr = "عطار";
  } else if (type === "note") {
    href = item.id ? `/note?id=${item.id}` : `/note?name=${encodeURIComponent(item.name || "")}`;
    title = item.name;
    image = item.image_url;
    bio = item.description;
    typeLabel = "Note";
    typeAr = "نوتة";
  }

  return (
    <a href={href} className="group block">
      <div className="flex items-center gap-1 mb-2">
        <span className="text-xs font-heading font-semibold text-amber-600 dark:text-amber-400 uppercase tracking-wide">{isAr ? typeAr : typeLabel}</span>
      </div>
      <div className="flex gap-2 pb-2">
        <div className="w-12 h-12 flex-shrink-0 rounded-none overflow-hidden bg-white border border-amber-100 flex items-center justify-center">
          {image ? (
            <img src={image} alt={title} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full bg-white" />
          )}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-1 mb-0.5 flex-wrap">
            <span className="text-xs font-semibold group-hover:text-primary transition-colors font-body leading-tight">{isAr ? (titleAr || title) : (title || titleAr)}</span>
          </div>
          {(bio || bioAr) && (
            <p className="text-[10px] text-muted-foreground leading-relaxed line-clamp-2 font-body">
              {isAr ? (bioAr || bio) : (bio || bioAr)}
            </p>
          )}
        </div>
      </div>
    </a>
  );
}