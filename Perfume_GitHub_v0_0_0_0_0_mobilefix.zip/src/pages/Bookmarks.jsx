import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Notebook, X } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { useBookmarks } from "@/hooks/useBookmarks";

const TYPE_LABEL = {
  brand:    { en: "Brand",    ar: "براند",  emoji: "🏛️" },
  perfume:  { en: "Perfume",  ar: "عطر",    emoji: "🌹" },
  perfumer: { en: "Perfumer", ar: "عطّار",  emoji: "👑" },
  quote:    { en: "Quote",    ar: "اقتباس", emoji: "💬" },
  note:     { en: "Note",     ar: "نوتة",   emoji: "🌿" },
  blog:     { en: "Blog",     ar: "مدوّنة", emoji: "📖" },
  glossary: { en: "Term",     ar: "مصطلح",  emoji: "📖" },
  story:    { en: "Story",    ar: "قصة",    emoji: "📜" },
  wisdom:   { en: "Wisdom",   ar: "حكمة",   emoji: "🕊️" },
  store:    { en: "Store",    ar: "متجر",   emoji: "🏪" },
};

export default function Bookmarks() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { bookmarks, toggleBookmark } = useBookmarks();

  // Group by type, preserving section order; include ANY type present
  // (e.g. "wisdom") even if not in the predefined order, so no entry is hidden.
  const order = ["brand", "perfume", "perfumer", "quote", "note", "blog", "glossary", "story", "wisdom", "store"];
  const known = new Set(order);
  const extras = [...new Set(bookmarks.map((b) => b.item_type).filter((t) => !known.has(t)))];
  const grouped = [...order, ...extras]
    .map((type) => ({ type, items: bookmarks.filter((b) => b.item_type === type) }))
    .filter((g) => g.items.length > 0);

  return (
    <div className="px-4 pt-12 pb-20 max-w-lg mx-auto space-y-5">
      {/* Header row: back + title + @ آت button. The @ button is a plain
          text link to /at — no background, no border, just an elegant amber
          tone. Renders exactly as " —@  —آت " per spec. */}
      <div className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center justify-center w-8 h-8 rounded-none hover:bg-secondary transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <h1 className="font-heading text-xl font-bold flex items-center gap-2">
            <Notebook className="w-5 h-5" strokeWidth={1.25} style={{ color: "#16a34a" }} />
            {isAr ? "مفكرة" : "Notebook"}
          </h1>
        </div>
        <Link
          to="/at"
          className="font-body text-sm transition-opacity hover:opacity-70"
          style={{ color: "#a16207", letterSpacing: "0.04em" }}
        >
          {isAr ? "—آت" : "__@"}
        </Link>
      </div>

      {bookmarks.length === 0 && (
        <div className="text-center py-16 space-y-2">
          <Notebook className="w-10 h-10 text-muted-foreground/40 mx-auto" strokeWidth={1.25} />
          <p className="text-sm text-muted-foreground font-body">
            {isAr ? "المفكرة فارغة" : "Your notebook is empty"}
          </p>
          <p className="text-xs text-muted-foreground/70 font-body">
            {isAr
              ? "اضغط أيقونة المفكرة على أي مدخل لإضافته هنا"
              : "Tap the notebook icon on any entry to add it here"}
          </p>
        </div>
      )}

      {/* Clean ruled list — no card, no border, no background, no count. Each
          entry is a plain pressable row. Words act as their own buttons. */}
      {grouped.map(({ type, items }) => {
        const lbl = TYPE_LABEL[type] || { en: type, ar: type, emoji: "🔖" };
        return (
          <div key={type} className="space-y-1">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground font-body flex items-center gap-1.5">
              <span>{lbl.emoji}</span>
              {isAr ? lbl.ar : lbl.en}
            </p>
            {items.map((b) => (
              <div
                key={b.id}
                className="flex items-center gap-2 px-1 py-2.5 transition-opacity hover:opacity-70"
                style={{ borderBottom: "1px solid #e5e7eb" }}
              >
                <button
                  className="flex-1 text-left min-w-0"
                  onClick={() => b.path && navigate(b.path)}
                >
                  {b.title_en && (
                    <p className="text-sm font-body font-medium truncate" dir="ltr">{b.title_en}</p>
                  )}
                  {b.title_ar && (
                    <p className="text-sm font-body text-muted-foreground truncate" dir="rtl">{b.title_ar}</p>
                  )}
                  {b.subtitle && (
                    <p className="text-[10px] text-muted-foreground/70 font-body truncate" dir="auto">{b.subtitle}</p>
                  )}
                </button>
                <button
                  onClick={() => toggleBookmark({ item_type: b.item_type, item_id: b.item_id })}
                  title={isAr ? "إزالة" : "Remove"}
                  className="flex items-center justify-center w-7 h-7 rounded-none text-muted-foreground hover:text-rose-600 transition-colors flex-shrink-0"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}
