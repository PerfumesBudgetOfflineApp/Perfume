import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeftIcon as ArrowLeft, DownloadIcon as Download, FileTextIcon as FileText, ImageIcon, PdfIcon as FileType2, CheckSquareIcon as CheckSquare, SquareIcon as Square } from "@/components/icons/LineIcons";
import { toast } from "sonner";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { compareEnglish } from "@/lib/sortName";
import { DEFAULT_USER_MARK, getExportSettings } from "@/lib/exportSettings";
import { getAppName } from "@/lib/useAppName";
import { exportElementAsImage, exportElementAsPDF, downloadText } from "@/lib/collectionExport";
import { format } from "date-fns";

function perfumeTitle(p, isAr) {
  if (!p) return "";
  return (isAr ? (p.name_ar || p.name_en) : (p.name_en || p.name_ar)) || p.name || "";
}

export default function NewCollection() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();

  const [person, setPerson] = useState("all");          // all | person1 | person2
  const [selected, setSelected] = useState(null);       // Set<upId> | null (=all)
  const [typeOverride, setTypeOverride] = useState({});  // upId -> 'sample'|'bottle'
  const [fmt, setFmt] = useState("image");               // image | pdf | text
  const [bg, setBg] = useState("#ffffff");
  const [busy, setBusy] = useState(false);
  const [showMark, setShowMark] = useState(() => {
    try { return getExportSettings()?.showUserMark !== false; } catch { return true; }
  });

  const { data: userPerfumes = [], isLoading } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
  });

  const personPerfumes = useMemo(
    () => (person === "all" ? userPerfumes : userPerfumes.filter((u) => u.person === person)),
    [userPerfumes, person]
  );

  const { data: perfumeDetails = [] } = useQuery({
    queryKey: ["perfumes-details", personPerfumes],
    queryFn: async () => {
      if (personPerfumes.length === 0) return [];
      const ids = [...new Set(personPerfumes.map((up) => up.perfume_id))];
      const results = await Promise.all(
        ids.map((id) => apphost.entities.Perfume.filter({ id }).then((r) => r?.[0]))
      );
      return results.filter(Boolean);
    },
    enabled: personPerfumes.length > 0,
  });

  const perfumeById = useMemo(() => {
    const m = new Map();
    perfumeDetails.forEach((p) => m.set(String(p.id), p));
    return m;
  }, [perfumeDetails]);

  // النوع الافتراضي لكل سجل: قنينة إن وُجد شراء قنينة، وإلا عينة.
  const defaultType = (up) => {
    const recs = purchases.filter(
      (r) => String(r.perfume_id) === String(up.perfume_id) &&
        (person === "all" || r.person === up.person)
    );
    if (recs.some((r) => r.type === "bottle")) return "bottle";
    return "sample";
  };
  const rowType = (up) => typeOverride[up.id] || defaultType(up);

  // التجميع بالبراند (أبجدياً إنجليزياً)، وعطور كل براند مرتّبة.
  const groups = useMemo(() => {
    const byBrand = new Map();
    for (const up of personPerfumes) {
      const p = perfumeById.get(String(up.perfume_id));
      if (!p) continue;
      const brand = (p.brand_name || up.brand_name || (isAr ? "بدون براند" : "No brand")).trim();
      if (!byBrand.has(brand)) byBrand.set(brand, []);
      byBrand.get(brand).push({ up, perfume: p });
    }
    const arr = [...byBrand.entries()].map(([brand, items]) => ({
      brand,
      items: items.sort((a, b) => compareEnglish(a.perfume, b.perfume, 1)),
    }));
    arr.sort((a, b) => compareEnglish({ name_en: a.brand }, { name_en: b.brand }, 1));
    return arr;
  }, [personPerfumes, perfumeById, isAr]);

  const allIds = useMemo(
    () => groups.flatMap((g) => g.items.map((it) => it.up.id)),
    [groups]
  );
  const isSelected = (id) => (selected === null ? true : selected.has(id));
  const selectedCount = selected === null ? allIds.length : [...selected].filter((id) => allIds.includes(id)).length;

  const toggleRow = (id) => {
    setSelected((prev) => {
      const base = prev === null ? new Set(allIds) : new Set(prev);
      if (base.has(id)) base.delete(id); else base.add(id);
      return base;
    });
  };
  const toggleAll = () => {
    if (selectedCount === allIds.length) setSelected(new Set());
    else setSelected(null);
  };
  const toggleType = (id, current) =>
    setTypeOverride((prev) => ({ ...prev, [id]: current === "sample" ? "bottle" : "sample" }));

  // البيانات المختارة للتصدير.
  const exportGroups = useMemo(
    () =>
      groups
        .map((g) => ({ ...g, items: g.items.filter((it) => isSelected(it.up.id)) }))
        .filter((g) => g.items.length > 0),
    [groups, selected]
  );
  const exportTotal = exportGroups.reduce((s, g) => s + g.items.length, 0);

  const titleAr = "مجموعتي الجديدة";
  const titleEn = "My New Collection";

  const headerMark = () => {
    let settings = {};
    try { settings = getExportSettings() || {}; } catch { settings = {}; }
    const bits = [];
    if (showMark) bits.push(DEFAULT_USER_MARK);
    if (settings.showAppName !== false) {
      try { const n = getAppName().name_en; if (n) bits.push(n); } catch { /* ignore */ }
    }
    bits.push(new Date().toLocaleDateString());
    return bits.join("  ·  ");
  };

  const buildText = () => {
    const lines = [];
    lines.push(isAr ? titleAr : titleEn);
    lines.push(headerMark());
    lines.push("");
    for (const g of exportGroups) {
      lines.push(`■ ${g.brand}`);
      for (const { up, perfume } of g.items) {
        const t = rowType(up);
        const tag = t === "bottle" ? (isAr ? "قنينة" : "Bottle") : (isAr ? "عينة" : "Sample");
        lines.push(`   • ${perfumeTitle(perfume, isAr)}  [${tag}]`);
      }
      lines.push("");
    }
    lines.push(`${isAr ? "الإجمالي" : "Total"}: ${exportTotal}`);
    return lines.join("\n");
  };

  const handleExport = async () => {
    if (exportTotal === 0) {
      toast.error(isAr ? "لا عطور محدّدة" : "No perfumes selected");
      return;
    }
    setBusy(true);
    try {
      const stamp = format(new Date(), "yyyy-MM-dd");
      if (fmt === "text") {
        await downloadText(buildText(), `new-collection-${stamp}.txt`);
      } else {
        const el = document.getElementById("new-collection-export-card");
        if (!el) throw new Error("export card missing");
        if (fmt === "image") await exportElementAsImage(el, `new-collection-${stamp}.png`, bg);
        else await exportElementAsPDF(el, `new-collection-${stamp}.pdf`, bg);
      }
      toast.success(isAr ? "تم التصدير" : "Exported");
    } catch (e) {
      console.error("export failed", e);
      toast.error(isAr ? "فشل التصدير" : "Export failed");
    } finally {
      setBusy(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="px-5 pt-12 pb-24">
      {/* Header */}
      <div className="flex items-center gap-3 mb-5">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-heading text-2xl font-bold">🌿 {isAr ? titleAr : titleEn}</h1>
          <p className="text-xs text-muted-foreground mt-1">
            {selectedCount}/{allIds.length} {isAr ? "محدّد" : "selected"}
          </p>
        </div>
      </div>

      {/* Person filter */}
      <div className="flex gap-2 mb-4">
        {[
          { v: "all", label: isAr ? "الكل" : "All" },
          { v: "person1", label: names.person1 },
          { v: "person2", label: names.person2 },
        ].map((o) => (
          <button
            key={o.v}
            onClick={() => { setPerson(o.v); setSelected(null); }}
            className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${
              person === o.v ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>

      {allIds.length === 0 ? (
        <div className="text-center py-10 bg-secondary/30 rounded-none">
          <p className="text-sm text-muted-foreground font-body">
            {isAr ? "لا توجد عطور مملوكة لعرضها" : "No owned perfumes to show"}
          </p>
        </div>
      ) : (
        <>
          {/* Select-all */}
          <button
            onClick={toggleAll}
            className="flex items-center gap-2 mb-4 text-xs font-body text-primary"
          >
            {selectedCount === allIds.length
              ? <CheckSquare className="w-4 h-4" />
              : <Square className="w-4 h-4" />}
            {isAr ? "تحديد الكل" : "Select all"}
          </button>

          {/* Brand groups */}
          <div className="space-y-5">
            {groups.map((g) => (
              <div key={g.brand}>
                <div className="flex items-center gap-2 mb-2">
                  <h2 className="font-heading text-base font-semibold">{g.brand}</h2>
                  <span className="text-[10px] text-primary rounded-none">{g.items.length}</span>
                </div>
                <div className="space-y-1.5">
                  {g.items.map(({ up, perfume }) => {
                    const t = rowType(up);
                    const sel = isSelected(up.id);
                    return (
                      <div
                        key={up.id}
                        className={`flex items-center gap-3 rounded-none p-2.5 transition-colors ${
                          sel ? "bg-secondary/50" : "bg-secondary/20 opacity-60"
                        }`}
                      >
                        <button onClick={() => toggleRow(up.id)} aria-label="select" className="flex-shrink-0">
                          {sel ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4 text-muted-foreground" />}
                        </button>
                        <div
                          className="flex-1 min-w-0 cursor-pointer"
                          onClick={() => navigate(`/perfume?id=${perfume.id}`)}
                        >
                          <p className="text-xs font-body font-bold truncate">{perfumeTitle(perfume, isAr)}</p>
                        </div>
                        <button
                          onClick={() => toggleType(up.id, t)}
                          className={`flex-shrink-0 text-[10px] font-body font-medium rounded-none transition-all ${
 t === "bottle"
 ? " text-amber-700 dark:text-amber-400"
 : " text-blue-700 dark:text-blue-400"
 }`}
                        >
                          {t === "bottle" ? (isAr ? "🍾 قنينة" : "🍾 Bottle") : (isAr ? "💧 عينة" : "💧 Sample")}
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Export controls */}
          <div className="mt-8 pt-6 border-t border-border space-y-4">
            <p className="text-sm font-body font-medium">{isAr ? "تصدير المجموعة" : "Export collection"}</p>
            <div className="flex gap-2">
              {[
                { v: "image", label: isAr ? "صورة" : "Image", icon: ImageIcon },
                { v: "pdf", label: "PDF", icon: FileType2 },
                { v: "text", label: isAr ? "نص" : "Text", icon: FileText },
              ].map((o) => {
                const Icon = o.icon;
                return (
                  <button
                    key={o.v}
                    onClick={() => setFmt(o.v)}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${
                      fmt === o.v ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" /> {o.label}
                  </button>
                );
              })}
            </div>

            {fmt !== "text" && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground font-body">{isAr ? "الخلفية" : "Background"}</span>
                {["#ffffff", "#faf5ec", "#1c1917"].map((c) => (
                  <button
                    key={c}
                    onClick={() => setBg(c)}
                    className={`w-7 h-7 rounded-none border-2 ${bg === c ? "border-primary" : "border-border"}`}
                    style={{ background: c }}
                    aria-label={c}
                  />
                ))}
              </div>
            )}

            <button
              onClick={() => setShowMark((v) => !v)}
              className="flex items-center gap-2 text-xs font-body"
            >
              {showMark ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4 text-muted-foreground" />}
              <span className={showMark ? "text-foreground" : "text-muted-foreground"}>
                {isAr ? `علامة المستخدم (${DEFAULT_USER_MARK})` : `User mark (${DEFAULT_USER_MARK})`}
              </span>
            </button>

            <Button onClick={handleExport} disabled={busy || exportTotal === 0} className="w-full h-11 rounded-none font-body gap-2">
              <Download className="w-4 h-4" />
              {busy ? (isAr ? "جارٍ..." : "Working...") : `${isAr ? "تنزيل" : "Download"} (${exportTotal})`}
            </Button>
          </div>
        </>
      )}

      {/* Hidden export card (RTL-aware, Arabic rendered by browser) */}
      <div style={{ position: "fixed", left: 0, top: 0, zIndex: -1, opacity: 1, pointerEvents: "none" }} aria-hidden="true">
        <div
          id="new-collection-export-card"
          dir={isAr ? "rtl" : "ltr"}
          style={{
            width: "640px",
            boxSizing: "border-box",
            padding: "40px 36px",
            background: bg,
            color: bg === "#1c1917" ? "#f5f0e6" : "#241c12",
            fontFamily: "'Cairo','Amiri','Segoe UI',sans-serif",
          }}
        >
          <div style={{ textAlign: "center", marginBottom: "10px", fontSize: "13px", color: bg === "#1c1917" ? "#cbb98a" : "#9a8a6a" }}>
            {headerMark()}
          </div>
          <h2 style={{ textAlign: "center", fontSize: "30px", fontWeight: 700, margin: "0 0 6px" }}>
            🌿 {isAr ? titleAr : titleEn}
          </h2>
          <p style={{ textAlign: "center", fontSize: "13px", margin: "0 0 26px", color: bg === "#1c1917" ? "#a8a097" : "#8a7d63" }}>
            {exportTotal} {isAr ? "عطر" : "perfumes"} {exportGroups.length} {isAr ? "براند" : "brands"}
          </p>

          {exportGroups.map((g) => (
            <div key={g.brand} style={{ marginBottom: "20px" }}>
              <div
                style={{
                  fontSize: "17px",
                  fontWeight: 700,
                  borderBottom: `1.5px solid ${bg === "#1c1917" ? "#4a4036" : "#e0cfa0"}`,
                  paddingBottom: "5px",
                  marginBottom: "8px",
                  color: bg === "#1c1917" ? "#e8c97a" : "#a16207",
                }}
              >
                {g.brand}
              </div>
              {g.items.map(({ up, perfume }) => {
                const t = rowType(up);
                const tag = t === "bottle" ? (isAr ? "قنينة" : "Bottle") : (isAr ? "عينة" : "Sample");
                return (
                  <div
                    key={up.id}
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                      fontSize: "15px",
                      padding: "6px 4px",
                      borderBottom: `0.5px solid ${bg === "#1c1917" ? "#332d26" : "#efe7d4"}`,
                    }}
                  >
                    <span>{t === "bottle" ? "🍾" : "💧"} {perfumeTitle(perfume, isAr)}</span>
                    <span
                      style={{
                        fontSize: "12px",
                        fontWeight: 600,
                        padding: "2px 10px",
                        borderRadius: "999px",
                        background: t === "bottle"
                          ? (bg === "#1c1917" ? "#3a2e10" : "#fdf0d4")
                          : (bg === "#1c1917" ? "#10243a" : "#e2effb"),
                        color: t === "bottle"
                          ? (bg === "#1c1917" ? "#f0c674" : "#92610c")
                          : (bg === "#1c1917" ? "#7fb6ef" : "#1a5fa5"),
                      }}
                    >
                      {tag}
                    </span>
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
