import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel,
  AlertDialogContent, AlertDialogDescription, AlertDialogFooter,
  AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { ArrowLeft, Trash2, CalendarDays, User, Camera, SprayCan } from "lucide-react";
import { accordColor, accordChipStyle } from "@/lib/accordColors";
import AccordBars from "@/components/perfume/AccordBars";
import StarRating from "@/components/perfume/StarRating";
import FragranceNotesGrid from "@/components/perfume/FragranceNotesGrid";
import ListBadge from "@/components/perfume/ListBadge";
import PerfumePlaceholder from "@/components/perfume/PerfumePlaceholder";
import ZoomableImage from "@/components/shared/ZoomableImage";
import PerfumeCardBox from "@/components/perfume/PerfumeCardBox";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import { decadeLabel } from "@/lib/decade";
import { dominantAccord } from "@/components/perfume/AccordFlacon";
import { scentClassAr } from "@/lib/crowdLabels";
import StoreSelector from "@/components/store/StoreSelector";
import EditPurchaseDialog from "@/components/purchase/EditPurchaseDialog";
import { format } from "date-fns";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";
import HealthRatingSection from "@/components/perfume/HealthRatingSection";
import { perfumeLabels, analyzePerfume, MECH } from "@/lib/headacheRisk";
import PerfumersSection from "@/components/perfume/PerfumersSection";
import SimilarPerfumes from "@/components/perfume/SimilarPerfumes";
import EditPerfumeDialog from "@/components/perfume/EditPerfumeDialog";
import WearScheduleSection from "@/components/perfume/WearScheduleSection";
import ExportReviewDialog from "@/components/perfume/ExportReviewDialog";
import EnhancedExportDialog from "@/components/perfume/EnhancedExportDialog";
import LuxuryCardExport from "@/components/export/LuxuryCardExport";
import CopyMenu from "@/components/shared/CopyMenu";
import BookmarkButton from "@/components/shared/BookmarkButton";
import PinButton from "@/components/shared/PinButton";
import { perfumeDbText, perfumeFullText } from "@/lib/copyData";

export default function PerfumeDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { formatPrice } = useCurrency();
  const [wearDialogOpen, setWearDialogOpen] = useState(false);
  const [wearNote, setWearNote] = useState("");
  const [wearPerson, setWearPerson] = useState("person1");
  const [wearMood, setWearMood] = useState("");
  const [activePerson, setActivePerson] = useState("person1");
  const [editNotes, setEditNotes] = useState(false);
  const [notes, setNotes] = useState("");
  const [editSampleMl, setEditSampleMl] = useState(false);
  const [sampleMl, setSampleMl] = useState("");
  const [editSampleCost, setEditSampleCost] = useState(false);
  const [sampleCost, setSampleCost] = useState("");
  const [purchaseType, setPurchaseType] = useState("sample");
  const [selectedStore, setSelectedStore] = useState("");
  const [showImageDialog, setShowImageDialog] = useState(false);

  const [wishDialogOpen, setWishDialogOpen] = useState(false);
  const [wishPrice, setWishPrice] = useState("");
  const [wishPriority, setWishPriority] = useState("medium");
  const [wishNotes, setWishNotes] = useState("");

  // Shared perfume data (app database)
  const { data: perfume, isLoading } = useQuery({
    queryKey: ["perfume", id],
    queryFn: () => apphost.entities.Perfume.filter({ id }),
    select: (data) => data?.[0],
    enabled: !!id,
  });

  // Per-person user data
  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfume", id],
    queryFn: () => apphost.entities.UserPerfume.filter({ perfume_id: id }),
    enabled: !!id,
  });

  const userDataP1 = userPerfumes.find((u) => u.person === "person1") || null;
  const userDataP2 = userPerfumes.find((u) => u.person === "person2") || null;
  const activeUserData = activePerson === "person1" ? userDataP1 : userDataP2;
  


  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs-perfume", id],
    queryFn: () => apphost.entities.WearLog.filter({ perfume_id: id }),
    enabled: !!id,
  });

  // Fetch ALL purchases for this perfume (both persons)
  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records", id],
    queryFn: () => apphost.entities.PurchaseRecord.filter({ perfume_id: id }, "-created_date"),
    enabled: !!id,
  });

  const { data: stores = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });

  // For edit dialog: fetch categories and odor families from DB
  const { data: allMainNotes = [] } = useQuery({
    queryKey: ["notes-main-for-edit"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ note_category: "main_note" }, "name", 300),
    staleTime: 1000 * 60 * 10,
  });


  // For export: fetch all note records to match by name
  const { data: allNoteRecords = [] } = useQuery({
    queryKey: ["all-perfume-notes-export"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 1000 * 60 * 10,
  });
  const noteRecordsForExport = {};
  allNoteRecords.forEach(n => { noteRecordsForExport[n.name?.toLowerCase()] = n; });

  // For export: fetch all perfumers to get Arabic names
  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["all-perfumers-export"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: 1000 * 60 * 10,
  });
  const perfumersMapByName = {};
  allPerfumers.forEach(p => { if (p.name) perfumersMapByName[p.name.toLowerCase()] = p; });

  // Fetch all perfumes ONLY when this perfume actually has related links.
  // العطور الجديدة (130 ألف) بلا روابط → لا نحمّل القائمة الكاملة فتفتح الصفحة فوراً.
  const { data: allPerfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
    enabled: !!perfume && String(perfume.related_perfume_ids || "").trim() !== "",
  });



  const wearMutation = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wear-logs-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success((isAr ? "سُجّل في سجل الارتداء" : "Logged to wear history"));
      setWearDialogOpen(false);
      setWearNote("");
      setWearMood("");
      setWearPerson("person1");
    },
  });

  // Fetch perfume-related ShopBrands to find linked brand
  const { data: shopBrands = [] } = useQuery({
    queryKey: ["shop-brands-light"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const recordPurchaseEverywhere = async ({ perfume, activePerson, purchaseType, mlVal, costVal, selectedStore, stores, activeUserData }) => {
    console.log("🛒 START purchase:", { perfumeName: perfume.name_en, mlVal, costVal, selectedStore });
    const store = selectedStore ? stores.find((s) => String(s.id) === String(selectedStore)) : null;
    const today = format(new Date(), "yyyy-MM-dd");
    const perfumeName = perfume.name_en || perfume.name || "";

    // 0. Ensure UserPerfume exists (required for purchase tracking)
    let userPerfumeId = activeUserData?.id;
    if (!userPerfumeId) {
      const existing = await apphost.entities.UserPerfume.filter({ perfume_id: perfume.id, person: activePerson });
      if (existing.length > 0) {
        userPerfumeId = existing[0].id;
      } else {
        const created = await apphost.entities.UserPerfume.create({
          perfume_id: perfume.id,
          perfume_name: perfumeName,
          brand_name: perfume.brand_name || "",
          person: activePerson,
          sample_ml: 0,
          sample_cost: 0,
        });
        userPerfumeId = created.id;
      }
    }

    console.log("UserPerfume ready, id:", userPerfumeId);
    // 1. Create PurchaseRecord
    const pr = await apphost.entities.PurchaseRecord.create({
      user_perfume_id: userPerfumeId,
      perfume_id: perfume.id,
      perfume_name: perfumeName,
      brand_name: perfume.brand_name || "",
      person: activePerson,
      type: purchaseType,
      ml: mlVal,
      cost: costVal,
      purchase_date: today,
      store_id: selectedStore || null,
      store_name: store?.name || null,
    });

    console.log("PurchaseRecord created:", pr?.id);
    // 2. Find or create ShopProduct linked to this perfume
    const personVal = activePerson === "person1" ? "person1" : "person2";
    const existingProducts = await apphost.entities.ShopProduct.filter({ linked_perfume_id: perfume.id, person: personVal });
    const linkedShopBrand = shopBrands.find(b => b.linked_perfume_brand_id === perfume.brand_id);

    if (existingProducts.length > 0) {
      // Update existing ShopProduct cost
      const sp = existingProducts[0];
      await apphost.entities.ShopProduct.update(sp.id, {
        cost: (sp.cost || 0) + costVal,
        ml: (sp.ml || 0) + mlVal,
        purchase_date: today,
        purchase_type: purchaseType,
        store_id: selectedStore || sp.store_id || null,
        store_name: (selectedStore ? stores.find(s => String(s.id) === String(selectedStore))?.name : null) || sp.store_name || null,
      });
    } else {
      // Create new ShopProduct
      const store = selectedStore ? stores.find((s) => String(s.id) === String(selectedStore)) : null;
      await apphost.entities.ShopProduct.create({
        name: perfumeName,
        name_ar: perfume.name_ar || "",
        brand_id: linkedShopBrand?.id || null,
        brand_name: linkedShopBrand?.name || perfume.brand_name || "",
        category_id: "cat_fragrance",
        category_name_en: "Perfumes & Fragrances",
        category_name_ar: "العطور و الروائح",
        linked_perfume_id: perfume.id,
        linked_perfume_name: perfumeName,
        cost: costVal,
        purchase_date: today,
        purchase_type: purchaseType,
        ml: mlVal,
        person: personVal,
        status: "active",
        store_id: store?.id || null,
        store_name: store?.name || null,
      });
    }

    console.log("ShopProduct done");
    // ملاحظة: لا نُنشئ BudgetExpense هنا — الشراء يُسجَّل كـShopProduct ويُحتسب
    // ضمن «المشتريات» (totalPurchases) في الميزانية. إنشاء BudgetExpense إضافي
    // كان يحتسب نفس المبلغ مرّتين (22 → 44). [إصلاح Dior]
    // 4. Update UserPerfume totals (sample_ml + sample_cost)
    const upResults = await apphost.entities.UserPerfume.filter({ perfume_id: perfume.id, person: activePerson });
    const up = upResults?.[0];
    if (up) {
      await apphost.entities.UserPerfume.update(up.id, {
        sample_ml: (parseFloat(up.sample_ml || 0) + mlVal),
        sample_cost: (parseFloat(up.sample_cost || 0) + costVal),
      });
    }

    console.log("Purchase complete!");
    return pr;
  };

  const purchaseMutation = useMutation({
    mutationFn: (data) => recordPurchaseEverywhere(data),
    onError: (error) => {
      console.error("Purchase failed:", error);
      toast.error(`فشل التسجيل: ${error.message || error}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["purchase-records", id] });
      queryClient.invalidateQueries({ queryKey: ["shop-products"] });
      queryClient.invalidateQueries({ queryKey: ["shop-products-by-category"] });
      toast.success((isAr ? "سُجّل الشراء" : "Purchase recorded"));
    },
  });

  // Upsert user perfume data (create or update)
  const upsertUserData = useMutation({
    mutationFn: async ({ person, field, value }) => {
      const existing = person === "person1" ? userDataP1 : userDataP2;
      const personName = person === "person1" ? names.person1 : names.person2;
      const dataToSave = { [field]: value };
      if (existing) {
        return apphost.entities.UserPerfume.update(existing.id, { ...dataToSave, person_name: personName });
      } else {
        return apphost.entities.UserPerfume.create({
          perfume_id: id,
          perfume_name: perfume?.name_en || perfume?.name_ar || "",
          brand_name: perfume?.brand_name || "",
          brand_id: perfume?.brand_id || "",
          person,
          person_name: personName,
          ...dataToSave,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["user-perfumes"] });
      toast.success((isAr ? "تم التحديث" : "Updated"));
    },
  });

  // Remove from person's collection (doesn't delete the perfume from app DB)
  const removeFromCollection = useMutation({
    mutationFn: async (person) => {
      const existing = person === "person1" ? userDataP1 : userDataP2;
      if (existing) {
        return apphost.entities.UserPerfume.delete(existing.id);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["user-perfumes"] });
      toast.success((isAr ? "أُزيل من مجموعتك" : "Removed from your collection"));
    },
  });

  // Fetch user mark
  const { data: userData } = useQuery({
    queryKey: ["current-user"],
    queryFn: () => apphost.auth.me(),
  });

  // Update perfume image
  const updatePerfumeMutation = useMutation({
    mutationFn: (data) => apphost.entities.Perfume.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfume", id] });
      toast.success((isAr ? "حُدّثت الصورة" : "Image updated"));
    },
  });

  // تقييم العطر (يُخزَّن على سجلّ العطر — هو ما يُظهر المعيّنات الذهبية في البطاقة)
  const ratingMutation = useMutation({
    mutationFn: (rating) => apphost.entities.Perfume.update(id, { rating }),
    onMutate: async (rating) => {
      await queryClient.cancelQueries({ queryKey: ["perfume", id] });
      const prev = queryClient.getQueryData(["perfume", id]);
      queryClient.setQueryData(["perfume", id], (old) =>
        Array.isArray(old) ? old.map((p) => ({ ...p, rating })) : old
      );
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev !== undefined) queryClient.setQueryData(["perfume", id], ctx.prev);
      toast.error(isAr ? "تعذّر حفظ التقييم" : "Couldn't save rating");
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfume", id] });
      queryClient.invalidateQueries({ queryKey: ["perfumes"] });
    },
  });



  // Add to wishlist
  const addToWishlist = useMutation({
    mutationFn: () => apphost.entities.Wishlist.create({
      perfume_id: id,
      perfume_name: perfume.name_en || perfume.name_ar || "",
      brand_name: perfume.brand_name || "",
      brand_id: perfume.brand_id || "",
      image_url: perfume.image_url || "",
      estimated_price: parseFloat(wishPrice) || 0,
      person: activePerson,
      priority: wishPriority,
      notes: wishNotes,
      added_date: format(new Date(), "yyyy-MM-dd"),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["wishlists"] });
      toast.success(isAr ? "تمت إضافة الرغبة" : "Added to wishlist!");
      setWishDialogOpen(false);
      setWishPrice("");
      setWishPriority("medium");
      setWishNotes("");
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!perfume) {
    return (
      <div className="px-5 pt-12 text-center">
        <p className="text-muted-foreground font-body">{isAr ? "العطر غير موجود" : "Perfume not found"}</p>
        <Button variant="ghost" onClick={() => navigate("/")} className="mt-4">{isAr ? "الرئيسية" : "Go Home"}</Button>
      </div>
    );
  }



  const handleNoteClick = (note) => {
    navigate(`/explore?noteSearch=${encodeURIComponent(note)}`);
  };

  const handleAttrClick = (attr, value) => {
    const params = new URLSearchParams();
    if (attr === "gender") params.set("genderFilter", value);
    if (attr === "type") params.set("typeFilter", value);
    navigate(`/explore?${params.toString()}`);
  };

  const handleNoteSave = () => {
    updatePerfumeMutation.mutate({ 
      personal_notes: notes,
      rating: perfume.rating
    });
    setEditNotes(false);
  };

  return (
    <div className="pb-4 bg-white min-h-screen">
      {/* Hero Image — حدّ ذهبي كالجداول + مسافة تحتها، الضغط يكبّر بلا زرّ */}
      <div className="px-5 pt-6 relative">
         {perfume.image_url && perfume.image_url !== "white" ? (
           <div className="border border-[#C8A02E] bg-white p-1.5">
             <ZoomableImage
               src={perfume.image_url}
               alt={perfume.name_en || perfume.name || ""}
               bare
               hideZoomBadge
               inlineMaxHeight="300px"
               className="w-full flex items-center justify-center [&_img]:max-h-[300px]"
             />
           </div>
         ) : (
           <div className="border border-[#C8A02E] bg-white p-2 flex items-center justify-center" style={{ minHeight: 220 }}>
             <PerfumePlaceholder perfume={perfume} />
           </div>
         )}
         <div className="absolute top-9 left-8">
           <Button variant="secondary" size="icon" className="rounded-none shadow-md" onClick={() => navigate(-1)}>
             <ArrowLeft className="w-5 h-5" />
           </Button>
         </div>
       </div>

      <div className="px-5 mt-5 relative space-y-5">

         {/* الاسم والبراند — عرض حرّ بلا جدول: الإنجليزي يسار، والبراند+العربي يمين (ثابت مهما كانت اللغة) */}
         <div className="flex items-start justify-between gap-3">
          {perfume.name_en ? (
            <h1 className="font-heading text-2xl font-bold leading-tight flex-1 min-w-0 break-words" style={{ color: "#9a7b1f" }}>{perfume.name_en}</h1>
          ) : (
            <div className="flex-1" />
          )}
          <div className="flex flex-col items-end gap-1.5 shrink-0 text-right max-w-[55%]">
            {perfume.brand_name && (
              <button
                onClick={async () => {
                  if (perfume.brand_id) {
                    navigate(`/brand?id=${perfume.brand_id}`);
                  } else if (perfume.brand_name) {
                    const matches = await apphost.entities.PerfumeBrand.filter({ name: perfume.brand_name });
                    if (matches?.[0]?.id) {
                      navigate(`/brand?id=${matches[0].id}`);
                    } else {
                      console.warn("Brand not found:", perfume.brand_name);
                    }
                  }
                }}
                className="text-[10px] text-primary font-body uppercase tracking-widest font-medium hover:underline cursor-pointer">
                {perfume.brand_name}
              </button>
            )}
            {perfume.name_ar && (
              <p className="font-heading text-lg font-semibold leading-tight" dir="rtl" style={{ color: "#9D174D" }}>{perfume.name_ar}</p>
            )}
            {!perfume.name_en && !perfume.name_ar && perfume.name && (
              <h1 className="font-heading text-2xl font-bold leading-tight" style={{ color: "#9a7b1f" }}>{perfume.name}</h1>
            )}
          </div>
        </div>
        {activeUserData?.list && <div className="flex justify-end -mt-2"><ListBadge list={activeUserData.list} /></div>}

        {/* عن العطر About — النوع/التركيز/السنة بعد الوصف */}
        {(perfume.about_en || perfume.about_ar || perfume.scent_class || perfume.concentration || perfume.release_year || perfume.discontinued) && (
          <div className="bg-card p-5 shadow-sm space-y-3" style={{ borderRadius: 0, border: "1px solid #C8A02E" }}>
            <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">About عن العطر</p>
            {perfume.about_en && (
              <p className="text-sm font-body text-foreground/90 leading-relaxed">{perfume.about_en}</p>
            )}
            {perfume.about_ar && (
              <p className="text-sm font-body text-foreground/90 leading-relaxed text-right" dir="rtl">{perfume.about_ar}</p>
            )}
            <div className="flex items-center gap-2.5 flex-wrap pt-1">
              {perfume.scent_class && (
                <span dir="rtl" className="text-xs font-body px-3 py-1" style={{ border: "1px solid #C8A02E", color: "#9a7b1f", borderRadius: 0, background: "transparent" }}>
                  {scentClassAr(perfume.scent_class)} {perfume.scent_class}
                </span>
              )}
              {perfume.concentration && (() => {
                const typeObj = PERFUME_TYPES.find(t => t.value === perfume.concentration);
                const label = typeObj ? `${typeObj.label_ar} ${perfume.concentration}` : perfume.concentration;
                return <span dir="rtl" className="text-xs font-body px-3 py-1" style={{ border: "1px solid #C8A02E", color: "#9a7b1f", borderRadius: 0, background: "transparent" }}>{label}</span>;
              })()}
              {perfume.release_year && (
                <span className="text-xs font-body px-3 py-1" style={{ border: "1px solid #C8A02E", color: "#9a7b1f", borderRadius: 0, background: "transparent" }}>{perfume.release_year}</span>
              )}
              {perfume.discontinued && <span className="px-3 py-1 text-xs font-body font-medium text-red-600 dark:text-red-400" style={{ border: "1px solid #ef9a9a", borderRadius: 0 }}>{isAr ? "متوقّف" : "Discontinued"}</span>}
            </div>
          </div>
        )}

        {/* بطاقة العطر الإضافية — بلا ليبل/إطار/اسم/براند، خلفية شفافة لتندمج مع الصفحة */}
        <div className="py-1">
          <div className="max-w-[170px] mx-auto">
            <div className="relative aspect-square bg-white overflow-hidden flex items-center justify-center">
              <AccordFlaconCard perfume={perfume} bestOfDecade={!!perfume.best_of_decade} className="w-full h-full" />
            </div>
          </div>
          {perfume.best_of_decade && decadeLabel(perfume.release_year) && (
            <p className="text-center text-[11px] font-body mt-1.5" style={{ color: "#3B6D11" }}>
              {isAr ? `أفضل العقد — ${decadeLabel(perfume.release_year)}` : `Best of decade — ${decadeLabel(perfume.release_year)}`}
            </p>
          )}
          {(() => {
            const dom = dominantAccord(perfume.accords);
            // الشارات على نفس سطر النوتة المسيطرة: منقطع (بنّي) · مجموعة (ذهبي) · نوتة مقيّدة (أحمر)
            const RESTRICTED_RE = /\b(?:grey ambergris|white ambergris|ambergris|benzyl benzoate|cinnamaldehyde|civet absolute|civettone|civetone|civet|coumarin|deer musk|eugenol|indian sandalwood|lilial|lyral|peru balsam|pine tar)\b/i;
            const noteTxt = `${perfume.top_notes || ""} ${perfume.heart_notes || ""} ${perfume.base_notes || ""}`;
            const restricted = RESTRICTED_RE.test(noteTxt);
            const discontinued = perfume.discontinued === true || perfume.discontinued === "true" || perfume.discontinued === 1;
            const inCollection = !!(perfume.collection && String(perfume.collection).trim());
            const sq = (color, title) => <span key={title} title={title} className="inline-block w-2.5 h-2.5 flex-shrink-0" style={{ background: color }} />;
            if (!dom && !restricted && !discontinued && !inCollection) return null;
            return (
              <div className="flex items-center justify-center gap-2 mt-1 flex-wrap" dir={isAr ? "rtl" : "ltr"}>
                {restricted && sq("#dc2626", isAr ? "نوتة مقيّدة" : "Restricted note")}
                {discontinued && sq("#8a5a2b", isAr ? "منقطع" : "Discontinued")}
                {inCollection && sq("#16a34a", isAr ? "ضمن مجموعة" : "In a collection")}
                {dom && (
                  <>
                    <span className="inline-block w-2.5 h-2.5 flex-shrink-0" style={{ background: dom.bar }} />
                    <span className="text-xs font-body font-semibold text-foreground/80">{String(dom.en || "").toUpperCase()} {dom.ar}</span>
                  </>
                )}
              </div>
            );
          })()}
        </div>

        {/* بطاقة العطر — رأي الجمهور المستورد */}
        <PerfumeCardBox perfume={perfume} />

        {/* Odor Family — العائلة العطرية */}
        {perfume.accords ? (
          <AccordBars accords={perfume.accords} />
        ) : perfume.odor_family && (
          <div className="bg-white rounded-none border border-[#C8A02E] px-5 py-4 shadow-sm">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest ml-0 mr-2">العائلة العطرية Odor Family</span>
              {perfume.odor_family.split(",").map(f => f.trim()).filter(Boolean).map(f => (
                <Link
                  key={f}
                  to={`/at?name=${encodeURIComponent(f)}`}
                  className="inline-flex items-center gap-1.5 border px-3 py-1 rounded-none text-xs font-body font-medium text-foreground/80 uppercase transition-opacity hover:opacity-70"
                  style={accordChipStyle(f)}
                  title={`@${f}`}
                >
                  <span className="w-2 h-2 rounded-none flex-shrink-0" style={{ background: accordColor(f) }} />
                  {f}
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Health indicator — مؤشر الصحة (يُولَّد تلقائياً من نوتات العطر) */}
        {(() => {
          const hLabels = perfumeLabels(perfume);
          const { groups } = analyzePerfume(perfume);
          const famCount = groups.length;
          const heavy = /parfum|extrait|مركّز/i.test(`${perfume.concentration || ""} ${perfume.type || ""}`);
          const score = famCount + (heavy ? 1 : 0);
          let level;
          if (famCount === 0) level = { ar: "مناسب للحسّاسين", en: "Sensitive-friendly", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
          else if (score <= 2) level = { ar: "منخفض", en: "Low", bg: "#EAF3DE", fg: "#3B6D11", dot: "#639922" };
          else if (score <= 4) level = { ar: "متوسط", en: "Medium", bg: "#FAEEDA", fg: "#854F0B", dot: "#BA7517" };
          else level = { ar: "مرتفع", en: "High", bg: "#FCEBEB", fg: "#791F1F", dot: "#E24B4A" };
          const countFor = (m) => (hLabels.find((l) => l.mech === m)?.groups.length) || 0;
          const allergyLabel = hLabels.find((l) => l.mech === "allergy");
          const squares = (n) => (
            <span className="inline-flex gap-1">
              {[0, 1, 2, 3].map((i) => (
                <span key={i} style={{ width: 9, height: 9, background: i < n ? "#C8A02E" : "transparent", border: "1px solid #C8A02E", display: "inline-block" }} />
              ))}
            </span>
          );
          return (
            <div className="bg-white rounded-none border border-[#C8A02E] px-5 py-4 shadow-sm space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest">مؤشر الصحة Health</span>
                <span className="inline-flex items-center gap-1.5 text-xs font-body font-medium px-2.5 py-1" style={{ background: level.bg, color: level.fg, borderRadius: 0 }}>
                  <span style={{ width: 9, height: 9, borderRadius: "50%", background: level.dot, display: "inline-block" }} />
                  {level.ar} {level.en}
                </span>
              </div>
              {famCount > 0 ? (
                <div className="space-y-1.5">
                  {["neuro", "sinus", "allergy"].map((m) => (
                    <div key={m} className="flex items-center justify-between">
                      <span className="text-[13px] font-body text-foreground">{MECH[m].emoji} {MECH[m].ar} <span className="text-muted-foreground">{MECH[m].en}</span></span>
                      {squares(Math.min(countFor(m), 4))}
                    </div>
                  ))}
                  {allergyLabel && (
                    <p className="text-xs font-body pt-1 border-t border-border/40">
                      <span className="text-muted-foreground">محسِّسات معروفة Known sensitisers ({allergyLabel.groups.length}): </span>
                      <span className="text-foreground/80">{allergyLabel.groups.map((g) => `${g.ar} ${g.en}`).join(" - ")}</span>
                    </p>
                  )}
                </div>
              ) : (
                <p className="text-xs text-muted-foreground font-body">لا وسوم خطر بارزة من نوتاته No prominent risk labels from its notes</p>
              )}
            </div>
          );
        })()}

        {/* Perfume Occasions — أموجي مع نص بلا إطارات */}
         {perfume.occasions && (
          <div className="px-5 py-4" style={{ borderRadius: 0 }}>
            <p className="text-[10px] font-body font-semibold text-muted-foreground uppercase tracking-widest mb-2">Best For مناسبات العطر</p>
            <div dir="rtl" className="flex flex-wrap gap-x-5 gap-y-1.5 text-sm font-body text-foreground/90">
              {perfume.occasions.split(",").map(o => o.trim()).filter(Boolean).map(o => {
                const occasionLabels = { 
                  daylight: "☀️ Daylight نهار", 
                  evening: "🌙 Evening مساء", 
                  wedding: "💍 Wedding زفاف", 
                  celebration: "🎉 Celebration احتفال", 
                  relax: "😌 Relax استرخاء", 
                  work: "💼 Work عمل", 
                  sport: "⚽ Sport رياضة", 
                  casual: "👕 Casual عادي", 
                  very_special: "✨ Very Special خاص جداً" 
                };
                return (
                  <span key={o}>{occasionLabels[o] || o}</span>
                );
              })}
            </div>
          </div>
        )}

        {/* Fragrance Notes — grid with images */}
        <FragranceNotesGrid perfume={perfume} isAr={isAr} />

        {/* العطّارون وعطور مشابهة معاً في المقدمة — لكلٍّ مساحته */}
        <PerfumersSection perfume={perfume} />
        <SimilarPerfumes perfume={perfume} isAr={isAr} />

        {/* Personal Section — per person — NOSE — خلفية لون خفيفة لكل شخص */}
        <div className="rounded-none border border-[#C8A02E] p-5 shadow-sm space-y-5 mt-8" style={{ background: activePerson === "person2" ? "#F5F3FB" : "#FBF6E6" }}>
          <div className="flex items-center gap-2.5 flex-wrap pb-2 border-b border-[#EADFB4]">
            <span className="font-heading font-bold text-base tracking-wider">{isAr ? "الأنف" : "NOSE"}</span>
            <button
              onClick={() => { setActivePerson("person1"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person1" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person1}
            </button>
            <button
              onClick={() => { setActivePerson("person2"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person2" ? "text-violet-500" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person2}
            </button>
          </div>

          {/* Impressions — before rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "إعجاب" : "Like"}</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: "great", emoji: "😍", label: "Great" },
                { value: "neutral", emoji: "😐", label: "Neutral" },
                { value: "not_great", emoji: "😕", label: "Not Great" },
              ].map(({ value, emoji, label }) => {
                const active = activeUserData?.impression === value;
                return (
                  <button
                    key={value}
                    onClick={() => upsertUserData.mutate({ person: activePerson, field: "impression", value: active ? null : value })}
                    className={`flex flex-col items-center gap-1.5 py-3 text-xs font-body transition-all ${active ? "font-bold text-primary" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className="text-xl">{emoji}</span>
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick reactions — stored in UserPerfume.list */}
          <div className="flex gap-2">
            {[
              { value: "favorite", emoji: "❤️", label: "Fav",     activeColor: "text-rose-500" },
              { value: "recommend", emoji: "👍", label: "Like",    activeColor: "text-amber-600" },
              { value: "dislike",  emoji: "👎", label: "Dislike",  activeColor: "text-slate-600" },
            ].map(({ value, emoji, label, activeColor }) => {
              const active = activeUserData?.list === value;
              return (
                <button
                  key={value}
                  onClick={() => upsertUserData.mutate({ person: activePerson, field: "list", value: active ? "none" : value })}
                  className={`flex-1 flex flex-col items-center gap-1 py-2.5 text-xs font-body transition-all ${active ? `font-bold ${activeColor}` : "text-muted-foreground hover:text-foreground"}`}
                >
                  <span className="text-lg">{emoji}</span>
                  <span>{label}</span>
                </button>
              );
            })}
          </div>

          {/* Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "التقييم" : "Rating"}</p>
            <StarRating
              rating={activeUserData?.rating || 0}
              onChange={(rating) => upsertUserData.mutate({ person: activePerson, field: "rating", value: rating })}
              size="lg"
            />
          </div>

          {/* === Detailed rating: scent · longevity · sillage · bottle === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "تقييم تفصيلي" : "Detailed Rating"}</p>
            <div className="space-y-2">
              {[
                { field: "r_scent",     ar: "الرائحة", en: "Scent" },
                { field: "r_longevity", ar: "الثبات",  en: "Longevity" },
                { field: "r_sillage",   ar: "الفوحان", en: "Sillage" },
                { field: "r_bottle",    ar: "الزجاجة", en: "Bottle" },
              ].map(({ field, ar, en }) => (
                <div key={field} className="flex items-center justify-between gap-2 py-1.5 px-1">
                  <span className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wide">{isAr ? ar : en}</span>
                  <StarRating rating={activeUserData?.[field] || 0} onChange={(v) => upsertUserData.mutate({ person: activePerson, field, value: v })} size="sm" />
                </div>
              ))}
            </div>
          </div>

          {/* === Recommend to others === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "ترشّح العطر للآخرين؟" : "Recommend to others?"}</p>
            <div className="grid grid-cols-2 gap-2">
              {[
                { value: "no",    emoji: "🚫", ar: "لا",           en: "No",           activeColor: "text-slate-600" },
                { value: "women", emoji: "🌸", ar: "نعم — نساء",   en: "Yes — Women",  activeColor: "text-rose-500" },
                { value: "men",   emoji: "🔷", ar: "نعم — رجال",   en: "Yes — Men",    activeColor: "text-sky-600" },
                { value: "any",   emoji: "👥", ar: "نعم — للجميع", en: "Yes — Anyone", activeColor: "text-amber-600" },
              ].map(({ value, emoji, ar, en, activeColor }) => {
                const active = activeUserData?.recommend_to === value;
                return (
                  <button
                    key={value}
                    onClick={() => upsertUserData.mutate({ person: activePerson, field: "recommend_to", value: active ? null : value })}
                    className={`flex items-center justify-center gap-1.5 py-2.5 text-xs font-body transition-all ${active ? `font-bold ${activeColor}` : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className="text-base">{emoji}</span>
                    <span>{isAr ? ar : en}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* === Note-phase impressions: top · heart · base === */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "انطباع المراحل" : "Note Phases"}</p>
            <div className="space-y-2">
              {[
                { field: "note_top",   ar: "مقدمة", en: "Top" },
                { field: "note_heart", ar: "قلب",      en: "Heart" },
                { field: "note_base",  ar: "أساس",     en: "Base" },
              ].map(({ field, ar, en }) => {
                const v = activeUserData?.[field];
                return (
                  <div key={field} className="flex items-center justify-between gap-2 py-1.5 px-1">
                    <span className="text-xs font-body font-medium text-muted-foreground">{isAr ? ar : en}</span>
                    <div className="flex gap-2">
                      <button onClick={() => upsertUserData.mutate({ person: activePerson, field, value: v === "like" ? null : "like" })} className={`w-9 h-8 rounded-none text-sm transition-all ${v === "like" ? "bg-amber-100 shadow-sm" : "opacity-50 hover:opacity-100"}`}>👍</button>
                      <button onClick={() => upsertUserData.mutate({ person: activePerson, field, value: v === "dislike" ? null : "dislike" })} className={`w-9 h-8 rounded-none text-sm transition-all ${v === "dislike" ? "bg-slate-100 shadow-sm" : "opacity-50 hover:opacity-100"}`}>👎</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Other Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "انطباع الآخرين" : "Others' Impression"}</p>
            <div className="grid grid-cols-4 gap-2">
              {[
                { value: "love_it", emoji: "🥰", label: "Love it" },
                { value: "like_it", emoji: "😍", label: "Like it" },
                { value: "neutral", emoji: "😐", label: "Neutral" },
                { value: "hate_it", emoji: "😠", label: "Hate it" },
              ].map(({ value, emoji, label }) => {
                const active = activeUserData?.other_rating === value;
                return (
                  <button
                    key={value}
                    onClick={() => upsertUserData.mutate({ person: activePerson, field: "other_rating", value: active ? null : value })}
                    className={`flex flex-col items-center gap-1.5 py-2.5 rounded-none text-[10px] font-body font-medium transition-all ${active ? "bg-primary/10 shadow-sm text-primary" : "text-muted-foreground hover:text-foreground"}`}
                  >
                    <span className="text-xl">{emoji}</span>
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Occasions — unlimited multi-select. Stored as CSV in `occasions`;
              falls back to legacy occasion/occasion2 fields for older records. */}
           <div className="space-y-2">
             {(() => {
               const parseOccasions = (ud) => {
                 if (!ud) return [];
                 if (ud.occasions) return ud.occasions.split(",").map((s) => s.trim()).filter(Boolean);
                 const arr = [];
                 if (ud.occasion && ud.occasion !== "none") arr.push(ud.occasion);
                 if (ud.occasion2 && ud.occasion2 !== "none") arr.push(ud.occasion2);
                 return arr;
               };
               const selected = parseOccasions(activeUserData);
               const OCCASIONS = [
                 { value: "daylight", emoji: "☀️", label: "Daylight" },
                 { value: "evening", emoji: "🌙", label: "Evening" },
                 { value: "wedding", emoji: "💍", label: "Wedding" },
                 { value: "celebration", emoji: "🎉", label: "Celebration" },
                 { value: "relax", emoji: "😌", label: "Relax" },
                 { value: "work", emoji: "💼", label: "Work" },
                 { value: "sport", emoji: "⚽", label: "Sport" },
                 { value: "casual", emoji: "👕", label: "Casual" },
                 { value: "very_special", emoji: "✨", label: "Very Special" },
               ];
               return (
                 <>
                   <div className="flex items-center gap-2">
                     <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "أفضل المناسبات" : "Best Occasions"}</p>
                     <span className="text-[10px] text-muted-foreground font-body">({selected.length})</span>
                   </div>
                   <div className="grid grid-cols-2 gap-2">
                     {OCCASIONS.map(({ value, emoji, label }) => {
                       const active = selected.includes(value);
                       return (
                         <button
                           key={value}
                           onClick={() => {
                             const next = active ? selected.filter((v) => v !== value) : [...selected, value];
                             upsertUserData.mutate({ person: activePerson, field: "occasions", value: next.join(",") });
                           }}
                           className={`flex flex-col items-center gap-1 py-2 rounded-none border text-[10px] font-body font-medium transition-all ${active ? "bg-primary/10 border-primary shadow-sm text-primary" : "bg-secondary/40 border-border/50 text-muted-foreground hover:text-foreground"}`}
                         >
                           <span className="text-lg">{emoji}</span>
                           <span>{label}</span>
                         </button>
                       );
                     })}
                   </div>
                 </>
               );
             })()}
           </div>

          {/* Health Ratings */}
          <HealthRatingSection
            activeUserData={activeUserData}
            activePerson={activePerson}
            onUpdate={(field, value) => upsertUserData.mutate({ person: activePerson, field, value })}
          />

          {/* Related Perfumes — user-added (shown FIRST) */}
          {perfume.related_perfume_ids && perfume.related_perfume_ids.trim() && (
            <div className="bg-transparent rounded-none space-y-2">
              <h3 className="font-heading font-semibold text-sm px-1">{isAr ? "تذكرني في العطور  عطور مقاربة" : "Remind Me Of  Similar Fragrances"}</h3>

              <div className="space-y-2">
                {perfume.related_perfume_ids.split(",").map((relId, idx) => {
                  const relName = perfume.related_perfume_names?.split(",")[idx]?.trim();
                  const trimmedRelId = relId.trim();
                  if (!trimmedRelId || !relName) return null;

                  const relPerfume = allPerfumes.find(p => String(p.id) === String(trimmedRelId));

                  return (
                    <Link
                      key={trimmedRelId}
                      to={`/perfume?id=${trimmedRelId}`}
                      className="flex items-center gap-3 group"
                    >
                      <div className="w-16 h-16 rounded-none border-2 border-amber-500/70 bg-white/80 flex items-center justify-center overflow-hidden shadow-sm group-hover:shadow-md transition-all flex-shrink-0">
                        {relPerfume?.image_url ? (
                          <img src={relPerfume.image_url} alt={relName} className="w-full h-full object-contain p-0.5" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-2xl opacity-20">🧴</div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-body font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-1">
                          {relName}
                        </p>
                        {relPerfume?.brand_name && (
                          <p className="text-[9px] text-muted-foreground font-body line-clamp-1 mb-0.5">
                            {relPerfume.brand_name}
                          </p>
                        )}
                        {relPerfume?.top_notes || relPerfume?.heart_notes || relPerfume?.base_notes ? (
                          <div className="flex gap-1 flex-wrap">
                            {[relPerfume?.top_notes, relPerfume?.heart_notes, relPerfume?.base_notes]
                              .filter(Boolean)
                              .flatMap((notes, idx) => 
                                notes.split(",").slice(0, 2).map(n => n.trim()).filter(Boolean).map((n, i) => (
                                  <span key={`${idx}-${i}`} className="text-[8px] text-amber-700 dark:text-amber-400 rounded-none font-body">
                                    {n}
                                  </span>
                                ))
                              )}
                          </div>
                        ) : null}
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          )}

          {/* Similar Perfumes منقولة للمقدمة بجانب العطّارين */}

          {/* Reverse Related — Linked By / Connected With */}
          {allPerfumes.some(p => p.related_perfume_ids?.includes(id)) && (
            <div className="bg-card rounded-none border border-[#C8A02E] p-5 shadow-sm space-y-3">
              <div className="flex items-center gap-2 mb-2">
                <span className="text-base">🔗</span>
                <h3 className="font-heading font-semibold text-sm">{isAr ? "تم ربطه مع  عطور ترتبط به" : "Linked By  Connected With"}</h3>
              </div>

              <div className="space-y-2">
                {allPerfumes.filter(p => p.related_perfume_ids?.split(",").some(rid => rid.trim() === id)).map((relPerfume) => (
                  <Link
                    key={relPerfume.id}
                    to={`/perfume?id=${relPerfume.id}`}
                    className="flex items-center gap-3 p-2.5 rounded-none border border-blue-200/50 bg-white/50 dark:bg-slate-950/30 hover:border-blue-300 transition-colors group"
                  >
                    <span className="text-lg">←</span>
                    <div className="flex-1 min-w-0">
                      <p className="font-heading font-semibold text-xs group-hover:opacity-70 transition-opacity">
                        {relPerfume.name_en || relPerfume.name_ar}
                      </p>
                    </div>
                    <span className="text-blue-600/40 dark:text-blue-400/40 text-xs">←</span>
                  </Link>
                ))}
              </div>
            </div>
          )}

          {/* Lists — multi-select chips */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "القوائم" : "Lists"}</p>
            <ListMultiSelect activeUserData={activeUserData} activePerson={activePerson} upsertUserData={upsertUserData} />
          </div>

          {/* Notes, Category, ML, Price */}
          <div className="space-y-3">
            <div className="grid grid-cols-3 gap-2">
              {perfume.category && (
                <div className="bg-secondary/40 rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الفئة" : "Category"}</p>
                  <p className="text-xs font-body font-medium">{perfume.category}</p>
                </div>
              )}
              {perfume.ml && (
                <div className="bg-secondary/40 rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الحجم" : "Volume"}</p>
                  <p className="text-xs font-body font-medium">{perfume.ml}ml</p>
                </div>
              )}
              {perfume.price && (
                <div className="bg-secondary/40 rounded-none p-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "السعر" : "Price"}</p>
                  <p className="text-xs font-body font-medium">{formatPrice(perfume.price)}</p>
                </div>
              )}
            </div>

            {/* Personal Review — per-person (stored in UserPerfume.review) */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider font-bold">📝 {isAr ? "مراجعتك" : "Your Review"}</p>
                {!editNotes && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-7 text-xs"
                    onClick={() => {
                      setEditNotes(true);
                      setNotes(activeUserData?.review || "");
                    }}
                  >
                    {activeUserData?.review ? "✏️ Edit" : "✏️ Add"}
                  </Button>
                )}
              </div>

              {!editNotes && (
                <div className="rounded-none p-4 bg-secondary/40 border-2 border-border/40">
                  {activeUserData?.review ? (
                    <p className="text-sm font-body text-foreground/85 whitespace-pre-wrap leading-relaxed">{activeUserData.review}</p>
                  ) : (
                    <p className="text-xs italic text-muted-foreground">{isAr ? "لا مراجعة بعد" : "No review yet"}</p>
                  )}
                </div>
              )}
            </div>

            {/* Edit Review — saves to the active person's UserPerfume.review */}
            {editNotes && (
              <div className="rounded-none p-4 space-y-3 border-2 border-primary/40 bg-primary/5">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider font-bold">✏️ {isAr ? "اكتب مراجعتك" : "Write Your Review"}</p>
                <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} className="rounded-none font-body min-h-[100px]" placeholder={isAr ? "شارك خواطرك" : "Share your thoughts..."} />
                <div className="flex gap-2">
                  <Button size="sm" className="rounded-none font-body" onClick={() => { upsertUserData.mutate({ person: activePerson, field: "review", value: notes }); setEditNotes(false); }}>
                    {isAr ? "تم" : "Done"}
                  </Button>
                  <Button size="sm" variant="ghost" className="rounded-none font-body" onClick={() => { setNotes(activeUserData?.review || ""); setEditNotes(false); }}>{isAr ? "إلغاء" : "Cancel"}</Button>
                </div>
              </div>
            )}

            {/* Sample/Collection */}
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">Sample / Collection</p>
              <div className="bg-secondary/40 rounded-none p-3 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "الحجم الكلي" : "Total Volume"}</p>
                    <p className="text-sm font-body font-medium">{activeUserData?.sample_ml ? `${activeUserData.sample_ml}ml` : "—"}</p>
                  </div>
                  <div>
                    <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-0.5">{isAr ? "التكلفة الكلية" : "Total Cost"}</p>
                    <p className="text-sm font-body font-medium">{activeUserData?.sample_cost ? formatPrice(activeUserData.sample_cost) : "—"}</p>
                  </div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-none font-body text-xs h-9"
                  onClick={() => {
                    setEditSampleMl(true);
                    setSampleMl("");
                    setEditSampleCost(true);
                    setSampleCost("");
                    setPurchaseType("sample");
                  }}
                >
                  🛍️ I Bought
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-none font-body text-xs h-9 bg-pink-50 dark:bg-pink-950/30 text-pink-600 dark:text-pink-400 border-pink-200 dark:border-pink-800"
                  onClick={() => setWishDialogOpen(true)}
                >
                  💕 I Want To Buy
                </Button>
              </div>
              {editSampleMl && editSampleCost && (
                <div className="space-y-2 bg-accent/30 rounded-none p-3">
                  <div className="flex gap-2 mb-2">
                    <button
                      onClick={() => setPurchaseType("sample")}
                      className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${purchaseType === "sample" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
                    >
                      Sample
                    </button>
                    <button
                      onClick={() => setPurchaseType("bottle")}
                      className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${purchaseType === "bottle" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
                    >
                      Bottle
                    </button>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      type="number"
                      step="0.5"
                      placeholder="ML"
                      value={sampleMl}
                      onChange={(e) => setSampleMl(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-none border border-input bg-transparent text-xs font-body"
                    />
                    <input
                      type="number"
                      step="0.1"
                      placeholder={isAr ? "التكلفة" : "Cost"}
                      value={sampleCost}
                      onChange={(e) => setSampleCost(e.target.value)}
                      className="w-full px-2 py-1.5 rounded-none border border-input bg-transparent text-xs font-body"
                    />
                  </div>
                  <div className="space-y-1">
                    <p className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">Store (optional)</p>
                    <StoreSelector
                      value={selectedStore}
                      onChange={setSelectedStore}
                    />
                  </div>
                  {/* Who is buying indicator */}
                  <div className="flex items-center justify-center gap-2 py-1">
                    <span className="text-[10px] text-muted-foreground font-body uppercase tracking-widest">القائم بالشراء</span>
                    <button
                      onClick={() => setActivePerson("person1")}
                      className={`text-xs font-body font-bold rounded-none transition-all ${activePerson === "person1" ? " text-primary" : " text-muted-foreground"}`}
                    >
                      {names.person1}
                    </button>
                    <button
                      onClick={() => setActivePerson("person2")}
                      className={`text-xs font-body font-bold rounded-none transition-all ${activePerson === "person2" ? " text-violet-600" : " text-muted-foreground"}`}
                    >
                      {names.person2}
                    </button>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      className="flex-1 rounded-none font-body text-xs h-8"
                      onClick={() => {
                        const mlVal = parseFloat(sampleMl || 0);
                        const costVal = parseFloat(sampleCost || 0);
                        if (mlVal <= 0 || costVal <= 0) {
                          toast.error((isAr ? "أدخل مل و تكلفة صحيحة" : "Please enter valid ML and Cost"));
                          return;
                        }
                        const newMl = (parseFloat(activeUserData?.sample_ml || 0) + mlVal);
                        const newCost = (parseFloat(activeUserData?.sample_cost || 0) + costVal);

                        // Record the purchase everywhere (totals updated in onSuccess)
                        purchaseMutation.mutate({
                          perfume,
                          activePerson,
                          purchaseType,
                          mlVal,
                          costVal,
                          selectedStore,
                          stores,
                          activeUserData,
                        });
                        setEditSampleMl(false);
                        setEditSampleCost(false);
                        setSampleMl("");
                        setSampleCost("");
                        setSelectedStore("");
                      }}
                    >
                      Add {purchaseType === "sample" ? "Sample" : "Bottle"}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="flex-1 rounded-none font-body text-xs h-8"
                      onClick={() => {
                        setEditSampleMl(false);
                        setEditSampleCost(false);
                        setSampleMl("");
                        setSampleCost("");
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              )}
            </div>


          </div>

          </div>

          {/* Image Management — moved beside Edit in footer */}

          {/* تعديل العطر نُقل إلى فوتر الصفحة (بعد جدولة الارتداء) */}

          {/* صندوق التصدير الموحّد — صندوق ذهبي واحد بلا فواصل داخلية */}
          <div className="border border-[#C8A02E] p-2.5 space-y-2" style={{ borderRadius: 0 }}>
            <div className="flex items-stretch gap-2">
              <ExportReviewDialog 
                perfume={perfume} 
                wearLogs={wearLogs}
                activeUserData={activeUserData}
                activePerson={activePerson}
                userDataP1={userDataP1}
                userDataP2={userDataP2}
                names={names}
                purchaseRecords={purchaseRecords}
                allNoteRecords={allNoteRecords}
                allPerfumers={allPerfumers}
              />
              <EnhancedExportDialog
                perfume={perfume}
                userDataP1={userDataP1}
                userDataP2={userDataP2}
                names={names}
                allNoteRecords={allNoteRecords}
              />
            </div>
            <div className="flex items-stretch gap-2">
              <LuxuryCardExport
                kind="perfume"
                perfume={perfume}
                userData={activeUserData}
                personName={activePerson === "person2" ? (names?.person2 || "B") : (names?.person1 || "A")}
                extra={{ wearCount: wearLogs.length }}
                trigger={<button className="flex-1 h-11 rounded-none font-body text-xs border border-[#C8A02E] text-[#7a6212] hover:bg-[#FBF6E6]">{isAr ? "تصدير بطاقة" : "Export Card"}</button>}
              />
              <button
                onClick={() => navigate("/cast-away")}
                className="flex-1 h-11 rounded-none font-body text-xs border border-[#C8A02E] text-[#7a6212] hover:bg-[#FBF6E6]"
              >
                {isAr ? "كاست أواي" : "Cast Away"}
              </button>
            </div>
            <div className="flex items-center justify-center gap-4 pt-1">
              {/* أيقونة عطر — أضف/أزل من مجموعتي (تتغيّر اللون: أخضر في المجموعة، أزرق خارجها) */}
              <button
                onClick={() => {
                  if (activeUserData) { removeFromCollection.mutate(activePerson); }
                  else { upsertUserData.mutate({ person: activePerson, field: "list", value: "own" }); }
                }}
                disabled={upsertUserData.isPending || removeFromCollection.isPending}
                title={activeUserData ? (isAr ? "في مجموعتي" : "In my collection") : (isAr ? "أضف لمجموعتي" : "Add to my collection")}
                aria-label={activeUserData ? "In my collection" : "Add to my collection"}
                className="flex items-center justify-center w-8 h-8 bg-transparent transition-opacity hover:opacity-70"
                style={{ color: activeUserData ? "#C8A02E" : "#1450c8" }}
              >
                <SprayCan className="w-[18px] h-[18px]" strokeWidth={1.75} fill={activeUserData ? "#C8A02E22" : "none"} />
              </button>
              <BookmarkButton descriptor={{
                item_type: "perfume",
                item_id: id,
                title_en: perfume.name_en || perfume.name || "",
                title_ar: perfume.name_ar || "",
                subtitle: perfume.brand_name || "",
                path: `/perfume?id=${id}`,
              }} />
              <PinButton kind="perfume" id={id} />
              <CopyMenu
                entity="perfume"
                dbText={perfumeDbText(perfume)}
                fullText={perfumeFullText(perfume, {
                  activeUserData,
                  wearLogs,
                  purchases: purchaseRecords,
                  personName: names?.[activePerson] || "",
                })}
              />
            </div>
          </div>




          {/* Remove from MY collection (not delete from app DB) */}
          {activeUserData && (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive font-body gap-1.5 text-xs w-full">
                  <Trash2 className="w-3.5 h-3.5" /> Remove from {activePerson === "person1" ? names.person1 : names.person2}'s collection
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle className="font-heading">{isAr ? "إزالة من المجموعة؟" : "Remove from collection?"}</AlertDialogTitle>
                  <AlertDialogDescription className="font-body">
                    This removes your personal data (rating, list, notes) for this perfume. The perfume stays in the app database and other person's data is unaffected.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel className="font-body">{isAr ? "إلغاء" : "Cancel"}</AlertDialogCancel>
                  <AlertDialogAction onClick={() => removeFromCollection.mutate(activePerson)} className="bg-destructive font-body">{isAr ? "إزالة" : "Remove"}</AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            )}

            {/* Purchase History */}
        <div className="bg-card rounded-none border border-[#C8A02E] p-5 shadow-sm space-y-3">
          <div>
            <h2 className="font-heading font-semibold">{isAr ? "سجل الشراء" : "Purchase History"}</h2>
            <p className="text-xs text-muted-foreground font-body">{purchaseRecords.length} purchase{purchaseRecords.length !== 1 ? "es" : ""}</p>
          </div>
          {purchaseRecords.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body">{isAr ? "لا مشتريات مسجّلة بعد" : "No purchases recorded yet."}</p>
          ) : (
            <div className="space-y-2">
              {purchaseRecords.map((record) => (
                <div key={record.id} className="flex flex-col gap-2 bg-secondary/40 rounded-none p-3 hover:bg-secondary/60 transition-colors">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[9px] font-bold rounded-none ${record.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                        {record.person === "person2" ? names.person2 : names.person1}
                      </span>
                      <span className="text-[10px] font-body font-bold rounded-none text-foreground/70">
                        {record.type === "sample" ? "Sample" : "Bottle"}
                      </span>
                      <span className="text-xs text-muted-foreground font-body">{record.purchase_date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p className="text-xs font-body font-medium">{record.ml}ml</p>
                        <p className="text-[10px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                      </div>
                      <EditPurchaseDialog
                        record={record}
                        perfumeId={id}
                        activePerson={record.person}
                        stores={stores}
                        onSuccess={() => queryClient.invalidateQueries({ queryKey: ["purchase-records", id] })}
                      />
                    </div>
                  </div>
                  {record.store_name && (
                    <button
                      onClick={() => navigate(`/store?id=${record.store_id}`)}
                      className="text-xs font-body text-primary hover:underline w-fit"
                    >
                      🏪 {record.store_name}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Wear History */}
        <div className="bg-card rounded-none border border-[#C8A02E] p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "سجل الارتداء" : "Wear History"}</h2>
              <p className="text-xs text-muted-foreground font-body">{wearLogs.length} time{wearLogs.length !== 1 ? "s" : ""} worn</p>
            </div>
            <Button size="sm" className="rounded-none font-body gap-1.5 h-9" onClick={() => setWearDialogOpen(true)}>
              <CalendarDays className="w-3.5 h-3.5" /> Log
            </Button>
          </div>
          {wearLogs.slice(0, 5).map((l) => {
            const moodEmojis = { amazing: "😍", happy: "😊", calm: "😌", confident: "😎", romantic: "💕", sexy: "🔥", sad: "😔", energetic: "⚡", thoughtful: "🤔", relaxing: "😴", unknown: "🤷", neutral: "😑" };
            return (
            <div key={l.id} className="flex items-center gap-2 text-xs font-body">
              <span className={`text-[9px] font-bold rounded-none ${l.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                {l.person === "person2" ? names.person2 : names.person1}
              </span>
              <span className="text-muted-foreground">{l.date}</span>
              {l.mood && <span className="text-base">{moodEmojis[l.mood]}</span>}
              {l.note && <span className="text-foreground/70 truncate">— {l.note}</span>}
            </div>
          );
          })}
          {wearLogs.length === 0 && (
            <p className="text-xs text-muted-foreground font-body">{isAr ? "لا سجلات ارتداء بعد" : "No wear logs yet."}</p>
          )}
        </div>

        {/* Wear Schedule — التخطيط المستقبلي (بعد سجل الارتداء الماضي) */}
        <WearScheduleSection perfume={perfume} activePerson={activePerson} names={names} />

        {/* فوتر الصفحة — تعديل العطر منفصل تماماً */}
        <div className="mt-6 pt-4" style={{ borderTop: "1px solid #C8A02E" }}>
          <div className="grid grid-cols-2 gap-2 items-stretch">
            <Dialog>
                        <DialogTrigger asChild>
                          <Button className="w-full h-9 rounded-none font-body gap-1.5 text-[11px]" style={{ background: "#FBE4EC", color: "#9D2C5B" }}>
                            <Camera className="w-4 h-4" /> {perfume.image_url ? "Change" : "Add"} Perfume Image
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-sm rounded-none">
                          <DialogHeader>
                            <DialogTitle className="font-heading">{perfume.image_url ? "Change" : "Add"} Perfume Image</DialogTitle>
                          </DialogHeader>
                          <div className="space-y-3">
                            <input
                              type="file"
                              accept="image/*"
                              onChange={async (e) => {
                                const file = e.target.files?.[0];
                                if (!file) return;
                                
                                // Validate file type
                                const allowedTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
                                if (!allowedTypes.includes(file.type)) {
                                  toast.error('Only images (JPG, PNG, WebP, GIF) and PDF files are allowed');
                                  return;
                                }
                                
                                // Validate file size (max 5MB)
                                const maxSize = 5 * 1024 * 1024;
                                if (file.size > maxSize) {
                                  toast.error('File size must be less than 5MB');
                                  return;
                                }
                                
                                try {
                                  const { file_url } = await apphost.integrations.Core.UploadFile({ file });
                                  await apphost.entities.Perfume.update(id, { image_url: file_url });
                                  queryClient.invalidateQueries({ queryKey: ["perfume", id] });
                                  toast.success((isAr ? "حُدّثت الصورة" : "Image updated"));
                                } catch (error) {
                                  toast.error((isAr ? "فشل الرفع" : "Upload failed:") + error.message);
                                }
                              }}
                              className="w-full px-3 py-2 border border-input rounded-none text-sm font-body"
                            />
                          </div>
                        </DialogContent>
                      </Dialog>
            <EditPerfumeDialog perfume={perfume} allPerfumes={allPerfumes} allMainNotes={allMainNotes} />
          </div>
        </div>

        {/* Wishlist Dialog */}
        <Dialog open={wishDialogOpen} onOpenChange={setWishDialogOpen}>
          <DialogContent className="max-w-sm rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading">💕 {isAr ? "أرغب بالشراء" : "I Want To Buy"}</DialogTitle>
            </DialogHeader>
          <div className="space-y-3">
            <div className="bg-secondary/40 rounded-none p-3">
              <p className="text-xs font-body font-bold">{perfume.name_en || perfume.name_ar || ""}</p>
              <p className="text-[10px] text-muted-foreground">{perfume.brand_name}</p>
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "السعر المتوقع" : "Estimated Price"}</p>
              <Input
                type="number"
                step="0.1"
                placeholder="0.00"
                value={wishPrice}
                onChange={(e) => setWishPrice(e.target.value)}
                className="rounded-none h-9 text-xs"
              />
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "الأولوية" : "Priority"}</p>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { val: "high", emoji: "🔴", label: "High" },
                  { val: "medium", emoji: "🟡", label: "Medium" },
                  { val: "low", emoji: "🔵", label: "Low" },
                ].map(({ val, emoji, label }) => (
                  <button
                    key={val}
                    onClick={() => setWishPriority(val)}
                    className={`py-1.5 rounded-none text-xs font-body font-medium transition-all ${
                      wishPriority === val
                        ? "bg-primary text-primary-foreground shadow"
                        : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {emoji} {label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <p className="text-xs font-body font-medium mb-1">{isAr ? "ملاحظات" : "Notes"}</p>
              <Textarea
                value={wishNotes}
                onChange={(e) => setWishNotes(e.target.value)}
                placeholder={isAr ? "مثلاً: أفضل تركيب، رائحة دافئة..." : "E.g., love the scent, warm fragrance..."}
                className="rounded-none text-xs min-h-[60px] resize-none font-body"
              />
            </div>

            <Button
              className="w-full h-10 rounded-none font-body"
              onClick={() => addToWishlist.mutate()}
              disabled={addToWishlist.isPending}
            >
              {addToWishlist.isPending ? (isAr ? "جاري..." : "Adding...") : (isAr ? "💕 أرغب بالشراء" : "💕 I Want To Buy")}
            </Button>
          </div>
        </DialogContent>
        </Dialog>

        {/* Log wear dialog */}
        <Dialog open={wearDialogOpen} onOpenChange={setWearDialogOpen}>
          <DialogContent className="max-w-sm rounded-none">
            <DialogHeader>
              <DialogTitle className="font-heading text-base">تسجيل ارتداء  Log Wear</DialogTitle>
            </DialogHeader>
            <div className="space-y-3">
              <p className="text-sm font-body text-muted-foreground">
                Logging <span className="font-semibold text-foreground">{perfume?.name}</span>
              </p>
              <div className="flex gap-2">
                <button onClick={() => setWearPerson("person1")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${wearPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                  <User className="w-3.5 h-3.5" /> {names.person1}
                </button>
                <button onClick={() => setWearPerson("person2")}
                  className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${wearPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                  <User className="w-3.5 h-3.5" /> {names.person2}
                </button>
              </div>
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "المزاج" : "Mood"}</p>
                <div className="grid grid-cols-5 gap-2">
                  {[
                    { value: "amazing", emoji: "😍", label: "Amazing" },
                    { value: "happy", emoji: "😊", label: "Happy" },
                    { value: "calm", emoji: "😌", label: "Calm" },
                    { value: "confident", emoji: "😎", label: "Confident" },
                    { value: "romantic", emoji: "💕", label: "Romantic" },
                    { value: "sexy", emoji: "🔥", label: "Sexy" },
                    { value: "sad", emoji: "😔", label: "Sad" },
                    { value: "energetic", emoji: "⚡", label: "Energetic" },
                    { value: "thoughtful", emoji: "🤔", label: "Thoughtful" },
                    { value: "relaxing", emoji: "😴", label: "Relaxing" },
                    { value: "unknown", emoji: "🤷", label: "I don't Know" },
                    { value: "neutral", emoji: "😑", label: "I don't Care" },
                  ].map(({ value, emoji, label }) => (
                    <button
                      key={value}
                      onClick={() => setWearMood(wearMood === value ? "" : value)}
                      className={`flex flex-col items-center gap-1 py-2 rounded-none border text-[10px] font-body font-medium transition-all ${wearMood === value ? "bg-primary/10 border-primary shadow-sm" : "bg-secondary/40 border-border/50 hover:border-primary/30"}`}
                    >
                      <span className="text-lg">{emoji}</span>
                      <span className="text-[9px]">{label}</span>
                    </button>
                  ))}
                </div>
              </div>
              <Textarea
                value={wearNote}
                onChange={(e) => setWearNote(e.target.value)}
                placeholder={isAr ? "ملاحظة اختياري" : "Optional note..."}
                className="rounded-none font-body text-sm min-h-[64px] resize-none"
              />
              <Button
                className="w-full h-10 rounded-none font-body"
                onClick={() => wearMutation.mutate({
                    date: format(new Date(), "yyyy-MM-dd"),
                    perfume_id: id,
                    perfume_name: perfume.name_en || perfume.name_ar || perfume.name || "",
                    brand_name: perfume.brand_name || "",
                    person: wearPerson,
                    mood: wearMood || null,
                    note: wearNote,
                  })}
                disabled={wearMutation.isPending}
              >
                {wearMutation.isPending ? "Saving..." : `Log for ${wearPerson === "person2" ? names.person2 : names.person1}`}
              </Button>
            </div>
          </DialogContent>
          </Dialog>

          {/* Delete dialog removed - now in EditPerfumeDialog */}
          </div>
          </div>
          );
          }

function InfoChip({ icon: Icon, label }) {
  return (
    <div className="flex items-center gap-1.5 bg-secondary/60 rounded-none px-3 py-1">
      <Icon className="w-3.5 h-3.5 text-primary/70" />
      <span className="text-xs font-body font-medium">{label}</span>
    </div>
  );
}

function ListMultiSelect({ activeUserData, activePerson, upsertUserData }) {
  const { isAr } = useLang();
  const { data: allLists = [], refetch } = useQuery({
    queryKey: ["custom-lists"],
    queryFn: () => apphost.entities.CustomList.list("name"),
  });

  const qc = useQueryClient();
  const perfumeId = new URLSearchParams(window.location.search).get("id");

  // Separate system lists from user custom lists
  const SYSTEM = ["📦 Own", "🛒 Wishlist"];
  const systemLists = allLists.filter(l => SYSTEM.includes(`${l.icon} ${l.name}`));
  const customLists = allLists.filter(l => !SYSTEM.includes(`${l.icon} ${l.name}`));

  const isInList = (list) => {
    if (!list.perfume_ids || !perfumeId) return false;
    return list.perfume_ids.split(",").map(id => id.trim()).includes(perfumeId);
  };

  const toggleList = (list) => {
    const ids = list.perfume_ids ? list.perfume_ids.split(",").map(id => id.trim()).filter(Boolean) : [];
    const inList = ids.includes(perfumeId);
    const newIds = inList ? ids.filter(id => id !== perfumeId) : [...ids, perfumeId];
    apphost.entities.CustomList.update(list.id, { perfume_ids: newIds.join(",") })
      .then(() => qc.invalidateQueries({ queryKey: ["custom-lists"] }));
  };

  const chipClass = (active) =>
    `flex items-center gap-1.5 rounded-none text-xs font-body font-medium transition-all ${active ? " text-primary " : " text-muted-foreground hover:text-foreground"}`;

  if (allLists.length === 0) {
    return <p className="text-xs text-muted-foreground font-body">{isAr ? "لا قوائم بعد أنشئها في صفحة القوائم" : "No lists yet. Create lists in the Lists page."}</p>;
  }

  return (
    <div className="flex flex-wrap gap-2">
      {systemLists.map((list) => (
        <button key={list.id} onClick={() => toggleList(list)} className={chipClass(isInList(list))}>
          <span>{list.icon || "📋"}</span> {list.name}
        </button>
      ))}
      {customLists.map((list) => (
        <button key={list.id} onClick={() => toggleList(list)} className={chipClass(isInList(list))}>
          <span>{list.icon || "📋"}</span> {list.name}
        </button>
      ))}
    </div>
  );
}

function NoteRow({ icon: Icon, label, value }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-8 h-8 rounded-none bg-secondary/60 flex items-center justify-center flex-shrink-0 mt-0.5">
        {Icon && <Icon className="w-4 h-4 text-primary/60" />}
      </div>
      <div>
        <p className="text-xs font-body font-medium text-muted-foreground uppercase tracking-wider">{label}</p>
        <p className="text-sm font-body">{value}</p>
      </div>
    </div>
  );
}