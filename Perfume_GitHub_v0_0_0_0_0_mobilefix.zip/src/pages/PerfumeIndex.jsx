import { useState, useEffect, useMemo, useCallback, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Search, X, Loader2 } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { apphost } from "@/api/apphostClient";
import { rankName } from "@/lib/sortName";

/**
 * PerfumeIndex — فهرس العطور A–Z فوق ~130k عطر، أوفلاين وبلا تجميد.
 * يعتمد فهرس 'sort_key' (rank + الاسم بحروف صغيرة) مع مؤشّر نطاق
 * (pageByIndexRange): يُقرأ حرفٌ/بادئة واحدة فقط صفحةً صفحة — لا تحميل للقاعدة كاملة.
 */

const LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").concat("#");
const PAGE = 50;

// قَصّ صفّي محدود بعدد المحارف؛ يستبدل التجاوز بنقطتين فقط (..) لا بثلاث.
function trimText(s, max) {
  const str = String(s || "");
  if (str.length <= max) return str;
  return str.slice(0, max).replace(/\s+$/, "") + "..";
}

// يبني حدود مفتاح الفرز للبادئة/الحرف المختار.
function boundsFor(query, letter) {
  const t = (query || "").trim().toLowerCase();
  if (t) {
    const prefix = String(rankName(t)) + t;       // نفس صياغة sort_key للبادئة
    return { lower: prefix, upper: prefix + "\uffff" };
  }
  if (letter === "all") return null;               // كل العطور بترتيب الفرز (sort_key) — بلا تصفية
  if (letter === "#") return { lower: "1" };       // كل ما ليس حرفاً إنجليزياً (أرقام/رموز/لغات أخرى)
  const prefix = "0" + letter.toLowerCase();        // حرف إنجليزي (rank 0)
  return { lower: prefix, upper: prefix + "\uffff" };
}

export default function PerfumeIndex() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const [letter, setLetter] = useState("all");
  const [query, setQuery] = useState("");
  const [items, setItems] = useState([]);
  const [total, setTotal] = useState(0);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lettersOpen, setLettersOpen] = useState(false); // شريط الحروف مطوي افتراضياً

  const offsetRef = useRef(0);
  const reqIdRef = useRef(0);

  const bounds = useMemo(() => boundsFor(query, letter), [query, letter]);

  const loadPage = useCallback(async (reset) => {
    const myReq = ++reqIdRef.current;
    if (reset) { setLoading(true); offsetRef.current = 0; }
    else setLoadingMore(true);
    try {
      // «الكل» (bounds فارغ): لا نعدّ كلّ الـ130 ألف قبل أوّل صفحة — نتركه ونشتقّ
      // «المزيد» من امتلاء الصفحة، والإجمالي يأتي لاحقاً بعدّ رخيص غير حاجب.
      const withTotal = reset && bounds != null;
      const { items: rows, total: tot } = await apphost.entities.Perfume.pageByIndexRange(
        "sort_key", bounds, offsetRef.current, PAGE, "next", withTotal
      );
      if (myReq !== reqIdRef.current) return; // سباق: تجاهل نتيجة قديمة
      offsetRef.current += rows.length;
      setItems((prev) => (reset ? rows : [...prev, ...rows]));
      setHasMore(rows.length === PAGE);
      if (reset && tot != null) setTotal(tot);
    } catch (e) {
      console.error("perfume index load failed", e);
      if (myReq === reqIdRef.current && reset) { setItems([]); setTotal(0); setHasMore(false); }
    } finally {
      if (myReq === reqIdRef.current) { setLoading(false); setLoadingMore(false); }
    }
  }, [bounds]);

  useEffect(() => { loadPage(true); }, [loadPage]);

  // في «الكل» (نطاق فارغ) نجلب الإجمالي بعدّ أصليّ رخيص — متوازٍ ولا يحجب أوّل صفحة.
  useEffect(() => {
    if (bounds != null) return;
    let alive = true;
    apphost.entities.Perfume.count().then((c) => { if (alive) setTotal(c); }).catch(() => {});
    return () => { alive = false; };
  }, [bounds]);

  // ضغط «All» يفتح الشريط ويختار «الكل». ضغط حرف يختاره ويطوي الشريط.
  // ضغط الحرف النشط بينما الشريط مطوي يعيد فتحه دون تغيير الفلتر.
  const onPickLetter = (l) => {
    setQuery("");
    if (l === "all") {
      setLetter("all");
      setLettersOpen(true);
      return;
    }
    if (!lettersOpen && l === letter) {
      setLettersOpen(true);
      return;
    }
    setLetter(l);
    setLettersOpen(false);
  };
  return (
    <div className="px-5 pt-12 pb-16">
      {/* رأس */}
      <div className="flex items-center gap-3 mb-4">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">{isAr ? "فهرس العطور" : "Perfume Index"}</h1>
        </div>
      </div>

      {/* بحث بالبادئة */}
      <div className="relative mb-3">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <input
          dir="ltr"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder={isAr ? "بحث عن عطر" : "Search Perfume"}
          className="w-full pl-10 pr-9 h-11 rounded-none font-body bg-secondary/50 border-0 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--brand)]/40"
        />
        {query && (
          <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* أحرف A–Z + #: مطوية افتراضياً، تنفتح بضغط «All»؛ وعند اختيار حرف يبقى هو وحده ظاهراً */}
      <div className="flex flex-wrap gap-1 mb-4" dir="ltr">
        <button
          onClick={() => onPickLetter("all")}
          className={`px-2 h-7 rounded-none text-xs font-body font-bold transition-colors ${
            !query.trim() && letter === "all" ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
          }`}
        >
          {isAr ? "الكل" : "All"}
        </button>
        {lettersOpen ? (
          LETTERS.map((l) => {
            const active = !query.trim() && l === letter;
            return (
              <button
                key={l}
                onClick={() => onPickLetter(l)}
                className={`w-7 h-7 rounded-none text-xs font-body font-bold transition-colors ${
                  active ? "bg-[var(--brand)] text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/70"
                }`}
              >
                {l}
              </button>
            );
          })
        ) : (
          !query.trim() && letter !== "all" && (
            <button
              key={letter}
              onClick={() => onPickLetter(letter)}
              className="w-7 h-7 rounded-none text-xs font-body font-bold transition-colors bg-[var(--brand)] text-white shadow"
            >
              {letter}
            </button>
          )
        )}
      </div>

      {/* النتائج */}
      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="w-6 h-6 text-[var(--brand)] animate-spin" />
        </div>
      ) : items.length === 0 ? (
        <div className="text-center py-16 space-y-2">
          <Search className="w-9 h-9 text-[var(--brand)]/25 mx-auto" />
          <p className="text-sm text-muted-foreground font-body">{isAr ? "لا عطور هنا" : "No perfumes here"}</p>
        </div>
      ) : (
        <>
          <div className="divide-y divide-border/40">
            {items.map((p) => (
              <Link
                key={p.id}
                to={`/perfume?id=${p.id}`}
                dir="ltr"
                className="flex items-center justify-between gap-3 py-2.5 px-2 -mx-2 rounded-none hover:bg-secondary/60 transition-colors group"
              >
                <div className="min-w-0 flex-1 overflow-hidden">
                  <p className="text-sm font-body font-medium text-foreground group-hover:text-[var(--brand)] transition-colors whitespace-nowrap overflow-hidden">
                    {trimText(p.name_en || p.name || p.name_ar, 28)}
                  </p>
                </div>
                {p.brand_name && (
                  <span className="text-[10px] text-muted-foreground font-body shrink-0 max-w-[28%] whitespace-nowrap overflow-hidden text-right">{trimText(p.brand_name, 14)}</span>
                )}
              </Link>
            ))}
          </div>

          {hasMore && (
            <div className="flex justify-center pt-4">
              <button
                onClick={() => loadPage(false)}
                disabled={loadingMore}
                className="inline-flex items-center gap-2 rounded-none text-xs font-body font-medium text-foreground disabled:opacity-60 transition-colors"
              >
                {loadingMore ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : null}
                {isAr ? `عرض المزيد (${items.length}/${total})` : `Load more (${items.length}/${total})`}
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
