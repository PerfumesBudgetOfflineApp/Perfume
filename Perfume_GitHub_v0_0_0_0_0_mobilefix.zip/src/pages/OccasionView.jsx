import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ArrowDownUp, AArrowUp, AArrowDown } from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import PerfumeCard from "@/components/perfume/PerfumeCard";

const OCCASION_LABELS = {
  daylight: { en: "Daylight", ar: "نهار" },
  evening: { en: "Evening", ar: "مساء" },
  wedding: { en: "Wedding", ar: "زفاف" },
  celebration: { en: "Celebration", ar: "احتفال" },
  relax: { en: "Relax", ar: "استرخاء" },
  work: { en: "Work", ar: "عمل" },
  sport: { en: "Sport", ar: "رياضة" },
  casual: { en: "Casual", ar: "عادي" },
  very_special: { en: "Very Special", ar: "خاص جداً" },
};

const PER_PAGE = 50;

export default function OccasionView() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const occ = new URLSearchParams(window.location.search).get("o") || "";
  const [sortMode, setSortMode] = useState("year");
  const [page, setPage] = useState(0);

  const { data: allPerfumes = [], isLoading } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const label = OCCASION_LABELS[occ];
  const title = label ? (isAr ? label.ar : label.en) : occ;

  const matching = allPerfumes.filter((p) =>
    (p.occasions || "")
      .split(",")
      .map((o) => o.trim())
      .includes(occ)
  );

  const sorted = [...matching].sort((a, b) => {
    if (sortMode === "alpha_asc" || sortMode === "alpha_desc") {
      const an = (a.name_en || a.name || "").trim(), bn = (b.name_en || b.name || "").trim();
      const isEng = (s) => /^[A-Za-z]/.test(s);
      const ar = isEng(an) ? 0 : 1, br = isEng(bn) ? 0 : 1;
      if (ar !== br) return ar - br;
      const cmp = an.localeCompare(bn, "en", { sensitivity: "base", numeric: true });
      return sortMode === "alpha_desc" ? -cmp : cmp;
    }
    if (sortMode === "type") return (a.type || "").localeCompare(b.type || "");
    if (b.release_year && a.release_year) return b.release_year - a.release_year;
    if (b.release_year) return 1;
    if (a.release_year) return -1;
    return 0;
  });

  const totalPages = Math.ceil(sorted.length / PER_PAGE);
  const pageItems = sorted.slice(page * PER_PAGE, (page + 1) * PER_PAGE);

  return (
    <div className="min-h-screen bg-background">
      <div className="relative bg-background border-b border-border pt-14 pb-6 px-5">
        <button onClick={() => navigate(-1)} className="absolute top-10 left-4 rounded-none p-2 hover:bg-secondary">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h1 className="font-heading font-bold text-xl text-center mt-2">{title}</h1>
        <p className="text-xs text-muted-foreground font-body text-center mt-1">
          {sorted.length} {isAr ? "عطر" : (sorted.length === 1 ? "perfume" : "perfumes")}
        </p>
      </div>

      <div className="px-5 py-5 space-y-4">
        {/* sort */}
        <div className="flex items-center justify-center gap-1.5">
          <ArrowDownUp className="w-3.5 h-3.5 text-primary" />
          {[
            { id: "year", ar: "الإصدار", en: "Release" },
            { id: "type", ar: "النوع", en: "Type" },
          ].map((s) => (
            <button key={s.id} onClick={() => { setSortMode(s.id); setPage(0); }}
              className={`text-[10px] rounded-none ${sortMode === s.id ? " text-background" : " text-muted-foreground"}`}>
              {isAr ? s.ar : s.en}
            </button>
          ))}
          {[
            { id: "alpha_asc", Icon: AArrowUp, ar: "أبجدي تصاعدي", en: "A → Z" },
            { id: "alpha_desc", Icon: AArrowDown, ar: "أبجدي تنازلي", en: "Z → A" },
          ].map((s) => (
            <button key={s.id} onClick={() => { setSortMode(s.id); setPage(0); }}
              title={isAr ? s.ar : s.en} aria-label={isAr ? s.ar : s.en}
              className={`p-1 rounded-none transition-colors ${sortMode === s.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              <s.Icon className="w-4 h-4" />
            </button>
          ))}
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-16">
            <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
          </div>
        ) : sorted.length === 0 ? (
          <p className="text-center text-sm text-muted-foreground font-body py-10">
            {isAr ? "لا توجد عطور لهذه المناسبة" : "No perfumes for this occasion"}
          </p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3">
              {pageItems.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
            </div>
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-3 pt-2">
                <button disabled={page === 0} onClick={() => setPage((n) => Math.max(0, n - 1))}
                  className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "السابق" : "Prev"}</button>
                <span className="text-xs text-muted-foreground">{page + 1} / {totalPages}</span>
                <button disabled={page >= totalPages - 1} onClick={() => setPage((n) => Math.min(totalPages - 1, n + 1))}
                  className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "التالي" : "Next"}</button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
