import { useState, useMemo, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { useLang } from "@/lib/LanguageContext";
import { useTranslations } from "@/lib/useTranslations";
import { openHtmlReport } from "@/lib/exportHelper";
import { useExportSettings, DEFAULT_USER_MARK } from "@/lib/exportSettings";
import UserContentControls from "@/components/shared/UserContentControls";
import InteractionBar from "@/components/shared/InteractionBar";
import { getAppName } from "@/lib/useAppName";
import Pagination from "@/components/shared/Pagination";
import { toast } from "sonner";

/**
 * Quotes page (v3 — separated text_en / text_ar, with Interactions tab)
 *
 * Schema:
 *   { text_en, text_ar, quoteauthor, category }   ← new
 *   { text_enar, author, category }                ← legacy (read-only fallback)
 *
 * Layout:
 *   - Header: title + back + Add + Export PDF
 *   - Category chips (multi-line, fit-to-screen, NO numbers)
 *     First two chips: "All" + "Interaction" (user's reactions, comments, additions)
 *   - Quote cards
 *      • EN text on top, AR text below — both shown, no `..` separator
 *      • Author shown ONLY when set (hidden by default)
 *      • Like / Dislike / WTF / Favorite + Add thought
 *   - Footer: total count
 */

// ── Helpers ───────────────────────────────────────────────────────────

/**
 * Resolve EN / AR text for any quote, regardless of legacy or new schema.
 * Legacy quotes use text_enar = "English .. Arabic". New ones use separate
 * text_en and text_ar fields. We always emit { en, ar }.
 */
function resolveQuoteTexts(q) {
  if (!q) return { en: "", ar: "" };
  if (q.text_en || q.text_ar) {
    return {
      en: (String(q.text_en || "")).trim(),
      ar: (String(q.text_ar || "")).trim(),
    };
  }
  // Legacy fallback: split on space-..-space
  const raw = (String(q.text_enar || "")).trim();
  if (!raw) return { en: "", ar: "" };
  const parts = raw.split(/\s+\.\.\s+/);
  if (parts.length >= 2) {
    let en = parts[0].trim().replace(/\.$/, "").trim();
    let ar = parts.slice(1).join(" .. ").trim().replace(/\.$/, "").trim();
    const enHasAr = /[\u0600-\u06FF]/.test(en);
    const arHasAr = /[\u0600-\u06FF]/.test(ar);
    if (enHasAr && !arHasAr) [en, ar] = [ar, en];
    return { en, ar };
  }
  // No separator — assign to whichever side matches the script
  if (/[\u0600-\u06FF]/.test(raw)) return { en: "", ar: raw };
  return { en: raw, ar: "" };
}

function resolveQuoteAuthor(q) {
  if (!q) return "";
  return (q.quoteauthor || q.author || "").trim();
}

// Split a "English العربية" category label into two pieces.
function splitCategoryLabel(cat) {
  if (!cat) return { en: "", ar: "" };
  const m = cat.match(/^([A-Za-z\s\-&]+?)\s+([\u0600-\u06FF].*)$/);
  if (m) return { en: m[1].trim(), ar: m[2].trim() };
  return { en: cat, ar: cat };
}

// ── Component ─────────────────────────────────────────────────────────
export default function Quotes() {
  const { isAr } = useLang();
  const { t } = useTranslations();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [selectedCategory, setSelectedCategory] = useState("all");
  const [quoteSearch, setQuoteSearch] = useState("");
  const [thoughtDialogOpen, setThoughtDialogOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [selectedQuote, setSelectedQuote] = useState(null);
  const [thought, setThought] = useState("");
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [exportLang, setExportLang] = useState("both"); // both | en | ar
  const [includeAuthors, setIncludeAuthors] = useState(false);
  const [exportSettings] = useExportSettings();

  // New-quote form
  const [newQuoteEn, setNewQuoteEn] = useState("");
  const [newQuoteAr, setNewQuoteAr] = useState("");
  const [newQuoteCategory, setNewQuoteCategory] = useState("");
  const [newQuoteAuthor, setNewQuoteAuthor] = useState("");

  // Data
  const { data: quotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("-created_date"),
  });
  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-updated_date"),
  });

  // Map quote_id → user_quote
  const userQuoteMap = useMemo(() => {
    const m = {};
    for (const uq of userQuotes) m[String(uq.quote_id)] = uq;
    return m;
  }, [userQuotes]);

  // Quote IDs the current user has interacted with
  const interactedIds = useMemo(() => {
    const s = new Set();
    for (const uq of userQuotes) {
      if (uq.reaction && uq.reaction !== "none") s.add(String(uq.quote_id));
      if (uq.thought) s.add(String(uq.quote_id));
      if (uq.favorite) s.add(String(uq.quote_id));
    }
    return s;
  }, [userQuotes]);

  // ── Categories ──
  // Chips never show numbers. First two are always:
  //   - All (الكل)
  //   - Interaction (تفاعل)
  // Then categories ordered by occurrence count.
  const categories = useMemo(() => {
    const counts = {};
    for (const q of quotes) {
      const cat = q.category || "Uncategorized بدون تصنيف";
      counts[cat] = (counts[cat] || 0) + 1;
    }
    const sorted = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    return [
      { value: "all", label_en: "All", label_ar: "الكل" },
      { value: "__interaction__", label_en: "Interaction", label_ar: "تفاعل" },
      ...sorted.map(([cat]) => {
        const lbl = splitCategoryLabel(cat);
        return { value: cat, label_en: lbl.en, label_ar: lbl.ar };
      }),
    ];
  }, [quotes]);

  // ── Filtered quotes ──
  const filteredQuotes = useMemo(() => {
    let visible = quotes.filter((q) => !q.hidden);
    if (selectedCategory === "__interaction__") {
      visible = visible.filter((q) => interactedIds.has(String(q.id)));
    } else if (selectedCategory !== "all") {
      visible = visible.filter((q) => q.category === selectedCategory);
    }
    // بحث نصي: داخل النص الإنجليزي/العربي والمؤلف والفئة (مفردة أو جملة)
    const s = quoteSearch.trim();
    if (s) {
      const q = s.toLowerCase();
      visible = visible.filter((quote) =>
        (String(quote.text_en || "")).toLowerCase().includes(q) ||
        (quote.text_ar || "").includes(s) ||
        (String(quote.text_enar || "")).toLowerCase().includes(q) ||
        (quote.quoteauthor || quote.author || "").toLowerCase().includes(q) ||
        (String(quote.category || "")).toLowerCase().includes(q)
      );
    }
    return visible;
  }, [quotes, selectedCategory, interactedIds, quoteSearch]);

  // ── Pagination (50 per page) — rendering all 4,000+ quotes at once is slow ──
  const PAGE_SIZE = 50;
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(filteredQuotes.length / PAGE_SIZE));
  // Reset to page 1 whenever the filter changes or the list shrinks past the page.
  useEffect(() => { setPage(1); }, [selectedCategory, quoteSearch]);
  useEffect(() => { if (page > pageCount) setPage(1); }, [page, pageCount]);
  const pagedQuotes = useMemo(
    () => filteredQuotes.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    [filteredQuotes, page]
  );

  // ── Mutations ──
  const reactionMutation = useMutation({
    mutationFn: async ({ quoteId, reaction }) => {
      const existing = userQuoteMap[String(quoteId)];
      const quote = quotes.find((q) => String(q.id) === String(quoteId));
      const snapshot = {
        text_en: quote?.text_en,
        text_ar: quote?.text_ar,
        category: quote?.category,
      };
      if (existing) {
        return apphost.entities.UserQuote.update(existing.id, { reaction, ...snapshot });
      }
      return apphost.entities.UserQuote.create({ quote_id: quoteId, reaction, ...snapshot });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const favoriteMutation = useMutation({
    mutationFn: async ({ quoteId, favorite }) => {
      const existing = userQuoteMap[String(quoteId)];
      const quote = quotes.find((q) => String(q.id) === String(quoteId));
      const snapshot = {
        text_en: quote?.text_en,
        text_ar: quote?.text_ar,
        category: quote?.category,
      };
      if (existing) {
        return apphost.entities.UserQuote.update(existing.id, { favorite, ...snapshot });
      }
      return apphost.entities.UserQuote.create({ quote_id: quoteId, favorite, ...snapshot });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const thoughtMutation = useMutation({
    mutationFn: async ({ quoteId, newThought }) => {
      const existing = userQuoteMap[String(quoteId)];
      const quote = quotes.find((q) => String(q.id) === String(quoteId));
      const snapshot = {
        text_en: quote?.text_en,
        text_ar: quote?.text_ar,
        category: quote?.category,
      };
      if (existing) {
        return apphost.entities.UserQuote.update(existing.id, { thought: newThought });
      }
      return apphost.entities.UserQuote.create({ quote_id: quoteId, thought: newThought, ...snapshot });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["user-quotes"] });
      setThoughtDialogOpen(false);
      setThought("");
    },
  });

  const deleteThoughtMutation = useMutation({
    mutationFn: ({ quoteId }) => {
      const existing = userQuoteMap[String(quoteId)];
      if (existing) return apphost.entities.UserQuote.update(existing.id, { thought: null });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["user-quotes"] }),
  });

  const createQuoteMutation = useMutation({
    mutationFn: async (data) => apphost.entities.Quote.create({ ...data, is_user: true }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      setCreateDialogOpen(false);
      setNewQuoteEn("");
      setNewQuoteAr("");
      setNewQuoteCategory("");
      setNewQuoteAuthor("");
      toast.success(isAr ? "تم إضافة الاقتباس" : "Quote added");
    },
  });

  // Edit an existing quote (built-in or user-created).
  const editQuoteMutation = useMutation({
    mutationFn: async ({ id, fields }) => {
      const clean = {};
      ["text_en", "text_ar", "quoteauthor", "category"].forEach((k) => {
        if (fields[k] !== undefined) clean[k] = fields[k];
      });
      return apphost.entities.Quote.update(id, clean);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      toast.success(isAr ? "تم الحفظ" : "Saved");
    },
  });

  // Delete user quotes outright; hide built-in quotes (restorable on re-seed).
  const removeQuoteMutation = useMutation({
    mutationFn: async (quote) => {
      if (quote.is_user) return apphost.entities.Quote.delete(quote.id);
      return apphost.entities.Quote.update(quote.id, { hidden: true });
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["quotes"] });
      toast.success(isAr ? "تم" : "Done");
    },
  });

  const handleOpenThought = (quote) => {
    setSelectedQuote(quote);
    const existing = userQuoteMap[String(quote.id)];
    setThought(existing?.thought || "");
    setThoughtDialogOpen(true);
  };

  // ── Export PDF ──
  const handleExportPDF = async () => {
    const list = filteredQuotes;
    if (list.length === 0) {
      toast.error(isAr ? "لا اقتباسات للتصدير" : "No quotes to export");
      return;
    }

    const escapeHtml = (s) =>
      String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

    // Universal header per exportSettings
    const headerBits = [];
    if (exportSettings.showUserMark) headerBits.push(`<span class="hdr-mark">${DEFAULT_USER_MARK}</span>`);
    if (exportSettings.showAppName)  headerBits.push(`<span class="hdr-app">${getAppName().name_en}</span>`);
    if (exportSettings.showDate)     headerBits.push(`<span class="hdr-date">${new Date().toLocaleDateString()}</span>`);
    const headerHtml = headerBits.length
      ? `<header class="page-header">${headerBits.join('<span class="hdr-sep">·</span>')}</header>`
      : "";

    const quotesHtml = list.map((q) => {
      const { en, ar } = resolveQuoteTexts(q);
      const author = includeAuthors ? resolveQuoteAuthor(q) : "";

      let body = "";
      if (exportLang === "en" || exportLang === "both") {
        if (en) body += `<p class="text-en" dir="ltr">${escapeHtml(en)}</p>`;
      }
      if (exportLang === "ar" || exportLang === "both") {
        if (ar) body += `<p class="text-ar" dir="rtl">${escapeHtml(ar)}</p>`;
      }
      if (author) body += `<p class="author">— ${escapeHtml(author)}</p>`;

      // Optionally append the user's own reaction + thought (default OFF)
      if (exportSettings.showUserInteraction) {
        const uq = userQuoteMap[String(q.id)];
        if (uq) {
          const rxLabel = {
            like: isAr ? "👍 إعجاب" : "👍 Like",
            dislike: isAr ? "👎 لم يعجبني" : "👎 Dislike",
            wtf: isAr ? "؟! غريب" : "?! WTF",
          }[uq.reaction];
          const bits = [];
          if (uq.favorite) bits.push(isAr ? "❤ مفضّل" : "❤ Favourite");
          if (rxLabel) bits.push(rxLabel);
          if (bits.length) body += `<p class="ux-react">${bits.join(" · ")}</p>`;
          if (uq.thought) body += `<p class="ux-thought" dir="auto">“${escapeHtml(uq.thought)}”</p>`;
        }
      }
      return `<article class="quote">${body}</article>`;
    }).join("");

    const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{isAr ? "اقتباسات" : "Quotes"}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=Amiri:ital,wght@0,400;0,700&display=swap" rel="stylesheet">
<style>
  * { box-sizing: border-box; }
  body {
    font-family: 'Cormorant Garamond', 'Amiri', Georgia, serif;
    font-size: 11pt;            /* smaller per user request */
    line-height: 1.55;
    color: #1a1a1a;
    background: #fefdf9;
    margin: 0;
    padding: 24px 32px;
    max-width: 720px;
    margin: 0 auto;
  }
  .page-header {
    display: flex; align-items: center; gap: 6px;
    border-bottom: 0.5pt solid #d8cfb8; padding-bottom: 6px; margin-bottom: 12px;
    font-size: 9pt; color: #6b6b6b;
  }
  .hdr-mark { font-size: 12pt; }
  .hdr-app  { font-weight: 600; letter-spacing: 0.04em; }
  .hdr-date { color: #999; }
  .hdr-sep  { color: #c9bfa9; }
  .quote {
    margin: 0 0 14pt;
    padding: 6pt 0;
    border-bottom: 0.4pt dotted #ddd2b8;
    page-break-inside: avoid;
  }
  .quote:last-child { border-bottom: none; }
  .text-en {
    margin: 0;
    font-weight: 400;
    text-align: justify;
    color: #1a1a1a;
  }
  .text-ar {
    margin: 3pt 0 0;
    font-family: 'Amiri', 'Cormorant Garamond', serif;
    text-align: justify;
    color: #1a1a1a;
  }
  .author {
    margin: 4pt 0 0;
    font-size: 9pt;
    font-style: italic;
    color: #6b6b6b;
    text-align: right;
  }
  @media print {
    body { padding: 0; background: #fff; }
    @page {
      size: A5;
      margin: 14mm 14mm;
    }
  }
</style>
</head>
<body>
${headerHtml}
${quotesHtml}
</body>
</html>`;

    await openHtmlReport(html, "quotes");
    setExportDialogOpen(false);
  };

  // ── Render ──
  return (
    <div className="flex flex-col min-h-screen">
      {/* رأس الصفحة — يمرّر مع المحتوى (صفحة واحدة، بلا تثبيت يغطّي القائمة) */}
      <div className="px-4 pt-12 pb-3">
        <div className="flex items-center justify-between gap-2 mb-3">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost" size="icon"
              onClick={() => navigate("/goals")}
              className="rounded-none -ml-2 h-8 w-8"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <h1 className="font-heading text-lg font-bold">
              {t("quotes.title")}
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setExportDialogOpen(true)}
              className="flex items-center gap-1 text-[10px] font-body font-medium rounded-none text-muted-foreground transition-colors"
              title={isAr ? "تصدير PDF" : "Export PDF"}
            >
              <Download className="w-3 h-3" /> PDF
            </button>
            <Button
              size="sm"
              className="rounded-none h-8 text-xs font-body px-3"
              onClick={() => setCreateDialogOpen(true)}
            >
              {isAr ? "إضافة" : "Add"}
            </Button>
            <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
          </div>
        </div>

        {/* بحث في الاقتباسات — عنوان أو مفردة داخل النص */}
        <Input
          value={quoteSearch}
          onChange={(e) => setQuoteSearch(e.target.value)}
          placeholder={isAr ? "ابحث في الاقتباسات (نص، مؤلف، فئة)..." : "Search quotes (text, author, category)..."}
          dir={isAr ? "rtl" : "ltr"}
          className="rounded-none h-10 font-body text-sm mb-2"
        />

        {/* Category chips — bilingual, multi-line, fit-to-screen, NO numbers */}
        <div className="flex flex-wrap gap-1.5 pb-1">
          {categories.map((cat) => {
            const active = selectedCategory === cat.value;
            return (
              <button
                key={cat.value}
                onClick={() => setSelectedCategory(cat.value)}
                className={`text-[10px] font-body px-1.5 py-0.5 rounded transition-all leading-tight ${
                  active
                    ? "text-amber-700 dark:text-amber-400 font-bold underline underline-offset-4 decoration-amber-500/60"
                    : "text-amber-700/55 dark:text-amber-500/50 hover:text-amber-700 dark:hover:text-amber-400"
                }`}
              >
                <span dir="ltr" style={{ unicodeBidi: "isolate" }}>{cat.label_en}</span>
                <span className="inline-block w-2.5" />
                <span dir="rtl" style={{ unicodeBidi: "isolate" }}>{cat.label_ar}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* قائمة الاقتباسات — بلا صناديق، يفصلها خط ذهبي خام */}
      <div className="px-4 py-2">
        {filteredQuotes.length === 0 && (
          <div className="text-center py-12 space-y-2">
            <p className="font-heading text-sm font-semibold">
              {isAr ? "لا اقتباسات هنا" : "No quotes here"}
            </p>
          </div>
        )}

        {pagedQuotes.map((quote) => {
          const uq = userQuoteMap[String(quote.id)];
          const reaction = uq?.reaction || "none";
          const favorite = !!uq?.favorite;
          const hasThought = !!uq?.thought;
          const { en, ar } = resolveQuoteTexts(quote);
          const author = resolveQuoteAuthor(quote);

          return (
            <div
              key={quote.id}
              className="py-4 space-y-2"
              style={{ borderBottom: "1px solid rgba(184,134,11,0.35)" }}
            >
              {/* Bilingual quote text — tap to open the quote's own page */}
              <div
                onClick={() => navigate(`/quote?id=${quote.id}`)}
                className="space-y-2 cursor-pointer"
                role="button"
              >
              {en && (
                <p
                  className="text-[13px] font-body leading-relaxed text-foreground/90"
                  dir="ltr"
                  style={{ unicodeBidi: "isolate" }}
                >
                  {en}
                </p>
              )}
              {ar && (
                <p
                  className="text-[13px] font-body leading-relaxed text-foreground/90"
                  dir="rtl"
                  style={{ unicodeBidi: "isolate" }}
                >
                  {ar}
                </p>
              )}

              {/* القائل فقط — التصنيف انتقل لصفحة الاقتباس (عرض + تعديل + إهمال) */}
              {author && (
                <div className="text-[10px] text-muted-foreground font-body">
                  <span>— {author}</span>
                </div>
              )}
              </div>

              {/* Unified interaction bar: reactions + notebook + WTF */}
              <InteractionBar
                reaction={favorite ? "favorite" : reaction}
                hasThought={hasThought}
                showWtf={true}
                onReact={(kind) => {
                  if (kind === "favorite") {
                    favoriteMutation.mutate({ quoteId: quote.id, favorite: !favorite });
                  } else {
                    reactionMutation.mutate({
                      quoteId: quote.id,
                      reaction: reaction === kind ? "none" : kind,
                    });
                  }
                }}
                onThought={() => handleOpenThought(quote)}
                bookmark={{
                  item_type: "quote",
                  item_id: quote.id,
                  title_en: resolveQuoteTexts(quote).en || "",
                  title_ar: resolveQuoteTexts(quote).ar || "",
                  subtitle: quote.quoteauthor || quote.author || "",
                  path: `/quotes`,
                }}
              />

              {/* Existing thought */}
              {hasThought && (
                <div className="bg-secondary/40 rounded-none p-2 space-y-1.5">
                  <p className="text-[9px] uppercase tracking-wider text-muted-foreground font-body">
                    {isAr ? "فكرتي" : "My thought"}
                  </p>
                  <p className="text-[11px] font-body" dir="auto">
                    {uq.thought}
                  </p>
                  <button
                    onClick={() => deleteThoughtMutation.mutate({ quoteId: quote.id })}
                    className="text-[10px] text-destructive hover:text-destructive/70 font-body"
                  >
                    {isAr ? "حذف" : "Delete"}
                  </button>
                </div>
              )}

              {/* Edit / delete the quote itself — additive, below reactions */}
              <UserContentControls
                kind="quote"
                entry={quote}
                isUser={!!quote.is_user}
                compact
                onSave={(fields) => editQuoteMutation.mutateAsync({ id: quote.id, fields })}
                onDelete={() => removeQuoteMutation.mutateAsync(quote)}
              />
            </div>
          );
        })}
      </div>

      {/* Page switcher (50 per page) */}
      <Pagination
        page={page}
        pageCount={pageCount}
        onChange={setPage}
        totalItems={filteredQuotes.length}
        pageSize={PAGE_SIZE}
      />

      {/* Footer count */}
      <div className="flex-shrink-0 px-4 py-2 bg-secondary/30 border-t border-border/40">
        <p className="text-[10px] text-muted-foreground font-body text-center">
          {filteredQuotes.length}{" "}
          {isAr ? "اقتباس" : filteredQuotes.length === 1 ? "quote" : "quotes"}
          {selectedCategory !== "all" && selectedCategory !== "__interaction__" && (
            <span className="opacity-60">
              {" "}/ {quotes.length} {isAr ? "إجمالي" : "total"}
            </span>
          )}
        </p>
      </div>

      {/* Thought dialog */}
      <Dialog open={thoughtDialogOpen} onOpenChange={setThoughtDialogOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isAr ? "أضف فكرتك" : "Add your thought"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <Textarea
              value={thought}
              onChange={(e) => setThought(e.target.value)}
              placeholder={isAr ? "ماذا تفكر بهذا الاقتباس؟" : "What do you think about this quote?"}
              className="rounded-none font-body text-xs min-h-[100px] resize-none"
              dir="auto"
            />
            <Button
              className="w-full h-10 rounded-none"
              onClick={() => {
                if (selectedQuote) thoughtMutation.mutate({
                  quoteId: selectedQuote.id,
                  newThought: thought.trim(),
                });
              }}
              disabled={!thought.trim() || thoughtMutation.isPending}
            >
              {thoughtMutation.isPending
                ? isAr ? "جارٍ..." : "Saving..."
                : isAr ? "حفظ" : "Save"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add-quote dialog */}
      <Dialog open={createDialogOpen} onOpenChange={setCreateDialogOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isAr ? "إضافة اقتباس" : "Add quote"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                English
              </label>
              <Textarea
                value={newQuoteEn}
                onChange={(e) => setNewQuoteEn(e.target.value)}
                placeholder={isAr ? "اقتباس بالإنجليزية" : "English quote"}
                className="rounded-none font-body text-xs min-h-[60px] resize-none"
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                العربية
              </label>
              <Textarea
                value={newQuoteAr}
                onChange={(e) => setNewQuoteAr(e.target.value)}
                placeholder="النص العربي"
                className="rounded-none font-body text-xs min-h-[60px] resize-none"
                dir="rtl"
              />
              <p className="text-[9px] text-muted-foreground font-body">
                {isAr
                  ? "يمكنك ترك إحدى اللغتين فارغة"
                  : "You can leave either language empty"}
              </p>
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                {isAr ? "التصنيف" : "Category"}
              </label>
              <Input
                value={newQuoteCategory}
                onChange={(e) => setNewQuoteCategory(e.target.value)}
                placeholder="Inspiration إلهام"
                className="rounded-none h-9 font-body text-xs"
                dir="auto"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                {isAr ? "القائل (اختياري)" : "Author (optional)"}
              </label>
              <Input
                value={newQuoteAuthor}
                onChange={(e) => setNewQuoteAuthor(e.target.value)}
                placeholder={isAr ? "اسم القائل" : "Author name"}
                className="rounded-none h-9 font-body text-xs"
                dir="auto"
              />
            </div>
            <Button
              className="w-full h-10 rounded-none font-body text-sm"
              onClick={() => {
                createQuoteMutation.mutate({
                  text_en: newQuoteEn.trim(),
                  text_ar: newQuoteAr.trim(),
                  quoteauthor: newQuoteAuthor.trim(),
                  category: newQuoteCategory.trim() || "Inspiration إلهام",
                });
              }}
              disabled={
                (!newQuoteEn.trim() && !newQuoteAr.trim()) ||
                createQuoteMutation.isPending
              }
            >
              {createQuoteMutation.isPending
                ? isAr ? "جارٍ..." : "Saving..."
                : isAr ? "إضافة" : "Add"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Export dialog — language + author + branding toggles */}
      <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
        <DialogContent className="max-w-sm rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">
              {isAr ? "تصدير الاقتباسات" : "Export quotes"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <p className="text-[10px] uppercase tracking-wider font-body text-muted-foreground">
                {isAr ? "اللغة" : "Language"}
              </p>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { v: "both", en: "EN + AR", ar: "EN + AR" },
                  { v: "en",   en: "EN",      ar: "EN" },
                  { v: "ar",   en: "AR",      ar: "AR" },
                ].map((o) => (
                  <button
                    key={o.v}
                    type="button"
                    onClick={() => setExportLang(o.v)}
                    className={`py-2 rounded-none text-xs font-body font-medium transition-all ${
                      exportLang === o.v
                        ? "bg-primary text-primary-foreground shadow"
                        : "bg-secondary text-muted-foreground"
                    }`}
                  >
                    {o.en}
                  </button>
                ))}
              </div>
            </div>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeAuthors}
                onChange={(e) => setIncludeAuthors(e.target.checked)}
                className="w-4 h-4 rounded accent-primary"
              />
              <span className="text-xs font-body">
                {isAr ? "إظهار القائل" : "Show author"}
              </span>
            </label>
            <Button
              className="w-full h-10 rounded-none font-body text-sm"
              onClick={handleExportPDF}
            >
              <Download className="w-4 h-4 mr-2" />
              {isAr ? "تصدير" : "Export"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
