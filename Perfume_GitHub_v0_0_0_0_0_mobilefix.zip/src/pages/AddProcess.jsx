import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { initDB, processes } from '@/lib/indexedDB';
import { toast } from 'sonner';

export default function AddProcess() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const editId = searchParams.get('edit');

  const [form, setForm] = useState({
    name: '',
    description: '',
    status: 'active',
    progress: 0
  });
  const [loading, setLoading] = useState(!!editId);

  useEffect(() => {
    if (editId) {
      const load = async () => {
        try {
          await initDB();
          const process = await processes.get(parseInt(editId));
          if (process) {
            setForm(process);
          }
        } catch (error) {
          console.error('Failed to load:', error);
        } finally {
          setLoading(false);
        }
      };
      load();
    }
  }, [editId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!form.name.trim()) {
      toast.error('اسم العملية مطلوب');
      return;
    }

    try {
      await initDB();
      if (editId) {
        await processes.update(parseInt(editId), form);
        toast.success('تم تحديث العملية');
      } else {
        await processes.add(form);
        toast.success('تم إنشاء العملية الجديدة');
      }
      navigate('/process');
    } catch (error) {
      toast.error('فشلت العملية');
      console.error(error);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="px-4 pt-12 pb-8 max-w-2xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/process')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-2xl font-bold">
          {editId ? 'تعديل العملية' : 'عملية جديدة'}
        </h1>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Name */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-muted-foreground uppercase">اسم العملية</label>
          <Input
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            placeholder="مثال: مراجعة المشروع"
            className="rounded-none h-11 text-sm"
          />
        </div>

        {/* Description */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-muted-foreground uppercase">الوصف</label>
          <Textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="وصف العملية بالتفصيل..."
            className="rounded-none text-sm min-h-[120px]"
          />
        </div>

        {/* Status */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-muted-foreground uppercase">الحالة</label>
          <div className="flex gap-2">
            {['active', 'paused', 'completed'].map(status => (
              <button
                key={status}
                type="button"
                onClick={() => setForm({ ...form, status })}
                className={` rounded-none text-xs font-medium transition-all ${
 form.status === status
 ? 'bg-primary text-primary-foreground border-primary'
 : 'bg-secondary hover:border-primary/50'
 }`}
              >
                {status === 'active' && '🟢 نشطة'}
                {status === 'paused' && '⏸️ موقوفة'}
                {status === 'completed' && 'مكتملة'}
              </button>
            ))}
          </div>
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-muted-foreground uppercase">التقدم (%)</label>
          <div className="flex gap-3">
            <input
              type="range"
              min="0"
              max="100"
              value={form.progress || 0}
              onChange={(e) => setForm({ ...form, progress: parseInt(e.target.value) })}
              className="flex-1 h-2 bg-secondary rounded-none cursor-pointer"
            />
            <span className="text-sm font-semibold w-12 text-center">{form.progress || 0}%</span>
          </div>
          <div className="w-full bg-secondary rounded-none h-2">
            <div
              className="bg-amber-500 h-2 rounded-none transition-all"
              style={{ width: `${form.progress || 0}%` }}
            />
          </div>
        </div>

        {/* Buttons */}
        <div className="flex gap-2 pt-4">
          <Button type="submit" className="flex-1 h-11 rounded-none font-body">
            {editId ? 'تحديث' : 'إنشاء'}
          </Button>
          <Button type="button" variant="outline" className="flex-1 h-11 rounded-none font-body" onClick={() => navigate('/process')}>
            إلغاء
          </Button>
        </div>
      </form>
    </div>
  );
}