import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAppName } from "@/lib/useAppName";
import { Button } from "@/components/ui/button";

/**
 * AppInfo — نص على خلفية بيضاء فقط: بلا إطارات، بلا خلفيات مختلفة، بلا أيقونات.
 * العناوين الرئيسية ذهبية (var(--brand)). لكل قسم: النص العربي ثم الإنجليزي.
 */
export default function AppInfo() {
  const navigate = useNavigate();
  const { name_en, name_ar, version } = useAppName();

  return (
    <div className="px-5 pt-12 pb-8 space-y-7">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-none" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">App Info</h1>
          <p className="text-xs text-muted-foreground font-body mt-0.5" dir="rtl">معلومات التطبيق</p>
        </div>
      </div>

      {/* Special Thanks شكر خاص — بلا إطارات، اللون كما هو */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-amber-700 dark:text-amber-400">شكر خاص Special Thanks</h2>
        <p className="text-sm italic text-amber-800 dark:text-amber-300 leading-relaxed" dir="rtl">إلى من يبقون الموسيقى مفعمة بالحياة و الحيوية.. ابقوا الموسيقى تُسمع بعيداً عن الإزعاج</p>
        <p className="text-sm italic text-amber-800 dark:text-amber-300 leading-relaxed" dir="ltr">To those who keep Music full of life and vitality. Keep Music heard away from the disturbance.</p>
        <div className="flex flex-wrap gap-x-3 gap-y-1" dir="ltr">
          {["Joe Rogan","Fragrantica.com","Parfumo.com","Google Alphabet","YouTube","Claude","Base44","Development Community","GitHub","Gemini","Android Studio","Apple Developer","Grok","Co-pilot","OpenAI","Perfumes Community","FragDB","Lucide"].map((n) => (
            <span key={n} className="text-xs font-body text-amber-700 dark:text-amber-400">{n}</span>
          ))}
        </div>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="rtl">مجتمع العطور و المجتمع التقني و كل من نسينا ذكرهم لإسهاماتهم القيمة و جهودهم الجبارة. شكراً جزيلاً لكم.</p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="ltr">And anyone we have forgotten to mention for their great input and great effort. Thank You very much.</p>
      </section>

      {/* About حول التطبيق */}
      <section className="space-y-2">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">حول التطبيق About</h2>
        <p className="font-heading font-bold text-base" dir="ltr">{name_en} · <span className="text-foreground/80">{name_ar}</span> <span className="text-xs text-muted-foreground font-body">v{version}</span></p>
        <p className="text-sm font-body font-semibold text-[var(--brand)]" dir="ltr">GitHub · <span dir="rtl">جيتهب</span></p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="rtl">نسخة نظيفة و مخصّصة، متاحة المصدر للتطوير. الكتالوجات الضخمة محذوفة، وتبقى بنية التطبيق كاملة مع بيانات أمثلة توضّح كيف ترتبط كل الميزات.</p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="ltr">A clean, source-available edition for development. The heavy catalogs are removed; the full app structure remains, with example data showing how every feature connects.</p>
        <p className="text-sm font-body font-semibold text-[var(--brand)] leading-relaxed" dir="rtl">يُنصح بتطويره على منصة كلود (Claude).</p>
        <p className="text-sm font-body font-semibold text-[var(--brand)] leading-relaxed" dir="ltr">Recommended to develop it on the Claude platform.</p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="rtl">تطبيق {name_ar} هو متتبع عطور شخصي للأزواج و عشاق العطور. سجل ارتداءك اليومي، و ابني مجموعتك، و اكتشف عطوراً جديدة، و شارك الرحلة مع شخص مميز.</p>
        <p className="text-sm font-body text-muted-foreground leading-relaxed" dir="ltr">{name_en} is a personal fragrance tracker for couples and fragrance enthusiasts. Log your daily wears, build your collection, discover new scents, and share the journey with someone special.</p>
      </section>

      {/* Privacy سياسة الخصوصية */}
      <section className="space-y-2">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">سياسة الخصوصية Privacy Policy</h2>
        <div dir="rtl" className="space-y-2 text-sm font-body text-muted-foreground leading-relaxed">
          <p><span className="font-semibold text-foreground">تطبيق محلي بالكامل:</span> هذا التطبيق يعمل بالكامل على جهازك. كل بياناتك تُخزَّن محلياً على جهازك فقط (في قاعدة بيانات المتصفّح IndexedDB)، و لا تُرسَل أو تُنقَل إلى أي خادم أو طرف ثالث إطلاقاً.</p>
          <p><span className="font-semibold text-foreground">لا يحتاج إنترنت:</span> التطبيق يعمل بدون اتصال بالإنترنت تماماً. لا يوجد تسجيل دخول، و لا حساب، و لا مزامنة سحابية، و لا أي تتبّع.</p>
          <p><span className="font-semibold text-foreground">جمع البيانات:</span> لا نجمع أي بيانات عنك. ما تُدخِله في التطبيق (عطور، سجلات ارتداء، ملاحظات، ميزانية) يبقى على جهازك وحدك، تحت سيطرتك الكاملة.</p>
          <p><span className="font-semibold text-foreground">مشاركة البيانات:</span> لا تُباع بياناتك و لا تُشارَك مع أي جهة، لأنّها ببساطة لا تغادر جهازك أبداً.</p>
          <p><span className="font-semibold text-foreground">حذف البيانات:</span> أنت تملك بياناتك بالكامل. يمكنك حذفها في أي وقت بمسح بيانات الموقع من إعدادات المتصفّح.</p>
        </div>
        <div dir="ltr" className="space-y-2 text-sm font-body text-muted-foreground leading-relaxed">
          <p><span className="font-semibold text-foreground">Fully local app:</span> This app runs entirely on your device. All your data is stored locally on your device only (in the browser's IndexedDB database) and is never sent or transmitted to any server or third party whatsoever.</p>
          <p><span className="font-semibold text-foreground">No internet required:</span> The app works completely offline. There is no login, no account, no cloud sync, and no tracking of any kind.</p>
          <p><span className="font-semibold text-foreground">Data Collection:</span> We collect no data about you. Whatever you enter (perfumes, wear logs, notes, budget) stays on your device alone, under your full control.</p>
          <p><span className="font-semibold text-foreground">Data Sharing:</span> Your data is never sold or shared with anyone, because it simply never leaves your device.</p>
          <p><span className="font-semibold text-foreground">Deleting your data:</span> You own your data completely. You can delete it any time by clearing the site data from your browser settings.</p>
        </div>
      </section>

      {/* Copyright حقوق الملكية الفكرية */}
      <section className="space-y-2">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">حقوق الملكية الفكرية Copyright &amp; Intellectual Property</h2>
        <div dir="rtl" className="space-y-2 text-sm font-body text-muted-foreground leading-relaxed">
          <p><span className="font-semibold text-foreground">قاعدة بيانات العطور:</span> تُتاح بموجب رخصة MIT.</p>
          <p><span className="font-semibold text-foreground">المحتوى المُولَّد بالذكاء الاصطناعي:</span> القصص و الاقتباسات و ما في حُكمها مُولَّدة بمساعدة الذكاء الاصطناعي، مع الحرص على عدم اقتباس أيّ عمل أدبيّ اقتباساً كاملاً، و الإشارة إلى مصدره عند وجوده.</p>
          <p><span className="font-semibold text-foreground">دقّة المعلومات:</span> الذكاء الاصطناعي — كالبشر — قد يُخطئ؛ و وجود أيّ معلومة هنا لا يضمن دقّتها الكاملة.</p>
          <p><span className="font-semibold text-foreground">طلب إزالة محتوى (DMCA):</span> إن رأيت محتوًى يمسّ حقوقك أو رغبت في إزالته، يُرجى التواصل معنا، و سنستجيب وفق إجراءات DMCA.</p>
        </div>
        <div dir="ltr" className="space-y-2 text-sm font-body text-muted-foreground leading-relaxed">
          <p><span className="font-semibold text-foreground">Perfume database:</span> provided under the MIT License.</p>
          <p><span className="font-semibold text-foreground">AI-generated content:</span> the stories, quotes and similar material are generated with the help of AI, with care taken not to quote any literary work in full, and with attribution to the source where one exists.</p>
          <p><span className="font-semibold text-foreground">Accuracy:</span> AI — like humans — can make mistakes; the presence of any information here does not guarantee its accuracy.</p>
          <p><span className="font-semibold text-foreground">Content removal (DMCA):</span> if you believe any content infringes your rights or wish it removed, please contact us; we will respond in line with DMCA procedures.</p>
        </div>
      </section>

      {/* Terms الشروط و السياسة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">الشروط و السياسة Terms &amp; Policy</h2>
        <div dir="rtl" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">مجاني و مفتوح المصدر</h3><p>{name_ar} مجاني تماماً للاستخدام و التعديل و التوزيع. لا توجد قيود ترخيص تتجاوز الترخيص مفتوح المصدر الأصلي.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">الاستخدام التجاري</h3><p>يمكن نشر نسختك الخاصة من {name_ar} تجارياً دون قيود. جميع الأكواد متاحة بحرية للاستخدام التجاري.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">مستودع GitHub</h3><p>الكود المصدري الكامل متاح على GitHub. يمكن لأي شخص مراجعة الكود و فهم كيفية عمل التطبيق و المساهمة في التحسينات أو نشر نسختهم الخاصة تجارياً.</p></div>
        </div>
        <div dir="ltr" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">Free &amp; Open Source</h3><p>{name_en} is completely free to use, modify, and distribute. There are no licensing restrictions beyond the original open-source license.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Commercial Use</h3><p>You can deploy your own instance of {name_en} commercially without restrictions. All code is freely available for commercial use.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">GitHub Repository</h3><p>The complete source code is available on GitHub. Anyone can review the code, understand how the application works, contribute improvements, or deploy their own instance commercially.</p></div>
        </div>
      </section>

      {/* Due Diligence التطوير و المنصة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">التطوير و المنصة Due Diligence &amp; Development</h2>
        <div dir="rtl" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">المنصة</h3><p>بُنِيَ {name_ar} ليعمل محلياً بالكامل على جهازك باستخدام قاعدة بيانات المتصفّح (IndexedDB)، دون أي خادم أو اتصال بالإنترنت.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">التطوير و التصميم</h3><p>صُمِّم هذا التطبيق و طُوِّر بعناية، مع اهتمام كبير بتجربة المستخدم و الأداء و إمكانية الوصول.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">جودة الكود</h3><p>يتبع الكود أفضل الممارسات الحديثة بما في ذلك React hooks و تكوين المكونات و التصميم المستجيب و معايير إمكانية الوصول. جميع الأكواد مفتوحة المصدر و تتوفر للمراجعة العامة.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">التعامل مع البيانات</h3><p>تبقى كل بياناتك على جهازك و لا تُنقَل إلى أي مكان. لا يوجد خادم و لا نقل بيانات عبر الشبكة على الإطلاق.</p></div>
        </div>
        <div dir="ltr" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">Platform</h3><p>{name_en} is built to run entirely on your device using the browser's local database (IndexedDB), with no server and no internet connection.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Development &amp; Design</h3><p>This application has been designed and developed with care, reflecting close attention to user experience, performance, and accessibility.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Code Quality</h3><p>The codebase follows modern best practices including React hooks, component composition, responsive design, and accessibility standards. All code is open-source and available for public review.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Data Handling</h3><p>All your data stays on your device and is never transmitted anywhere. There is no server and no network data transfer of any kind.</p></div>
        </div>
      </section>

      {/* AI &amp; Technologies الذكاء الاصطناعي و التقنيات */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">الذكاء الاصطناعي و التقنيات AI &amp; Technologies</h2>
        <div dir="rtl" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">تطوير التطبيق</h3><p>تم تطوير {name_ar} من خلال عدّة منصّات تقنية: Base44 و Claude و Grok.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">الشفافية</h3><p>نؤمن بالكشف الشفاف عن مشاركة الذكاء الاصطناعي في تطوير البرامج. يستخدم هذا التطبيق الذكاء الاصطناعي كمساعد في التطوير، تماماً كما هو الحال عند استخدام محررات الأكواد و الفاحصات و المجمعات.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">مكدس التكنولوجيا</h3><p>مبني باستخدام React و Tailwind CSS و قاعدة بيانات IndexedDB المحلية. التطبيق متجاوب و سهل الوصول و مصمم للعمل بسلاسة و بلا إنترنت على جميع الأجهزة.</p></div>
        </div>
        <div dir="ltr" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">App Development</h3><p>{name_en} was developed through several technical platforms: Base44, Claude, and Grok.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Transparency</h3><p>We believe in transparent disclosure of AI involvement in software development. This application uses AI as a development aid, similar to using code editors, linters, and compilers.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Technology Stack</h3><p>Built with React, Tailwind CSS, and a local IndexedDB database. The app is responsive, accessible, and designed to work seamlessly and offline on all devices.</p></div>
        </div>
      </section>

      {/* Quotes اقتباسات */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)]">اقتباسات Quotes</h2>
        <p className="text-sm font-body text-muted-foreground" dir="rtl">مرر المعرفة, الثقافة, القيم و ما إلى ذلك</p>
        <p className="text-sm font-body text-muted-foreground" dir="ltr">Pass on knowledge, culture, values and so on</p>
        <div dir="rtl" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">حب العطور</h3><p>العطور ليست مجرد رائحة، بل هي رحلة عاطفية. كل رائحة تحكي قصة، تثير ذكريات، و تربط قلوبنا بالعالم من حولنا. نؤمن بأهمية الاحتفال بهذا الشغف المشترك.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">المشاركة و الاتصال</h3><p>التطبيق مصمم للأزواج و العائلات لمشاركة رحلتهم معاً. نحن نؤمن بقوة الارتباط من خلال المصالح المشتركة و الذكريات الجميلة.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">الشفافية و الأمان</h3><p>بياناتك ملك لك وحدك. لا نصدرها أو نبيعها. نحن شفافون تماماً حول كيفية استخدام معلوماتك و تخزينها.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">الابتكار المسؤول</h3><p>نستخدم التكنولوجيا و الذكاء الاصطناعي بمسؤولية لتحسين تجربتك، مع الحفاظ على القيم الإنسانية في الأساس.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">الحرية و المرونة</h3><p>التطبيق مفتوح المصدر و المجاني. أنت حر في استخدامه و تعديله و المساهمة فيه كما تشاء.</p></div>
        </div>
        <div dir="ltr" className="space-y-3 text-sm font-body text-muted-foreground leading-relaxed">
          <div><h3 className="font-semibold text-foreground mb-1">Love of Fragrance</h3><p>Fragrances are more than just scents—they are emotional journeys. Each fragrance tells a story, evokes memories, and connects our hearts to the world around us. We celebrate this shared passion.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Sharing &amp; Connection</h3><p>The app is designed for couples and families to share their journey together. We believe in the power of connection through shared interests and beautiful memories.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Transparency &amp; Security</h3><p>Your data is yours alone. We don't resell or trade it. We are completely transparent about how your information is used and stored.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Responsible Innovation</h3><p>We use technology and AI responsibly to enhance your experience while keeping human values at the core.</p></div>
          <div><h3 className="font-semibold text-foreground mb-1">Freedom &amp; Flexibility</h3><p>The app is open-source and free. You're free to use it, modify it, and contribute to it as you wish.</p></div>
        </div>
      </section>

      {/* Gift dedication */}
      <div className="text-center py-4 space-y-1">
        <p className="text-xs text-muted-foreground font-body" dir="rtl">إهداء ❤️ لمحبين العطور.</p>
        <p className="text-xs text-muted-foreground font-body" dir="ltr">A gift ❤️ for fragrance lovers.</p>
      </div>

      {/* Footer */}
      <div className="text-center pb-8 space-y-1 text-xs font-body text-muted-foreground leading-relaxed">
        <p className="font-heading font-bold text-sm text-[var(--brand)]" dir="ltr">PerfumesBudgetOfflineApp</p>
      </div>
    </div>
  );
}
