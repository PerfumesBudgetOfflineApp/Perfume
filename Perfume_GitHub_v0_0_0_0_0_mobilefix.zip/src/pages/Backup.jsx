import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { ArrowLeft, Download, Upload, AlertCircle, Lock, Eye, EyeOff } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob } from "@/lib/exportHelper";
import { encryptBackup, decryptBackup, isEncryptedBackup } from "@/lib/backupCrypto";
import { toast } from "sonner";

export default function Backup() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const queryClient = useQueryClient();
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  // Mandatory password for encrypted backup (export & restore are never plaintext)
  const [exportPassword, setExportPassword] = useState("");
  const [exportPasswordConfirm, setExportPasswordConfirm] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const MIN_PW = 6;
  const pwValid = exportPassword.length >= MIN_PW && exportPassword === exportPasswordConfirm;
  // Holds a parsed-but-locked encrypted file awaiting a password to restore
  const [pendingEncrypted, setPendingEncrypted] = useState(null);
  const [importPassword, setImportPassword] = useState("");

  // User data - Only current user's data (auto-filtered via RLS)
  const { data: userPerfumes = [] } = useQuery({ queryKey: ["user-perfumes"], queryFn: () => apphost.entities.UserPerfume.list("-created_date") });
  const { data: wearLogs = [] } = useQuery({ queryKey: ["wear-logs"], queryFn: () => apphost.entities.WearLog.list("-date") });
  const { data: layers = [] } = useQuery({ queryKey: ["layers"], queryFn: () => apphost.entities.PerfumeLayer.list("-created_date") });
  const { data: posts = [] } = useQuery({ queryKey: ["blog-posts"], queryFn: () => apphost.entities.BlogPost.list("-created_date") });
  const { data: wishlist = [] } = useQuery({ queryKey: ["wishlist"], queryFn: () => apphost.entities.Wishlist.list() });
  const { data: userBrands = [] } = useQuery({ queryKey: ["user-brands"], queryFn: () => apphost.entities.UserBrand.list() });
  const { data: goals = [] } = useQuery({ queryKey: ["goals"], queryFn: () => apphost.entities.Goal.list() });
  const { data: budgetExpenses = [] } = useQuery({ queryKey: ["budget-expenses"], queryFn: () => apphost.entities.BudgetExpense.list() });
  const { data: budgetIncomes = [] } = useQuery({ queryKey: ["budget-incomes"], queryFn: () => apphost.entities.BudgetIncome.list() });
  const { data: purchaseRecords = [] } = useQuery({ queryKey: ["purchase-records"], queryFn: () => apphost.entities.PurchaseRecord.list() });
  const { data: shopProducts = [] } = useQuery({ queryKey: ["shop-products"], queryFn: () => apphost.entities.ShopProduct.list() });

  // Built-in database
  const { data: perfumes = [] } = useQuery({ queryKey: ["perfumes"], queryFn: () => apphost.entities.Perfume.list() });
  const { data: brands = [] } = useQuery({ queryKey: ["brands"], queryFn: () => apphost.entities.PerfumeBrand.list() });
  const { data: perfumers = [] } = useQuery({ queryKey: ["perfumers"], queryFn: () => apphost.entities.Perfumer.list() });
  const { data: notes = [] } = useQuery({ queryKey: ["notes"], queryFn: () => apphost.entities.PerfumeNote.list() });
  const { data: collections = [] } = useQuery({ queryKey: ["collections"], queryFn: () => apphost.entities.PerfumeCollection.list() });
  const { data: quotes = [] } = useQuery({ queryKey: ["quotes"], queryFn: () => apphost.entities.Quote.list() });
  const { data: glossary = [] } = useQuery({ queryKey: ["glossary"], queryFn: () => apphost.entities.GlossaryTerm.list() });
  const { data: stores = [] } = useQuery({ queryKey: ["stores"], queryFn: () => apphost.entities.Store.list() });
  const { data: shopBrands = [] } = useQuery({ queryKey: ["shop-brands"], queryFn: () => apphost.entities.ShopBrand.list() });
  const { data: shopCategories = [] } = useQuery({ queryKey: ["shop-categories"], queryFn: () => apphost.entities.ShopCategory.list() });
  const { data: wisdom = [] } = useQuery({ queryKey: ["wisdom"], queryFn: () => apphost.entities.Wisdom.list() });

  const handleExport = async () => {
    if (!pwValid) {
      toast.error(isAr ? `كلمة السرّ مطلوبة (${MIN_PW} أحرف على الأقل) و يجب أن تتطابق` : `Password is required (min ${MIN_PW} chars) and must match`);
      return;
    }
    setExporting(true);
    try {
      const backup = {
        version: "2.0",
        exported_at: new Date().toISOString(),
        user_data: {
          userPerfumes,
          wearLogs,
          layers,
          posts,
          wishlist,
          userBrands,
          goals,
          budgetExpenses,
          budgetIncomes,
          purchaseRecords,
          shopProducts,
        },
        builtin_database: {
          perfumes,
          brands,
          perfumers,
          notes,
          collections,
          quotes,
          glossary,
          stores,
          shopBrands,
          shopCategories,
          wisdom,
        },
      };

      // Password is mandatory — the backup is always encrypted (never plaintext).
      const fileObject = await encryptBackup(backup, exportPassword);
      const suffix = "-encrypted";

      const blob = new Blob([JSON.stringify(fileObject, null, 2)], { type: "application/json" });
      await downloadBlob(blob, `process-app-backup${suffix}-${new Date().toISOString().split("T")[0]}.json`);
      toast.success(isAr ? "تم تنزيل النسخة المشفّرة!" : "Encrypted backup downloaded!");
      setExportPassword(""); setExportPasswordConfirm("");
    } catch (e) {
      toast.error(isAr ? "فشل التصدير" : "Export failed");
    } finally {
      setExporting(false);
    }
  };

  // Writes a parsed (already-decrypted) backup payload into the local database.
  // Strips ids so autoIncrement assigns fresh ones (avoids id collisions).
  const restorePayload = async (backup) => {
    const ud = backup.user_data || {};
    const map = [
      ["UserPerfume", ud.userPerfumes],
      ["WearLog", ud.wearLogs],
      ["PerfumeLayer", ud.layers],
      ["BlogPost", ud.posts],
      ["Wishlist", ud.wishlist],
      ["UserBrand", ud.userBrands],
      ["Goal", ud.goals],
      ["BudgetExpense", ud.budgetExpenses],
      ["BudgetIncome", ud.budgetIncomes],
      ["PurchaseRecord", ud.purchaseRecords],
      ["ShopProduct", ud.shopProducts],
    ];
    let restored = 0;
    for (const [entity, rows] of map) {
      if (!Array.isArray(rows) || rows.length === 0) continue;
      const cleaned = rows.map(({ id, ...rest }) => rest); // drop old id
      try {
        await apphost.entities[entity].bulkCreate(cleaned);
        restored += cleaned.length;
      } catch (err) {
        console.error(`Restore failed for ${entity}`, err);
      }
    }
    return restored;
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImporting(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);

      // Encrypted file? Hold it and ask for the password (separate UI step).
      if (isEncryptedBackup(parsed)) {
        setPendingEncrypted(parsed);
        setImportPassword("");
        toast.info(isAr ? "هذه نسخة مشفّرة — أدخل كلمة السرّ لاستعادتها." : "Encrypted backup — enter the password to restore.");
        return;
      }

      // No restore without a password: reject any non-encrypted backup.
      toast.error(isAr ? "لا استرداد بدون كلمة سرّ — هذه النسخة غير مشفّرة. تُقبل النسخ المشفّرة فقط." : "No restore without a password — this backup is not encrypted. Only password-protected backups are accepted.");
    } catch (err) {
      toast.error(isAr ? "ملف النسخة غير صالح" : "Invalid backup file");
    } finally {
      setImporting(false);
      e.target.value = "";
    }
  };

  // Decrypt the held encrypted file with the entered password, then restore.
  const handleDecryptAndRestore = async () => {
    if (!pendingEncrypted || !importPassword) return;
    setImporting(true);
    try {
      const backup = await decryptBackup(pendingEncrypted, importPassword);
      const count = await restorePayload(backup);
      await queryClient.invalidateQueries();
      toast.success(isAr ? `تمت استعادة ${count} سجلّ بنجاح.` : `Restored ${count} records successfully.`);
      setPendingEncrypted(null);
      setImportPassword("");
    } catch (err) {
      if (err.code === "WRONG_PASSWORD") {
        toast.error(isAr ? "كلمة السرّ غير صحيحة. حاول مرّة أخرى." : "Wrong password. Please try again.");
      } else {
        toast.error(isAr ? "تعذّر فكّ تشفير الملف" : "Could not decrypt the file");
      }
    } finally {
      setImporting(false);
    }
  };

  const userDataTotal = userPerfumes.length + wearLogs.length + layers.length + posts.length + wishlist.length + userBrands.length + goals.length + budgetExpenses.length + budgetIncomes.length + purchaseRecords.length + shopProducts.length;
  const builtinDataTotal = perfumes.length + brands.length + perfumers.length + notes.length + collections.length + quotes.length + glossary.length + stores.length + shopBrands.length + shopCategories.length + wisdom.length;
  const totalRecords = userDataTotal + builtinDataTotal;

  return (
    <div className={`px-4 pt-12 pb-8 space-y-6 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-none" onClick={() => navigate(-1)}>
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </Button>
        <h1 className="font-heading text-2xl font-bold">{isAr ? "النسخ الاحتياطية و الاستعادة" : "Backup & Restore"}</h1>
      </div>

      {/* Summary - User Data */}
      <div className="bg-card rounded-none border border-border/60 p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100/50 dark:bg-blue-900/30 rounded-none flex items-center justify-center">
            <span className="text-lg">👤</span>
          </div>
          <div>
            <p className="font-heading font-semibold">{isAr ? "بيانات حسابك الشخصية" : "Your Personal Data"}</p>
            <p className="text-xs text-muted-foreground font-body">{userDataTotal} {isAr ? "سجل إجمالي" : "total records"}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { label_en: "Collections", label_ar: "الكلكشن الخاصة بك", count: userPerfumes.length },
            { label_en: "Wear Logs", label_ar: "سجل الاستخدام", count: wearLogs.length },
            { label_en: "Layers", label_ar: "المزج و الطبقات", count: layers.length },
            { label_en: "Journal", label_ar: "دفتر اليوميات", count: posts.length },
            { label_en: "Wishlist", label_ar: "قائمة الأمنيات", count: wishlist.length },
            { label_en: "Brand Reviews", label_ar: "تقييمات الماركات", count: userBrands.length },
            { label_en: "Goals", label_ar: "الأهداف", count: goals.length },
            { label_en: "Budget", label_ar: "الميزانية", count: budgetExpenses.length + budgetIncomes.length },
            { label_en: "Purchases", label_ar: "المشتريات", count: purchaseRecords.length + shopProducts.length },
          ].map(({ label_en, label_ar, count }) => (
            <div key={label_en} className="bg-secondary/50 rounded-none px-3 py-2.5">
              <p className="text-lg font-heading font-bold text-primary">{count}</p>
              <p className="text-[11px] text-muted-foreground font-body">{isAr ? label_ar : label_en}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Summary - Built-in Database */}
      <div className="bg-card rounded-none border border-border/60 p-5 space-y-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-emerald-100/50 dark:bg-emerald-900/30 rounded-none flex items-center justify-center">
            <span className="text-lg">🗄️</span>
          </div>
          <div>
            <p className="font-heading font-semibold">{isAr ? "قاعدة البيانات المدمجة" : "Built-in Database"}</p>
            <p className="text-xs text-muted-foreground font-body">{builtinDataTotal} {isAr ? "سجل إجمالي" : "total records"}</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          {[
            { label_en: "Perfumes", label_ar: "العطور", count: perfumes.length },
            { label_en: "Brands", label_ar: "الماركات", count: brands.length },
            { label_en: "Perfumers", label_ar: "العطارون", count: perfumers.length },
            { label_en: "Notes", label_ar: "النوتات", count: notes.length },
            { label_en: "Collections", label_ar: "المجموعات", count: collections.length },
            { label_en: "Quotes", label_ar: "الاقتباسات", count: quotes.length },
            { label_en: "Wisdom & Insights", label_ar: "الحكم و المواعظ", count: wisdom.length },
            { label_en: "Glossary", label_ar: "المسرد", count: glossary.length },
            { label_en: "Stores", label_ar: "المتاجر", count: stores.length + shopBrands.length },
            { label_en: "Categories", label_ar: "التصنيفات", count: shopCategories.length },
          ].map(({ label_en, label_ar, count }) => (
            <div key={label_en} className="bg-secondary/50 rounded-none px-3 py-2.5">
              <p className="text-lg font-heading font-bold text-primary">{count}</p>
              <p className="text-[11px] text-muted-foreground font-body">{isAr ? label_ar : label_en}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Export */}
      <div className="bg-card rounded-none border border-border/60 p-5 space-y-3">
        <div className="flex items-center gap-3 mb-1">
          <Download className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">{isAr ? "تصدير النسخة الاحتياطية الكاملة" : "Export Complete Backup"}</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          {isAr
            ? "قم بتنزيل بيانات حسابك الشخصية و قاعدة بيانات العطور الكاملة كملف JSON. احفظه في Google Drive أو iCloud أو أي مكان تفضله."
            : "Download your personal data AND the complete Perfume Book with all reference data as a JSON file. Save it to Google Drive, iCloud, or anywhere you like."}
        </p>
        <div className="space-y-2 text-xs text-muted-foreground font-body rounded-none ">
          <p>📦 <strong>{isAr ? "يتضمن:" : "Includes:"}</strong></p>
          <ul className="list-disc list-inside space-y-0.5">
            <li><strong>{isAr ? "بيانات حسابك:" : "Your Data:"}</strong> {isAr ? "الكلكشن، سجل الاستخدام، الأهداف، الميزانية، المشتريات و المزيد" : "Collections, wear logs, goals, budget, purchases, and more"}</li>
            <li><strong>{isAr ? "كتاب العطور:" : "Perfume Book:"}</strong> {isAr ? "جميع العطور و الماركات و العطارون مصنفين حسب الفئات" : "All perfumes, brands, perfumers classified by families"}</li>
            <li><strong>{isAr ? "نوتات العطور:" : "Fragrance Notes:"}</strong> {isAr ? "قاعدة بيانات النوتات الكاملة مع الفئات و الهرمية" : "Complete notes database with categories and pyramids"}</li>
            <li><strong>{isAr ? "الحكم و المواعظ:" : "Wisdom & Insights:"}</strong> {isAr ? "الاقتباسات و الحكم و المصطلحات" : "Quotes, insights, and glossary terms"}</li>
            <li><strong>{isAr ? "البيانات المرجعية:" : "Reference Data:"}</strong> {isAr ? "المجموعات و المتاجر و التصنيفات و بيانات التسوق" : "Collections, stores, categories, and shop information"}</li>
          </ul>
        </div>

        {/* Mandatory password protection */}
        <div className="space-y-2 pt-1">
          <div className="flex items-center gap-2">
            <Lock className="w-3.5 h-3.5 text-primary" />
            <label className="text-sm font-body font-medium">
              {isAr ? "حماية بكلمة السرّ (مطلوبة)" : "Password protection (required)"}
            </label>
          </div>
          <div className="relative">
            <input
              type={showPassword ? "text" : "password"}
              value={exportPassword}
              onChange={(e) => setExportPassword(e.target.value)}
              placeholder={isAr ? `كلمة السرّ (${MIN_PW} أحرف على الأقل)` : `Password (min ${MIN_PW} chars)`}
              className={`w-full h-11 rounded-none border border-border bg-background px-3 ${isAr ? "pl-10 text-right" : "pr-10"} text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/40`}
            />
            <button
              type="button"
              onClick={() => setShowPassword((s) => !s)}
              className={`absolute top-1/2 -translate-y-1/2 ${isAr ? "left-3" : "right-3"} text-muted-foreground hover:text-foreground`}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>
          <input
            type={showPassword ? "text" : "password"}
            value={exportPasswordConfirm}
            onChange={(e) => setExportPasswordConfirm(e.target.value)}
            placeholder={isAr ? "تأكيد كلمة السرّ" : "Confirm password"}
            className={`w-full h-11 rounded-none border bg-background px-3 ${isAr ? "text-right" : ""} text-sm font-body focus:outline-none focus:ring-2 focus:ring-primary/40 ${exportPasswordConfirm && exportPassword !== exportPasswordConfirm ? "border-red-400" : "border-border"}`}
          />
          {exportPasswordConfirm && exportPassword !== exportPasswordConfirm && (
            <p className="text-xs font-body text-red-600">{isAr ? "كلمتا السرّ غير متطابقتين" : "Passwords do not match"}</p>
          )}
          <div className="bg-red-50 border border-red-200 rounded-none px-4 py-3 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs font-body text-red-700">
              {isAr
                ? "احفظ كلمة السرّ في مكان آمن. التطبيق محلّيّ بالكامل بلا خادم، فإذا نسيتها لن تتمكّن أنت ولا أيّ أحد من استعادة هذه النسخة نهائيّاً. يُشتقّ مفتاح التشفير من كلمة السرّ نفسها (لا من الجهاز)، فتستطيع الاستعادة على أيّ جهاز جديد بتنصيب جديد بكلمة السرّ فقط."
                : "Keep this password safe. The app is fully local with no server, so if you forget it, neither you nor anyone can ever recover this backup. The encryption key is derived from the password itself (not the device), so you can restore on any brand-new device with just the password."}
            </p>
          </div>
        </div>

        <Button className="w-full h-11 rounded-none font-body gap-2" onClick={handleExport} disabled={exporting || !pwValid}>
          <Lock className="w-4 h-4" />
          {exporting
            ? (isAr ? "جاري التصدير..." : "Exporting...")
            : (isAr ? "تنزيل نسخة مشفّرة" : "Download Encrypted Backup")}
        </Button>
      </div>

      {/* Import */}
      <div className="bg-card rounded-none border border-border/60 p-5 space-y-3">
        <div className="flex items-center gap-3 mb-1">
          <Upload className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">{isAr ? "استعادة من نسخة احتياطية" : "Restore from Backup"}</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          {isAr ? "قم برفع ملف نسخة احتياطية تم تصديره مسبقاً لاستعادة بياناتك." : "Upload a previously exported backup file to restore your data."}
        </p>
        <div className="bg-amber-50 border border-amber-200 rounded-none px-4 py-3 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs font-body text-amber-700">
            {isAr
              ? "سيتم إضافة البيانات فوق السجلات الموجودة. قد تظهر إدخالات مكررة."
              : "Restore will add data on top of existing records. Duplicate entries may appear."}
          </p>
        </div>
        <label className="w-full">
          <input type="file" accept=".json" className="hidden" onChange={handleImport} disabled={importing} />
          <div className="w-full h-11 rounded-none font-body border-2 border-dashed border-border flex items-center justify-center gap-2 text-sm text-muted-foreground hover:border-primary hover:text-primary cursor-pointer transition-colors">
            <Upload className="w-4 h-4" />
            {importing ? (isAr ? "جاري قراءة الملف..." : "Reading file...") : (isAr ? "اختر ملف النسخة الاحتياطية" : "Choose Backup File")}
          </div>
        </label>

        {/* Encrypted file: ask for password before restoring */}
        {pendingEncrypted && (
          <div className="bg-secondary/40 border border-primary/30 rounded-none p-4 space-y-3">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-primary" />
              <p className="text-sm font-body font-medium">
                {isAr ? "نسخة مشفّرة — أدخل كلمة السرّ" : "Encrypted backup — enter password"}
              </p>
            </div>
            <input
              type="password"
              value={importPassword}
              onChange={(e) => setImportPassword(e.target.value)}
              onKeyDown={(e) => { if (e.key === "Enter") handleDecryptAndRestore(); }}
              placeholder={isAr ? "كلمة السرّ" : "Password"}
              className={`w-full h-11 rounded-none border border-border bg-background px-3 text-sm font-body ${isAr ? "text-right" : ""} focus:outline-none focus:ring-2 focus:ring-primary/40`}
              autoFocus
            />
            <div className="flex gap-2">
              <Button className="flex-1 h-10 rounded-none font-body gap-2" onClick={handleDecryptAndRestore} disabled={importing || !importPassword}>
                <Lock className="w-4 h-4" />
                {importing ? (isAr ? "جاري الاستعادة..." : "Restoring...") : (isAr ? "فكّ التشفير و الاستعادة" : "Decrypt & Restore")}
              </Button>
              <Button variant="ghost" className="h-10 rounded-none font-body" onClick={() => { setPendingEncrypted(null); setImportPassword(""); }} disabled={importing}>
                {isAr ? "إلغاء" : "Cancel"}
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}