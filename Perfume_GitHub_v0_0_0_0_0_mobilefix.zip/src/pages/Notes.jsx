import { useState, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Search, Flower2, Upload, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { useLang } from "@/lib/LanguageContext";
import { RISK_GROUPS, MECH } from "@/lib/headacheRisk";

const PYRAMID_LABELS = { top: "Top", heart: "Heart", base: "Base", conductor: "Conductor", all: "All Layers" };
const PYRAMID_COLORS = {
  top: "bg-sky-100 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300",
  heart: "bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300",
  base: "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300",
  conductor: "bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300",
  all: "bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300",
};

const CATEGORIES = [
  "Floral زهري",
  "Woody خشبي",
  "Citrus حمضي",
  "Oriental شرقي",
  "Spicy توابل",
  "Aquatic مائي",
  "Fruity فاكهي",
  "Green أخضر",
  "Gourmand حلو",
  "Earthy ترابي",
  "Musky مسكي",
  "Powdery بودرة",
  "Resinous راتنجي"
];
const ODOR_FAMILIES = [
  "Fresh منعش",
  "Warm دافئ",
  "Sweet حلو",
  "Dry جاف",
  "Green أخضر",
  "Earthy ترابي",
  "Aquatic مائي",
  "Smoky دخاني",
  "Creamy كريمي",
  "Leathery جلدي"
];

// Multi-select chip component
function ChipSelect({ label, options, selected, onToggle }) {
  const selectedSet = new Set((selected || "").split(",").map(s => s.trim()).filter(Boolean));
  return (
    <div className="space-y-1.5">
      <Label className="text-xs font-body">{label}</Label>
      <div className="flex flex-wrap gap-1.5">
        {options.map((opt) => {
          const active = selectedSet.has(opt);
          return (
            <button key={opt} type="button" onClick={() => onToggle(opt, active, selectedSet)}
              className={` rounded-none text-xs font-body font-medium transition-all ${active ? " text-primary-foreground " : " text-muted-foreground "}`}>
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}

export default function Notes() {
  const { isAr } = useLang();
  const urlParams = new URLSearchParams(window.location.search);
  const initialCat = urlParams.get("catFilter") || "all";
  const initialPyramid = urlParams.get("pyramidFilter") || "all";
  const initialOdor = urlParams.get("odorFilter") || "all";
  const initialAllowed = urlParams.get("allowedFilter") || "all";
  const initialLevel = urlParams.get("levelFilter") || "all";

  const [view, setView] = useState("alpha"); // "alpha" | "pyramid" | "sub" | "low"
  const [search, setSearch] = useState("");
  const [catFilter, setCatFilter] = useState(initialCat);
  const [pyramidFilter, setPyramidFilter] = useState(initialPyramid);
  const [odorFilter, setOdorFilter] = useState(initialOdor);
  const [allowedFilter, setAllowedFilter] = useState(initialAllowed);
  const [levelFilter, setLevelFilter] = useState(initialLevel);
  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState({ note_category: "sub_notes" });
  const [uploading, setUploading] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: notes = [], isLoading } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
    staleTime: 0,
  });

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeNote.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["notes"] });
      setAddOpen(false);
      setForm({ note_category: "sub_notes" });
      toast.success("أُضيفت الملاحظة");
    },
  });

  const handleUploadImage = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (e.target) e.target.value = ""; // Prevent double-trigger on Android
    setUploading(true);
    try {
      const result = await apphost.integrations.Core.UploadFile({ file });
      setForm({ ...form, image_url: result.file_url });
      toast.success("رُفعت الصورة");
    } catch {
      toast.error("فشل الرفع");
    }
    setUploading(false);
  };

  const handleToggleChip = (field) => (opt, active, selectedSet) => {
    const newSet = new Set(selectedSet);
    if (active) newSet.delete(opt); else newSet.add(opt);
    setForm({ ...form, [field]: [...newSet].join(", ") });
  };

  // Count perfumes per note name
  const noteCount = useMemo(() => {
    const map = {};
    perfumes.forEach((p) => {
      const allNotes = [p.top_notes, p.heart_notes, p.base_notes, p.innovation_notes]
        .filter(Boolean).join(",").split(",").map(n => n.trim().toLowerCase()).filter(Boolean);
      allNotes.forEach((n) => { map[n] = (map[n] || 0) + 1; });
    });
    return map;
  }, [perfumes]);

  const filterNote = (note) => {
    if (note.hidden) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      if (!note.name?.toLowerCase().includes(q) && !note.name_ar?.includes(search) && !note.category?.toLowerCase().includes(q) && !note.odor_family?.toLowerCase().includes(q) && !note.origin?.toLowerCase().includes(q)) return false;
    }
    if (catFilter !== "all") {
      const noteCats = (note.category || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!noteCats.includes(catFilter)) return false;
    }
    if (pyramidFilter !== "all") {
      const notePyramids = (note.pyramid || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!notePyramids.includes(pyramidFilter)) return false;
    }
    if (odorFilter !== "all") {
      const noteOdors = (note.odor_family || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!noteOdors.includes(odorFilter)) return false;
    }
    if (allowedFilter !== "all") {
      const isAllowed = note.is_allowed !== false; // default true
      if (allowedFilter === "allowed" && !isAllowed) return false;
      if (allowedFilter === "banned" && isAllowed) return false;
    }
    if (levelFilter !== "all" && note.note_category !== levelFilter) return false;
    return true;
  };

  const mainNotes = notes.filter(n => n.note_category === "main_note" && filterNote(n));
  const subNotes = notes.filter(n => (!n.note_category || n.note_category === "sub_notes") && filterNote(n));
  const lowNotes = notes.filter(n => n.note_category === "low_notes" && filterNote(n));
  const restrictedNotes = notes.filter(n => n.is_allowed === false && filterNote(n));

  // النوتات المؤكَّد أنّها تسبّب إشكالات صحية — مبنيّة على عائلات الخطر المنسَّقة
  // (RISK_GROUPS): لكل عائلة نوتاتها المطابِقة من قاعدة النوتات + آلياتها + السبب.
  const healthGroups = useMemo(() => {
    const q = (search || "").trim().toLowerCase();
    return RISK_GROUPS.map((g) => {
      const matches = notes.filter((n) => {
        const t = `${n.name || ""} ${n.name_en || ""} ${n.name_ar || ""}`.toLowerCase();
        return g.keys.some((k) => t.includes(String(k).toLowerCase()));
      });
      return { ...g, matches };
    }).filter((g) => {
      if (!q) return true;
      return (
        g.ar.toLowerCase().includes(q) ||
        g.en.toLowerCase().includes(q) ||
        g.matches.some((n) => `${n.name || ""} ${n.name_ar || ""}`.toLowerCase().includes(q))
      );
    });
  }, [notes, search]);

  const sortNotes = (list) => [...list].sort((a, b) => {
    const ca = noteCount[a.name?.toLowerCase()] || 0;
    const cb = noteCount[b.name?.toLowerCase()] || 0;
    return cb - ca;
  });

  const groupByCategory = (list) => {
    const map = {};
    list.forEach((n) => {
      const key = n.category || "Uncategorized";
      if (!map[key]) map[key] = [];
      map[key].push(n);
    });
    return Object.entries(map).sort((a, b) => b[1].length - a[1].length);
  };

  const isFiltering = search.trim() || catFilter !== "all" || pyramidFilter !== "all" || odorFilter !== "all" || allowedFilter !== "all" || levelFilter !== "all";

  return (
    <div className="pb-20 min-h-screen">
      <Tabs value={view} onValueChange={setView} className="w-full">
        {/* Header */}
        <div className="relative bg-background border-b border-border pt-14 pb-5 px-5">
          <button className="absolute top-10 left-4 rounded-none hover:bg-secondary p-2 hover:bg-secondary transition-colors" onClick={() => navigate('/perfumes')}>
            <ArrowLeft className="w-5 h-5" />
          </button>
          <button className="absolute top-10 right-4 rounded-none text-muted-foreground hover:text-foreground transition-colors text-xs font-body h-8 " onClick={() => setAddOpen(true)}>
            {isAr ? "إضافة" : "Add"}
          </button>
          <div className="text-center mt-2">
            <h1 className="font-heading text-xl font-bold">{isAr ? "النوتات" : "Perfume Notes"}</h1>
          </div>

          {/* التبويبات — زوايا حادة، خلفية شفافة، إطار روز جولد، خط أصغر */}
          <div className="mt-4 flex gap-1.5">
            {[
              { key: "alpha", label: "Alphabetical" },
              { key: "pyramid", label: "Pyramid" },
              { key: "sub", label: "Sub" },
              { key: "low", label: "Low" },
              { key: "restrictions", label: "Restrictions قيود" },
              { key: "health", label: "Health صحة" },
            ].map(({ key, label }) => (
              <button key={key} onClick={() => setView(key)}
                style={{ borderRadius: 0, borderColor: "#B76E79" }}
                className={`flex-1 py-2 px-0.5 border bg-transparent text-[10px] leading-tight font-body font-semibold transition-all ${view === key ? "text-[#B76E79] bg-[#B76E79]/10" : "text-muted-foreground hover:text-[#B76E79]"}`}>
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* TAB: أبجدية - عرض كل النوتات (main+sub) في عمودين + Low منفصل */}
        <TabsContent value="alpha" className="px-4 pt-4 space-y-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث في النوتات..." className="pl-9 rounded-none h-10 font-body text-sm" />
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <NotesTwoColumns
              mainSubNotes={[...mainNotes, ...subNotes]}
              noteCount={noteCount}
            />
          )}
        </TabsContent>

        {/* TAB: هرمي - بالفلاتر */}
        <TabsContent value="pyramid" className="px-4 pt-4">
          <NotesIndexContent 
            notes={notes} 
            isLoading={isLoading}
            search={search}
            setSearch={setSearch}
            allowedFilter={allowedFilter}
            setAllowedFilter={setAllowedFilter}
            catFilter={catFilter}
            setCatFilter={setCatFilter}
            pyramidFilter={pyramidFilter}
            setPyramidFilter={setPyramidFilter}
            odorFilter={odorFilter}
            setOdorFilter={setOdorFilter}
            noteCount={noteCount}
            perfumes={perfumes}
          />
        </TabsContent>

        {/* TAB: Sub Notes */}
        <TabsContent value="sub" className="px-4 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-body font-semibold text-sky-700">Sub Notes النوتات الفرعية</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث..." className="pl-9 rounded-none h-10 font-body text-sm" />
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <>
              {subNotes.length === 0
                ? <p className="text-xs text-muted-foreground font-body text-center py-8">لا يوجد</p>
                : <SubLowPaginatedList notes={subNotes} noteCount={noteCount} borderColor="border-sky-200" />
              }
            </>
          )}
          <p className="text-xs font-body text-muted-foreground text-center">{subNotes.length} نوتة فرعية</p>
        </TabsContent>

        {/* TAB: Low Notes منفصل */}
        <TabsContent value="low" className="px-4 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-body font-semibold text-amber-700">🧪 Low Notes النوتات الثانوية</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث..." className="pl-9 rounded-none h-10 font-body text-sm" />
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <>
              {lowNotes.length === 0
                ? <p className="text-xs text-muted-foreground font-body text-center py-8">لا يوجد</p>
                : <SubLowPaginatedList notes={lowNotes} noteCount={noteCount} borderColor="border-amber-200" />
              }
            </>
          )}
          <p className="text-xs font-body text-muted-foreground text-center">{lowNotes.length} نوتة ثانوية</p>
        </TabsContent>

        {/* ───── Restrictions tab ───── */}
        <TabsContent value="restrictions" className="px-4 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-body font-semibold text-red-700">⛔ Restrictions النوتات المقيدة</p>
          </div>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث في النوتات المقيدة..." className="pl-9 rounded-none h-10 font-body text-sm" />
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : (
            <>
              {restrictedNotes.length === 0
                ? <p className="text-xs text-muted-foreground font-body text-center py-8">لا توجد نوتات مقيدة مطابقة</p>
                : <SubLowPaginatedList notes={restrictedNotes} noteCount={noteCount} borderColor="border-red-200" />
              }
            </>
          )}
          <p className="text-xs font-body text-muted-foreground text-center">{restrictedNotes.length} نوتة مقيدة</p>
        </TabsContent>

        {/* ───── Health-issue notes tab — نوتات تسبب إشكالات صحية ───── */}
        <TabsContent value="health" className="px-4 pt-4 space-y-3">
          <p className="text-sm font-body font-semibold text-rose-700">⚠️ نوتات تسبب إشكالات صحية Health-issue notes</p>
          <p className="text-xs text-muted-foreground font-body">عائلات نوتات مؤكَّد ارتباطها بالصداع أو الجيوب أو التحسّس، مع نوتاتها في قاعدتك. — Note families confirmed to be linked to headache, sinus, or allergy, with their notes in your database.</p>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input value={search} onChange={(e) => setSearch(e.target.value)}
              placeholder="بحث في النوتات الصحية..." className="pl-9 rounded-none h-10 font-body text-sm" />
          </div>
          {isLoading ? (
            <div className="flex items-center justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : healthGroups.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body text-center py-8">لا نتائج No results</p>
          ) : (
            <div className="space-y-2">
              {healthGroups.map((g) => (
                <div key={g.id} className="bg-white rounded-none border border-rose-200 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-body font-semibold text-sm">{g.ar} <span className="text-muted-foreground font-normal">{g.en}</span></span>
                    <span className="flex gap-2 flex-shrink-0">
                      {g.mech.map((m) => (
                        <span key={m} className="text-[10px] font-bold text-primary">{MECH[m].emoji} {MECH[m].ar} {MECH[m].en}</span>
                      ))}
                    </span>
                  </div>
                  <p className="text-xs text-muted-foreground font-body mt-1">{g.reasonAr}</p>
                  <p className="text-[11px] text-muted-foreground/80 font-body italic">{g.reasonEn}</p>
                  {g.matches.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {g.matches.slice(0, 40).map((n) => (
                        <Link key={n.id} to={`/note?id=${n.id}`}
                          className="inline-flex items-center rounded-none text-[11px] font-body text-foreground/80 transition-colors">
                          {n.name}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
          <p className="text-xs font-body text-muted-foreground text-center">{healthGroups.reduce((s, g) => s + g.matches.length, 0)} نوتة صحية مطابقة</p>
        </TabsContent>
      </Tabs>

      {/* تذييل الصفحة: العدّاد (بلا نقطة، حسب اللغة) + رابط إنشاء عطر */}
      <div className="px-5 mt-6 mb-2 flex flex-col items-center gap-3">
        <p className="text-[11px] font-body text-muted-foreground text-center">
          {isAr
            ? `${notes.length} نوتة   ${perfumes.length} عطر`
            : `${notes.length} notes   ${perfumes.length} perfumes`}
        </p>
        <Link to="/make-perfume"
          style={{ borderRadius: 0, borderColor: "#C8A02E", color: "#C8A02E" }}
          className="text-xs font-body font-semibold border bg-transparent px-4 py-2 hover:bg-[#C8A02E]/10 transition-colors">
          {isAr ? "أنشئ عطراً" : "Create a Perfume"}
        </Link>
      </div>

      {/* Add Note Dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading">{isAr ? "إضافة نوتة" : "Add Note"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">

            {/* Name — single bilingual field */}
             <div className="space-y-1.5">
               <Label className="text-xs font-body">Note Name (English)</Label>
               <Input value={form.name_en || ""} onChange={(e) => setForm({ ...form, name_en: e.target.value, name: [e.target.value, form.name_ar].filter(Boolean).join(" ") })}
                 className="rounded-none font-body" placeholder="e.g. Rose" />
             </div>
             <div className="space-y-1.5">
               <Label className="text-xs font-body">اسم النوتة (عربي)</Label>
               <Input value={form.name_ar || ""} onChange={(e) => setForm({ ...form, name_ar: e.target.value, name: [form.name_en, e.target.value].filter(Boolean).join(" ") })}
                 className="rounded-none font-body" placeholder="مثال: ورد" dir="rtl" />
             </div>

             {/* Note Category (Catalog Level) — moved up */}
             <div className="space-y-1.5">
               <Label className="text-xs font-body">📚 Catalog Level</Label>
               <div className="grid grid-cols-3 gap-1">
                 {[
                   { val: "main_note", label: "Main", color: "bg-emerald-500 text-white" },
                   { val: "sub_notes", label: "Sub", color: "bg-sky-500 text-white" },
                   { val: "low_notes", label: "Low", color: "bg-amber-500 text-white" },
                 ].map(({ val, label, color }) => (
                   <button key={val} type="button" onClick={() => setForm({ ...form, note_category: val })}
                     className={`py-2 rounded-none text-xs font-body font-medium transition-all ${form.note_category === val ? color : "bg-secondary text-muted-foreground"}`}>
                     {label}
                   </button>
                 ))}
               </div>
             </div>

            {/* Category — multi-select */}
            <div className="space-y-1.5">
              <Label className="text-xs font-body">التصنيف Category</Label>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map((cat) => {
                  const selected = (form.category || "").split(",").map(s => s.trim()).includes(cat);
                  return (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => {
                        const arr = (form.category || "").split(",").map(s => s.trim()).filter(Boolean);
                        const next = selected ? arr.filter(a => a !== cat) : [...arr, cat];
                        setForm({ ...form, category: next.join(", ") });
                      }}
                      className={` rounded-none text-xs font-body font-medium transition-all ${selected ? " text-primary-foreground " : " text-muted-foreground "}`}
                    >
                      {cat}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Odor Family — multi-select */}
            <div className="space-y-1.5">
              <Label className="text-xs font-body">العائلة العطرية Odor Family</Label>
              <div className="flex flex-wrap gap-1.5">
                {ODOR_FAMILIES.map((fam) => {
                  const selected = (form.odor_family || "").split(",").map(s => s.trim()).includes(fam);
                  return (
                    <button
                      key={fam}
                      type="button"
                      onClick={() => {
                        const arr = (form.odor_family || "").split(",").map(s => s.trim()).filter(Boolean);
                        const next = selected ? arr.filter(a => a !== fam) : [...arr, fam];
                        setForm({ ...form, odor_family: next.join(", ") });
                      }}
                      className={` rounded-none text-xs font-body font-medium transition-all ${selected ? " text-primary-foreground " : " text-muted-foreground "}`}
                    >
                      {fam}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Pyramid — multi-select */}
             <div className="space-y-1.5">
               <Label className="text-xs font-body">الهرم العطري Pyramid Position</Label>
               <div className="grid grid-cols-5 gap-1">
                 {["top", "heart", "base", "conductor", "all"].map((p) => {
                   const selected = (form.pyramid || "").split(",").map(s => s.trim()).includes(p);
                   return (
                     <button
                       key={p}
                       type="button"
                       onClick={() => {
                         const arr = (form.pyramid || "").split(",").map(s => s.trim()).filter(Boolean);
                         const next = selected ? arr.filter(a => a !== p) : [...arr, p];
                         setForm({ ...form, pyramid: next.join(", ") });
                       }}
                       className={`py-2 rounded-none text-[10px] font-body font-medium transition-all border ${selected ? PYRAMID_COLORS[p] + " border-current" : "bg-secondary text-muted-foreground border-border"}`}
                     >
                       {PYRAMID_LABELS[p]}
                     </button>
                   );
                 })}
               </div>
             </div>



            {/* Description */}
            <div className="space-y-1.5">
              <Label className="text-xs font-body">Description الوصف</Label>
              <Textarea value={form.description || ""} onChange={(e) => setForm({ ...form, description: e.target.value })}
                className="rounded-none font-body min-h-[60px]" placeholder="How does it smell? / كيف تبدو رائحته؟" />
            </div>

            {/* Origin */}
            <div className="space-y-1.5">
              <Label className="text-xs font-body">المنشأ Origin</Label>
              <Input value={form.origin || ""} onChange={(e) => setForm({ ...form, origin: e.target.value })}
                className="rounded-none font-body" placeholder="e.g. Bulgaria, India..." />
            </div>

            {/* Photo */}
            <div className="space-y-1.5">
              <Label className="text-xs font-body">صورة Photo</Label>
              {form.image_url ? (
                <div className="relative w-full h-24 rounded-none border border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
                  <img src={form.image_url} alt="Note" className="w-full h-full object-cover" />
                  <button type="button" onClick={() => setForm({ ...form, image_url: "" })} className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600">
                    <X className="w-3.5 h-3.5 text-white" />
                  </button>
                </div>
              ) : (
                <label className="flex items-center justify-center gap-2 w-full h-24 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                  <Upload className="w-4 h-4 text-muted-foreground" />
                  <span className="text-xs font-body text-muted-foreground">اضغط للرفع Click to upload</span>
                  <input type="file" onChange={handleUploadImage} disabled={uploading} accept="image/*" className="hidden" />
                </label>
              )}
            </div>

            <Button className="w-full rounded-none font-body" onClick={() => createMutation.mutate(form)} disabled={createMutation.isPending || uploading || !form.name}>
              {createMutation.isPending ? "Saving..." : "Add Note"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function NotesIndexContent({
  notes,
  isLoading,
  search,
  setSearch,
  allowedFilter,
  setAllowedFilter,
  catFilter,
  setCatFilter,
  pyramidFilter,
  setPyramidFilter,
  odorFilter,
  setOdorFilter,
  noteCount,
  perfumes,
  levelFilter = "all",
}) {
  const PYRAMID_LABELS = { top: "Top", heart: "Heart", base: "Base", conductor: "Conductor", all: "All Layers" };
  const CATEGORIES = [
    "Floral زهري",
    "Woody خشبي",
    "Citrus حمضي",
    "Oriental شرقي",
    "Spicy توابل",
    "Aquatic مائي",
    "Fruity فاكهي",
    "Green أخضر",
    "Gourmand حلو",
    "Earthy ترابي",
    "Musky مسكي",
    "Powdery بودرة",
    "Resinous راتنجي"
  ];
  const ODOR_FAMILIES = [
    "Fresh منعش",
    "Warm دافئ",
    "Sweet حلو",
    "Dry جاف",
    "Green أخضر",
    "Earthy ترابي",
    "Aquatic مائي",
    "Smoky دخاني",
    "Creamy كريمي",
    "Leathery جلدي"
  ];

  const filterNote = (note) => {
    if (note.hidden) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      if (!note.name?.toLowerCase().includes(q) && !note.name_ar?.includes(search) && !note.category?.toLowerCase().includes(q) && !note.odor_family?.toLowerCase().includes(q) && !note.origin?.toLowerCase().includes(q)) return false;
    }
    if (catFilter !== "all") {
      const noteCats = (note.category || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!noteCats.includes(catFilter)) return false;
    }
    if (pyramidFilter !== "all") {
      const notePyramids = (note.pyramid || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!notePyramids.includes(pyramidFilter)) return false;
    }
    if (odorFilter !== "all") {
      const noteOdors = (note.odor_family || "").split(",").map(s => s.trim()).filter(Boolean);
      if (!noteOdors.includes(odorFilter)) return false;
    }
    if (allowedFilter !== "all") {
      const isAllowed = note.is_allowed !== false; // default true
      if (allowedFilter === "allowed" && !isAllowed) return false;
      if (allowedFilter === "banned" && isAllowed) return false;
    }
    if (levelFilter !== "all" && note.note_category !== levelFilter) return false;
    return true;
  };

  const mainNotes = notes.filter(n => n.note_category === "main_note" && filterNote(n));
  const subNotes = notes.filter(n => (!n.note_category || n.note_category === "sub_notes") && filterNote(n));
  const lowNotes = notes.filter(n => n.note_category === "low_notes" && filterNote(n));
  const restrictedNotes = notes.filter(n => n.is_allowed === false && filterNote(n));

  return (
    <div className="space-y-3 pb-20">
      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input value={search} onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث في النوتات... / Search notes..." className="pl-9 rounded-none h-10 font-body text-sm" />
      </div>

      {/* Filters */}
      <div className="space-y-2">
        {/* Categories */}
        <div className="space-y-1">
          <p className="text-xs font-body font-semibold text-muted-foreground px-1">التصنيفات Categories</p>
          <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)}
            className="text-xs font-body font-medium rounded-none cursor-pointer w-full">
            <option value="all">كل التصنيفات All Categories</option>
            {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
        {/* Odor Families */}
        <div className="space-y-1">
          <p className="text-xs font-body font-semibold text-muted-foreground px-1">العائلات Odor Families</p>
          <select value={odorFilter} onChange={(e) => setOdorFilter(e.target.value)}
            className="text-xs font-body font-medium rounded-none cursor-pointer w-full">
            <option value="all">كل العائلات All Odor</option>
            {ODOR_FAMILIES.map(f => <option key={f} value={f}>{f}</option>)}
          </select>
        </div>
        {/* Usage Status (IFRA) */}
        <div className="space-y-1">
          <p className="text-xs font-body font-semibold text-muted-foreground px-1">الاستخدام Status</p>
          <select value={allowedFilter} onChange={(e) => setAllowedFilter(e.target.value)}
            className="text-xs font-body font-medium rounded-none cursor-pointer w-full">
            <option value="all">كل النوتات All Notes</option>
            <option value="allowed">مسموح Allowed</option>
            <option value="banned">مقيد-غير مسموح Restricted-Not Allowed</option>
          </select>
        </div>
        {/* Pyramid */}
        <div className="space-y-1">
          <p className="text-xs font-body font-semibold text-muted-foreground px-1">الهرم Pyramid</p>
          <div className="grid grid-cols-5 gap-1">
            {["all", "top", "heart", "base", "conductor"].map((p) => (
              <button key={p} onClick={() => setPyramidFilter(p)}
                className={`text-[10px] font-body font-medium rounded-none transition-colors text-center ${pyramidFilter === p ? " text-primary-foreground " : " text-muted-foreground"}`}>
                {p === "all" ? "All" : PYRAMID_LABELS[p]}
              </button>
            ))}
          </div>
        </div>
      </div>

      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {!isLoading && notes.length === 0 && (
        <div className="text-center py-16 space-y-3">
          <Flower2 className="w-12 h-12 text-primary/20 mx-auto" />
          <p className="text-muted-foreground font-body text-sm">No notes yet. Tap + to add the first ingredient.</p>
        </div>
      )}

      {!isLoading && notes.length > 0 && (
        <NotesThreeColumns
          mainNotes={mainNotes}
          subNotes={subNotes}
          lowNotes={lowNotes}
          noteCount={noteCount}
        />
      )}
    </div>
  );
}

const NOTE_CAT_BADGE = {
  main_note:  { label: "Main",  cls: "bg-emerald-100 text-emerald-700" },
  sub_notes:  { label: "Sub",   cls: "bg-sky-100 text-sky-700" },
  low_notes:  { label: "Low",   cls: "bg-amber-100 text-amber-700" },
};
const PYRAMID_BADGE = {
  top:       { label: "Top",       cls: "bg-sky-50 text-sky-600 border border-sky-200" },
  heart:     { label: "Heart",     cls: "bg-rose-50 text-rose-600 border border-rose-200" },
  base:      { label: "Base",      cls: "bg-amber-50 text-amber-600 border border-amber-200" },
  conductor: { label: "Conductor", cls: "bg-teal-50 text-teal-600 border border-teal-200" },
  all:       { label: "All",       cls: "bg-violet-50 text-violet-600 border border-violet-200" },
};

const NOTE_CAT_TEXT = {
  main_note: "text-emerald-600",
  sub_notes:  "text-sky-600",
  low_notes:  "text-amber-600",
};
// إطار لوني إضافي (حلقة) حول الإطار الذهبي — يميّز فئة النوتة دون تغيير صورتها.
const NOTE_CAT_RING = {
  main_note: "ring-emerald-400",
  sub_notes:  "ring-sky-400",
  low_notes:  "ring-amber-400",
};
const PYRAMID_TEXT = {
  top:       "text-sky-500",
  heart:     "text-rose-500",
  base:      "text-amber-500",
  conductor: "text-teal-500",
  all:       "text-violet-500",
};

function NoteRow({ note, count }) {
  const catKey = note.note_category || "sub_notes";
  const catLabel = NOTE_CAT_BADGE[catKey]?.label || "Sub";
  const catTextCls = NOTE_CAT_TEXT[catKey] || "text-sky-600";
  const catRing = NOTE_CAT_RING[catKey] || "ring-sky-400";
  const pyramids = (note.pyramid || "").split(",").map(s => s.trim()).filter(Boolean).slice(0, 2);
  const odorFamily = (note.odor_family || "").split(",")[0].trim();

  return (
    <Link to={`/note?id=${note.id}`} className="flex items-center gap-3 px-3 py-2.5 hover:bg-secondary/30 transition-colors">
      {/* صورة النوتة: إطار ذهبي + حلقة لونية إضافية حسب الفئة. لا نبدّل الصورة المفقودة
          إلى قارورة العطر العامة (data-img-fallback=1 يتخطّى المعالج العام)؛ نُخفي الصورة
          المكسورة فيظهر الصندوق النظيف الموحّد بدل القارورة. */}
      <div className="w-9 h-9 overflow-hidden flex-shrink-0 flex items-center justify-center" style={{ background: "transparent" }}>
        {note.image_url
          ? <img src={note.image_url} alt={note.name} data-img-fallback="1" onError={(e) => { e.currentTarget.style.display = "none"; }} className="w-full h-full object-contain" style={{ background: "transparent" }} />
          : <div className="w-full h-full" />
        }
      </div>

      {/* الاسم + العائلة */}
      <div className="flex-1 min-w-0">
        <p className={`text-[13px] font-heading font-semibold truncate leading-tight tracking-tight ${note.is_allowed === false ? "text-red-600 line-through decoration-red-500 decoration-2" : ""}`}>
          {note.name}
        </p>
        {odorFamily && (
          <p className="text-[10px] font-body text-muted-foreground/70 truncate mt-0.5">{odorFamily}</p>
        )}
      </div>

      {/* الجهة اليمنى: labels نصية شفافة */}
      <div className="flex flex-col items-end gap-0.5 flex-shrink-0">
        <span className={`text-[10px] font-body font-semibold ${catTextCls}`}>{catLabel}</span>
        {pyramids.length > 0 && (
          <div className="flex items-center gap-1">
            {pyramids.map(p => PYRAMID_TEXT[p] ? (
              <span key={p} className={`text-[9px] font-body ${PYRAMID_TEXT[p]}`}>{PYRAMID_BADGE[p]?.label || p}</span>
            ) : null)}
          </div>
        )}
        {count > 0 && (
          <span className="text-[9px] font-body font-bold text-primary/60">{count}</span>
        )}
      </div>
    </Link>
  );
}

function NotesTwoColumns({ mainSubNotes, noteCount }) {
  const LIMIT = 50;
  const [page, setPage] = useState(0);
  const paginated = mainSubNotes.slice(page * LIMIT, (page + 1) * LIMIT);

  return (
    <div className="space-y-2 pb-6">
      <p className="text-[10px] font-body font-bold text-emerald-700 px-1 uppercase tracking-wider">
        Main & Sub Notes <span className="font-normal opacity-70">({mainSubNotes.length})</span>
      </p>
      <div className="bg-card rounded-none border border-border overflow-hidden divide-y divide-border">
        {paginated.map(note => (
          <NoteRow key={note.id} note={note} count={noteCount[note.name?.toLowerCase()] || 0} />
        ))}
      </div>
      {mainSubNotes.length > LIMIT && (
        <div className="flex justify-center gap-2 pt-1">
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
            className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">‹</button>
          <span className="text-[10px] font-body text-muted-foreground">{page + 1}/{Math.ceil(mainSubNotes.length / LIMIT)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * LIMIT >= mainSubNotes.length}
            className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">›</button>
        </div>
      )}
    </div>
  );
}

function SubLowPaginatedList({ notes, noteCount, borderColor }) {
  const LIMIT = 50;
  const [page, setPage] = useState(0);
  const paginated = notes.slice(page * LIMIT, (page + 1) * LIMIT);
  return (
    <div className="space-y-2">
      <div className={`bg-card rounded-none border ${borderColor} overflow-hidden divide-y divide-border`}>
        {paginated.map(note => (
          <NoteRow key={note.id} note={note} count={noteCount[note.name?.toLowerCase()] || 0} />
        ))}
      </div>
      {notes.length > LIMIT && (
        <div className="flex justify-center gap-2 pt-1">
          <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
            className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">‹</button>
          <span className="text-[10px] font-body text-muted-foreground">{page + 1}/{Math.ceil(notes.length / LIMIT)}</span>
          <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * LIMIT >= notes.length}
            className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">›</button>
        </div>
      )}
    </div>
  );
}

function NotesThreeColumns({ mainNotes, subNotes, lowNotes, noteCount }) {
  const LIMIT = 50;
  const [mainPage, setMainPage] = useState(0);
  const [subPage, setSubPage] = useState(0);
  const [lowPage, setLowPage] = useState(0);
  const [collapsed, setCollapsed] = useState({ main: false, sub: false, low: false });

  const paginate = (list, page) => list.slice(page * LIMIT, (page + 1) * LIMIT);

  const renderSection = (key, title, list, page, setPage, titleColor) => {
    const isCollapsed = collapsed[key];
    return (
      <div className="space-y-2">
        <button
          onClick={() => setCollapsed(c => ({ ...c, [key]: !c[key] }))}
          className={`flex items-center gap-2 w-full text-left px-1 group`}
        >
          <span className={`text-[10px] font-body font-bold uppercase tracking-wider ${titleColor}`}>
            {title} <span className="font-normal opacity-70">({list.length})</span>
          </span>
          <span className={`text-[10px] text-muted-foreground ml-auto transition-transform ${isCollapsed ? "" : "rotate-180"}`}>▲</span>
        </button>
        {!isCollapsed && (
          <>
            {list.length === 0
              ? <p className="text-[10px] text-muted-foreground font-body text-center py-4">—</p>
              : <div className="bg-card rounded-none border border-border overflow-hidden divide-y divide-border">
                  {paginate(list, page).map(note => (
                    <NoteRow key={note.id} note={note} count={noteCount[note.name?.toLowerCase()] || 0} />
                  ))}
                </div>
            }
            {list.length > LIMIT && (
              <div className="flex justify-center gap-2 pt-1">
                <button onClick={() => setPage(p => Math.max(0, p - 1))} disabled={page === 0}
                  className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">‹</button>
                <span className="text-[10px] font-body text-muted-foreground">{page + 1}/{Math.ceil(list.length / LIMIT)}</span>
                <button onClick={() => setPage(p => p + 1)} disabled={(page + 1) * LIMIT >= list.length}
                  className="text-[10px] font-body px-2 py-1 rounded border disabled:opacity-30">›</button>
              </div>
            )}
          </>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      {renderSection("main", "Main", mainNotes, mainPage, setMainPage, "text-emerald-600")}
      {renderSection("sub", "Sub", subNotes, subPage, setSubPage, "text-sky-600")}
      {renderSection("low", "Low", lowNotes, lowPage, setLowPage, "text-amber-600")}
    </div>
  );
}