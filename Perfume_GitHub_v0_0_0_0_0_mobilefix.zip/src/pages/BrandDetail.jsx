import { useState, useEffect, useMemo } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { decadeFromYear } from "@/lib/decade";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import {
  ArrowLeft, Building2, Globe, Edit2, Heart, HeartOff, Upload, X, Download, AArrowUp, AArrowDown
} from "lucide-react";
import BrandLogo from "@/components/brand/BrandLogo";
import AccordFlacon, { dominantAccord } from "@/components/perfume/AccordFlacon";
import StarRating from "@/components/perfume/StarRating";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { captureElement } from "@/lib/captureCanvas";
import EditPurchaseDialog from "@/components/purchase/EditPurchaseDialog";
import NotesTagSearch from "@/components/maestro/NotesTagSearch";
import HealthRatingSection from "@/components/perfume/HealthRatingSection";
import BrandPerfumersSection from "@/components/brand/BrandPerfumersSection";
import { openExternalUrl, saveCanvasAsImage, downloadBlob } from "@/lib/exportHelper";
import { ExportHeader, ExportFooter } from "@/lib/exportHeader";
import BilingualText from "@/components/export/BilingualText";
import ExportOptionsBar from "@/components/export/ExportOptionsBar";
import CopyMenu from "@/components/shared/CopyMenu";
import { brandDbText, brandFullText } from "@/lib/copyData";
import BookmarkButton from "@/components/shared/BookmarkButton";
import PinButton from "@/components/shared/PinButton";
import LuxuryCardExport from "@/components/export/LuxuryCardExport";

// Brand collections are derived automatically from the perfume name
// (e.g. "Private Blend Tobacco Vanille" → "Private Blend"). These are brand
// lines/collections, distinct from a user's personal lists.
const KNOWN_COLLECTIONS = [
  "Private Blend", "Signature", "Le Parfum", "Les Exclusifs", "La Collection",
  "Maison", "Exclusive Collection", "Prive", "Privé", "Collection Privée",
  "Atelier", "Heritage", "Reserve", "Limited Edition", "Extrait", "Absolu",
  "Oud Collection", "Water Collection", "Cologne Collection", "Replica",
  "Aqua", "Acqua", "Velvet Collection", "Noir Collection",
];
function deriveCollection(name) {
  if (!name) return "";
  for (const c of KNOWN_COLLECTIONS) {
    if (name.toLowerCase().includes(c.toLowerCase())) return c;
  }
  return "";
}

// لون إطار الصندوق حسب الجنس — نفس ألوان صفحة /explore (PerfumeCard).
// يدعم تسميتي البيانات: Men/Male، Women/Female، Unisex.
const GENDER_BORDER = {
  Men: "#22c55e", Male: "#22c55e",
  Women: "#f472b6", Female: "#f472b6",
  Unisex: "#fcd34d",
};
// اختصار بنقطتين «..» (لا ثلاث نقاط) عند طول النص.
function clip2(s, n) {
  const t = String(s || "");
  return t.length > n ? t.slice(0, n).replace(/\s+$/, "") + ".." : t;
}
// اختصار نوع العطر للزاوية (كثير من عطور القاعدة الجديدة بلا نوع → فارغ).
function shortType(t) {
  if (!t) return "";
  const s = String(t);
  if (/edp|de parfum/i.test(s)) return "EDP";
  if (/edt|de toilette/i.test(s)) return "EDT";
  if (/edc|de cologne/i.test(s)) return "EDC";
  if (/extrait/i.test(s)) return "Extrait";
  if (/fra[iî]che/i.test(s)) return "Fraîche";
  if (/parfum/i.test(s)) return "Parfum";
  return s.length > 8 ? s.slice(0, 8) : s;
}

export default function BrandDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const id = urlParams.get("id");
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { formatPrice } = useCurrency();
  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState(null);
  const [showParentSuggestions, setShowParentSuggestions] = useState(false);
  const [userData, setUserData] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [activePerson, setActivePerson] = useState("person1");
  const [pSortMode, setPSortMode] = useState("year"); // year | gender | season | alpha
  const [pPage, setPPage] = useState(0);
  const PERFUMES_PER_PAGE = 50;
  const [editNotes, setEditNotes] = useState(false);
  const [notesValue, setNotesValue] = useState("");
  const [exportOpen, setExportOpen] = useState(false);
  const [exportPerson, setExportPerson] = useState("person1");
  const [exportNoteLang, setExportNoteLang] = useState("en"); // en | ar | both
  const [exportBg, setExportBg] = useState("#ffffff");
  const [exportTextColor, setExportTextColor] = useState(""); // "" = auto
  const [exportFormat, setExportFormat] = useState("image");
  const [exportLoading, setExportLoading] = useState(false);
  const [exportOptions, setExportOptions] = useState({
    includeDescription: true,
    includePerfumers: true,
    includeSignatureNotes: true,
    includeInnovationNotes: true,
    includeOccasions: true,
    includeTopPerfumes: true,
    includeTopCollections: true,
    includeImpression: true,
    includeRating: true,
    includeOtherRating: true,
    includeFavorite: true,
    includeReview: true,
    includePurchases: true,
    includeHealth: true,
  });

  useEffect(() => {
    apphost.auth.me().then(setUserData).catch(() => {});
  }, []);

  // ── Fav / Dislike ──
  const favBrandsP1 = userData?.fav_brands_p1 ? userData.fav_brands_p1.split(",").map(s => s.trim()).filter(Boolean) : [];
  const favBrandsP2 = userData?.fav_brands_p2 ? userData.fav_brands_p2.split(",").map(s => s.trim()).filter(Boolean) : [];
  const dislikeBrandsP1 = userData?.dislike_brands_p1 ? userData.dislike_brands_p1.split(",").map(s => s.trim()).filter(Boolean) : [];
  const dislikeBrandsP2 = userData?.dislike_brands_p2 ? userData.dislike_brands_p2.split(",").map(s => s.trim()).filter(Boolean) : [];

  const toggleOpinion = async (person, brandId, type) => {
    const favKey = person === "person1" ? "fav_brands_p1" : "fav_brands_p2";
    const dislikeKey = person === "person1" ? "dislike_brands_p1" : "dislike_brands_p2";
    const currentFav = person === "person1" ? favBrandsP1 : favBrandsP2;
    const currentDislike = person === "person1" ? dislikeBrandsP1 : dislikeBrandsP2;
    let newFav = currentFav;
    let newDislike = currentDislike;
    if (type === "fav") {
      newFav = currentFav.includes(brandId) ? currentFav.filter(b => b !== brandId) : [...currentFav.filter(b => b !== brandId), brandId];
      newDislike = currentDislike.filter(b => b !== brandId);
    } else {
      newDislike = currentDislike.includes(brandId) ? currentDislike.filter(b => b !== brandId) : [...currentDislike.filter(b => b !== brandId), brandId];
      newFav = currentFav.filter(b => b !== brandId);
    }
    const updates = { [favKey]: newFav.join(","), [dislikeKey]: newDislike.join(",") };
    await apphost.auth.updateMe(updates);
    setUserData({ ...userData, ...updates });
    toast.success((isAr ? "تم التحديث" : "Updated"));
  };

  // ── Brand data ──
  const { data: brand, isLoading } = useQuery({
    queryKey: ["brand", id],
    queryFn: async () => {
      const results = await apphost.entities.PerfumeBrand.filter({ id });
      return results?.[0] || null;
    },
    enabled: !!id,
  });

  // ── Perfumes by brand ──
  // المسار السريع: إن خُزّنت perfume_ids للبراند وقت الزراعة، نجلب بالمعرّف عبر
  // getMany — بلا مسح 130 ألف. وإلا نرجع لمسار filter القديم (نفس النتيجة) للبيانات
  // القديمة أو البراندات غير المطابقة.
  const brandPerfumeIds = brand?.perfume_ids
    ? brand.perfume_ids.split(",").map((s) => s.trim()).filter(Boolean)
    : [];
  const hasBrandIds = brandPerfumeIds.length > 0;
  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes-by-brand", brand?.name, hasBrandIds, brandPerfumeIds.length],
    queryFn: () =>
      hasBrandIds
        ? apphost.entities.Perfume.getMany(brandPerfumeIds)
        : apphost.entities.Perfume.filter({ brand_name: brand.name }),
    enabled: !!brand?.name,
  });

  // ── Collections by brand ──
  const { data: collections = [] } = useQuery({
    queryKey: ["collections-by-brand", id],
    queryFn: () => apphost.entities.PerfumeCollection.filter({ brand_id: id }),
    enabled: !!id,
  });

  // مجموعات تلقائية مُشتقّة من حقل `collection` في العطر نفسه (مثل Versace → Eros).
  // تُدمج مع المجموعات اليدوية حتى تظهر مجموعات القاعدة وعطورها داخل البراند.
  const displayCollections = useMemo(() => {
    const manual = collections || [];
    const manualNames = new Set(manual.map((c) => (c.name || "").trim().toLowerCase()).filter(Boolean));
    const autoMap = {};
    (perfumes || []).forEach((p) => {
      const c = (p.collection || "").trim();
      if (!c || manualNames.has(c.toLowerCase())) return;
      (autoMap[c] = autoMap[c] || []).push(p);
    });
    const auto = Object.keys(autoMap)
      .sort((a, b) => a.localeCompare(b))
      .map((name) => ({ id: "auto:" + name, name, name_ar: "", auto: true }));
    return [...manual, ...auto];
  }, [collections, perfumes]);

  const getCollectionPerfumes = (col) => {
    const list = col.auto
      ? (perfumes || []).filter((p) => (p.collection || "").trim() === col.name)
      : (perfumes || []).filter((p) => p.collection_id === col.id);
    return [...list].sort((a, b) => {
      if (b.release_year && a.release_year) return b.release_year - a.release_year;
      if (b.release_year) return 1;
      if (a.release_year) return -1;
      return new Date(b.created_date) - new Date(a.created_date);
    });
  };

  const [showAddCollection, setShowAddCollection] = useState(false);
  const [newCollection, setNewCollection] = useState({ name: "", name_ar: "", description: "" });
  const [savingCollection, setSavingCollection] = useState(false);

  const handleAddCollection = async () => {
    if (!newCollection.name) { toast.error((isAr ? "اسم المجموعة مطلوب" : "Collection name required")); return; }
    setSavingCollection(true);
    await apphost.entities.PerfumeCollection.create({ ...newCollection, brand_id: id, brand_name: brand.name });
    queryClient.invalidateQueries({ queryKey: ["collections-by-brand", id] });
    setNewCollection({ name: "", name_ar: "", description: "" });
    setShowAddCollection(false);
    setSavingCollection(false);
    toast.success((isAr ? "أُضيفت المجموعة" : "Collection added"));
  };

  // ── UserBrand per person ──
  const { data: userBrands = [] } = useQuery({
    queryKey: ["user-brand", id],
    queryFn: () => apphost.entities.UserBrand.filter({ brand_id: id }),
    enabled: !!id,
  });
  const userDataP1 = userBrands.find(u => u.person === "person1") || null;
  const userDataP2 = userBrands.find(u => u.person === "person2") || null;


  const activeUserData = activePerson === "person1" ? userDataP1 : userDataP2;

  // ── Sibling brands (same owned_by / parent_company) ──
  const { data: allBrands = [] } = useQuery({
    queryKey: ["brands-light"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  // ── Purchase records linked to any perfume of this brand ──
  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records-brand", brand?.name],
    queryFn: () => apphost.entities.PurchaseRecord.filter({ brand_name: brand.name }, "-created_date"),
    enabled: !!brand?.name,
  });

  // متاجر التسوّق (ShopBrand) — كيان المتاجر الموحّد المستخدم في المشتريات والتسوّق.
  // (أُزيل استعلام Store القديم؛ التوحيد على ShopBrand.)
  const { data: shopBrands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });
  const brandStore = brand
    ? shopBrands.find(
        (s) =>
          String(s.source_brand_id || "") === String(brand.id) ||
          ((s.name || "") === (brand.name || "") && s.type === "perfume_store")
      )
    : null;
  const [storeToggling, setStoreToggling] = useState(false);
  const toggleBrandStore = async () => {
    if (!brand || storeToggling) return;
    setStoreToggling(true);
    try {
      if (brandStore) {
        await apphost.entities.ShopBrand.delete(brandStore.id);
        toast.success(isAr ? "أُزيل من المتاجر" : "Removed from stores");
      } else {
        await apphost.entities.ShopBrand.create({
          name: brand.name,
          name_ar: brand.name_ar || "",
          type: "perfume_store",
          logo_url: brand.logo_url || null,
          website: brand.website || null,
          country: brand.country || "",
          person: "family",
          category_name_en: "Perfume",
          category_name_ar: "عطور",
          source: "from_brand",
          source_brand_id: String(brand.id),
        });
        toast.success(isAr ? "أُضيف للمتاجر — التسوّق ← المتاجر ← العطور" : "Added to stores — Shopping > Stores > Perfume");
      }
      await queryClient.invalidateQueries({ queryKey: ["shop-brands"] });
    } catch (e) {
      toast.error(isAr ? "تعذّر التحديث" : "Update failed");
    } finally {
      setStoreToggling(false);
    }
  };

  // ── All Perfumers (for Arabic names in export) ──
  const { data: allPerfumers = [] } = useQuery({
    queryKey: ["all-perfumers-export"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
    staleTime: 1000 * 60 * 10,
  });
  const perfumersMapByName = {};
  allPerfumers.forEach(p => { if (p.name) perfumersMapByName[p.name.toLowerCase()] = p; });

  // ── Unified description (merges legacy description_ar + bio fields) ──
  const unifiedDescription = (() => {
    if (!brand) return "";
    const parts = [
      brand.description?.trim(),
      brand.description_ar?.trim(),
      brand.bio?.trim(),
    ].filter(Boolean);
    const seen = new Set();
    return parts.filter(p => {
      const key = p.toLowerCase().replace(/\s+/g, ' ');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).join("\n\n");
  })();

  // ── Signature Notes ──
  const { data: allNotes = [] } = useQuery({
    queryKey: ["perfume-notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  // Get signature notes data
  const signatureNoteIds = brand?.signature_notes_ids ? brand.signature_notes_ids.split(",").map(s => s.trim()).filter(Boolean) : [];
  const signatureNotes = signatureNoteIds.map(id => allNotes.find(n => String(n.id) === String(id))).filter(Boolean);

  // ── Upsert UserBrand ──
  const upsertUserBrand = useMutation({
    mutationFn: async ({ person, field, value }) => {
      const existing = person === "person1" ? userDataP1 : userDataP2;
      const dataToSave = { [field]: value };
      if (existing) {
        return apphost.entities.UserBrand.update(existing.id, dataToSave);
      } else {
        return apphost.entities.UserBrand.create({
          brand_id: id,
          brand_name: brand?.name,
          person,
          ...dataToSave,
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["user-brand", id] });
    },
  });

  // ── Brand edit ──
  const updateMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeBrand.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["brand", id] });
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success((isAr ? "حُدّث البراند" : "Brand updated"));
      setEditOpen(false);
    },
  });

  const openEdit = () => {
    // Auto-migrate legacy innovation_notes into signature_notes_names
    let signatureNames = brand.signature_notes_names || "";
    if (brand.innovation_notes && brand.innovation_notes.trim()) {
      const existing = signatureNames.split(",").map(s => s.trim()).filter(Boolean);
      const innovations = brand.innovation_notes.split(",").map(s => s.trim()).filter(Boolean);
      const merged = [...existing];
      for (const n of innovations) if (!merged.includes(n)) merged.push(n);
      signatureNames = merged.join(",");
    }

    // Auto-merge description_ar + bio into description (unified field)
    const parts = [
      brand.description?.trim(),
      brand.description_ar?.trim(),
      brand.bio?.trim(),
    ].filter(Boolean);
    // Dedup: if user already wrote AR in description, don't duplicate from description_ar
    const seen = new Set();
    const uniqueParts = parts.filter(p => {
      const key = p.toLowerCase().replace(/\s+/g, ' ');
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
    const mergedDescription = uniqueParts.join("\n\n");

    setForm({
      ...brand,
      signature_notes_names: signatureNames,
      innovation_notes: "", // legacy
      description: mergedDescription,
      description_ar: "",   // legacy — content now lives in description
      bio: "",               // legacy — content now lives in description
    });
    setEditOpen(true);
  };

  const handleUploadLogo = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await apphost.integrations.Core.UploadFile({ file });
      setForm(prev => ({ ...prev, logo_url: result.file_url }));
      toast.success((isAr ? "رُفع الشعار" : "Logo uploaded"));
    } catch { toast.error((isAr ? "فشل الرفع" : "Upload failed")); }
    setUploading(false);
  };

  // ── Export ──
  const handleExport = async () => {
    console.log("🖼️ Export started — format:", exportFormat);
    const el = document.getElementById("brand-export-card");
    if (!el) {
      console.error("Export card element not found");
      toast.error((isAr ? "بطاقة التصدير غير موجودة" : "Export card not found"));
      return;
    }
    console.log("Found export element:", el.offsetWidth, "x", el.offsetHeight);
    setExportLoading(true);
    try {
      const brandSlug = (brand.name || "brand").toLowerCase().replace(/[^a-z0-9]/gi, "").slice(0, 15) || "brand";
      const timestamp = Date.now();

      console.log("📸 Rendering with html2canvas...");

      // Use a FIXED export width independent of dialog dimensions, otherwise
      // the on-screen offsetWidth (constrained by max-w on small viewports)
      // forces the export layout to wrap too aggressively and content gets clipped.
      const EXPORT_WIDTH = 820;

      // Clone to off-screen wrapper to avoid scroll/RTL mirror issues
      const clone = el.cloneNode(true);
      const wrapper = document.createElement("div");
      wrapper.style.cssText = [
        "position: fixed",
        "top: 0",
        "left: 0",
        "z-index: -1",
        "opacity: 1",
        "pointer-events: none",
        "background: #ffffff",
        "width: " + EXPORT_WIDTH + "px",
        "max-width: none",
        "max-height: none",
        "overflow: visible",
      ].join("; ");
      clone.style.maxHeight = "none";
      clone.style.overflow = "visible";
      clone.style.width = EXPORT_WIDTH + "px";
      wrapper.appendChild(clone);
      document.body.appendChild(wrapper);

      // Two rAF flushes for layout
      await new Promise((r) => requestAnimationFrame(() => requestAnimationFrame(r)));

      // Wait for all <img> inside the clone to finish loading.
      // Without this, html2canvas captures missing images and the export looks
      // half-empty even though the data exists.
      const imgs = Array.from(clone.querySelectorAll("img"));
      await Promise.all(imgs.map((img) => {
        if (img.complete && img.naturalWidth > 0) return Promise.resolve();
        return new Promise((res) => {
          img.onload = img.onerror = () => res();
          setTimeout(res, 3000); // hard timeout
        });
      }));
      // One more rAF after images load
      await new Promise((r) => requestAnimationFrame(r));

      const fullWidth = clone.scrollWidth;
      const fullHeight = clone.scrollHeight;

      const canvas = await captureElement(clone, {
        backgroundColor: "#ffffff",
        scale: 3,
        useCORS: false,
        allowTaint: false,
        logging: false,
        width: fullWidth,
        height: fullHeight,
        windowWidth: fullWidth,
        windowHeight: fullHeight,
      });

      document.body.removeChild(wrapper);

      // Cap longest side at 1080 with high-quality smoothing (supersampled above).
      let outCanvas = canvas;
      const longest = Math.max(canvas.width, canvas.height);
      if (longest > 1080) {
        const ratio = 1080 / longest;
        outCanvas = document.createElement("canvas");
        outCanvas.width = Math.round(canvas.width * ratio);
        outCanvas.height = Math.round(canvas.height * ratio);
        const ctx = outCanvas.getContext("2d");
        ctx.imageSmoothingEnabled = true;
        ctx.imageSmoothingQuality = "high";
        ctx.drawImage(canvas, 0, 0, outCanvas.width, outCanvas.height);
      }
      console.log("Canvas rendered:", outCanvas.width, "x", outCanvas.height);

      if (exportFormat === "image") {
        await saveCanvasAsImage(outCanvas, `${brandSlug}-review-${timestamp}.png`);
        console.log("Image downloaded");
        toast.success((isAr ? "صُدّرت الصورة" : "Image exported"));
      } else {
        const { jsPDF } = await import("jspdf");
        const pdf = new jsPDF("portrait", "mm", "a4");
        const imgWidth = 210;
        const imgHeight = (outCanvas.height * imgWidth) / outCanvas.width;
        pdf.addImage(outCanvas.toDataURL("image/png"), "PNG", 0, 0, imgWidth, imgHeight);
        const pdfBlob = pdf.output('blob');
        await downloadBlob(pdfBlob, `${brandSlug}-review-${timestamp}.pdf`);
        console.log("PDF saved");
        toast.success((isAr ? "صُدّر الملف" : "PDF exported"));
      }
      setExportOpen(false);
    } catch (err) {
      console.error("Export failed:", err);
      toast.error((isAr ? "فشل التصدير" : "Export failed:") + (err?.message || "Unknown error"));
    }
    setExportLoading(false);
  };

  if (isLoading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
    </div>
  );

  if (!brand) return (
    <div className="px-5 pt-12 text-center space-y-4">
      <p className="text-muted-foreground font-body">{isAr ? "البراند غير موجود" : "Brand not found"}</p>
      <Button variant="ghost" onClick={() => navigate("/brands")}>{isAr ? "رجوع" : "Go Back"}</Button>
    </div>
  );

  const displayName = isAr ? (brand.name_ar || brand.name) : brand.name;
  const hasBestOfDecade = (perfumes || []).some((p) => p.best_of_decade && decadeFromYear(p.release_year) !== null);
  const displayCountry = isAr ? (brand.country_ar || brand.country) : brand.country;

  // Show all purchases (both persons), sorted by date
  const activePurchases = purchaseRecords;
  const totalSpent = activePurchases.reduce((s, r) => s + (r.cost || 0), 0);
  const totalMl = activePurchases.reduce((s, r) => s + (r.ml || 0), 0);

  // Export card data
  const getExportUserData = () => {
    if (exportPerson === "all") return null;
    return exportPerson === "person1" ? userDataP1 : userDataP2;
  };
  const exportUserData = getExportUserData();
  const exportPurchases = exportPerson === "all" 
    ? purchaseRecords 
    : purchaseRecords.filter(r => r.person === exportPerson);
  const exportName = exportPerson === "all" 
    ? (isAr ? "الجميع" : "All Users") 
    : (exportPerson === "person1" ? names.person1 : names.person2);

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-white px-5 pt-6 pb-0">
        <div className="flex items-center justify-between mb-4">
          <Button variant="ghost" size="icon" className="rounded-none hover:bg-white/20" onClick={() => navigate("/perfumes")}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          {/* Bookmark + Copy moved to the bottom of the page */}
        </div>
        <div className="flex flex-col items-center gap-6 pb-8">
           <div className="w-40 h-40 rounded-none bg-white shadow-lg flex items-center justify-center flex-shrink-0 overflow-hidden border-2 border-yellow-400/50">
             <BrandLogo brand={brand} imgClassName="w-full h-full object-contain p-4" initialsSize={52} />
           </div>
           <div className="text-center space-y-2">
             <h1 className="font-heading text-3xl font-bold leading-tight">{isAr ? (brand.name_ar || brand.name) : brand.name}</h1>
             {isAr && brand.name_ar && <p className="text-sm text-muted-foreground font-body">{brand.name}</p>}
             {!isAr && brand.name_ar && <p className="text-sm text-muted-foreground font-body">{brand.name_ar}</p>}
             {hasBestOfDecade && (
               <div className="flex items-center justify-center gap-1.5 pt-0.5">
                 <svg width="34" height="9" viewBox="0 0 34 9" aria-hidden="true">
                   <g fill="#3B6D11">
                     <rect x="1.5" y="1.5" width="3" height="6" />
                     <rect x="7.5" y="1.5" width="3" height="6" />
                     <rect x="13.5" y="1.5" width="3" height="6" />
                     <rect x="19.5" y="1.5" width="3" height="6" />
                     <rect x="25.5" y="1.5" width="3" height="6" />
                   </g>
                 </svg>
                 <span className="text-[10px] font-body text-muted-foreground tracking-wide">{isAr ? "لديه عطور أفضل العقد" : "Has best-of-decade perfumes"}</span>
               </div>
             )}
           </div>
         </div>
      </div>

      <div className="px-5 space-y-5 mt-5">

        {/* About — description first, then meta row below */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          {unifiedDescription && (
            <p className="text-sm font-body text-foreground/80 leading-relaxed whitespace-pre-line">{unifiedDescription}</p>
          )}
          {/* meta row: website globe + country + est + activity status */}
          <div className="flex flex-wrap items-center gap-3 text-xs font-body pt-1">
            {brand.website && (
              <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(brand.website); }}
                aria-label={isAr ? "موقع البراند" : "Brand website"} title={brand.website}
                className="text-sky-600 hover:text-sky-700 transition-colors">
                <Globe className="w-4 h-4" />
              </button>
            )}
            {displayCountry && (
              <Link
                to={`/at?name=${encodeURIComponent(brand.country || displayCountry)}`}
                className="text-muted-foreground hover:opacity-70 transition-opacity"
                title={`@${brand.country || displayCountry}`}
              >
                {displayCountry}
              </Link>
            )}
            {brand.year_established && <span className="text-muted-foreground">Est. {brand.year_established}</span>}
            <span className={brand.in_business !== false ? "text-emerald-600 font-medium" : "text-red-500 font-medium"}>
              {brand.in_business !== false ? (isAr ? "نشِط" : "Active") : (isAr ? "متوقّف" : "Closed")}
            </span>
          </div>
          {/* perfume count on its own line */}
          <div className="text-xs font-body text-muted-foreground flex items-center gap-1.5">
            <span className="text-[11px] leading-none">{(typeof localStorage !== "undefined" && localStorage.getItem("userMark")) || "🧴"}</span>
            {perfumes.length} {isAr ? "عطر" : (perfumes.length === 1 ? "perfume" : "perfumes")}
          </div>
        </div>

        {/* Perfumes by brand - Grid */}
        <div className="space-y-3 bg-card rounded-none p-5 shadow-sm">
          <div className="flex items-center justify-between flex-wrap gap-2">
            <h2 className="font-heading font-semibold">{isAr ? "العطور" : "Perfumes"}</h2>
            {/* sort options — text pills + alphabetical asc/desc as icon-only
                buttons (AArrowUp / AArrowDown), matching the sort control used
                on the Glossary page. */}
            <div className="flex items-center gap-1.5">
              {[
                { id: "year", ar: "الإصدار", en: "Release" },
                { id: "gender", ar: "الجنس", en: "Gender" },
                { id: "season", ar: "الموسم", en: "Season" },
              ].map((s) => (
                <button key={s.id} onClick={() => { setPSortMode(s.id); setPPage(0); }}
                  className={`text-[10px] rounded-none inline-flex items-center gap-1 ${pSortMode === s.id ? " text-background" : " text-muted-foreground"}`}>
                  {isAr ? s.ar : s.en}
                </button>
              ))}
              {[
                { id: "alpha_asc", Icon: AArrowUp, ar: "أبجدي تصاعدي", en: "A → Z" },
                { id: "alpha_desc", Icon: AArrowDown, ar: "أبجدي تنازلي", en: "Z → A" },
              ].map((s) => (
                <button key={s.id} onClick={() => { setPSortMode(s.id); setPPage(0); }}
                  title={isAr ? s.ar : s.en} aria-label={isAr ? s.ar : s.en}
                  className={`p-1 rounded-none transition-colors ${pSortMode === s.id ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
                  <s.Icon className="w-4 h-4" />
                </button>
              ))}
            </div>
          </div>
          {perfumes.length === 0
            ? <p className="text-sm text-muted-foreground font-body text-center py-6">{isAr ? "لا عطور بعد لهذا البراند." : "No perfumes added yet for this brand."}</p>
            : (() => {
                const sorted = [...perfumes].sort((a, b) => {
                  if (pSortMode === "alpha_asc" || pSortMode === "alpha_desc") {
                    const an = (a.name_en || a.name || "").trim(), bn = (b.name_en || b.name || "").trim();
                    const isEng = (s) => /^[A-Za-z]/.test(s);
                    const ar = isEng(an) ? 0 : 1, br = isEng(bn) ? 0 : 1;
                    if (ar !== br) return ar - br; // keep the English block first in both directions
                    const cmp = an.localeCompare(bn, "en", { sensitivity: "base", numeric: true });
                    return pSortMode === "alpha_desc" ? -cmp : cmp;
                  }
                  if (pSortMode === "gender") return (a.gender || "").localeCompare(b.gender || "");
                  if (pSortMode === "season") return (a.season || "").localeCompare(b.season || "");
                  // year (default)
                  if (b.release_year && a.release_year) return b.release_year - a.release_year;
                  if (b.release_year) return 1;
                  if (a.release_year) return -1;
                  return new Date(b.created_date) - new Date(a.created_date);
                });
                const totalPages = Math.ceil(sorted.length / PERFUMES_PER_PAGE);
                const pageItems = sorted.slice(pPage * PERFUMES_PER_PAGE, (pPage + 1) * PERFUMES_PER_PAGE);
                return (
                  <>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                      {pageItems.map(p => {
                        // مجموعة البراند (تلقائياً من اسم العطر، مثل "Private Blend")
                        const coll = p.collection || deriveCollection(p.name_en || p.name || "");
                        const dom = dominantAccord(p.accords);
                        const accName = dom ? (isAr ? (dom.ar || dom.en) : dom.en) : "";
                        const accColor = dom ? dom.bar : "#94a3b8";
                        const gColor = GENDER_BORDER[p.gender] || "rgba(120,120,120,0.35)";
                        const sh = "0 1px 2px rgba(255,255,255,0.95)";
                        const ty = shortType(p.type);
                        return (
                          <button key={p.id} onClick={() => navigate(`/perfume?id=${p.id}`)}
                            className="flex flex-col text-left hover:opacity-80 transition-opacity">
                            {/* علبة العطر: زوايا حادّة، إطار بلون الجنس، قنينة ملوّنة بالأكورد */}
                            <div className="relative w-full aspect-square bg-white overflow-hidden flex items-center justify-center"
                              style={{ border: `1.5px solid ${gColor}`, borderRadius: 0 }}>
                              {p.image_url
                                ? <img src={p.image_url} alt={p.name_en || p.name} className="w-full h-full object-cover" />
                                : <AccordFlacon accords={p.accords} style={{ maxWidth: "62%", height: "100%" }} />}
                              {/* أربع زوايا: المجموعة • السنة (صغيرة) • الأكورد المسيطر • النوع */}
                              {coll && (
                                <span className="absolute top-1 left-1 text-[8px] font-body font-bold" style={{ color: "var(--brand)", textShadow: sh }}>{clip2(coll, 13)}</span>
                              )}
                              {p.release_year && (
                                <span className="absolute top-1 right-1 text-[7px] font-body font-bold" style={{ color: "#1864ab", textShadow: sh }}>{p.release_year}</span>
                              )}
                              {accName && (
                                <span className="absolute bottom-1 left-1 text-[8px] font-body font-semibold" style={{ color: accColor, textShadow: sh }}>{accName}</span>
                              )}
                              {ty && (
                                <span className="absolute bottom-1 right-1 text-[8px] font-body font-semibold" style={{ color: "#5f5e5a", textShadow: sh }}>{ty}</span>
                              )}
                            </div>
                            {/* الاسم: سطران ثابتان، إنجليزي فقط، اختصار بنقطتين «..» */}
                            <p className="mt-1 text-[11px] font-body font-bold text-foreground"
                              style={{ lineHeight: 1.25, height: 28, overflow: "hidden" }}>
                              {clip2(p.name_en || p.name, 40)}
                            </p>
                          </button>
                        );
                      })}
                    </div>
                    {/* pagination */}
                    {totalPages > 1 && (
                      <div className="flex items-center justify-center gap-3 pt-3">
                        <button disabled={pPage === 0} onClick={() => setPPage((n) => Math.max(0, n - 1))}
                          className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "السابق" : "Prev"}</button>
                        <span className="text-xs text-muted-foreground">{pPage + 1} / {totalPages}</span>
                        <button disabled={pPage >= totalPages - 1} onClick={() => setPPage((n) => Math.min(totalPages - 1, n + 1))}
                          className="text-xs px-3 py-1.5 rounded-none border disabled:opacity-40">{isAr ? "التالي" : "Next"}</button>
                      </div>
                    )}
                  </>
                );
              })()
          }
        </div>

        {/* Signature Notes — unified card */}
        {(signatureNotes.length > 0 || brand.innovation_notes) && (
          <div className="bg-card/50 backdrop-blur-sm rounded-none p-5 shadow-sm space-y-3 border border-border/30">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-body font-semibold uppercase tracking-widest text-primary rounded-none ">
                🌸 Signature Notes النوتات المميّزة
              </span>
            </div>
            <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-3">
              {/* Notes from signature_notes_ids (linked to DB) */}
              {signatureNotes.map(note => (
                <button
                  key={`sig-${note.id}`}
                  onClick={() => navigate(`/note?id=${note.id}`)}
                  className="flex flex-col gap-1.5 text-left hover:opacity-80 transition-opacity group"
                >
                  <div className="w-full aspect-square rounded-none bg-white overflow-hidden flex items-center justify-center border border-border/50">
                    {note.image_url ? (
                      <img src={note.image_url} alt={note.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full bg-white" />
                    )}
                  </div>
                  <p className="text-[11px] font-body font-semibold text-center leading-tight line-clamp-2 text-foreground/80 group-hover:underline px-0.5">{note.name}</p>
                </button>
              ))}
              {/* Legacy innovation_notes (free text, may not be in DB) — only render names not already shown */}
              {(brand.innovation_notes || "").split(",").map(s => s.trim()).filter(Boolean)
                .filter(name => !signatureNotes.some(n => n.name === name))
                .map(name => (
                  <InnovationNoteCard key={`inn-${name}`} name={name} navigate={navigate} allNotes={allNotes} />
                ))}
            </div>
          </div>
        )}

        {/* ─── Perfumers linked to this brand ─── */}
        <BrandPerfumersSection brand={brand} />

        {/* ─── Occasion/Occasions — Best For ─── */}
        {perfumes.some(p => p.occasions) && (
          <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
            <h2 className="font-heading font-semibold">{isAr ? "أفضل المناسبات" : "Best For"}</h2>
            <div className="flex flex-wrap gap-x-4 gap-y-2">
              {Array.from(new Set(
                perfumes
                  .filter(p => p.occasions)
                  .flatMap(p => p.occasions.split(",").map(o => o.trim()))
              )).map(occasion => {
                const occasionLabels = { 
                  daylight: { en: "Daylight", ar: "نهار" }, 
                  evening: { en: "Evening", ar: "مساء" }, 
                  wedding: { en: "Wedding", ar: "زفاف" }, 
                  celebration: { en: "Celebration", ar: "احتفال" }, 
                  relax: { en: "Relax", ar: "استرخاء" }, 
                  work: { en: "Work", ar: "عمل" }, 
                  sport: { en: "Sport", ar: "رياضة" }, 
                  casual: { en: "Casual", ar: "عادي" }, 
                  very_special: { en: "Very Special", ar: "خاص جداً" } 
                };
                const label = occasionLabels[occasion];
                return (
                  <button key={occasion}
                    onClick={() => navigate(`/occasion?o=${encodeURIComponent(occasion)}`)}
                    className="text-xs font-body font-medium text-cyan-700 dark:text-cyan-400 hover:text-cyan-500 transition-colors">
                    {label ? (isAr ? label.ar : label.en) : occasion}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* ─── Collections ─── */}

        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "المجموعات" : "Collections"}</h2>
              <p className="text-xs text-muted-foreground font-body">{displayCollections.length} collection{displayCollections.length !== 1 ? "s" : ""}</p>
            </div>
            <Button size="sm" variant="outline" className="rounded-none h-8 gap-1 text-xs" onClick={() => setShowAddCollection(!showAddCollection)}>
              Add
            </Button>
          </div>

          {showAddCollection && (
            <div className="bg-primary/5 border border-primary/20 rounded-none p-3 space-y-2">
              <Input value={newCollection.name} onChange={e => setNewCollection({...newCollection, name: e.target.value})} placeholder={isAr ? "اسم المجموعة بالإنجليزية" : "Collection name (EN)"} className="rounded-none h-10 font-body text-sm" />
              <Input value={newCollection.name_ar} onChange={e => setNewCollection({...newCollection, name_ar: e.target.value})} placeholder="اسم المجموعة (عربي)" className="rounded-none h-10 font-body text-sm" dir="rtl" />
              <Input value={newCollection.description} onChange={e => setNewCollection({...newCollection, description: e.target.value})} placeholder={isAr ? "الوصف اختياري" : "Description (optional)"} className="rounded-none h-10 font-body text-sm" />
              <div className="flex gap-2">
                <Button size="sm" className="rounded-none flex-1 text-xs" onClick={handleAddCollection} disabled={savingCollection}>
                  {savingCollection ? "Saving..." : "Save Collection"}
                </Button>
                <Button size="sm" variant="ghost" className="rounded-none text-xs" onClick={() => setShowAddCollection(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
              </div>
            </div>
          )}

          {displayCollections.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body text-center py-3">{isAr ? "لا مجموعات بعد أضف واحدة أعلاه" : "No collections yet. Add one above."}</p>
          ) : (
            <div className="space-y-3">
              {displayCollections.map(col => {
                const colPerfumes = getCollectionPerfumes(col);
                return (
                  <div key={col.id} className="bg-card/30 backdrop-blur-sm rounded-none p-4 space-y-3 border border-primary/20">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-body font-semibold">{isAr ? (col.name_ar || col.name) : col.name}</p>
                        {isAr && col.name_ar && <p className="text-[10px] text-muted-foreground font-body">{col.name}</p>}
                        {col.description && <p className="text-[10px] text-muted-foreground font-body mt-0.5">{col.description}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] text-primary rounded-none font-body font-semibold">
                          {colPerfumes.length}
                        </span>
                        {!col.auto && (
                          <button
                            onClick={() => navigate(`/brand-collection?id=${col.id}`)}
                            className="text-[10px] text-primary-foreground rounded-none font-body font-semibold transition-colors"
                          >
                            تصفح
                          </button>
                        )}
                      </div>
                    </div>
                    {colPerfumes.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {colPerfumes.map(p => (
                          <button
                            key={p.id}
                            onClick={() => navigate(`/perfume?id=${p.id}`)}
                            className="flex items-center gap-1 text-[10px] rounded-none font-body transition-colors"
                          >
                            {p.release_year && <span className="text-muted-foreground">{p.release_year} ·</span>}
                            <span>{p.name_en || p.name}</span>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
          </div>

          {/* Add Perfume Button */}
          <Button 
          onClick={() => navigate(`/add?brand=${brand.id}`)} 
          className="w-full h-10 rounded-none font-body gap-2 bg-primary hover:bg-primary/90"
          >
          Add Perfume to {brand.name}
          </Button>

          {/* ─── Opinion buttons ─── */}
        <div className="space-y-2">
          {[
            { person: "person1", label: names.person1, favList: favBrandsP1, dislikeList: dislikeBrandsP1, favActiveClass: "bg-primary text-primary-foreground border-primary", dislikeActiveClass: "bg-red-500 text-white border-red-500", favIdleClass: "text-primary border-primary/30 bg-primary/5 hover:bg-primary/10", dislikeIdleClass: "text-red-500 border-red-200 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:border-red-900" },
            { person: "person2", label: names.person2, favList: favBrandsP2, dislikeList: dislikeBrandsP2, favActiveClass: "bg-violet-500 text-white border-violet-500", dislikeActiveClass: "bg-red-500 text-white border-red-500", favIdleClass: "text-violet-600 border-violet-300 bg-violet-50 hover:bg-violet-100 dark:bg-violet-950/20 dark:border-violet-800", dislikeIdleClass: "text-red-500 border-red-200 bg-red-50 hover:bg-red-100 dark:bg-red-950/20 dark:border-red-900" },
          ].map(({ person, label, favList, dislikeList, favActiveClass, dislikeActiveClass, favIdleClass, dislikeIdleClass }) => {
            const isFav = favList.includes(id);
            const isDislike = dislikeList.includes(id);
            return (
              <div key={person} className="space-y-1">
                <p className="text-[10px] text-muted-foreground font-body font-semibold uppercase tracking-wide px-0.5">{label}</p>
                <div className="grid grid-cols-2 gap-2">
                  <button onClick={() => toggleOpinion(person, id, "fav")}
                    className={`flex items-center justify-center gap-1.5 py-2.5 rounded-none border text-xs font-body font-semibold transition-all ${isFav ? favActiveClass : favIdleClass}`}>
                    <Heart className={`w-3.5 h-3.5 ${isFav ? "fill-current" : ""}`} />
                    {isFav ? "Favorite ✓" : "Favorite"}
                  </button>
                  <button onClick={() => toggleOpinion(person, id, "dislike")}
                    className={`flex items-center justify-center gap-1.5 py-2.5 rounded-none border text-xs font-body font-semibold transition-all ${isDislike ? dislikeActiveClass : dislikeIdleClass}`}>
                    <HeartOff className="w-3.5 h-3.5" />
                    {isDislike ? "Don't Like ✓" : "Don't Like"}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* ─── NOSE — Personal Review Section ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-5">
          {/* Person switcher */}
          <div className="flex items-center gap-2.5 flex-wrap pb-2 border-b border-border/40">
            <span className="font-heading font-bold text-base tracking-wider">{isAr ? "الأنف" : "NOSE"}</span>
            <span className="text-muted-foreground text-sm">·</span>
            <button onClick={() => { setActivePerson("person1"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person1" ? "text-primary" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person1}
            </button>
            <span className="text-muted-foreground text-sm">·</span>
            <button onClick={() => { setActivePerson("person2"); setEditNotes(false); }}
              className={`text-sm font-body font-bold transition-colors ${activePerson === "person2" ? "text-violet-500" : "text-muted-foreground hover:text-foreground"}`}>
              {names.person2}
            </button>
          </div>

          {/* Impression */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "الانطباع" : "Impression"}</p>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: "great", emoji: "😍", label: "Great" },
                { value: "neutral", emoji: "😐", label: "Neutral" },
                { value: "not_great", emoji: "😕", label: "Not Great" },
              ].map(({ value, emoji, label }) => {
                const active = activeUserData?.impression === value;
                return (
                  <button key={value}
                    onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "impression", value: active ? null : value })}
                    className={`flex flex-col items-center gap-1.5 py-3 rounded-none border text-xs font-body font-medium transition-all ${active ? "bg-primary/10 border-primary shadow-sm text-primary" : "bg-secondary/40 border-border/50 text-muted-foreground hover:text-foreground"}`}>
                    <span className="text-xl">{emoji}</span>
                    <span>{label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick reactions */}
          <div className="flex gap-2">
            {[
              { value: "love_it", emoji: "🥰", label: "Love it", activeClass: "bg-rose-50 border-rose-300 text-rose-500 shadow-sm" },
              { value: "like_it", emoji: "😍", label: "Like it", activeClass: "bg-emerald-50 border-emerald-300 text-emerald-600 shadow-sm" },
              { value: "neutral", emoji: "😐", label: "Neutral", activeClass: "bg-slate-100 border-slate-400 text-slate-600 shadow-sm" },
              { value: "hate_it", emoji: "😠", label: "Hate it", activeClass: "bg-red-50 border-red-300 text-red-500 shadow-sm" },
            ].map(({ value, emoji, label, activeClass }) => {
              const active = activeUserData?.other_rating === value;
              return (
                <button key={value}
                  onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "other_rating", value: active ? null : value })}
                  className={`flex-1 flex flex-col items-center gap-1 py-2.5 rounded-none border text-xs font-body font-medium transition-all ${active ? activeClass : "bg-secondary/40 border-border/50 text-muted-foreground hover:text-foreground"}`}>
                  <span className="text-lg">{emoji}</span>
                  <span>{label}</span>
                </button>
              );
            })}
          </div>

          {/* Rating */}
          <div className="space-y-2">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "التقييم" : "Rating"}</p>
            <StarRating
              rating={activeUserData?.rating || 0}
              onChange={v => upsertUserBrand.mutate({ person: activePerson, field: "rating", value: v })}
              size="lg"
            />
          </div>

          {/* Health Ratings */}
          <HealthRatingSection
            activeUserData={activeUserData}
            activePerson={activePerson}
            onUpdate={(field, value) => upsertUserBrand.mutate({ person: activePerson, field, value })}
          />

          {/* Personal Notes */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <p className="text-xs text-muted-foreground font-body uppercase tracking-wider">{isAr ? "مراجعتي" : "My Review"}</p>
              {!editNotes && (
                <Button variant="ghost" size="sm" className="text-xs font-body h-7"
                  onClick={() => { setEditNotes(true); setNotesValue(activeUserData?.personal_notes || ""); }}>
                  Edit
                </Button>
              )}
            </div>
            {editNotes ? (
               <div className="space-y-2">
                 <Textarea value={notesValue} onChange={e => setNotesValue(e.target.value)}
                   className="rounded-none font-body min-h-[80px]" placeholder={isAr ? "خواطرك عن هذا البراند" : "Your thoughts about this brand..."} />
                 <div className="flex gap-2">
                   <Button size="sm" className="rounded-none font-body" onClick={() => {
                     upsertUserBrand.mutate({ person: activePerson, field: "personal_notes", value: notesValue });
                     setEditNotes(false);
                   }}>{isAr ? "حفظ" : "Save"}</Button>
                  <Button size="sm" variant="ghost" className="rounded-none font-body" onClick={() => setEditNotes(false)}>{isAr ? "إلغاء" : "Cancel"}</Button>
                </div>
              </div>
            ) : (
              <p className="text-sm font-body text-foreground/80 whitespace-pre-wrap">{activeUserData?.personal_notes || "No review yet"}</p>
            )}
          </div>
        </div>

        {/* ─── Purchase History (perfumes of this brand) ─── */}
        <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-border/40">
            <div>
              <h2 className="font-heading font-semibold">{isAr ? "سجل الشراء" : "Purchase History"}</h2>
              <p className="text-xs text-muted-foreground font-body">{activePurchases.length} purchase{activePurchases.length !== 1 ? "s" : ""}</p>
            </div>
            <div className="text-right">
              <p className="text-xs font-bold text-primary font-heading">{formatPrice(totalSpent)}</p>
              <p className="text-[9px] text-muted-foreground font-body">{totalMl}ml total</p>
            </div>
          </div>

          {activePurchases.length === 0 ? (
            <p className="text-xs text-muted-foreground font-body text-center py-4">{isAr ? "لا مشتريات مسجّلة لهذا البراند" : "No purchases recorded for this brand."}</p>
          ) : (
            <div className="space-y-2">
              {activePurchases.map(record => (
                <div key={record.id} className="flex flex-col gap-2 bg-secondary/40 rounded-none p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`text-[9px] font-bold rounded-none ${record.person === "person2" ? " text-violet-600" : " text-primary"}`}>
                        {record.person === "person2" ? names.person2 : names.person1}
                      </span>
                      <span className="text-[10px] font-body font-bold rounded-none text-foreground/70">
                        {record.type === "sample" ? "Sample" : "Bottle"}
                      </span>
                      <span className="text-[10px] font-body font-semibold text-foreground/80 truncate max-w-[100px]">{record.perfume_name}</span>
                      <span className="text-[9px] text-muted-foreground font-body">{record.purchase_date}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="text-right">
                        <p className="text-xs font-body font-medium">{record.ml}ml</p>
                        <p className="text-[10px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                      </div>
                      <EditPurchaseDialog
                        record={record}
                        perfumeId={record.perfume_id}
                        activePerson={activePerson}
                        stores={shopBrands}
                        onSuccess={() => {
                          queryClient.invalidateQueries({ queryKey: ["purchase-records-brand", brand?.name] });
                        }}
                      />
                    </div>
                  </div>
                  {record.store_name && (
                    <button onClick={() => navigate(`/store?id=${record.store_id}`)}
                      className="text-xs font-body text-primary hover:underline w-fit">
                      🏪 {record.store_name}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* ─── Owned By (show only if linked) ─── */}
        {brand.owned_by && (() => {
          const ownerKey = brand.owned_by.trim().toLowerCase();
          const siblingBrands = allBrands.filter(b =>
            b.id !== id && (
              b.owned_by?.trim().toLowerCase() === ownerKey ||
              b.parent_company?.trim().toLowerCase() === ownerKey ||
              b.name?.trim().toLowerCase() === ownerKey
            )
          );
          return (
            <div className="bg-card rounded-none p-5 shadow-sm space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-primary/10 rounded-none flex items-center justify-center flex-shrink-0">
                  <Building2 className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">{isAr ? "يملكه" : "Owned By"}</p>
                  <button
                    onClick={() => navigate(`/owner-group?name=${encodeURIComponent(brand.owned_by)}`)}
                    className="text-sm font-body font-bold text-primary hover:underline text-left"
                  >
                    {brand.owned_by}
                  </button>
                </div>
              </div>
              {siblingBrands.length > 0 && (
                <div className="pt-2">
                  <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold mb-2">العلامات المملوكة لنفس المجموعة</p>
                  <div className="flex flex-wrap gap-x-4 gap-y-1.5">
                    {siblingBrands.map(b => (
                      <button
                        key={b.id}
                        onClick={() => navigate(`/brand?id=${b.id}`)}
                        className="text-xs font-body font-medium text-teal-700 dark:text-teal-400 hover:text-teal-500 transition-colors"
                      >
                        {b.name}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          );
        })()}

        {/* ─── Bookmark + Copy (centered, bottom) ─── */}
        <div className="flex justify-center items-center gap-3 pt-2">
          <BookmarkButton descriptor={{
            item_type: "brand",
            item_id: id,
            title_en: brand.name,
            title_ar: brand.name_ar || "",
            subtitle: brand.country || "",
            path: `/brand?id=${id}`,
          }} />
          <PinButton kind="brand" id={id} />
          {/* زر مجموعتي — أيقونة براند بجانب النوتبوك */}
          <button
            onClick={() => upsertUserBrand.mutate({ person: activePerson, field: "in_collection", value: !activeUserData?.in_collection })}
            disabled={upsertUserBrand.isPending}
            title={activeUserData?.in_collection ? (isAr ? "في مجموعتي" : "In my collection") : (isAr ? "أضف لمجموعتي" : "Add to my collection")}
            aria-label={isAr ? "مجموعتي" : "My collection"}
            className="flex items-center justify-center w-8 h-8 bg-transparent transition-opacity hover:opacity-70"
          >
            <Building2 className="w-4 h-4" strokeWidth={1.25} style={{ color: activeUserData?.in_collection ? "#16a34a" : "#1450c8" }} />
          </button>
          <CopyMenu
            entity="brand"
            dbText={brandDbText(brand)}
            fullText={brandFullText(brand, {
              perfumes,
              favorite:      activeUserData?.favorite,
              rating:        activeUserData?.other_rating,
              personalNotes: activeUserData?.notes || "",
              purchases:     purchaseRecords?.map((r) => ({
                purchase_date: r.purchase_date,
                perfume_name:  r.perfume_name,
                ml:            r.ml,
                cost:          r.cost,
              })) || [],
              personName: names?.[activePerson] || "",
            })}
          />
        </div>

        {/* ─── Export Brand Review (تقرير مفصّل) ─── */}
         <Button onClick={() => setExportOpen(true)}
           className="w-full h-10 rounded-none font-body gap-2 bg-primary/10 text-primary hover:bg-primary/20">
           <Download className="w-4 h-4" /> {isAr ? "تصدير مراجعة البراند" : "Export Brand Review"}
         </Button>

         {/* بطاقة فاخرة جديدة للبراند */}
         <LuxuryCardExport
           kind="brand"
           brand={brand}
           userData={activeUserData}
           personName={activePerson === "person2" ? (names?.person2 || "B") : (names?.person1 || "A")}
         />

         {/* ─── Edit Brand Button ─── */}
         <Button size="icon" variant="outline" className="w-full h-10 rounded-none gap-2" onClick={openEdit}>
           <Edit2 className="w-4 h-4" /> {isAr ? "تعديل البراند" : "Edit Brand"}
         </Button>

         {/* ─── أضِف/أزِل البراند من متاجر التسوّق (بإرادة المستخدم) ─── */}
         <Button size="icon" variant="outline" className="w-full h-10 rounded-none gap-2" onClick={toggleBrandStore} disabled={storeToggling}>
           <Building2 className="w-4 h-4" />
           {brandStore ? (isAr ? "في المتاجر — إزالة" : "In stores — Remove") : (isAr ? "أضِف للمتاجر" : "Add to stores")}
         </Button>

        </div>

      {/* ─── Export Dialog ─── */}
      <Dialog open={exportOpen} onOpenChange={setExportOpen}>
        <DialogContent className="max-w-lg w-[95vw] rounded-none max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading">{isAr ? "تصدير مراجعة البراند" : "Export Brand Review"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Universal export branding toggles (User Mark / App Name / Date) */}
            <ExportOptionsBar userMarkAvailable={true} />

            {/* Format */}
            <div className="flex gap-2">
              <button onClick={() => setExportFormat("image")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${exportFormat === "image" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                📸 Picture
              </button>
              <button onClick={() => setExportFormat("pdf")}
                className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${exportFormat === "pdf" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                📄 PDF
              </button>
            </div>

            {/* Profile */}
            <div className="grid grid-cols-3 gap-2">
              <button onClick={() => setExportPerson("all")}
                className={`py-2 rounded-none text-xs font-body font-medium transition-all ${exportPerson === "all" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                All
              </button>
              <button onClick={() => setExportPerson("person1")}
                className={`py-2 rounded-none text-xs font-body font-medium transition-all ${exportPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                {names.person1}
              </button>
              <button onClick={() => setExportPerson("person2")}
                className={`py-2 rounded-none text-xs font-body font-medium transition-all ${exportPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                {names.person2}
              </button>
            </div>

            {/* Export Options */}
            <div className="space-y-2 bg-secondary/30 rounded-none p-3">
              <p className="text-xs font-body font-semibold text-foreground uppercase tracking-wider">{isAr ? "تضمين في التصدير" : "Include in Export"}</p>
              <div className="space-y-1.5">
                {[
                  { key: "includeDescription", label: "Brand Description & Info" },
                  { key: "includePerfumers", label: "Perfumers العطارون" },
                  { key: "includeSignatureNotes", label: "Signature Notes النوتات المميّزة" },
                  { key: "includeOccasions", label: "Best Occasions المناسبات" },
                  { key: "includeTopPerfumes", label: "Top 12 Perfumes" },
                  { key: "includeTopCollections", label: "Top Collections" },
                  { key: "includeImpression", label: "Impression" },
                  { key: "includeRating", label: "Rating & Stars" },
                  { key: "includeOtherRating", label: "Sentiment Rating (Love/Like/Hate)" },
                  { key: "includeFavorite", label: "Favorite Status" },
                  { key: "includeReview", label: "Personal Review/Notes" },
                  { key: "includePurchases", label: "Purchase History" },
                { key: "includeHealth", label: "صداع Headache & حساسية جيوب أنفية Sinus" },
                ].map(({ key, label }) => (
                  <label key={key} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={exportOptions[key]}
                      onChange={(e) => setExportOptions({ ...exportOptions, [key]: e.target.checked })}
                      className="w-4 h-4 rounded accent-primary"
                    />
                    <span className="text-xs font-body text-foreground">{label}</span>
                  </label>
                ))}
              </div>
            </div>

            {/* Export color + language options */}
            <div className="space-y-3 mb-3">
              <div className="space-y-1.5">
                <p className="text-xs font-body text-muted-foreground">{isAr ? "لون الخلفية" : "Background color"}</p>
                <div className="flex flex-wrap gap-1.5">
                  {["#ffffff","#165d31","#0c447c","#4b1528","#173404","#412402","#26215c","#2c2c2a","#5b1a1a","#0f4c4c","#3d3416","#1a1a2e"].map((c) => (
                    <button key={c} onClick={() => setExportBg(c)} aria-label={c}
                      style={{ width: 26, height: 26, borderRadius: "50%", background: c, border: exportBg === c ? "2px solid var(--color-text-primary)" : "1px solid rgba(127,127,127,0.4)" }} />
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <p className="text-xs font-body text-muted-foreground">{isAr ? "لون الخط" : "Text color"}</p>
                <div className="flex flex-wrap gap-1.5">
                  <button onClick={() => setExportTextColor("")} className="text-[10px] px-2 h-[26px] rounded-none border" style={{ borderColor: exportTextColor === "" ? "var(--color-text-primary)" : "rgba(127,127,127,0.4)" }}>{isAr ? "تلقائي" : "Auto"}</button>
                  {["#0f172a","#ffffff","#165d31","#854f0b","#993556","#0c447c","#b8860b","#4b1528","#1a1a2e","#0f4c4c","#5b1a1a","#475569"].map((c) => (
                    <button key={c} onClick={() => setExportTextColor(c)} aria-label={c}
                      style={{ width: 26, height: 26, borderRadius: "50%", background: c, border: exportTextColor === c ? "2px solid var(--color-text-primary)" : "1px solid rgba(127,127,127,0.4)" }} />
                  ))}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-body text-muted-foreground">{isAr ? "اسم العطر" : "Perfume name"}</span>
                {[{id:"en",ar:"إنجليزي",en:"EN"},{id:"ar",ar:"عربي",en:"AR"},{id:"both",ar:"الاثنان",en:"Both"}].map((o)=>(
                  <button key={o.id} onClick={()=>setExportNoteLang(o.id)} className={`text-[11px] rounded-none ${exportNoteLang===o.id?" text-background":" text-muted-foreground"}`}>{isAr?o.ar:o.en}</button>
                ))}
              </div>
            </div>
            <div id="brand-export-card" style={{ width: "100%", background: exportBg, borderRadius: 16, overflow: "hidden", border: "1px solid #e2e8f0", boxShadow: "0 4px 24px rgba(0,0,0,0.10)", padding: 20, boxSizing: "border-box", color: exportTextColor || (exportBg.toLowerCase() === "#ffffff" ? "#0f172a" : "#ffffff") }}>
              {/* Header row: logo + brand info */}
              <div style={{ display: "flex", gap: 14, alignItems: "flex-start", marginBottom: 12 }}>
                <div style={{ width: 80, height: 80, borderRadius: 0, overflow: "hidden", flexShrink: 0, background: "#ffffff", border: "1.5px solid var(--brand)", display: "flex", alignItems: "center", justifyContent: "center" }}>
                  <BrandLogo brand={brand} imgStyle={{ width: "100%", height: "100%", objectFit: "contain" }} initialsSize={28} />
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ borderLeft: "4px solid #f59e0b", paddingLeft: 10, marginBottom: 6 }}>
                    <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
                      <p style={{ fontSize: 20, fontWeight: 800, color: exportTextColor || (exportBg.toLowerCase() === "#ffffff" ? "#0f172a" : "#ffffff"), margin: 0, lineHeight: 1.2 }}>{brand.name}</p>
                      <ExportHeader userMark={userData?.mark || ""} inline />
                    </div>
                    {brand.name_ar && <p style={{ fontSize: 11, color: "#64748b", margin: "2px 0 0", direction: "rtl" }}>{brand.name_ar}</p>}
                  </div>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10, fontSize: 9, fontWeight: 700 }}>
                    {brand.country && <span style={{ color: "#ea580c" }}>🌍 {brand.country}</span>}
                    {brand.year_established && <span style={{ color: "#b45309" }}>📅 Est. {brand.year_established}</span>}
                    <span style={{ color: brand.in_business !== false ? "#15803d" : "#dc2626" }}>{brand.in_business !== false ? "Active" : "Closed"}</span>
                    {brand.owned_by && <span style={{ color: "#1d4ed8" }}>🏢 {brand.owned_by}</span>}
                    <span style={{ color: "#9333ea" }}>🌸 {perfumes.length} perfumes</span>
                  </div>
                </div>
              </div>

              {/* Brand Description (no heading) */}
              {exportOptions.includeDescription && unifiedDescription && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 10, color: exportTextColor || (exportBg.toLowerCase() === "#ffffff" ? "#475569" : "rgba(255,255,255,0.9)"), lineHeight: 1.5, margin: 0, wordWrap: "break-word", overflowWrap: "break-word", whiteSpace: "pre-line" }}>{unifiedDescription}</p>
                </div>
              )}

              {/* Perfumers */}
              {exportOptions.includePerfumers && brand.perfumer_names && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}>{isAr ? "عطّارون مرتبطون بهذه الدار" : "Perfumers"}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    {(Array.isArray(brand.perfumer_names) ? brand.perfumer_names.join(",") : String(brand.perfumer_names)).split(",").map(n => n.trim()).filter(Boolean).map(name => {
                      const rec = perfumersMapByName[name.toLowerCase()];
                      const arName = rec?.name_ar || "";
                      const isFemale = rec?.gender === "Female";
                      const color = isFemale ? "#be123c" : "#15803d";
                      return (
                        <span key={name} style={{ fontSize: 10, fontWeight: 700, color }}>
                          {isAr && arName ? arName : name}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Signature Notes — unified (includes legacy innovation notes) */}
              {exportOptions.includeSignatureNotes && (signatureNotes.length > 0 || brand.innovation_notes) && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}><BilingualText en="Signature Notes" ar="النوتات المميّزة" /></p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                    {/* Notes linked to DB */}
                    {signatureNotes.map(note => (
                      <div key={`sig-${note.id}`} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:3, width:60 }}>
                        <div style={{ width:52, height:52, borderRadius:8, overflow:"hidden", background:"transparent", border:"none", display:"flex", alignItems:"center", justifyContent:"center" }}>
                          {note.image_url ? <img src={note.image_url} alt={note.name} style={{ width:"100%", height:"100%", objectFit:"contain" }} /> : null}
                        </div>
                        <p style={{ fontSize:8, fontWeight:700, color:"#0f172a", textAlign:"center", margin:0, wordBreak:"break-word", lineHeight:1.3 }}>{note.name}</p>
                        {note.category && <p style={{ fontSize:7, color:"#64748b", margin:0, textAlign:"center" }}>{note.category}</p>}
                      </div>
                    ))}
                    {/* Legacy free-text notes (not already in signatureNotes) */}
                    {(brand.innovation_notes || "").split(",").map(n => n.trim()).filter(Boolean)
                      .filter(name => !signatureNotes.some(n => n.name?.toLowerCase() === name.toLowerCase()))
                      .map(name => {
                        const rec = allNotes.find(n => n.name?.toLowerCase() === name.toLowerCase());
                        return (
                          <div key={`inn-${name}`} style={{ display:"flex", flexDirection:"column", alignItems:"center", gap:3, width:60 }}>
                            <div style={{ width:52, height:52, borderRadius:8, overflow:"hidden", background:"transparent", border:"none", display:"flex", alignItems:"center", justifyContent:"center" }}>
                              {rec?.image_url ? <img src={rec.image_url} alt={name} style={{ width:"100%", height:"100%", objectFit:"contain" }} /> : null}
                            </div>
                            <p style={{ fontSize:8, fontWeight:700, color:"#0f172a", textAlign:"center", margin:0, wordBreak:"break-word", lineHeight:1.3 }}>{name}</p>
                            {rec?.category && <p style={{ fontSize:7, color:"#64748b", margin:0, textAlign:"center" }}>{rec.category}</p>}
                          </div>
                        );
                      })}
                  </div>
                </div>
              )}

              {/* Occasions in export */}
              {exportOptions.includeOccasions && perfumes.some(p => p.occasions) && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}>{isAr ? "أفضل المناسبات" : "Best For"}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    {Array.from(new Set(perfumes.filter(p=>p.occasions).flatMap(p=>String(p.occasions).split(",").map(o=>o.trim())))).map(occ => {
                      const ocLabels = {
                        daylight:    { emoji: "☀️", en: "Daylight",     ar: "نهار" },
                        evening:     { emoji: "🌙", en: "Evening",      ar: "مساء" },
                        wedding:     { emoji: "💍", en: "Wedding",      ar: "زفاف" },
                        celebration: { emoji: "", en: "Celebration",  ar: "احتفال" },
                        relax:       { emoji: "😌", en: "Relax",        ar: "استرخاء" },
                        work:        { emoji: "💼", en: "Work",         ar: "عمل" },
                        sport:       { emoji: "⚽", en: "Sport",        ar: "رياضة" },
                        casual:      { emoji: "👕", en: "Casual",       ar: "عادي" },
                        very_special:{ emoji: "✨", en: "Very Special", ar: "خاص جداً" },
                      };
                      const label = ocLabels[occ];
                      return (
                        <span key={occ} style={{ fontSize: 9, fontWeight: 600, color: "#0e7490" }}>
                          {label ? (isAr ? label.ar : label.en) : occ}
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Perfumes — up to 20 small thumbnails with names (note-grid style) */}
              {exportOptions.includeTopPerfumes && perfumes.length > 0 && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}>{isAr ? `العطور (${Math.min(perfumes.length, 20)})` : `Perfumes (${Math.min(perfumes.length, 20)})`}</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    {perfumes.slice(0, 20).map(p => {
                      const showAr = exportNoteLang === "ar" && p.name_ar;
                      const label = showAr ? p.name_ar : (p.name_en || p.name);
                      return (
                        <div key={p.id} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, width: 58 }}>
                          <div style={{ width: 50, height: 50 }}>
                            {p.image_url && p.image_url !== "white"
                              ? <img src={p.image_url} alt="" style={{ width: "100%", height: "100%", objectFit: "contain", background: "transparent" }} />
                              : <div style={{ width: "100%", height: "100%", background: "#fff", border: "1px solid var(--brand)" }} />}
                          </div>
                          <p style={{ fontSize: 8, fontWeight: 600, color: "#475569", textAlign: "center", margin: 0, lineHeight: 1.2, wordBreak: "break-word" }}>{label}</p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Top Collections */}
              {exportOptions.includeTopCollections && collections.length > 0 && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}>{isAr ? "المجموعات" : "Collections"}</p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                    {collections.slice(0, 6).map(col => (
                      <div key={col.id} style={{ background: "#f9fafb", borderRadius: 6, padding: 6, border: "1px solid #f1f5f9" }}>
                        <p style={{ fontSize: 9, fontWeight: 700, color: "#0f172a", margin: "0 0 2px", wordWrap: "break-word", overflowWrap: "break-word", whiteSpace: "normal" }}>{col.name}</p>
                        {col.launch_year && <p style={{ fontSize: 8, color: "#64748b", margin: 0 }}>Est. {col.launch_year}</p>}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Reviewer name and reviews */}
              {exportPerson === "all" ? (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  {[userDataP1, userDataP2].filter(Boolean).map((userData, idx) => (
                    <div key={idx} style={{ marginBottom: 8, paddingBottom: 8, borderBottom: idx === 0 ? "1px solid #f1f5f9" : "none" }}>
                      <div style={{ display: "flex", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                        <p style={{ fontSize: 9, fontWeight: 700, color: "#334155", margin: 0 }}>{userData === userDataP1 ? names.person1 : names.person2}</p>
                        {exportOptions.includeImpression && userData?.impression && (
                          <span style={{ fontSize: 10, color: "#b45309" }}>
                            {userData.impression === "great" ? (isAr ? "😍 رائع" : "😍 Great") : userData.impression === "not_great" ? (isAr ? "😕 سيء" : "😕 Not Great") : (isAr ? "😐 محايد" : "😐 Neutral")}
                          </span>
                        )}
                        {exportOptions.includeRating && userData?.rating > 0 && (
                          <span style={{ fontSize: 11, fontWeight: 700, color: "#92400e" }}>
                            {"■".repeat(userData.rating)}{"□".repeat(5 - userData.rating)}
                          </span>
                        )}
                        {exportOptions.includeOtherRating && userData?.other_rating && (
                          <span style={{ fontSize: 10, color: "#be123c" }}>
                            {userData.other_rating === "love_it" ? (isAr ? "🥰 أحبه" : "🥰 Love it") : userData.other_rating === "like_it" ? (isAr ? "😍 يعجبني" : "😍 Like it") : userData.other_rating === "neutral" ? (isAr ? "😐 محايد" : "😐 Neutral") : (isAr ? "😠 أكرهه" : "😠 Hate it")}
                          </span>
                        )}
                      </div>
                      {exportOptions.includeReview && userData?.personal_notes && (
                        <p style={{ fontSize: 10, color: "#475569", fontStyle: "italic", marginTop: 4, borderLeft: "3px solid #e2e8f0", paddingLeft: 8, lineHeight: 1.5, wordWrap: "break-word", overflowWrap: "break-word", whiteSpace: "normal" }}>{userData.personal_notes}</p>
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 4px" }}>{isAr ? "مراجعة" : "Review by"} {exportName}</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                  {exportOptions.includeImpression && exportUserData?.impression && (
                    <span style={{ fontSize: 10, background: "#fffbeb", color: "#b45309", border: "1px solid #fde68a", borderRadius: 999, padding: "3px 10px" }}>
                      {exportUserData.impression === "great" ? (isAr ? "😍 رائع" : "😍 Great") : exportUserData.impression === "not_great" ? (isAr ? "😕 سيء" : "😕 Not Great") : (isAr ? "😐 محايد" : "😐 Neutral")}
                    </span>
                  )}
                  {exportOptions.includeRating && exportUserData?.rating > 0 && (
                    <span style={{ fontSize: 11, fontWeight: 700, background: "#fffbeb", color: "#92400e", border: "1px solid #fde68a", borderRadius: 999, padding: "3px 10px" }}>
                      {"■".repeat(exportUserData.rating)}{"□".repeat(5 - exportUserData.rating)}
                    </span>
                  )}
                  {exportOptions.includeOtherRating && exportUserData?.other_rating && (
                    <span style={{ fontSize: 10, background: "#fff1f2", color: "#be123c", border: "1px solid #fecdd3", borderRadius: 999, padding: "3px 10px" }}>
                      {exportUserData.other_rating === "love_it" ? (isAr ? "🥰 أحبه" : "🥰 Love it") : exportUserData.other_rating === "like_it" ? (isAr ? "😍 يعجبني" : "😍 Like it") : exportUserData.other_rating === "neutral" ? (isAr ? "😐 محايد" : "😐 Neutral") : (isAr ? "😠 أكرهه" : "😠 Hate it")}
                    </span>
                  )}
                  {/* Fav / Dislike */}
                  {exportOptions.includeFavorite && (exportPerson === "person1" ? favBrandsP1 : favBrandsP2).includes(id) && (
                    <span style={{ fontSize: 10, background: "#fff1f2", color: "#be123c", border: "1px solid #fecdd3", borderRadius: 999, padding: "3px 10px" }}>❤️ {isAr ? "مفضّل" : "Favorite"}</span>
                  )}
                  </div>
                  {exportOptions.includeReview && exportUserData?.personal_notes && (
                  <p style={{ fontSize: 10, color: "#475569", fontStyle: "italic", marginTop: 8, borderLeft: "3px solid #e2e8f0", paddingLeft: 8, lineHeight: 1.5, wordWrap: "break-word", overflowWrap: "break-word", whiteSpace: "normal" }}>{exportUserData.personal_notes}</p>
                  )}
                  </div>
                  )}

              {/* Purchases summary */}
              {exportOptions.includePurchases && exportPurchases.length > 0 && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 6px" }}>
                    {isAr ? "المشتريات" : "Purchases"} {exportPurchases.length} {exportPurchases.reduce((s, r) => s + (r.ml || 0), 0)}ml
                  </p>
                  <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
                    {exportPurchases.slice(0, 6).map((r, i) => (
                      <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 8, fontSize: 10, color: "#334155", wordWrap: "break-word" }}>
                        <span style={{ fontSize: 9, fontWeight: 700, background: "#eff6ff", color: "#1d4ed8", borderRadius: 4, padding: "1px 5px", flexShrink: 0 }}>{r.type === "sample" ? (isAr ? "عينة" : "Sample") : (isAr ? "زجاجة" : "Bottle")}</span>
                        <span style={{ flex: 1, wordWrap: "break-word", overflowWrap: "break-word", whiteSpace: "normal" }}>{r.perfume_name}</span>
                        <span style={{ color: "#64748b", flexShrink: 0 }}>{r.ml}ml</span>
                        <span style={{ fontWeight: 700, color: "#059669", flexShrink: 0 }}>{formatPrice(r.cost)}</span>
                      </div>
                    ))}
                    {exportPurchases.length > 6 && (
                      <p style={{ fontSize: 9, color: "#94a3b8", margin: 0 }}>+{exportPurchases.length - 6} {isAr ? "أخرى" : "more"}...</p>
                    )}
                  </div>
                </div>
              )}

              {/* Health */}
              {exportOptions.includeHealth && exportPerson !== "all" && (exportUserData?.headache || exportUserData?.sinus_sensitivity) && (
                <div style={{ borderTop: "1px solid #f1f5f9", paddingTop: 8, marginBottom: 8 }}>
                  <p style={{ fontSize: 8, fontWeight: 700, color: "#94a3b8", textTransform: "uppercase", letterSpacing: "0.12em", margin: "0 0 5px" }}>Health الصحة</p>
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                    {exportUserData?.headache && (
                      <span style={{ fontSize: 9, fontWeight: 700, background: "#fef3c7", color: "#92400e", border: "1px solid #fde68a", borderRadius: 999, padding: "3px 10px" }}>
                        🤕 صداع: {{"none":"لا","weak":"ضعيف","medium":"متوسط","strong":"قوي"}[exportUserData.headache]}
                      </span>
                    )}
                    {exportUserData?.sinus_sensitivity && (
                      <span style={{ fontSize: 9, fontWeight: 700, background: "#eff6ff", color: "#1d4ed8", border: "1px solid #bfdbfe", borderRadius: 999, padding: "3px 10px" }}>
                        👃 جيوب أنفية: {{"yes":"نعم","a_little":"قليلاً","no":"لا"}[exportUserData.sinus_sensitivity]}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Bottom signature: photo + name, date, app name (when enabled) */}
              <ExportFooter compact photoName={userData?.display_name?.trim() || (userData?.full_name && userData.full_name !== "Local User" ? userData.full_name : "")} photoUrl={userData?.profile_photo || ""} />
            </div>

            <Button onClick={handleExport} disabled={exportLoading} className="w-full h-10 rounded-none font-body gap-2">
              <Download className="w-4 h-4" /> {exportLoading ? "Exporting..." : (exportFormat === "pdf" ? "Download PDF" : "Download Image")}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* ─── Edit Brand Dialog ─── */}
      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="max-w-sm rounded-none max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading">{isAr ? "تعديل البراند" : "Edit Brand"}</DialogTitle>
          </DialogHeader>
          {form && (
            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label className="text-xs font-body">{isAr ? "اسم البراند" : "Brand Name"}</Label>
                <Input value={form.name || ""} onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))} className="rounded-none font-body" />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">{isAr ? "الاسم العربي" : "Arabic Name"}</Label>
                <Input value={form.name_ar || ""} onChange={e => setForm(prev => ({ ...prev, name_ar: e.target.value }))} className="rounded-none font-body" dir="rtl" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1.5">
                  <Label className="text-xs font-body">{isAr ? "البلد" : "Country"}</Label>
                  <Input value={form.country || ""} onChange={e => setForm(prev => ({ ...prev, country: e.target.value }))} className="rounded-none font-body" />
                </div>
                <div className="space-y-1.5">
                  <Label className="text-xs font-body">{isAr ? "سنة التأسيس" : "Year Est."}</Label>
                  <Input type="number" value={form.year_established || ""} onChange={e => setForm(prev => ({ ...prev, year_established: Number(e.target.value) || undefined }))} className="rounded-none font-body" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">{isAr ? "الشركة الأم / القابضة" : "Parent Company / Holding"}</Label>
                <div className="relative">
                  <Input
                    value={form.owned_by || ""}
                    onChange={(e) => { setForm(prev => ({ ...prev, owned_by: e.target.value, parent_company: e.target.value })); setShowParentSuggestions(true); }}
                    onFocus={() => setShowParentSuggestions(true)}
                    onBlur={() => setTimeout(() => setShowParentSuggestions(false), 150)}
                    placeholder={isAr ? "ابحث في البراندات أو اكتب اسماً (مثل LVMH)" : "Search brands or type a name (e.g. LVMH)"}
                    className="rounded-none font-body"
                    id="parent-company"
                    autoComplete="off"
                  />
                  {showParentSuggestions && (form.owned_by || "").trim() && (() => {
                    const q = (form.owned_by || "").trim().toLowerCase();
                    // Build suggestion pool: existing parent companies + brand names,
                    // excluding this brand itself. Dedupe, keep close matches first.
                    const pool = new Set();
                    for (const b of allBrands) {
                      if (String(b.id) === String(id)) continue;
                      if (b.parent_company?.trim()) pool.add(b.parent_company.trim());
                      if (b.name?.trim()) pool.add(b.name.trim());
                    }
                    const matches = [...pool]
                      .filter(s => s.toLowerCase().includes(q) && s.toLowerCase() !== q)
                      .sort((a, b) => {
                        const ai = a.toLowerCase().startsWith(q) ? 0 : 1;
                        const bi = b.toLowerCase().startsWith(q) ? 0 : 1;
                        return ai - bi || a.localeCompare(b);
                      })
                      .slice(0, 8);
                    if (matches.length === 0) return null;
                    return (
                      <div className="absolute z-50 left-0 right-0 mt-1 bg-popover border border-border rounded-none shadow-lg max-h-52 overflow-y-auto">
                        {matches.map((s) => (
                          <button
                            key={s}
                            type="button"
                            onMouseDown={(e) => { e.preventDefault(); setForm(prev => ({ ...prev, owned_by: s, parent_company: s })); setShowParentSuggestions(false); }}
                            className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary transition-colors"
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    );
                  })()}
                </div>
                <p className="text-[10px] text-muted-foreground font-body">{isAr ? "ابحث واختر من البراندات الموجودة، أو اكتب اسماً جديداً" : "Search & pick an existing brand, or type a new name"}</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">{isAr ? "الموقع" : "Website"}</Label>
                <Input value={form.website || ""} onChange={e => setForm(prev => ({ ...prev, website: e.target.value }))} placeholder="https://..." className="rounded-none font-body" />
              </div>
              <div className="flex items-center gap-3 bg-secondary/50 rounded-none px-4 py-3">
                <Label className="text-sm font-body flex-1">{isAr ? "ما زال يعمل" : "Currently In Business?"}</Label>
                <button onClick={() => setForm(prev => ({ ...prev, in_business: !prev.in_business }))}
                  className={`w-10 h-6 rounded-none transition-colors ${form.in_business !== false ? "bg-primary" : "bg-muted"}`}>
                  <div className={`w-4 h-4 bg-white rounded-none shadow transition-transform mx-1 ${form.in_business !== false ? "translate-x-4" : "translate-x-0"}`} />
                </button>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">About حول البراند</Label>
                <Textarea value={form.description || ""} onChange={e => setForm(prev => ({ ...prev, description: e.target.value }))} className="rounded-none font-body min-h-[100px]" placeholder="EN: Description & history... / AR: الوصف و التاريخ..." />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Signature / Famous Notes النوتات المميّزة</Label>
                <p className="text-[10px] text-muted-foreground font-body mb-2">All available notes (Main, Sub, Low) - search to find</p>
                <NotesTagSearch
                  value={form.signature_notes_names || ""}
                  onChange={(v) => {
                    const names = v.split(",").map(s => s.trim()).filter(Boolean);
                    const ids = names.map(name => {
                      const note = allNotes.find(n => n.name === name);
                      return note?.id || "";
                    }).filter(Boolean);
                    setForm(prev => ({
                      ...prev,
                      signature_notes_names: v,
                      signature_notes_ids: ids.join(","),
                      // Clear legacy field so old data doesn't double up on next render
                      innovation_notes: "",
                    }));
                  }}
                  placeholder={isAr ? "ابحث عن أي نوتة" : "Search any note..."}
                  noteCategory="all"
                  id="signature-notes"
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-body">Logo / Photo</Label>
                {form.logo_url ? (
                  <div className="relative w-full h-24 rounded-none border border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
                    <img src={form.logo_url} alt="Logo" className="w-full h-full object-cover" />
                    <button type="button" onClick={() => setForm(prev => ({ ...prev, logo_url: "" }))}
                      className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600">
                      <X className="w-3.5 h-3.5 text-white" />
                    </button>
                  </div>
                ) : (
                  <label className="flex items-center justify-center gap-2 w-full h-24 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                    <Upload className="w-4 h-4 text-muted-foreground" />
                    <span className="text-xs font-body text-muted-foreground">{isAr ? "اضغط للرفع" : "Click to upload"}</span>
                    <input type="file" onChange={handleUploadLogo} disabled={uploading} accept="image/*" className="hidden" />
                  </label>
                )}
              </div>
              <Button className="w-full rounded-none font-body" onClick={() => updateMutation.mutate({ ...form })} disabled={updateMutation.isPending || uploading}>
                {updateMutation.isPending ? "Saving..." : "Save Changes"}
              </Button>
              <Button variant="ghost" className="w-full rounded-none font-body" style={{ color: "#d97706" }} onClick={async () => { try { await apphost.entities.PerfumeBrand.update(id, { hidden: true }); queryClient.invalidateQueries({ queryKey: ["brands"] }); toast.success(isAr ? "نُقل إلى المهملات Moved to Cast Away" : "Moved to Cast Away"); navigate("/brands"); } catch (e) { toast.error(isAr ? "تعذّر النقل" : "Failed"); } }}>
                {isAr ? "نقل إلى المهملات Cast away" : "Cast away"}
              </Button>
              <Button variant="ghost" className="w-full rounded-none font-body text-destructive hover:text-destructive" onClick={async () => { if (!confirm(isAr ? "حذف هذا البراند نهائياً؟ لا يمكن التراجع. Delete this brand permanently?" : "Delete this brand permanently? This cannot be undone.")) return; try { await apphost.entities.PerfumeBrand.delete(id); queryClient.invalidateQueries({ queryKey: ["brands"] }); toast.success(isAr ? "تم الحذف Deleted" : "Deleted"); navigate("/brands"); } catch (e) { toast.error(isAr ? "فشل الحذف" : "Delete failed"); } }}>
                {isAr ? "حذف البراند نهائياً Delete permanently" : "Delete permanently"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Small helper: render an innovation note card using pre-fetched allNotes
function InnovationNoteCard({ name, navigate, allNotes = [] }) {
  const record = allNotes.find(n => n.name?.toLowerCase() === name.toLowerCase());
  return (
    <button
      onClick={() => record ? navigate(`/note?id=${record.id}`) : navigate(`/explore?noteSearch=${encodeURIComponent(name)}`)}
      className="flex flex-col gap-2 text-left hover:opacity-80 transition-opacity group"
    >
      <div className="w-full aspect-square rounded-none overflow-hidden flex items-center justify-center border border-border/50 bg-white">
        {record?.image_url ? (
          <img src={record.image_url} alt={name} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-white" />
        )}
      </div>
      <div className="px-1">
        <p className="text-[10px] font-body font-semibold text-foreground line-clamp-2 group-hover:underline leading-tight">{name}</p>
      </div>
    </button>
  );
}