import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Star } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";

export default function TopRated() {
  const { isAr } = useLang();
  const navigate = useNavigate();
  const { names, profiles } = usePersonNames();
  const [activePerson, setActivePerson] = useState("person1");

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  // Only the perfumes the user has actually rated are needed here — fetch
  // those by id instead of loading the whole catalogue into memory.
  const ratedIds = useMemo(
    () => [...new Set(userPerfumes.map((u) => u.perfume_id).filter((v) => v != null))],
    [userPerfumes]
  );

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes-by-ids", ratedIds],
    queryFn: () => apphost.entities.Perfume.getMany(ratedIds),
    enabled: ratedIds.length > 0,
  });

  const getTopRated = (person) => {
    const userIds = userPerfumes
      .filter((u) => u.person === person && u.rating && u.rating >= 3)
      .sort((a, b) => (b.rating || 0) - (a.rating || 0))
      .map((u) => u.perfume_id);
    
    return perfumes
      .filter((p) => userIds.includes(p.id))
      .map((p) => ({
        ...p,
        rating: userPerfumes.find((u) => String(u.perfume_id) === String(p.id) && u.person === person)?.rating || 0,
      }))
      .sort((a, b) => b.rating - a.rating);
  };

  const p1TopRated = getTopRated("person1");
  const p2TopRated = getTopRated("person2");
  const activeTopRated = activePerson === "person1" ? p1TopRated : p2TopRated;

  const color = activePerson === "person1" ? profiles.person1?.color : profiles.person2?.color;
  const person = activePerson === "person1" ? names.person1 : names.person2;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="px-4 pt-12 pb-4 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center hover:bg-accent transition-colors">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="font-heading text-xl font-bold">{isAr ? "الأعلى تقييماً" : "Top Rated"}</h1>
          <p className="text-xs text-muted-foreground font-body">Perfumes rated 3+ stars</p>
        </div>
      </div>

      {/* Person Toggle */}
      <div className="px-4 mb-5 flex gap-2">
        <button
          onClick={() => setActivePerson("person1")}
          className={`flex-1 py-2.5 rounded-none text-sm font-body font-medium transition-all border ${
            activePerson === "person1"
              ? "bg-primary text-primary-foreground border-primary shadow"
              : "bg-secondary/50 border-border/50 text-muted-foreground hover:text-foreground"
          }`}
        >
          {names.person1}
        </button>
        <button
          onClick={() => setActivePerson("person2")}
          className={`flex-1 py-2.5 rounded-none text-sm font-body font-medium transition-all border ${
            activePerson === "person2"
              ? "bg-primary text-primary-foreground border-primary shadow"
              : "bg-secondary/50 border-border/50 text-muted-foreground hover:text-foreground"
          }`}
        >
          {names.person2}
        </button>
      </div>

      {/* Content */}
      <div className="px-4 space-y-4">
        {activeTopRated.length === 0 ? (
          <div className="text-center py-12 space-y-2">
            <Star className="w-12 h-12 text-muted-foreground/30 mx-auto" />
            <p className="text-muted-foreground font-body">{person} hasn't rated any perfumes yet</p>
          </div>
        ) : (
          <div className="space-y-4">
            {activeTopRated.map((perfume) => {
              const userPerfume = userPerfumes.find(
                (u) => String(u.perfume_id) === String(perfume.id) && u.person === activePerson
              );
              return (
                <div key={perfume.id} className="flex items-start gap-3 bg-card rounded-none p-3 border border-border/50">
                  <div className="flex-1 min-w-0">
                    <button
                      onClick={() => navigate(`/perfume?id=${perfume.id}`)}
                      className="text-left hover:opacity-70 transition-opacity"
                    >
                      <p className="text-xs text-primary font-body uppercase tracking-widest font-medium">{perfume.brand_name}</p>
                      <h3 className="font-heading font-semibold text-sm">{perfume.name}</h3>
                    </button>
                  </div>
                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <div className="flex items-center gap-0.5 bg-amber-50 dark:bg-amber-950/30 rounded-none px-2 py-1">
                      <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                      <span className="text-xs font-body font-bold text-amber-700 dark:text-amber-400">{userPerfume?.rating}</span>
                    </div>
                    {userPerfume?.private_notes && (
                      <p className="text-[10px] text-muted-foreground font-body text-right line-clamp-2 max-w-xs">
                        {userPerfume.private_notes}
                      </p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}