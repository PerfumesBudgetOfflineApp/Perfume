import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Droplets, Download } from "lucide-react";
import AppLogo from "@/components/icons/AppLogo";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import ActivityTimeline from "@/components/home/ActivityTimeline";
import { getSecureStorage } from "@/lib/storageEncryption";
import WearReminders from "@/components/shared/WearReminders";
import GlobalSearch from "@/components/home/GlobalSearch";
import ActivityExportDialog from "@/components/home/ActivityExportDialog";
import { useMemo, useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useTranslations } from "@/lib/useTranslations";
import { useLang } from "@/lib/LanguageContext";

export default function Home() {
  const navigate = useNavigate();
  const { t } = useTranslations();
  const { isAr } = useLang();

  const [filters, setFilters] = useState({ reviews: true, purchases: false, favorites: true, wearLogs: true, blogEntries: true, glossaryEntries: true, goals: true, budgetEntries: true, quotesActivity: true, wishes: false });
  const [sortOrder, setSortOrder] = useState("newest");
  const [exportOpen, setExportOpen] = useState(false);
  const [showActivity, setShowActivity] = useState(() => getSecureStorage("showActivityTimeline", true));
  useEffect(() => {
    const h = () => setShowActivity(getSecureStorage("showActivityTimeline", true));
    window.addEventListener("activitySectionChanged", h);
    return () => window.removeEventListener("activitySectionChanged", h);
  }, []);



  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: blogPosts = [] } = useQuery({
    queryKey: ["blog-posts"],
    queryFn: () => apphost.entities.BlogPost.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: glossaryTerms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: goals = [] } = useQuery({
    queryKey: ["goals"],
    queryFn: () => apphost.entities.Goal.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: budgetIncomes = [] } = useQuery({
    queryKey: ["budget-incomes"],
    queryFn: () => apphost.entities.BudgetIncome.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: budgetExpenses = [] } = useQuery({
    queryKey: ["budget-expenses"],
    queryFn: () => apphost.entities.BudgetExpense.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: userQuotes = [] } = useQuery({
    queryKey: ["user-quotes"],
    queryFn: () => apphost.entities.UserQuote.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: allQuotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: shopProducts = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: wishlists = [] } = useQuery({
    queryKey: ["wishlists"],
    queryFn: () => apphost.entities.Wishlist.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const hasActivities = useMemo(() => {
    return userPerfumes.length > 0 || purchaseRecords.length > 0 || wearLogs.length > 0 || blogPosts.length > 0 || glossaryTerms.length > 0 || goals.length > 0;
  }, [userPerfumes, purchaseRecords, wearLogs, blogPosts, glossaryTerms, goals]);

  // Build flat activities list for export (mirrors ActivityTimeline logic)
   const allActivitiesForExport = useMemo(() => {
     const all = [];
     userPerfumes.forEach((up) => {
       const impressionEmoji = up.impression === "great" ? "😍" : up.impression === "not_great" ? "😕" : up.impression === "neutral" ? "😐" : "";
       const ratingStars = up.rating ? "■".repeat(up.rating) + "□".repeat(5 - up.rating) : "";
       if (up.rating || up.impression) all.push({ type: "review", id: up.id, title: `Reviewed ${up.perfume_name}`, subtitle: `by ${up.brand_name}`, person: up.person, date: new Date(up.created_date), emoji: impressionEmoji, rating: up.rating, ratingStars, image_url: up.image_url });
       if (up.list === "favorite") all.push({ type: "favorite", id: `fav-${up.id}`, title: `Added to favorites`, subtitle: `${up.perfume_name} · ${up.brand_name}`, person: up.person, date: new Date(up.created_date) });
     });
     purchaseRecords.forEach((pr) => all.push({ type: "purchase", id: pr.id, title: `Purchased ${pr.type === "sample" ? "sample" : "bottle"}`, subtitle: `${pr.perfume_name} · ${pr.ml}ml`, person: pr.person, date: new Date(pr.purchase_date || pr.created_date) }));
     wearLogs.forEach((wl) => all.push({ type: "wear", id: wl.id, title: `Wore ${wl.perfume_name}`, subtitle: wl.brand_name, person: wl.person, date: new Date(wl.date || wl.created_date) }));
     blogPosts.forEach((bp) => all.push({ type: "blog", id: bp.id, title: bp.title, subtitle: `${bp.entry_type} entry`, person: bp.person, date: new Date(bp.created_date) }));
     glossaryTerms.forEach((gt) => all.push({ type: "glossary", id: `gl-${gt.id}`, title: gt.term_en, subtitle: gt.term_ar || "", person: null, date: new Date(gt.created_date) }));
     goals.forEach((g) => all.push({ type: "goal", id: `goal-${g.id}`, title: g.title, subtitle: `${g.category || ""} · ${g.status || "pending"}`, person: g.person === "both" ? null : g.person, date: new Date(g.created_date) }));
     budgetIncomes.forEach((inc) => all.push({ type: "budget", id: `inc-${inc.id}`, title: `Income: ${inc.type}`, subtitle: `${inc.amount} · ${inc.date || ""}`, person: inc.person === "family" ? null : inc.person, date: new Date(inc.date || inc.created_date) }));
     budgetExpenses.forEach((exp) => all.push({ type: "budget", id: `exp-${exp.id}`, title: `Expense: ${exp.category}`, subtitle: `${exp.amount} · ${exp.description || ""}`, person: exp.person === "family" ? null : exp.person, date: new Date(exp.date || exp.created_date) }));
     userQuotes.forEach((uq) => {
       const quote = allQuotes.find((q) => String(q.id) === String(uq.quote_id));
       const reactionLabel = uq.reaction === "like" ? "❤️" : uq.reaction === "dislike" ? "💔" : uq.reaction === "wtf" ? "😱" : "💬";
       const isNew = !uq.reaction || uq.reaction === "none";
       const title = isNew ? `Added quote` : `Reacted ${reactionLabel} to quote`;
       // Use new text_enar field with fallback to legacy text_en / snapshot copy on UserQuote
       const fullText = (quote?.text_enar) || (uq.text_enar) || (quote?.text_en) || (uq.text_en) || "";
       const subtitle = fullText.slice(0, 60) + (fullText.length > 60 ? "…" : "");
       all.push({ type: "quote", id: `uq-${uq.id}`, title, subtitle, person: null, date: new Date(uq.created_date) });
     });
     wishlists.forEach((w) => {
       if (w.perfume_id) {
         all.push({ type: "wish", id: `wish-${w.id}`, title: `Added to wishlist`, subtitle: `${w.perfume_name || ""} · ${w.brand_name || ""}`, person: w.person, date: new Date(w.added_date || w.created_date) });
       }
     });
     shopProducts.forEach((sp) => {
       if (sp.cost && sp.purchase_date) {
         all.push({ type: "purchase", id: `shop-${sp.id}`, title: `Purchased ${sp.name}`, subtitle: `${sp.brand_name || "Unknown"} · ${sp.cost}`, person: sp.person, date: new Date(sp.purchase_date) });
       }
     });
     all.sort((a, b) => b.date - a.date);
     return all;
   }, [userPerfumes, purchaseRecords, wearLogs, blogPosts, glossaryTerms, goals, budgetIncomes, budgetExpenses, userQuotes, allQuotes, wishlists, shopProducts]);

  return (
    <div className="px-4 pt-12 pb-32 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
         <AppLogo className="w-8 h-8" style={{ color: "var(--brand)" }} />
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.location.reload()}
            className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors text-base"
            title={isAr ? "تحديث" : "Refresh"}
          >
            ♻️
          </button>
          {hasActivities && (
            <button
              onClick={() => setExportOpen(true)}
              className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors"
              title={isAr ? "تصدير" : "Export Report"}
            >
              <Download className="w-4 h-4 text-foreground/60 hover:text-foreground transition-colors" />
            </button>
          )}
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* Golden divider */}
      <div className="h-px bg-gradient-to-r from-amber-300/40 via-amber-400/60 to-amber-300/40" />

      {/* البحث الشامل في كل التطبيق */}
      <GlobalSearch />

      {!hasActivities && (
        <>
          <div className={`text-center space-y-4 ${isAr ? 'rtl' : ''}`}>
            <h1 className="font-heading text-3xl font-bold">{t('home.welcomeBack')}</h1>
            <p className="text-sm text-muted-foreground font-body">{t('perfumes.myCollection')}</p>
          </div>
          <div className="space-y-3">
            <Button onClick={() => navigate("/")} className="w-full h-10 rounded-none font-body gap-2">
              <Droplets className="w-4 h-4" /> {t('navigation.perfumes')}
            </Button>
            <Button onClick={() => navigate("/explore")} variant="outline" className="w-full h-10 rounded-none font-body">
              {t('navigation.explore')}
            </Button>
            <Button onClick={() => navigate("/progress")} variant="outline" className="w-full h-10 rounded-none font-body">
              {t('navigation.wearHistory')}
            </Button>
          </div>
        </>
      )}


      {/* تذكير ارتداء العطر */}
      <WearReminders />

      {hasActivities && showActivity && (
        <ActivityTimeline filters={filters} sortOrder={sortOrder} />
      )}

      <ActivityExportDialog
        open={exportOpen}
        onOpenChange={setExportOpen}
        activities={allActivitiesForExport}
      />
    </div>
  );
}
