import { useState } from "react";
import BackButton from "@/components/shared/BackButton";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Flower2, ChevronRight } from "lucide-react";
import Pagination from "@/components/Pagination";

const PYRAMID_COLORS = {
  top: "border-sky-500 bg-sky-50 dark:bg-sky-900/10",
  heart: "border-rose-500 bg-rose-50 dark:bg-rose-900/10",
  base: "border-amber-500 bg-amber-50 dark:bg-amber-900/10",
  conductor: "border-teal-500 bg-teal-50 dark:bg-teal-900/10",
  all: "border-violet-500 bg-violet-50 dark:bg-violet-900/10",
};

const PYRAMID_BADGES = {
  top: "bg-sky-100 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300",
  heart: "bg-rose-100 dark:bg-rose-900/40 text-rose-700 dark:text-rose-300",
  base: "bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300",
  conductor: "bg-teal-100 dark:bg-teal-900/40 text-teal-700 dark:text-teal-300",
  all: "bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300",
};

export default function NotesIndex() {
  const [search, setSearch] = useState("");
  const [pyramidFilter, setPyramidFilter] = useState("all");

  const { data: notes = [], isLoading } = useQuery({
    queryKey: ["notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  const filtered = notes
    .filter((n) => {
      const matchSearch = !search || n.name?.toLowerCase().includes(search.toLowerCase()) || n.name_ar?.includes(search);
      const matchPyramid = pyramidFilter === "all" || (n.pyramid && n.pyramid.includes(pyramidFilter));
      return matchSearch && matchPyramid;
    });

  const pyramidGroups = {
    top: filtered.filter(n => n.pyramid && n.pyramid.includes("top")),
    heart: filtered.filter(n => n.pyramid && n.pyramid.includes("heart")),
    base: filtered.filter(n => n.pyramid && n.pyramid.includes("base")),
    other: filtered.filter(n => !n.pyramid || (n.pyramid !== "top" && n.pyramid !== "heart" && n.pyramid !== "base")),
  };

  return (
    <div className="px-5 pt-12 pb-4 space-y-6">
      <BackButton fallback="/" />
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-3xl font-bold">النوتات العطرية Notes</h1>
          <p className="text-xs text-muted-foreground font-body mt-1">{notes.length} note{notes.length !== 1 ? "s" : ""}</p>
        </div>
        <Link to="/notes">
          <Button size="sm" className="rounded-none font-body bg-emerald-800 hover:bg-emerald-900 text-white">
            Manage
          </Button>
        </Link>
      </div>

      {/* Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث عن نوتات Search notes..." className="pl-9 h-11 rounded-none font-body bg-secondary/50 border-0" />
        </div>
        <div className="flex gap-2 flex-wrap">
          {[
            { value: "all", label: "All" },
            { value: "top", label: "↑ Top" },
            { value: "heart", label: "♥ Heart" },
            { value: "base", label: "↓ Base" },
          ].map(({ value, label }) => (
            <button key={value} onClick={() => setPyramidFilter(value)}
              className={` rounded-none text-xs font-body font-medium transition-all ${pyramidFilter === value ? " text-white " : " text-muted-foreground hover:text-foreground"}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-emerald-200 border-t-emerald-800 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-900/20 rounded-none flex items-center justify-center mx-auto">
            <Flower2 className="w-8 h-8 text-emerald-700" />
          </div>
          <p className="text-muted-foreground font-body text-sm">لا نوتات No notes found</p>
        </div>
      ) : (
        <div className="space-y-8">
          {pyramidFilter === "all" ? (
            <>
              {/* Top Notes */}
              {pyramidGroups.top.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-heading text-lg font-semibold text-sky-900 dark:text-sky-400 flex items-center gap-2">
                    <div className="w-6 h-6 rounded-none bg-sky-100 dark:bg-sky-900/40 flex items-center justify-center text-xs">↑</div>
                    Top Notes ({pyramidGroups.top.length})
                  </h2>
                  <Pagination
                    items={pyramidGroups.top}
                    itemsPerPage={50}
                    renderItem={(items) => (
                      <div className="space-y-2">
                        {items.map((note) => <NoteCard key={note.id} note={note} />)}
                      </div>
                    )}
                    emptyMessage="No top notes found"
                  />
                </div>
              )}

              {/* Heart Notes */}
              {pyramidGroups.heart.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-heading text-lg font-semibold text-rose-900 dark:text-rose-400 flex items-center gap-2">
                    <div className="w-6 h-6 rounded-none bg-rose-100 dark:bg-rose-900/40 flex items-center justify-center text-xs">♥</div>
                    Heart Notes ({pyramidGroups.heart.length})
                  </h2>
                  <Pagination
                    items={pyramidGroups.heart}
                    itemsPerPage={50}
                    renderItem={(items) => (
                      <div className="space-y-2">
                        {items.map((note) => <NoteCard key={note.id} note={note} />)}
                      </div>
                    )}
                    emptyMessage="No heart notes found"
                  />
                </div>
              )}

              {/* Base Notes */}
              {pyramidGroups.base.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-heading text-lg font-semibold text-amber-900 dark:text-amber-400 flex items-center gap-2">
                    <div className="w-6 h-6 rounded-none bg-amber-100 dark:bg-amber-900/40 flex items-center justify-center text-xs">↓</div>
                    Base Notes ({pyramidGroups.base.length})
                  </h2>
                  <Pagination
                    items={pyramidGroups.base}
                    itemsPerPage={50}
                    renderItem={(items) => (
                      <div className="space-y-2">
                        {items.map((note) => <NoteCard key={note.id} note={note} />)}
                      </div>
                    )}
                    emptyMessage="No base notes found"
                  />
                </div>
              )}

              {/* Other Notes */}
              {pyramidGroups.other.length > 0 && (
                <div className="space-y-3">
                  <h2 className="font-heading text-lg font-semibold text-muted-foreground flex items-center gap-2">
                    <div className="w-6 h-6 rounded-none bg-secondary flex items-center justify-center text-xs">?</div>
                    Other ({pyramidGroups.other.length})
                  </h2>
                  <Pagination
                    items={pyramidGroups.other}
                    itemsPerPage={50}
                    renderItem={(items) => (
                      <div className="space-y-2">
                        {items.map((note) => <NoteCard key={note.id} note={note} />)}
                      </div>
                    )}
                    emptyMessage="No other notes found"
                  />
                </div>
              )}
            </>
          ) : (
            <Pagination
              items={filtered}
              itemsPerPage={50}
              renderItem={(items) => (
                <div className="space-y-2">
                  {items.map((note) => <NoteCard key={note.id} note={note} />)}
                </div>
              )}
              emptyMessage="No notes found"
            />
          )}
        </div>
      )}
    </div>
  );
}

function NoteCard({ note }) {
  const pyramid = note.pyramid?.split(",")[0]?.trim();
  const borderColor = pyramid ? PYRAMID_COLORS[pyramid] : "border-border/40 bg-card";
  const badgeColor = pyramid ? PYRAMID_BADGES[pyramid] : "bg-muted text-muted-foreground";

  return (
    <Link to={`/note?id=${note.id}`}>
      <div className={`rounded-none hover:shadow-md transition-all duration-200 flex items-center gap-3 border ${borderColor} overflow-hidden`}>
        {/* الخط الجانبي الملون */}
        <div className={`w-1 self-stretch flex-shrink-0 ${pyramid ? "" : "bg-muted"}`} style={{
          background: pyramid === "top" ? "#38bdf8" : pyramid === "heart" ? "#fb7185" : pyramid === "base" ? "#fbbf24" : pyramid === "conductor" ? "#2dd4bf" : pyramid === "all" ? "#a78bfa" : "#e2e8f0"
        }} />

        {/* الصورة */}
        <div className="w-10 h-10 flex-shrink-0 overflow-hidden flex items-center justify-center my-2.5" style={{ background: "transparent" }}>
          {note.image_url ? (
            <img src={note.image_url} alt={note.name} loading="lazy" decoding="async" className="w-full h-full object-contain" style={{ background: "transparent" }} />
          ) : null}
        </div>

        {/* المحتوى */}
        <div className="flex-1 min-w-0 py-2.5">
          <div className="flex items-center gap-1.5 flex-wrap">
            <p className="font-body font-semibold text-[13px] leading-tight">{note.name_en || note.name}</p>
            {pyramid && (
              <span className={`text-[9px] px-1.5 py-0.5 rounded-none font-body font-bold ${badgeColor}`}>
                {pyramid}
              </span>
            )}
          </div>
          {note.name_ar && (
            <p className="text-[11px] text-muted-foreground font-body mt-0.5" dir="rtl">{note.name_ar}</p>
          )}
          <div className="flex items-center gap-1.5 flex-wrap mt-1">
            {note.category && (
              <span className="text-[10px] text-muted-foreground rounded-none font-body">
                {note.category.split(",")[0].trim()}
              </span>
            )}
            {note.odor_family && (
              <span className="text-[10px] text-muted-foreground rounded-none font-body">
                {note.odor_family.split(",")[0].trim()}
              </span>
            )}
            {note.origin && (
              <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-body">📍 {note.origin}</span>
            )}
          </div>
        </div>

        <ChevronRight className="w-4 h-4 text-muted-foreground flex-shrink-0 mr-3" />
      </div>
    </Link>
  );
}