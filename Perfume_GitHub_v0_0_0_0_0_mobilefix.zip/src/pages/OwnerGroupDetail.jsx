import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Building2, Globe, CalendarDays, Droplets, ExternalLink } from "lucide-react";
import { Link } from "react-router-dom";
import { openExternalUrl } from "@/lib/exportHelper";

// Static info for well-known conglomerates
const GROUP_INFO = {
  "lvmh": {
    fullName: "LVMH Moët Hennessy Louis Vuitton",
    country: "France",
    founded: 1987,
    hq: "Paris, France",
    website: "https://www.lvmh.com",
    description: "LVMH is the world's largest luxury goods conglomerate, owning over 75 prestigious houses across fashion, leather goods, perfumes, cosmetics, watches, jewelry, wines and spirits.",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/LVMH_logo.svg/320px-LVMH_logo.svg.png",
  },
  "estee lauder": {
    fullName: "The Estée Lauder Companies",
    country: "USA",
    founded: 1946,
    hq: "New York, USA",
    website: "https://www.elcompanies.com",
    description: "The Estée Lauder Companies is a global leader in prestige beauty, manufacturing and marketing skincare, makeup, fragrance, and hair care products under a portfolio of renowned brands.",
    logo: "https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/Estee_Lauder_Companies_logo.svg/320px-Estee_Lauder_Companies_logo.svg.png",
  },
  "coty": {
    fullName: "Coty Inc.",
    country: "USA",
    founded: 1904,
    hq: "Amsterdam, Netherlands",
    website: "https://www.coty.com",
    description: "Coty is one of the world's largest beauty companies with a portfolio spanning fragrance, color cosmetics, and skin and body care.",
    logo: null,
  },
  "puig": {
    fullName: "Puig",
    country: "Spain",
    founded: 1914,
    hq: "Barcelona, Spain",
    website: "https://www.puig.com",
    description: "Puig is a family-owned fashion and fragrance business headquartered in Barcelona, with a portfolio of prestigious brands in fragrance, fashion, and beauty.",
    logo: null,
  },
  "chanel": {
    fullName: "Chanel S.A.",
    country: "France",
    founded: 1910,
    hq: "Paris, France",
    website: "https://www.chanel.com",
    description: "Chanel is a privately-held French fashion house, one of the most iconic luxury brands globally, known for its haute couture, ready-to-wear, fragrances, and accessories.",
    logo: null,
  },
  "hermès": {
    fullName: "Hermès International S.A.",
    country: "France",
    founded: 1837,
    hq: "Paris, France",
    website: "https://www.hermes.com",
    description: "Hermès is a French high-fashion luxury goods manufacturer known for its leather goods, lifestyle accessories, home furnishings, perfumery, jewelry, watches, and ready-to-wear.",
    logo: null,
  },
  "hermes": {
    fullName: "Hermès International S.A.",
    country: "France",
    founded: 1837,
    hq: "Paris, France",
    website: "https://www.hermes.com",
    description: "Hermès is a French high-fashion luxury goods manufacturer known for its leather goods, lifestyle accessories, home furnishings, perfumery, jewelry, watches, and ready-to-wear.",
    logo: null,
  },
  "richemont": {
    fullName: "Compagnie Financière Richemont SA",
    country: "Switzerland",
    founded: 1988,
    hq: "Geneva, Switzerland",
    website: "https://www.richemont.com",
    description: "Richemont is a Swiss luxury conglomerate best known for its prestigious jewelry and watch brands, also owning several fashion and accessories houses.",
    logo: null,
  },
  "kering": {
    fullName: "Kering S.A.",
    country: "France",
    founded: 1963,
    hq: "Paris, France",
    website: "https://www.kering.com",
    description: "Kering is a French multinational corporation specializing in luxury goods, managing the development of a series of renowned houses in fashion, leather goods, jewelry, and watches.",
    logo: null,
  },
  "l'oréal": {
    fullName: "L'Oréal S.A.",
    country: "France",
    founded: 1909,
    hq: "Clichy, France",
    website: "https://www.loreal.com",
    description: "L'Oréal is the world's largest cosmetics company, active in the field of production and sale of cosmetics, skin care, sun protection, make-up, perfumes, and hair care products.",
    logo: null,
  },
  "loreal": {
    fullName: "L'Oréal S.A.",
    country: "France",
    founded: 1909,
    hq: "Clichy, France",
    website: "https://www.loreal.com",
    description: "L'Oréal is the world's largest cosmetics company, active in the field of production and sale of cosmetics, skin care, sun protection, make-up, perfumes, and hair care products.",
    logo: null,
  },
};

function getGroupInfo(name) {
  if (!name) return null;
  const key = name.toLowerCase().trim();
  // Exact match first
  if (GROUP_INFO[key]) return GROUP_INFO[key];
  // Partial match
  for (const [k, v] of Object.entries(GROUP_INFO)) {
    if (key.includes(k) || k.includes(key)) return v;
  }
  return null;
}

export default function OwnerGroupDetail() {
  const urlParams = new URLSearchParams(window.location.search);
  const groupName = urlParams.get("name") || "";
  const navigate = useNavigate();

  const info = getGroupInfo(groupName);

  const { data: allBrands = [], isLoading } = useQuery({
    queryKey: ["brands-light"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const q = groupName.toLowerCase().trim();
  const relatedBrands = allBrands.filter(b =>
    b.owned_by?.toLowerCase().includes(q) ||
    b.parent_company?.toLowerCase().includes(q) ||
    b.name?.toLowerCase() === q
  );

  const getPerfumeCount = (brandName) =>
    perfumes.filter(p => p.brand_name === brandName).length;

  const displayName = info?.fullName || groupName;

  return (
    <div className="pb-8">
      {/* Header */}
      <div className="relative bg-gradient-to-br from-secondary to-accent px-5 pt-12 pb-8">
        <Button
          variant="secondary"
          size="icon"
          className="rounded-none shadow-md mb-4"
          onClick={() => navigate(-1)}
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>

        <div className="flex items-start gap-4">
          {/* Logo or Initials */}
          <div className="w-20 h-20 rounded-none bg-card shadow-lg flex items-center justify-center flex-shrink-0 overflow-hidden">
            {info?.logo ? (
              <img src={info.logo} alt={displayName} className="w-full h-full object-contain p-2" />
            ) : (
              <Building2 className="w-10 h-10 text-primary/30" />
            )}
          </div>

          <div className="flex-1 min-w-0 pt-1">
            <p className="text-xs text-muted-foreground font-body uppercase tracking-widest mb-1">المجموعة المالكة Holding Group</p>
            <h1 className="font-heading text-xl font-bold leading-tight">{displayName}</h1>
            {info?.country && (
              <p className="text-sm text-muted-foreground font-body mt-1 flex items-center gap-1.5">
                <Globe className="w-3.5 h-3.5" /> {info.country}
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="px-5 mt-5 space-y-5">

        {/* Info Cards */}
        <div className="grid grid-cols-2 gap-3">
          {info?.founded && (
            <div className="bg-card rounded-none p-4 shadow-sm flex items-center gap-3">
              <div className="w-9 h-9 bg-amber-100 dark:bg-amber-900/40 rounded-none flex items-center justify-center flex-shrink-0">
                <CalendarDays className="w-4 h-4 text-amber-600" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">تأسّس Founded</p>
                <p className="text-sm font-body font-bold">{info.founded}</p>
              </div>
            </div>
          )}
          {info?.hq && (
            <div className="bg-card rounded-none p-4 shadow-sm flex items-center gap-3">
              <div className="w-9 h-9 bg-sky-100 dark:bg-sky-900/40 rounded-none flex items-center justify-center flex-shrink-0">
                <Globe className="w-4 h-4 text-sky-600" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">HQ</p>
                <p className="text-sm font-body font-bold leading-tight">{info.hq}</p>
              </div>
            </div>
          )}
          <div className="bg-card rounded-none p-4 shadow-sm flex items-center gap-3 col-span-2">
            <div className="w-9 h-9 bg-primary/10 rounded-none flex items-center justify-center flex-shrink-0">
              <Droplets className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">براندات تطبيقك Brands in your app</p>
              <p className="text-sm font-body font-bold">{relatedBrands.length} brand{relatedBrands.length !== 1 ? "s" : ""}</p>
            </div>
          </div>
          {info?.website && (
            <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(info.website); }}className="bg-card rounded-none p-4 shadow-sm flex items-center gap-3 col-span-2 hover:bg-accent transition-colors"
            >
              <div className="w-9 h-9 bg-emerald-100 dark:bg-emerald-900/40 rounded-none flex items-center justify-center flex-shrink-0">
                <ExternalLink className="w-4 h-4 text-emerald-600" />
              </div>
              <div>
                <p className="text-[10px] text-muted-foreground font-body uppercase font-semibold">الموقع الرسمي Official Website</p>
                <p className="text-sm font-body font-bold text-emerald-600 truncate">{info.website}</p>
              </div>
            </button>
          )}
        </div>

        {/* Description */}
        {info?.description && (
          <div className="bg-card rounded-none p-5 shadow-sm">
            <h2 className="font-heading font-semibold mb-2">نبذة About</h2>
            <p className="text-sm font-body text-foreground/80 leading-relaxed">{info.description}</p>
          </div>
        )}

        {/* No static info — show generic card */}
        {!info && (
          <div className="bg-card rounded-none p-5 shadow-sm">
            <p className="text-sm font-body text-muted-foreground">
              No detailed information available for <span className="font-semibold text-foreground">"{groupName}"</span>. Showing related brands from your collection below.
            </p>
          </div>
        )}

        {/* Related Brands */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="font-heading font-semibold">البراندات Brands</h2>
            <span className="text-xs text-muted-foreground font-body">{relatedBrands.length} in your collection</span>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : relatedBrands.length === 0 ? (
            <div className="bg-card rounded-none p-6 text-center">
              <p className="text-sm text-muted-foreground font-body">لا براندات من هذه المجموعة في مجموعتك No brands from this group in your collection yet.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {relatedBrands.map(brand => {
                const count = getPerfumeCount(brand.name);
                return (
                  <Link key={brand.id} to={`/brand?id=${brand.id}`}>
                    <div className="flex flex-col items-center gap-2.5 p-4 rounded-none border-2 border-amber-400/70 bg-card hover:border-amber-500 hover:shadow-md transition-all text-center h-full">
                      <div className="w-16 h-16 rounded-none overflow-hidden flex items-center justify-center bg-white/80 flex-shrink-0">
                        {brand.logo_url ? (
                          <img src={brand.logo_url} alt={brand.name} className="w-full h-full object-contain" />
                        ) : (
                          <span className="font-heading font-bold text-2xl text-foreground/25">
                            {brand.name?.[0]?.toUpperCase()}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center justify-center gap-1.5 w-full">
                        <p className="font-heading font-semibold text-xs leading-tight line-clamp-2 flex-1">{brand.name}</p>
                        {count > 0 && (
                          <span className="text-[8px] font-body font-bold text-amber-600 rounded-none flex-shrink-0">
                            {count}
                          </span>
                        )}
                      </div>
                      {brand.country && (
                        <p className="text-[9px] text-muted-foreground font-body">{brand.country}</p>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}