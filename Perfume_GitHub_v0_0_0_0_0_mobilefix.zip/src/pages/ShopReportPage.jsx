import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { useCurrency } from "@/lib/useCurrency";
import { usePersonNames } from "@/lib/usePersonNames";
import { ALL_SUB_CATEGORIES } from "@/lib/shopCategories";
import ShopReport from "@/components/shopping/ShopReport";

/**
 * صفحة مستقلّة لتقارير التسوّق (بدل النافذة المنبثقة).
 * تجلب نفس بيانات صفحة /shopping وتمرّرها لمكوّن ShopReport،
 * وزرّ الرجوع يعود إلى /shopping.
 */
export default function ShopReportPage() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { currency } = useCurrency();
  const { names } = usePersonNames();

  const { data: brands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
  });
  const { data: products = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
  });

  return (
    <ShopReport
      products={products}
      brands={brands}
      categories={ALL_SUB_CATEGORIES}
      isAr={isAr}
      currency={currency}
      names={names}
      onClose={() => navigate("/shopping")}
    />
  );
}
