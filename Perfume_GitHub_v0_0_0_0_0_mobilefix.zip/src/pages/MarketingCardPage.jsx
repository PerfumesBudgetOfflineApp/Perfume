import { useNavigate } from "react-router-dom";
import BackButton from "@/components/shared/BackButton";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import MarketingCard from "@/components/shopping/MarketingCard";

/**
 * صفحة بطاقة التسويق المستقلة (بدل التبويب داخل /shopping).
 * عنوان واضح + باني البطاقة + زر سفلي للانتقال للميزانية والمصروفات.
 */
export default function MarketingCardPage() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  return (
    <div className="px-4 pt-12 pb-28 max-w-xl mx-auto">
      {/* Header */}
      <div className={`flex items-center gap-2 mb-4 ${isAr ? "flex-row-reverse text-right" : ""}`}>
        <BackButton fallback="/shopping" />
        <h1 className="font-heading text-lg font-bold leading-tight">
          {isAr ? "إنشاء بطاقة تسويق" : "Create Marketing Card"}
        </h1>
      </div>

      <MarketingCard />

      {/* Bottom action — go to Budget & Expenses */}
      <div className="mt-10 pt-2">
        <Button
          variant="outline"
          className="w-full rounded-none h-11 font-body"
          onClick={() => navigate("/budget")}
        >
          {isAr ? "عرض الميزانية والمصروفات" : "View Budget & Expenses"}
        </Button>
      </div>
    </div>
  );
}
