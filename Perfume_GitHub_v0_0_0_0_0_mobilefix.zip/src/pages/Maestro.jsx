import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, ChevronRight, Database, Settings, RefreshCw, Upload, Lock, AlertCircle } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { LOCAL_SEED_MAP } from "@/lib/localSeeder";
import { apphost } from "@/api/apphostClient";
import { useAppName, APP_NAME_DEFAULTS } from "@/lib/useAppName";
import { Button } from "@/components/ui/button";
import { downloadBlob } from "@/lib/exportHelper";
import { encryptBackup, decryptBackup, isEncryptedBackup } from "@/lib/backupCrypto";
import { toast } from "sonner";

const SECTIONS = [
  {
    id: "db-viewer",
    icon: "🗄️",
    label_en: "Database Viewer",
    label_ar: "عارض قاعدة البيانات",
    desc_en: "Browse all data hierarchically",
    desc_ar: "تصفح البيانات بشكل هرمي",
    color: "from-cyan-500/20 to-blue-500/20",
    border: "border-cyan-300/50",
    path: "/maestro/db-viewer",
  },
  {
    id: "brands",
    icon: "🏛️",
    label_en: "Perfume Brands",
    label_ar: "شركات العطور",
    desc_en: "Manage & edit all perfume brands",
    desc_ar: "إدارة و تعديل شركات العطور",
    color: "from-amber-500/20 to-orange-500/20",
    border: "border-amber-300/50",
    path: "/maestro/brands",
  },
  {
    id: "perfumes",
    icon: "🌹",
    label_en: "Perfumes Catalog",
    label_ar: "كتالوج العطور",
    desc_en: "Add & edit perfumes database",
    desc_ar: "إضافة و تعديل قاعدة بيانات العطور",
    color: "from-rose-500/20 to-pink-500/20",
    border: "border-rose-300/50",
    path: "/maestro/perfumes",
  },
  {
    id: "notes",
    icon: "🌿",
    label_en: "Fragrance Notes",
    label_ar: "نوتات العطور",
    desc_en: "Manage scent notes & ingredients",
    desc_ar: "إدارة النوتات و المكونات العطرية",
    color: "from-emerald-500/20 to-green-500/20",
    border: "border-emerald-300/50",
    path: "/maestro/notes",
  },
  {
    id: "perfumers",
    icon: "👑",
    label_en: "Perfumers",
    label_ar: "العطارون",
    desc_en: "Manage master perfumers",
    desc_ar: "إدارة كبار العطارين",
    color: "from-purple-500/20 to-violet-500/20",
    border: "border-purple-300/50",
    path: "/maestro/perfumers",
  },
  {
    id: "quotes",
    icon: "💬",
    label_en: "Random Quotes",
    label_ar: "الاقتباسات العشوائية",
    desc_en: "Manage & curate quotes",
    desc_ar: "إدارة و إضافة الاقتباسات",
    color: "from-blue-500/20 to-cyan-500/20",
    border: "border-blue-300/50",
    path: "/maestro/quotes",
  },
  {
    id: "glossary",
    icon: "📚",
    label_en: "Glossary Terms",
    label_ar: "مصطلحات المسرد",
    desc_en: "Manage glossary & definitions",
    desc_ar: "إدارة المسرد و التعريفات",
    color: "from-indigo-500/20 to-blue-500/20",
    border: "border-indigo-300/50",
    path: "/maestro/glossary",
  },
  {
    id: "perfume-stores",
    icon: "🏪",
    label_en: "Perfume Stores",
    label_ar: "متاجر العطور",
    desc_en: "Manage perfume store database",
    desc_ar: "إدارة قاعدة بيانات متاجر العطور",
    color: "from-teal-500/20 to-cyan-500/20",
    border: "border-teal-300/50",
    path: "/maestro/perfume-stores",
  },
  {
    id: "categories",
    icon: "🗂️",
    label_en: "Shopping Categories",
    label_ar: "تصنيفات التسوق",
    desc_en: "Main & sub categories management",
    desc_ar: "إدارة الأقسام الرئيسية و الفرعية",
    color: "from-yellow-500/20 to-amber-500/20",
    border: "border-yellow-300/50",
    path: "/maestro/categories",
  },
  {
    id: "odor-families",
    icon: "🎨",
    label_en: "Odor Families & Categories",
    label_ar: "العائلات و التصنيفات العطرية",
    desc_en: "Manage fragrance odor family & category lists",
    desc_ar: "إدارة قوائم العائلات و التصنيفات العطرية",
    color: "from-fuchsia-500/20 to-pink-500/20",
    border: "border-fuchsia-300/50",
    path: "/maestro/odor-families",
  },
  {
    id: "enums",
    icon: "🗃️",
    label_en: "Database Enums & Types",
    label_ar: "مدخلات قاعدة البيانات",
    desc_en: "View all built-in perfume types, seasons, genders...",
    desc_ar: "عرض جميع أنواع العطور و المواسم و الجنس...",
    color: "from-slate-500/20 to-gray-500/20",
    border: "border-slate-300/50",
    path: "/maestro/enums",
  },
  {
    id: "wisdom",
    icon: "💡",
    label_en: "Wisdom & Insights",
    label_ar: "الحكم و المواعظ",
    desc_en: "Manage wisdom quotes for budget & life",
    desc_ar: "إدارة الحكم و المواعظ للميزانية و الحياة",
    color: "from-amber-500/20 to-yellow-500/20",
    border: "border-amber-300/50",
    path: "/maestro/wisdom",
  },
];

export default function Maestro() {
  const { isAr } = useLang();
  const appName = useAppName();
  const [nameForm, setNameForm] = useState({ name_en: appName.name_en, name_ar: appName.name_ar, version: appName.version });
  const [authenticated, setAuthenticated] = useState(false);
  const [pagePassword, setPagePassword] = useState('');
  const [dbStats, setDbStats] = useState(null);
  const [loadingStats, setLoadingStats] = useState(false);
  const [seedingStatus, setSeedingStatus] = useState(null);
  const [seedingLoading, setSeedingLoading] = useState(false);
  const [showPasswordChange, setShowPasswordChange] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  // Full DB backup (password MANDATORY — never plaintext)
  const [dbExporting, setDbExporting] = useState(false);
  const [dbImporting, setDbImporting] = useState(false);
  const [dbExportPassword, setDbExportPassword] = useState('');
  const [dbExportPasswordConfirm, setDbExportPasswordConfirm] = useState('');
  const [dbPendingEncrypted, setDbPendingEncrypted] = useState(null);
  const [dbImportPassword, setDbImportPassword] = useState('');
  const MIN_DB_PW = 6;
  const dbPwValid = dbExportPassword.length >= MIN_DB_PW && dbExportPassword === dbExportPasswordConfirm;

  const handlePagePassword = () => {
    if (pagePassword === '1234') {
      setAuthenticated(true);
      setPagePassword('');
    } else {
      alert(isAr ? 'كلمة المرور غير صحيحة' : 'Wrong password');
      setPagePassword('');
    }
  };

  const runSeedFunction = async (functionName, description) => {
    setSeedingLoading(true);
    setSeedingStatus({ type: 'loading', message: description });
    try {
      // Use local seeder when available (offline mode)
      const localFn = LOCAL_SEED_MAP[functionName];
      if (localFn) {
        const result = await localFn();
        setSeedingStatus({ type: 'success', message: result.message || 'تم بنجاح' });
      } else {
        // Fall back to remote Base44 function
        const response = await apphost.functions.invoke(functionName, {});
        setSeedingStatus({ type: 'success', message: `${response.data?.message || 'تم'}` });
      }
      setTimeout(() => { fetchStats(); setSeedingStatus(null); }, 3000);
    } catch (error) {
      setSeedingStatus({ type: 'error', message: `${error.message}` });
    }
    setSeedingLoading(false);
  };

  const clearDatabase = async (entity) => {
    if (!confirm(`هل تريد فعلاً حذف جميع سجلات ${entity}؟`)) return;
    setSeedingLoading(true);
    setSeedingStatus({ type: 'loading', message: `جاري حذف ${entity}...` });
    try {
      const list = await apphost.entities[entity].list("name");
      for (const record of list) {
        await apphost.entities[entity].delete(record.id);
      }
      setSeedingStatus({ type: 'success', message: `تم حذف جميع ${entity}` });
      setTimeout(() => { fetchStats(); setSeedingStatus(null); }, 2000);
    } catch (error) {
      setSeedingStatus({ type: 'error', message: `${error.message}` });
    }
    setSeedingLoading(false);
  };

  const cleanShoppingStores = async () => {
    if (!confirm(isAr
      ? "حذف جميع متاجر التسوّق عدا متجر التطبيق (Process Store)؟ لا يُحذف أيّ براند عطور."
      : "Delete all shopping stores except the app store (Process Store)? No perfume brand is deleted.")) return;
    setSeedingLoading(true);
    setSeedingStatus({ type: 'loading', message: isAr ? 'جاري تنظيف متاجر التسوّق...' : 'Cleaning shopping stores...' });
    try {
      const list = await apphost.entities.ShopBrand.list("-created_date");
      let n = 0;
      for (const s of list) {
        if (s.source === "app_example") continue; // أبقِ متجر التطبيق Process Store
        await apphost.entities.ShopBrand.delete(s.id);
        n++;
      }
      setSeedingStatus({ type: 'success', message: isAr ? `حُذف ${n} متجر تسوّق` : `Removed ${n} shopping stores` });
      setTimeout(() => { fetchStats(); setSeedingStatus(null); }, 2000);
    } catch (error) {
      setSeedingStatus({ type: 'error', message: `${error.message}` });
    }
    setSeedingLoading(false);
  };

  const migrateStoresToShopBrands = async () => {
    if (!confirm(isAr
      ? "نقل المتاجر القديمة (Store) إلى متاجر التسوّق (ShopBrand)؟ لا يُحذف شيء؛ يُتخطّى المكرّر بالاسم."
      : "Copy legacy Stores into Shopping stores (ShopBrand)? Nothing is deleted; duplicates by name are skipped.")) return;
    setSeedingLoading(true);
    setSeedingStatus({ type: 'loading', message: isAr ? 'جاري نقل المتاجر القديمة...' : 'Migrating legacy stores...' });
    try {
      const [legacy, existing] = await Promise.all([
        apphost.entities.Store.list("name"),
        apphost.entities.ShopBrand.list("-created_date"),
      ]);
      const have = new Set(existing.map(b => (b.name || "").trim().toLowerCase()).filter(Boolean));
      let n = 0;
      for (const s of legacy) {
        const key = (s.name || "").trim().toLowerCase();
        if (!key || have.has(key)) continue; // تخطّي المكرّر بالاسم
        await apphost.entities.ShopBrand.create({
          name: s.name,
          name_ar: s.name_ar || "",
          type: "perfume_store",
          person: "family",
          website: s.website || null,
          logo_url: s.logo_url || null,
          description: s.description || null,
          country: s.country || "",
          category_name_en: "Perfume",
          category_name_ar: "عطور",
          source: "from_legacy_store",
        });
        have.add(key);
        n++;
      }
      setSeedingStatus({ type: 'success', message: isAr ? `نُقل ${n} متجراً (القديم محفوظ)` : `Migrated ${n} stores (legacy kept)` });
      setTimeout(() => { fetchStats(); setSeedingStatus(null); }, 2500);
    } catch (error) {
      setSeedingStatus({ type: 'error', message: `${error.message}` });
    }
    setSeedingLoading(false);
  };

  const handleChangePassword = () => {
    if (newPassword !== confirmPassword) {
      alert(isAr ? 'كلمتا المرور غير متطابقة' : 'Passwords do not match');
      return;
    }
    if (newPassword.length < 4) {
      alert(isAr ? 'كلمة المرور يجب أن تكون 4 أحرف على الأقل' : 'Password must be at least 4 characters');
      return;
    }
    alert(isAr ? 'تم تغيير كلمة المرور بنجاح. أعد تحميل الصفحة' : 'Password changed. Please reload the page');
    setShowPasswordChange(false);
    setNewPassword('');
    setConfirmPassword('');
  };

  const fetchStats = async () => {
    setLoadingStats(true);
    try {
      // Counts only — avoid loading entire tables (especially ~all perfumes)
      // into memory just to size the DB. Glossary still loads to split term/story.
      const [brandsN, perfumesN, notesN, perfumersN, quotesN, glossary, storesN, wisdomN, collectionsN] = await Promise.all([
        apphost.entities.PerfumeBrand.count(),
        apphost.entities.Perfume.count(),
        apphost.entities.PerfumeNote.count(),
        apphost.entities.Perfumer.count(),
        apphost.entities.Quote.count(),
        apphost.entities.GlossaryTerm.list("term_en"),
        apphost.entities.Store.count(),
        apphost.entities.Wisdom.count(),
        apphost.entities.PerfumeCollection.count(),
      ]);
      // Estimate size: average bytes per record (rough estimate based on avg JSON payload)
      const AVG_BYTES = { brands: 800, perfumes: 2500, notes: 600, perfumers: 1200, quotes: 300, glossary: 400, stores: 500, wisdom: 350, collections: 600 };
      const totalBytes =
        brandsN * AVG_BYTES.brands +
        perfumesN * AVG_BYTES.perfumes +
        notesN * AVG_BYTES.notes +
        perfumersN * AVG_BYTES.perfumers +
        quotesN * AVG_BYTES.quotes +
        glossary.length * AVG_BYTES.glossary +
        storesN * AVG_BYTES.stores +
        wisdomN * AVG_BYTES.wisdom +
        collectionsN * AVG_BYTES.collections;
      const totalMB = totalBytes / (1024 * 1024);
      const totalGB = totalMB / 1024;

      setDbStats({
        brands: brandsN,
        perfumes: perfumesN,
        notes: notesN,
        perfumers: perfumersN,
        quotes: quotesN,
        glossary: glossary.length,
        terms: glossary.filter((g) => (g.entry_type || "term") === "term").length,
        stories: glossary.filter((g) => g.entry_type === "story").length,
        stores: storesN,
        wisdom: wisdomN,
        collections: collectionsN,
        total: brandsN + perfumesN + notesN + perfumersN + quotesN + glossary.length + storesN + wisdomN + collectionsN,
        totalMB: totalMB.toFixed(2),
        totalGB: totalGB.toFixed(4),
        lastUpdated: new Date().toLocaleTimeString(),
      });
    } catch (e) {}
    setLoadingStats(false);
  };

  // ---- Full DB backup (entire built-in database) ----
  const DB_ENTITIES = [
    ["PerfumeBrand", "brands"],
    ["Perfume", "perfumes"],
    ["PerfumeNote", "notes"],
    ["Perfumer", "perfumers"],
    ["Quote", "quotes"],
    ["GlossaryTerm", "glossary"],
    ["Store", "stores"],
    ["ShopBrand", "shopBrands"],
    ["ShopCategory", "shopCategories"],
    ["Wisdom", "wisdom"],
    ["PerfumeCollection", "collections"],
  ];

  const handleDbExport = async () => {
    if (!dbPwValid) {
      toast.error(isAr ? `كلمة السرّ مطلوبة (${MIN_DB_PW} أحرف على الأقل) و يجب أن تتطابق` : `Password required (min ${MIN_DB_PW} chars) and must match`);
      return;
    }
    setDbExporting(true);
    try {
      const data = {};
      for (const [entity, key] of DB_ENTITIES) {
        try {
          data[key] = await apphost.entities[entity].list("-created_date");
        } catch {
          data[key] = [];
        }
      }
      const backup = {
        version: "db-1.0",
        type: "full_database",
        exported_at: new Date().toISOString(),
        builtin_database: data,
      };

      // Password mandatory — always encrypted, never plaintext.
      const fileObject = await encryptBackup(backup, dbExportPassword);
      const suffix = "-encrypted";
      const blob = new Blob([JSON.stringify(fileObject, null, 2)], { type: "application/json" });
      await downloadBlob(blob, `process-app-full-db${suffix}-${new Date().toISOString().split("T")[0]}.json`);
      toast.success(isAr ? "تم تنزيل قاعدة البيانات المشفّرة!" : "Encrypted database downloaded!");
      setDbExportPassword(""); setDbExportPasswordConfirm("");
    } catch (e) {
      toast.error(isAr ? "فشل تصدير قاعدة البيانات" : "Database export failed");
    } finally {
      setDbExporting(false);
    }
  };

  const restoreDbPayload = async (backup) => {
    const db = backup.builtin_database || {};
    let restored = 0;
    for (const [entity, key] of DB_ENTITIES) {
      const rows = db[key];
      if (!Array.isArray(rows) || rows.length === 0) continue;
      const cleaned = rows.map(({ id, ...rest }) => rest);
      try {
        await apphost.entities[entity].bulkCreate(cleaned);
        restored += cleaned.length;
      } catch (err) {
        console.error(`DB restore failed for ${entity}`, err);
      }
    }
    return restored;
  };

  const handleDbImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setDbImporting(true);
    try {
      const text = await file.text();
      const parsed = JSON.parse(text);
      if (isEncryptedBackup(parsed)) {
        setDbPendingEncrypted(parsed);
        setDbImportPassword("");
        toast.info(isAr ? "قاعدة بيانات مشفّرة — أدخل كلمة السرّ." : "Encrypted database — enter the password.");
        return;
      }
      // No restore without a password: reject any non-encrypted database file.
      toast.error(isAr ? "لا استرداد بدون كلمة سرّ — هذا الملفّ غير مشفّر. تُقبل النسخ المشفّرة فقط." : "No restore without a password — this file is not encrypted. Only password-protected backups are accepted.");
    } catch (err) {
      toast.error(isAr ? "ملف قاعدة البيانات غير صالح" : "Invalid database file");
    } finally {
      setDbImporting(false);
      e.target.value = "";
    }
  };

  const handleDbDecryptAndRestore = async () => {
    if (!dbPendingEncrypted || !dbImportPassword) return;
    setDbImporting(true);
    try {
      const backup = await decryptBackup(dbPendingEncrypted, dbImportPassword);
      const count = await restoreDbPayload(backup);
      await fetchStats();
      toast.success(isAr ? `تمت استعادة ${count} سجلّ.` : `Restored ${count} records.`);
      setDbPendingEncrypted(null);
      setDbImportPassword("");
    } catch (err) {
      if (err.code === "WRONG_PASSWORD") {
        toast.error(isAr ? "كلمة السرّ غير صحيحة." : "Wrong password.");
      } else {
        toast.error(isAr ? "تعذّر فكّ التشفير" : "Could not decrypt");
      }
    } finally {
      setDbImporting(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 60000); // auto-refresh every 60s
    return () => clearInterval(interval);
  }, []);

  if (!authenticated) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center z-50">
        <div className="bg-card border border-border rounded-none p-6 w-[90%] max-w-sm shadow-lg space-y-4">
          <div className="text-center">
            <div className="text-4xl mb-2">🔐</div>
            <h2 className="font-heading text-xl font-bold">{isAr ? 'صفحة الأدمن' : 'Admin'}</h2>
            <p className="text-sm text-muted-foreground font-body mt-1">{isAr ? 'أدخل كلمة المرور للوصول' : 'Enter password to access'}</p>
          </div>
          <input
            type="password"
            placeholder={isAr ? 'كلمة المرور: 1234' : 'Password: 1234'}
            value={pagePassword}
            onChange={(e) => setPagePassword(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handlePagePassword()}
            className="w-full px-4 py-2.5 border border-input rounded-none text-sm font-body bg-background focus:outline-none focus:ring-2 focus:ring-primary"
            autoFocus
          />
          <button
            onClick={handlePagePassword}
            className="w-full px-4 py-2.5 rounded-none bg-primary text-primary-foreground text-sm font-body font-medium hover:bg-primary/90 transition-all"
          >
            {isAr ? 'دخول' : 'Enter'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className={`px-4 pt-12 pb-24 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-6">
        <Link to="/" className="p-2 hover:bg-secondary rounded-none transition-colors">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div>
          <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
            <Settings className="w-6 h-6 text-primary" />
            Admin
          </h1>
          <p className="text-xs text-muted-foreground font-body">
            {isAr ? "لوحة إدارة قاعدة البيانات" : "Database Management Console"}
          </p>
        </div>
      </div>

      {/* Warning Banner */}
      <div className="bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-none p-3 mb-5 flex gap-2">
        <span className="text-amber-600 text-lg">⚠️</span>
        <div>
          <p className="text-xs font-body font-semibold text-amber-800 dark:text-amber-300">
            {isAr ? "منطقة المتمكنين" : "Advanced Admin Zone"}
          </p>
          <p className="text-[10px] text-amber-700 dark:text-amber-400 font-body">
            {isAr
              ? "التغييرات هنا تؤثر على قاعدة البيانات المشتركة لجميع المستخدمين"
              : "Changes here affect the shared built-in database for all users"}
          </p>
        </div>
      </div>

      {/* App Name Editor */}
      <div className="bg-card border border-border rounded-none p-4 mb-5 space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="font-heading font-semibold text-sm">{isAr ? "اسم التطبيق" : "App Name"}</h2>
          <button
            onClick={() => { setNameForm({ ...APP_NAME_DEFAULTS }); appName.update({ ...APP_NAME_DEFAULTS }); }}
            className="text-[10px] text-muted-foreground hover:text-foreground font-body underline"
          >
            {isAr ? "الافتراضي" : "Reset to default"}
          </button>
        </div>
        <div className="space-y-2">
          <div className="space-y-1">
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "بالإنجليزية" : "English"}</label>
            <input
              value={nameForm.name_en}
              onChange={(e) => setNameForm({ ...nameForm, name_en: e.target.value })}
              dir="ltr"
              className="w-full h-9 px-3 rounded-none border border-border bg-background text-sm font-body"
              placeholder="Process"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "بالعربية" : "Arabic"}</label>
            <input
              value={nameForm.name_ar}
              onChange={(e) => setNameForm({ ...nameForm, name_ar: e.target.value })}
              dir="rtl"
              className="w-full h-9 px-3 rounded-none border border-border bg-background text-sm font-body"
              placeholder="بروسس"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "الإصدار" : "Version"}</label>
            <input
              value={nameForm.version}
              onChange={(e) => setNameForm({ ...nameForm, version: e.target.value })}
              dir="ltr"
              className="w-full h-9 px-3 rounded-none border border-border bg-background text-sm font-body"
              placeholder="0.0.0"
            />
          </div>
        </div>
        <button
          onClick={() => appName.update(nameForm)}
          className="w-full h-9 rounded-none bg-primary text-primary-foreground text-sm font-body font-medium hover:bg-primary/90 transition-colors"
        >
          {isAr ? "حفظ اسم التطبيق" : "Save app name"}
        </button>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-4 gap-2 mb-5">
        {[
          { label: isAr ? "براندات" : "Brands", emoji: "🏛️" },
          { label: isAr ? "عطور" : "Perfumes", emoji: "🌹" },
          { label: isAr ? "نوتات" : "Notes", emoji: "🌿" },
          { label: isAr ? "عطارون" : "Perfumers", emoji: "👑" },
        ].map((s, i) => (
          <div key={i} className="bg-secondary/50 rounded-none p-2 text-center">
            <div className="text-lg">{s.emoji}</div>
            <p className="text-[9px] text-muted-foreground font-body leading-tight mt-0.5">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Sections Grid */}
      <div className="space-y-3">
        <p className="text-xs font-body text-muted-foreground uppercase tracking-wider px-1">
          {isAr ? "أقسام الإدارة" : "Management Sections"}
        </p>
        {SECTIONS.map((section) => (
          <Link
            key={section.id}
            to={section.path}
            className={`flex items-center justify-between bg-gradient-to-r ${section.color} border ${section.border} rounded-none px-4 py-3.5 hover:opacity-90 transition-all active:scale-[0.98]`}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{section.icon}</span>
              <div>
                <p className="text-sm font-body font-semibold">
                  {isAr ? section.label_ar : section.label_en}
                </p>
                <p className="text-[10px] text-muted-foreground font-body">
                  {isAr ? section.desc_ar : section.desc_en}
                </p>
              </div>
            </div>
            <ChevronRight className={`w-4 h-4 text-muted-foreground ${isAr ? "rotate-180" : ""}`} />
          </Link>
        ))}
      </div>

      {/* Settings Panel */}
      <div className="mt-6 bg-gradient-to-br from-purple-50/50 to-pink-50/50 dark:from-purple-950/20 dark:to-pink-950/20 border border-purple-200 dark:border-purple-800 rounded-none overflow-hidden">
        <div className="px-4 py-3 border-b border-purple-200 dark:border-purple-800">
          <div className="flex items-center gap-2">
            <span className="text-lg">⚙️</span>
            <p className="text-sm font-body font-semibold">{isAr ? "الإعدادات" : "Settings"}</p>
          </div>
        </div>
        <div className="p-4">
          <button
            onClick={() => setShowPasswordChange(true)}
            className="w-full px-4 py-2.5 rounded-none bg-purple-500 hover:bg-purple-600 text-white text-sm font-body font-medium transition-all"
          >
            🔐 {isAr ? 'تغيير كلمة مرور الأدمن' : 'Change Admin Password'}
          </button>
        </div>
      </div>

      {/* Seeding Panel */}
      <div className="mt-6 bg-gradient-to-br from-blue-50/50 to-cyan-50/50 dark:from-blue-950/20 dark:to-cyan-950/20 border border-blue-200 dark:border-blue-800 rounded-none overflow-hidden">
        <div className="px-4 py-3 border-b border-blue-200 dark:border-blue-800">
          <div className="flex items-center gap-2">
            <span className="text-lg">🌱</span>
            <p className="text-sm font-body font-semibold">{isAr ? "تغذية قاعدة البيانات" : "Database Seeding"}</p>
          </div>
        </div>
        <div className="p-4 space-y-3">
          {seedingStatus && (
            <div className={`p-3 rounded-none text-sm font-body ${seedingStatus.type === 'loading' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300' : seedingStatus.type === 'success' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300' : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'}`}>
              {seedingStatus.message}
            </div>
          )}
          
          <div className="space-y-2 flex flex-col">
            {/* Brands البراندات data/builtin_database/brands_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل البراندات...' : 'Loading brands...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-blue-500 hover:bg-blue-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="brands_builtin.json"
             >
               {seedingLoading ? '⏳' : '🏛️'} {isAr ? 'براندات Brands' : 'Brands براندات'}
             </button>

            {/* Perfumes العطور data/builtin_database → public/seed/perfumes[a-d]_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedBuiltinPerfumes', isAr ? 'جاري تحميل العطور...' : 'Loading perfumes...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-rose-500 hover:bg-rose-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="seed/perfumesa..d_builtin.json"
             >
               {seedingLoading ? '⏳' : '🌹'} {isAr ? 'عطور Perfumes' : 'Perfumes عطور'}
             </button>

            {/* Notes النوتات data/builtin_database/notes_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل النوتات...' : 'Loading notes...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="notes_builtin.json"
             >
               {seedingLoading ? '⏳' : '🌿'} {isAr ? 'نوتات Notes' : 'Notes نوتات'}
             </button>

            {/* Perfumers العطارون data/builtin_database/perfumers_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedPerfumers', isAr ? 'جاري تحميل العطارين...' : 'Loading perfumers...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-purple-500 hover:bg-purple-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="perfumers_builtin.json"
             >
               {seedingLoading ? '⏳' : '👑'} {isAr ? 'عطارون Perfumers' : 'Perfumers عطارون'}
             </button>

            {/* Quotes الاقتباسات data/builtin_database/quotes_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل الاقتباسات...' : 'Loading quotes...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-blue-400 hover:bg-blue-500 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="quotes_builtin.json"
             >
               {seedingLoading ? '⏳' : '💬'} {isAr ? 'اقتباسات Quotes' : 'Quotes اقتباسات'}
             </button>

            {/* Glossary Terms المسرد data/builtin_database/glossary_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل مصطلحات المسرد...' : 'Loading glossary...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-indigo-500 hover:bg-indigo-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="glossary_builtin.json"
             >
               {seedingLoading ? '⏳' : '📚'} {isAr ? 'مسرد Glossary' : 'Glossary مسرد'}
             </button>

            {/* Wisdoms الحكم data/builtin_database/wisdom_builtin.json */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل الحكم...' : 'Loading wisdoms...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white text-sm font-body font-medium transition-all"
               title="wisdom_builtin.json"
             >
               {seedingLoading ? '⏳' : '💡'} {isAr ? 'حكم Wisdoms' : 'Wisdoms حكم'}
             </button>

            {/* Seed All - حمّل الكل All builtin JSON files */}
             <button
               onClick={() => runSeedFunction('seedAllData', isAr ? 'جاري تحميل جميع البيانات...' : 'Loading all data...')}
               disabled={seedingLoading}
               className="w-full px-4 py-3 rounded-none bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50 text-white text-sm font-body font-semibold transition-all"
               title="All builtin JSON files"
             >
               {seedingLoading ? '⏳' : '⭐'} {isAr ? 'حمّل الكل Seed All' : 'Seed All حمّل الكل'}
             </button>
          </div>

          <div className="border-t border-blue-200 dark:border-blue-800 pt-3 mt-3">
            <p className="text-[10px] font-body text-blue-700 dark:text-blue-300 mb-2 font-semibold">{isAr ? 'تصفير قاعدة البيانات:' : 'Clear Database:'}</p>
            <div className="grid grid-cols-2 gap-2">
              {['PerfumeBrand', 'Perfume', 'PerfumeNote', 'Perfumer', 'Quote', 'GlossaryTerm', 'Store'].map((entity) => (
                <button
                  key={entity}
                  onClick={() => clearDatabase(entity)}
                  disabled={seedingLoading}
                  className=" rounded-none disabled:opacity-50 text-red-600 dark:text-red-400 text-[10px] font-body font-medium transition-all "
                >
                  {entity}
                </button>
              ))}
            </div>
            <button
              onClick={cleanShoppingStores}
              disabled={seedingLoading}
              className="mt-2 w-full rounded-none disabled:opacity-50 text-amber-700 dark:text-amber-400 text-[11px] font-body font-medium transition-all "
            >
              {isAr ? "تنظيف متاجر التسوّق (عدا متجر التطبيق)" : "Clean shopping stores (keep app store)"}
            </button>
            <button
              onClick={migrateStoresToShopBrands}
              disabled={seedingLoading}
              className="mt-2 w-full rounded-none disabled:opacity-50 text-blue-700 dark:text-blue-400 text-[11px] font-body font-medium transition-all "
            >
              {isAr ? "نقل المتاجر القديمة ← متاجر التسوّق (توحيد)" : "Migrate legacy stores -> Shopping (unify)"}
            </button>
          </div>
        </div>
      </div>

      {/* DB Size Panel */}
      <div className="mt-5 bg-card border border-border/60 rounded-none overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-border/40">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-primary" />
            <p className="text-sm font-body font-semibold">{isAr ? "حجم قاعدة البيانات" : "Database Size"}</p>
          </div>
          <div className="flex items-center gap-2">
            {dbStats && <p className="text-[9px] text-muted-foreground font-body">{dbStats.lastUpdated}</p>}
            <button onClick={fetchStats} disabled={loadingStats} className="p-1.5 hover:bg-secondary rounded-none transition-colors">
              <RefreshCw className={`w-3.5 h-3.5 text-muted-foreground ${loadingStats ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>
        {loadingStats && !dbStats ? (
          <div className="flex justify-center py-6">
            <div className="w-5 h-5 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
          </div>
        ) : dbStats ? (
          <div className="p-3">
            {/* Size Summary */}
            <div className="flex items-center justify-center gap-4 bg-gradient-to-r from-primary/10 to-primary/5 border border-primary/20 rounded-none p-3 mb-3">
              <div className="text-center">
                <p className="text-xl font-heading font-bold text-primary">{dbStats.totalMB} MB</p>
                <p className="text-[9px] text-muted-foreground font-body">{isAr ? "الحجم التقريبي" : "Est. Size"}</p>
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center">
                <p className="text-xl font-heading font-bold text-primary">{dbStats.totalGB} GB</p>
                <p className="text-[9px] text-muted-foreground font-body">{isAr ? "بالجيجا" : "In GB"}</p>
              </div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center">
                <p className="text-xl font-heading font-bold">{dbStats.total.toLocaleString()}</p>
                <p className="text-[9px] text-muted-foreground font-body">{isAr ? "إجمالي السجلات" : "Total Records"}</p>
              </div>
            </div>
            <div className="grid grid-cols-4 gap-2 mb-3">
              {[
                { label: isAr ? "براندات" : "Brands", value: dbStats.brands, emoji: "🏛️" },
                { label: isAr ? "عطور" : "Perfumes", value: dbStats.perfumes, emoji: "🌹" },
                { label: isAr ? "نوتات" : "Notes", value: dbStats.notes, emoji: "🌿" },
                { label: isAr ? "عطارون" : "Perfumers", value: dbStats.perfumers, emoji: "👑" },
                { label: isAr ? "اقتباسات" : "Quotes", value: dbStats.quotes, emoji: "💬" },
                { label: isAr ? "مسرد" : "Glossary", value: dbStats.glossary, emoji: "📚" },
                { label: isAr ? "مصطلحات" : "Terms", value: dbStats.terms, emoji: "📖" },
                { label: isAr ? "قصص" : "Stories", value: dbStats.stories, emoji: "📜" },
                { label: isAr ? "متاجر" : "Stores", value: dbStats.stores, emoji: "🏪" },
                { label: isAr ? "حكم و مواعظ" : "Wisdom", value: dbStats.wisdom, emoji: "💡" },
                { label: isAr ? "مجموعات" : "Collections", value: dbStats.collections, emoji: "🎭" },
                { label: isAr ? "الإجمالي" : "Total", value: dbStats.total, emoji: "📊", highlight: true },
              ].map((s, i) => (
                <div key={i} className={`rounded-none p-2 text-center ${s.highlight ? "bg-primary/10 border border-primary/30" : "bg-secondary/50"}`}>
                  <div className="text-base">{s.emoji}</div>
                  <p className={`text-sm font-body font-bold ${s.highlight ? "text-primary" : ""}`}>{(s.value ?? 0).toLocaleString()}</p>
                  <p className="text-[8px] text-muted-foreground font-body leading-tight">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        ) : null}
      </div>

      {/* Full DB Backup Panel */}
      <div className="mt-5 bg-card border border-border/60 rounded-none overflow-hidden">
        <div className="flex items-center gap-2 px-4 py-3 border-b border-border/40">
          <Database className="w-4 h-4 text-primary" />
          <p className="text-sm font-body font-semibold">{isAr ? "نسخة احتياطية كاملة لقاعدة البيانات" : "Full Database Backup"}</p>
        </div>
        <div className="p-4 space-y-3">
          <p className="text-xs font-body text-muted-foreground">
            {isAr
              ? "تصدير قاعدة البيانات المدمجة بالكامل (البراندات، العطور، النوتات، العطّارون، الاقتباسات، المسرد، المتاجر، الحكم) كملف واحد مشفّر بكلمة سرّ مطلوبة (تعمل على أي جهاز)."
              : "Export the entire built-in database (brands, perfumes, notes, perfumers, quotes, glossary, stores, wisdom) as a single file, encrypted with a required password (works on any device)."}
          </p>

          {/* Mandatory password */}
          <input
            type="password"
            value={dbExportPassword}
            onChange={(e) => setDbExportPassword(e.target.value)}
            placeholder={isAr ? `كلمة السرّ (مطلوبة — ${MIN_DB_PW} أحرف على الأقل)` : `Password (required — min ${MIN_DB_PW} chars)`}
            className={`w-full h-11 rounded-none border border-border bg-background px-3 text-sm font-body ${isAr ? "text-right" : ""} focus:outline-none focus:ring-2 focus:ring-primary/40`}
          />
          <input
            type="password"
            value={dbExportPasswordConfirm}
            onChange={(e) => setDbExportPasswordConfirm(e.target.value)}
            placeholder={isAr ? "تأكيد كلمة السرّ" : "Confirm password"}
            className={`w-full h-11 rounded-none border bg-background px-3 text-sm font-body ${isAr ? "text-right" : ""} focus:outline-none focus:ring-2 focus:ring-primary/40 ${dbExportPasswordConfirm && dbExportPassword !== dbExportPasswordConfirm ? "border-red-400" : "border-border"}`}
          />
          {dbExportPasswordConfirm && dbExportPassword !== dbExportPasswordConfirm && (
            <p className="text-xs font-body text-red-600">{isAr ? "كلمتا السرّ غير متطابقتين" : "Passwords do not match"}</p>
          )}
          <div className="bg-red-50 border border-red-200 rounded-none px-4 py-3 flex items-start gap-2">
            <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs font-body text-red-700">
              {isAr
                ? "احفظ كلمة السرّ في مكان آمن. التطبيق محلّيّ بلا خادم، فإذا نسيتها لن تتمكّن من استعادة هذه النسخة نهائيّاً. المفتاح مُشتقّ من كلمة السرّ (لا من الجهاز)، فتُستعاد على أيّ جهاز جديد بكلمة السرّ فقط."
                : "Keep this password safe. The app is local with no server, so if you forget it this backup can never be recovered. The key is derived from the password (not the device), so it restores on any new device with just the password."}
            </p>
          </div>

          <div className="flex gap-2">
            <Button className="flex-1 h-11 rounded-none font-body gap-2" onClick={handleDbExport} disabled={dbExporting || !dbPwValid}>
              <Lock className="w-4 h-4" />
              {dbExporting
                ? (isAr ? "جاري التصدير..." : "Exporting...")
                : (isAr ? "تصدير مشفّر" : "Export Encrypted")}
            </Button>
            <label className="flex-1">
              <input type="file" accept=".json" className="hidden" onChange={handleDbImport} disabled={dbImporting} />
              <div className="w-full h-11 rounded-none font-body border-2 border-dashed border-border flex items-center justify-center gap-2 text-sm text-muted-foreground hover:border-primary hover:text-primary cursor-pointer transition-colors">
                <Upload className="w-4 h-4" />
                {dbImporting ? (isAr ? "..." : "...") : (isAr ? "استيراد" : "Import")}
              </div>
            </label>
          </div>

          {/* Encrypted DB file: ask for password */}
          {dbPendingEncrypted && (
            <div className="bg-secondary/40 border border-primary/30 rounded-none p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-primary" />
                <p className="text-sm font-body font-medium">{isAr ? "قاعدة بيانات مشفّرة — أدخل كلمة السرّ" : "Encrypted database — enter password"}</p>
              </div>
              <input
                type="password"
                value={dbImportPassword}
                onChange={(e) => setDbImportPassword(e.target.value)}
                onKeyDown={(e) => { if (e.key === "Enter") handleDbDecryptAndRestore(); }}
                placeholder={isAr ? "كلمة السرّ" : "Password"}
                className={`w-full h-11 rounded-none border border-border bg-background px-3 text-sm font-body ${isAr ? "text-right" : ""} focus:outline-none focus:ring-2 focus:ring-primary/40`}
                autoFocus
              />
              <div className="flex gap-2">
                <Button className="flex-1 h-10 rounded-none font-body gap-2" onClick={handleDbDecryptAndRestore} disabled={dbImporting || !dbImportPassword}>
                  <Lock className="w-4 h-4" />
                  {dbImporting ? (isAr ? "جاري الاستعادة..." : "Restoring...") : (isAr ? "فكّ التشفير و الاستعادة" : "Decrypt & Restore")}
                </Button>
                <Button variant="ghost" className="h-10 rounded-none font-body" onClick={() => { setDbPendingEncrypted(null); setDbImportPassword(""); }} disabled={dbImporting}>
                  {isAr ? "إلغاء" : "Cancel"}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
      {showPasswordChange && (
        <div className="fixed inset-0 bg-black/50 flex items-end z-50">
          <div className="bg-card w-full rounded-none p-5 space-y-4 animate-in slide-in-from-bottom">
            <div>
              <h3 className="font-heading font-bold text-lg mb-1">{isAr ? 'تغيير كلمة المرور' : 'Change Password'}</h3>
              <p className="text-sm text-muted-foreground font-body">{isAr ? 'أدخل كلمة مرور جديدة لصفحة الأدمن' : 'Enter a new password for Admin page'}</p>
            </div>
            <div className="space-y-3">
              <input
                type="password"
                placeholder={isAr ? 'كلمة المرور الجديدة' : 'New password'}
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className="w-full px-3 py-2 border border-input rounded-none text-sm font-body bg-background"
              />
              <input
                type="password"
                placeholder={isAr ? 'تأكيد كلمة المرور' : 'Confirm password'}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleChangePassword()}
                className="w-full px-3 py-2 border border-input rounded-none text-sm font-body bg-background"
              />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => { setShowPasswordChange(false); setNewPassword(''); setConfirmPassword(''); }}
                className="flex-1 px-3 py-2 rounded-none bg-secondary text-foreground text-sm font-body font-medium"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                onClick={handleChangePassword}
                className="flex-1 px-3 py-2 rounded-none bg-primary hover:bg-primary/90 text-primary-foreground text-sm font-body font-medium"
              >
                {isAr ? 'تحديث' : 'Update'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <div className="mt-8 text-center">
        <p className="text-[10px] text-muted-foreground font-body">
          {isAr ? "🛠️ أدمن — إدارة التطبيق" : "🛠️ Admin — App Management"}
        </p>
      </div>
    </div>
  );
}