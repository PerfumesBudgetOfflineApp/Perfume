import { useState, useMemo, useEffect } from "react";
import { compareEnglish } from "@/lib/sortName";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Search, Building2, Upload, X, List, BarChart2, AArrowUp, AArrowDown, ArrowLeft, ChevronLeft, ChevronRight, Pin } from "lucide-react";
import BrandLogo from "@/components/brand/BrandLogo";
import { Link, useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import BrandsIndex from "@/components/brands/BrandsIndex";
import BrandsAnalytics from "@/components/brands/BrandsAnalytics";
import { usePins } from "@/lib/usePins";

export default function Brands() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [showParentSuggestions, setShowParentSuggestions] = useState(false);
  const [sortBy, setSortBy] = useState("name");
  const [nameAsc, setNameAsc] = useState(true);
  const [view, setView] = useState("list"); // "list" | "index" | "analytics"
  const [page, setPage] = useState(1);
  const BRANDS_PER_PAGE = 50;
  const queryClient = useQueryClient();

  const { data: brands = [], isLoading, refetch: refetchBrands } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  // عدد عطور كل براند يُقرأ من perfume_ids المملوءة وقت الزرع — بلا تحميل
  // الكتالوج (130 ألف) إطلاقاً، فتظهر الصفحة والعدّادات فوراً دون تعليق.

  // الكتالوج الكامل يُحمَّل فقط عند فتح تبويب التحليلات (لا في قائمة البراندات).
  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    enabled: view === "analytics",
    staleTime: Infinity,
  });

  // إجمالي عدد العطور للتذييل — عدّ IndexedDB الأصلي (رخيص، بلا قراءة السجلات).
  const { data: totalPerfumes = 0 } = useQuery({
    queryKey: ["perfumes", "count"],
    queryFn: () => apphost.entities.Perfume.count(),
    staleTime: Infinity,
  });

  // Holding companies — group brands by parent_company
  const holdingGroups = useMemo(() => {
    const groups = {};
    brands.forEach(b => {
      if (b.parent_company) {
        if (!groups[b.parent_company]) groups[b.parent_company] = [];
        groups[b.parent_company].push(b);
      }
    });
    return groups;
  }, [brands]);

  const [form, setForm] = useState({ name: "", name_ar: "", country: "", country_ar: "", year_established: "", owned_by: "", website: "", in_business: true, description: "", logo_url: "" });
  const [uploading, setUploading] = useState(false);

  const createMutation = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeBrand.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["brands"] });
      toast.success((isAr ? "أُضيف البراند" : "Brand added"));
      setOpen(false);
      setForm({ name: "", name_ar: "", country: "", country_ar: "", year_established: "", owned_by: "", website: "", in_business: true, description: "", logo_url: "" });
    },
  });

  const handleUploadLogo = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const result = await apphost.integrations.Core.UploadFile({ file });
      setForm({ ...form, logo_url: result.file_url });
      toast.success((isAr ? "رُفع الشعار" : "Logo uploaded"));
    } catch {
      toast.error((isAr ? "فشل الرفع" : "Upload failed"));
    }
    setUploading(false);
  };

  const filtered = useMemo(() => brands.filter((b) => {
    if (b.hidden) return false;
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      String(b.name || "").toLowerCase().includes(q) ||
      String(b.name_en || "").toLowerCase().includes(q) ||
      String(b.name_ar || "").includes(search) ||
      String(b.country || "").toLowerCase().includes(q) ||
      String(b.country_ar || "").includes(search)
    );
  }), [brands, search]);

  // خريطة عدّ العطور لكل براند — من perfume_ids المملوءة وقت الزرع (طول القائمة)،
  // بلا تحميل الكتالوج. براند بلا perfume_ids يظهر صفراً (لا تعليق).
  const perfumeCountMap = useMemo(() => {
    const m = new Map();
    for (const b of brands) {
      if (!b || !b.name) continue;
      const n = String(b.perfume_ids || "").split(",").filter(Boolean).length;
      m.set(b.name, n);
    }
    return m;
  }, [brands]);
  const getPerfumeCount = (brandName) => perfumeCountMap.get(brandName) || 0;

  // ترتيب موحّد يعتمد الاسم الإنجليزي عبر المكتبة المشتركة (لاتيني → أرقام → لغات أخرى → رموز)
  const nameSort = (a, b) => compareEnglish(a, b, 1);

  const sorted = useMemo(() => [...filtered].sort((a, b) => {
    if (sortBy === "perfumeCount") {
      return getPerfumeCount(b.name) - getPerfumeCount(a.name);
    }
    const cmp = nameSort(a, b);
    return nameAsc ? cmp : -cmp;
  }), [filtered, sortBy, perfumeCountMap, nameAsc]);

  const totalPages = Math.max(1, Math.ceil(sorted.length / BRANDS_PER_PAGE));
  const paginated = useMemo(
    () => sorted.slice((page - 1) * BRANDS_PER_PAGE, page * BRANDS_PER_PAGE),
    [sorted, page]
  );
  useEffect(() => { if (page > totalPages) setPage(1); }, [totalPages, page]);

  // البراندات المثبّتة (حتى ٦) — من القائمة المحمَّلة، بترتيب التثبيت.
  const { pinnedIds: pinnedBrandIds } = usePins("brand");
  const pinnedBrands = useMemo(() => {
    const byId = {};
    brands.forEach((b) => { byId[String(b.id)] = b; });
    return pinnedBrandIds.map((bid) => byId[String(bid)]).filter((b) => b && !b.hidden);
  }, [brands, pinnedBrandIds]);

  // ── Add Brand page (full-screen, not a modal) ──
  if (open) {
    return (
      <div className="px-5 pt-12 pb-10 space-y-5">
        <div className="flex items-center gap-3 mb-2">
          <button onClick={() => setOpen(false)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
            <ArrowLeft className="w-5 h-5" />
          </button>
          <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">{isAr ? "إضافة براند" : "Add Brand"}</h1>
        </div>
        <form
          onSubmit={(e) => { e.preventDefault(); createMutation.mutate(form); }}
          className="space-y-4"
        >
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "اسم البراند" : "Brand Name"}</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Chanel" className="rounded-none h-11 font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "الاسم العربي" : "Arabic Name"}</Label>
            <Input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} placeholder={isAr ? "الاسم بالعربية" : "Arabic name"} className="rounded-none h-11 font-body" dir="rtl" />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="space-y-1.5">
              <Label className="text-xs font-body">{isAr ? "البلد" : "Country"}</Label>
              <Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} placeholder="e.g. France" className="rounded-none h-11 font-body" />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-body">{isAr ? "سنة التأسيس" : "Year Est."}</Label>
              <Input type="number" value={form.year_established || ""} onChange={(e) => setForm({ ...form, year_established: Number(e.target.value) || undefined })} className="rounded-none h-11 font-body" />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "الشركة الأم / القابضة" : "Parent Company / Holding"}</Label>
            <div className="relative">
              <Input
                value={form.owned_by}
                onChange={(e) => { setForm({ ...form, owned_by: e.target.value }); setShowParentSuggestions(true); }}
                onFocus={() => setShowParentSuggestions(true)}
                onBlur={() => setTimeout(() => setShowParentSuggestions(false), 150)}
                placeholder={isAr ? "ابحث في البراندات أو اكتب اسماً" : "Search brands or type a name"}
                className="rounded-none h-11 font-body"
                autoComplete="off"
              />
              {showParentSuggestions && (form.owned_by || "").trim() && (() => {
                const q = (form.owned_by || "").trim().toLowerCase();
                const pool = new Set();
                for (const b of brands) {
                  if (b.parent_company?.trim()) pool.add(b.parent_company.trim());
                  if (b.name?.trim()) pool.add(b.name.trim());
                }
                const matches = [...pool]
                  .filter(s => s.toLowerCase().includes(q) && s.toLowerCase() !== q)
                  .sort((a, b) => {
                    const ai = a.toLowerCase().startsWith(q) ? 0 : 1;
                    const bi = b.toLowerCase().startsWith(q) ? 0 : 1;
                    return ai - bi || a.localeCompare(b);
                  })
                  .slice(0, 8);
                if (matches.length === 0) return null;
                return (
                  <div className="absolute z-50 left-0 right-0 mt-1 bg-popover border border-border rounded-none shadow-lg max-h-52 overflow-y-auto">
                    {matches.map((s) => (
                      <button
                        key={s}
                        type="button"
                        onMouseDown={(e) => { e.preventDefault(); setForm({ ...form, owned_by: s }); setShowParentSuggestions(false); }}
                        className="w-full text-left px-3 py-2 text-sm font-body hover:bg-secondary transition-colors"
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                );
              })()}
            </div>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "الموقع" : "Website"}</Label>
            <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://..." className="rounded-none h-11 font-body" />
          </div>
          <div className="flex items-center gap-3 px-1 py-2">
            <Label className="text-sm font-body flex-1">{isAr ? "ما زال يعمل" : "Currently In Business?"}</Label>
            <button type="button" onClick={() => setForm({ ...form, in_business: !form.in_business })}
              className={`w-10 h-6 rounded-none transition-colors ${form.in_business !== false ? "bg-primary" : "bg-muted"}`}>
              <div className={`w-4 h-4 bg-white rounded-none shadow transition-transform mx-1 ${form.in_business !== false ? "translate-x-4" : "translate-x-0"}`} />
            </button>
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "حول البراند" : "About"}</Label>
            <Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder={isAr ? "الوصف والتاريخ" : "Description & history"} className="rounded-none font-body min-h-[100px]" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">{isAr ? "الشعار أو الصورة" : "Logo/Photo"}</Label>
            {form.logo_url ? (
              <div className="relative w-full h-24 rounded-none border border-border bg-secondary/50 flex items-center justify-center overflow-hidden">
                <img src={form.logo_url} alt="Logo" className="w-full h-full object-cover" />
                <button type="button" onClick={() => setForm({ ...form, logo_url: "" })} className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-none flex items-center justify-center hover:bg-red-600">
                  <X className="w-3.5 h-3.5 text-white" />
                </button>
              </div>
            ) : (
              <label className="flex items-center justify-center gap-2 w-full h-24 rounded-none border-2 border-dashed border-border bg-secondary/30 cursor-pointer hover:bg-secondary/50 transition-colors">
                <Upload className="w-4 h-4 text-muted-foreground" />
                <span className="text-xs font-body text-muted-foreground">{isAr ? "اضغط للرفع" : "Click to upload"}</span>
                <input type="file" onChange={handleUploadLogo} disabled={uploading} accept="image/*" className="hidden" />
              </label>
            )}
          </div>
          <div className="flex gap-2 pt-2">
            <Button type="button" variant="outline" onClick={() => setOpen(false)} className="flex-1 rounded-none h-11 font-body">
              {isAr ? "إلغاء" : "Cancel"}
            </Button>
            <Button type="submit" className="flex-1 rounded-none h-11 font-body" disabled={createMutation.isPending || uploading}>
              {createMutation.isPending ? (isAr ? "جارٍ الحفظ..." : "Saving...") : (isAr ? "إضافة البراند" : "Add Brand")}
            </Button>
          </div>
        </form>
      </div>
    );
  }

  return (
    <div className="px-5 pt-12 pb-4 space-y-5">
      <BackButton fallback="/" />
      <div className="flex items-center justify-between">
         <div>
           <h1 className="font-heading text-2xl font-bold">{isAr ? "البراندات" : "Brands"}</h1>
         </div>
         <div className="flex items-center gap-2">
          {/* View toggles */}
          <button
            onClick={() => setView("list")}
            className={`w-9 h-9 rounded-none flex items-center justify-center transition-colors ${view === "list" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            title="List"
          >
            <List className="w-4 h-4" />
          </button>
          <button
            onClick={() => setView("index")}
            className={`w-9 h-9 rounded-none flex items-center justify-center transition-colors ${view === "index" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            title="Index"
          >
            <span className="text-[10px] font-bold font-body">{isAr ? "الفهرس" : "Index"}</span>
          </button>
          <button
            onClick={() => setView("analytics")}
            className={`w-9 h-9 rounded-none flex items-center justify-center transition-colors ${view === "analytics" ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            title="Analytics"
          >
            <BarChart2 className="w-4 h-4" />
          </button>

          {/* Add brand — opens a full-screen form (not a modal) */}
          <Button onClick={() => setOpen(true)} size="sm" variant="outline" className="rounded-none font-body text-xs h-9 px-3">
            Add
          </Button>
        </div>
      </div>

      {/* A–Z Index View */}
      {view === "index" && <BrandsIndex brands={brands} isAr={isAr} />}

      {/* Analytics View */}
      {view === "analytics" && <BrandsAnalytics brands={brands} perfumes={perfumes} />}

      {/* List View */}
      {view === "list" && (
        <div className="space-y-3">
          <div className="relative">
            <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none`} />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={isAr ? "ابحث" : "Search"}
              dir={isAr ? "rtl" : "ltr"}
              className={`${isAr ? "pr-10" : "pl-10"} h-11 rounded-none font-body bg-white border border-transparent`}
            />
          </div>

          {/* البراندات المثبّتة — أعلى الصفحة (تظهر فقط دون بحث) */}
          {!search.trim() && pinnedBrands.length > 0 && (
            <div className="space-y-2">
              <div className={`flex items-center gap-1.5 ${isAr ? "flex-row-reverse" : ""}`}>
                <Pin className="w-3.5 h-3.5" style={{ color: "#b45309" }} fill="#f59e0b" />
                <p className="text-xs font-body font-semibold text-muted-foreground">{isAr ? "مثبّتة" : "Pinned"}</p>
              </div>
              <div className="grid grid-cols-2 gap-4">
                {pinnedBrands.map((brand) => {
                  const count = getPerfumeCount(brand.name);
                  return (
                    <Link key={`pin-${brand.id}`} to={`/brand?id=${brand.id}`}>
                      <div className="group flex flex-col items-center gap-2 text-center h-full">
                        <div className="relative w-20 h-20 rounded-none overflow-hidden flex items-center justify-center bg-white border-2 border-amber-400/70 group-hover:border-amber-500 group-hover:shadow-md transition-all flex-shrink-0">
                          <BrandLogo brand={brand} initialsSize={24} />
                          {count > 0 && (
                            <span className="absolute bottom-0 right-0 text-[7px] leading-none font-body font-bold text-amber-700 bg-white/90 dark:bg-black/70 px-1 py-0.5 rounded-none">
                              {count}
                            </span>
                          )}
                        </div>
                        <p className="font-heading font-semibold text-xs leading-tight w-full break-words">
                          {brand.name}
                        </p>
                      </div>
                    </Link>
                  );
                })}
              </div>
            </div>
          )}
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => { if (sortBy === "name") setNameAsc((v) => !v); else setSortBy("name"); }}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all inline-flex items-center justify-center gap-1.5 ${sortBy === "name" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
              title={isAr ? (sortBy === "name" ? (nameAsc ? "أبجدي تصاعدي (اضغط للعكس)" : "أبجدي تنازلي (اضغط للعكس)") : "أبجدي") : (sortBy === "name" ? (nameAsc ? "A → Z (tap to reverse)" : "Z → A (tap to reverse)") : "Alphabetical")}
            >
              {sortBy === "name" && !nameAsc ? <AArrowDown className="w-3.5 h-3.5" /> : <AArrowUp className="w-3.5 h-3.5" />} {isAr ? "أبجدي" : "Alphabetical"}
            </button>
            <button
              onClick={() => setSortBy("perfumeCount")}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${sortBy === "perfumeCount" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {isAr ? "عدد العطور" : "Total Perfumes"}
            </button>
          </div>

          {isLoading ? (
            <div className="flex justify-center py-16">
              <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-16 space-y-3">
              <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
                <Building2 className="w-8 h-8 text-primary/30" />
              </div>
              <p className="text-muted-foreground font-body text-sm">{isAr ? "لا براندات" : "No brands found"}</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {paginated.map((brand) => {
                const count = getPerfumeCount(brand.name);
                const hasLogo = brand.logo_url || brand.perfumappdatabase_logo;
                return (
                  <Link key={brand.id} to={`/brand?id=${brand.id}`}>
                    <div className="group flex flex-col items-center gap-2 text-center h-full">
                      {/* الإطار الذهبي يحيط باللوقو فقط — خلفية بيضاء، والعدد بزاوية يمين أسفل */}
                      <div className="relative w-20 h-20 rounded-none overflow-hidden flex items-center justify-center bg-white border-2 border-amber-400/70 group-hover:border-amber-500 group-hover:shadow-md transition-all flex-shrink-0">
                        <BrandLogo brand={brand} initialsSize={24} />
                        {count > 0 && (
                          <span className="absolute bottom-0 right-0 text-[7px] leading-none font-body font-bold text-amber-700 bg-white/90 dark:bg-black/70 px-1 py-0.5 rounded-none">
                            {count}
                          </span>
                        )}
                      </div>
                      {/* اسم البراند خارج الإطار أسفله — دائماً */}
                      <p className="font-heading font-semibold text-xs leading-tight w-full break-words">
                        {brand.name}
                      </p>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}

          {/* صندوق «بحث مجموعتك»: مستطيل بزوايا حادّة، إطار ذهبي، خلفية بيضاء، بلا أيقونة/شرح/سهم */}
          <Link to="/collection-search" className="block px-4 py-3 mt-3 bg-white border border-[var(--brand)] hover:bg-amber-50 transition-colors text-center">
            <p className="text-sm font-body font-semibold text-foreground">{isAr ? "بحث مجموعتك" : "Collection Search"}</p>
          </Link>

          {/* السطر المدمج: ترقيم + عدّ البراندات + عدّ العطور + سهما تالي/سابق — بعد الصندوق */}
          {totalPerfumes > 0 && (
            <div className="flex items-center justify-between gap-2 pt-3" dir={isAr ? "rtl" : "ltr"}>
              {totalPages > 1 ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                  disabled={page === 1}
                  className="h-8 w-9 p-0"
                  aria-label={isAr ? "السابق" : "Previous"}
                >
                  {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
                </Button>
              ) : <span className="w-9" />}
              <span className="text-[11px] text-muted-foreground font-body tabular-nums">
                {isAr
                  ? `${page}-${totalPages} - ${sorted.length.toLocaleString()} - ${totalPerfumes.toLocaleString()} عطر`
                  : `${page}-${totalPages} - ${sorted.length.toLocaleString()} - ${totalPerfumes.toLocaleString()} Perfume`}
              </span>
              {totalPages > 1 ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
                  disabled={page === totalPages}
                  className="h-8 w-9 p-0"
                  aria-label={isAr ? "التالي" : "Next"}
                >
                  {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </Button>
              ) : <span className="w-9" />}
            </div>
          )}

          {/* Holding Companies Section */}
          {Object.keys(holdingGroups).length > 0 && (
            <div className="bg-card rounded-none p-5 shadow-sm space-y-3 mt-6">
              <div className="flex items-center gap-2 mb-1">
                <div className="w-8 h-8 bg-primary/10 rounded-none flex items-center justify-center">
                  <Building2 className="w-4 h-4 text-primary" />
                </div>
                <div>
                  <h2 className="font-heading font-semibold text-base">{isAr ? "شركات العطور القابضة" : "Holding Companies"}</h2>
                  <p className="text-xs text-muted-foreground font-body">{isAr ? "الشركات الأم و دورها العطري" : "Parent companies & their fragrance brands"}</p>
                </div>
              </div>
              <div className="space-y-3">
                {Object.entries(holdingGroups).map(([company, compBrands]) => (
                  <div key={company} className="bg-secondary/40 rounded-none p-3">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-sm font-body font-bold">{company}</p>
                      <span className="text-[10px] text-primary rounded-none font-body font-semibold">
                        {compBrands.length} {isAr ? "دار" : "brand" + (compBrands.length !== 1 ? "s" : "")}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {compBrands.map(b => (
                        <Link key={b.id} to={`/brand?id=${b.id}`}
                          className="text-xs rounded-none font-body transition-colors">
                          {b.name}
                        </Link>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
          </div>
          )}

          {/* عدّ العطور الآن مدمج في سطر الترقيم أعلاه (تحت صندوق «بحث مجموعتك») */}
          </div>
          );
          }