import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useSearchParams } from "react-router-dom";
import { Search, ChevronRight, ChevronLeft } from "lucide-react";
import BackButton from "@/components/shared/BackButton";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { Input } from "@/components/ui/input";
import { useLang } from "@/lib/LanguageContext";
import { LINES, LINE_AR, LINE_EN, lineOf, extractYear } from "@/lib/storyLines";
import { compareGlossary } from "@/lib/sortName";

const GOLD = "var(--brand)";

/**
 * مصنفات / Classification (/timelines)
 *
 * — تصانيف بعد خانة البحث؛ كلّ تصنيف يفتح خطّه الزمنيّ الخاصّ (لا «الكل»).
 * — القصص: داخل التصنيف خطّ زمنيّ بالسنوات (+ بلا تاريخ).
 * — المصطلحات: داخل التصنيف قائمة مرتّبة أبجدياً بالإنجليزية (بلا رؤوس أحرف).
 * — الحالة (التبويب + التصنيف) محفوظة في الرابط (?tab=&line=)، فالرجوع من قصّة
 *   يعيدك إلى الخطّ نفسه (يحترم آخر صفحة).
 * — تحميل كسول: لا نعالج السنوات إلا لعناصر التصنيف المفتوح فقط، ولا نعرض كلّ
 *   التصانيف دفعةً؛ كذلك المسار نفسه محمّل عبر React.lazy في App.jsx.
 */
export default function GlossaryTimelines() {
  const { isAr } = useLang();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") === "term" ? "term" : "story";
  const line = params.get("line") || "";
  const query = params.get("q") || "";

  const { data: all = [], isLoading } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });

  // تصنيف خفيف لكلّ سجلّ (مجال + هل هو قصّة) — بلا استخراج سنة هنا (مؤجّل).
  const classified = useMemo(
    () => all.map((r) => ({ rec: r, isStory: r.entry_type === "story", lineKey: lineOf(r) })),
    [all]
  );

  const pool = useMemo(
    () => classified.filter((c) => (tab === "story" ? c.isStory : !c.isStory)),
    [classified, tab]
  );

  // التصانيف: في النسخة النظيفة نعرض كل التصانيف الموجودة في LINES (الهيكل
  // يبقى ظاهراً ولو كان المحتوى فارغاً)، مرتّبةً بترتيب LINES، وما عداها أخيراً.
  const presentLines = useMemo(() => {
    const ordered = LINES.map(([k]) => k);
    const present = new Set(pool.map((c) => c.lineKey));
    if (present.has("other") && !ordered.includes("other")) ordered.push("other");
    return ordered;
  }, [pool]);

  const lineName = (k) => (isAr ? (LINE_AR[k] || k) : (LINE_EN[k] || k));

  const setUrl = (next, opts) => {
    const merged = { tab, line, q: query, ...next };
    const sp = {};
    if (merged.tab && merged.tab !== "story") sp.tab = merged.tab;
    if (merged.line) sp.line = merged.line;
    if (merged.q) sp.q = merged.q;
    setParams(sp, opts);
  };

  // عناصر التصنيف المفتوح + استخراج السنة (هنا فقط — كسول).
  const lineItems = useMemo(() => {
    if (!line) return [];
    const q = query.trim().toLowerCase();
    let arr = pool.filter((c) => c.lineKey === line);
    if (q) arr = arr.filter((c) =>
      ((c.rec.term_ar || "") + " " + (c.rec.term_en || "")).toLowerCase().includes(q));
    return arr.map((c) => ({ ...c, year: tab === "story" ? extractYear(c.rec.meaning || c.rec.meaning_ar || "") : null }));
  }, [pool, line, query, tab]);

  // بحث على مستوى التصانيف: أيّ تصنيف فيه نتيجة مطابقة.
  const matchedLines = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return presentLines;
    const present = new Set(
      pool
        .filter((c) => ((c.rec.term_ar || "") + " " + (c.rec.term_en || "")).toLowerCase().includes(q))
        .map((c) => c.lineKey)
    );
    return presentLines.filter((k) => present.has(k));
  }, [pool, presentLines, query]);

  const TitleLink = ({ c }) => (
    <Link
      to={`/glossary-term?id=${c.rec.id}`}
      className="block hover:opacity-70 transition-opacity"
    >
      <span className="font-body text-[15px] leading-snug text-foreground">
        {isAr ? (c.rec.term_ar || c.rec.term_en) : (c.rec.term_en || c.rec.term_ar)}
      </span>
      <span className="font-body text-[11px] text-muted-foreground ms-2">
        {isAr ? (c.rec.term_en || "") : (c.rec.term_ar || "")}
      </span>
    </Link>
  );

  // خطّ زمنيّ للقصص داخل التصنيف.
  const Timeline = ({ items }) => {
    const dated = items.filter((c) => c.year != null).sort((a, b) => a.year - b.year);
    const undated = items.filter((c) => c.year == null);
    return (
      <div>
        {dated.length > 0 && (
          <div className="relative border-s ps-4 ms-1" style={{ borderColor: "rgba(200,160,46,0.45)" }}>
            {dated.map((c) => (
              <div key={c.rec.id} className="relative py-1.5">
                <span className="absolute top-2 w-2 h-2"
                  style={{ insetInlineStart: "-1.3rem", background: GOLD }} />
                <span className="font-body text-xs tabular-nums text-muted-foreground" dir="ltr">{c.year}</span>
                <div className="mt-0.5"><TitleLink c={c} /></div>
              </div>
            ))}
          </div>
        )}
        {undated.length > 0 && (
          <div className="mt-5">
            <p className="font-body text-[11px] text-muted-foreground mb-2">{isAr ? "بلا تاريخ محدّد" : "Undated"}</p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5">
              {undated.map((c) => <TitleLink key={c.rec.id} c={c} />)}
            </div>
          </div>
        )}
      </div>
    );
  };

  // قائمة المصطلحات داخل التصنيف — مرتّبة أبجدياً بالإنجليزية (بلا رؤوس أحرف).
  const AlphaList = ({ items }) => {
    const sorted = [...items].sort((a, b) => compareGlossary(a.rec, b.rec, 1));
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 ps-1">
        {sorted.map((c) => <TitleLink key={c.rec.id} c={c} />)}
      </div>
    );
  };

  const Chevron = isAr ? ChevronLeft : ChevronRight;

  return (
    <div className="px-5 pt-12 pb-24 space-y-4">
      {/* الترويسة */}
      <div className="flex items-center justify-between">
        <BackButton fallback="/glossary" />
        <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>
          {isAr ? "مصنفات" : "Classification"}
        </h1>
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>

      {/* تبويبان: قصص / مصطلحات (تبديل التبويب يعيد للتصانيف ويُستبدل في السجلّ) */}
      <div className={`flex gap-4 ${isAr ? "flex-row-reverse" : ""}`}>
        {[["story", isAr ? "القصص" : "Stories"], ["term", isAr ? "المصطلحات" : "Terms"]].map(([m, label]) => (
          <button key={m}
            onClick={() => setUrl({ tab: m, line: "" }, { replace: true })}
            className="font-body text-sm py-1 hover:opacity-70 transition-opacity"
            style={{ color: GOLD, fontWeight: tab === m ? 700 : 500, opacity: tab === m ? 1 : 0.55 }}>
            {label}
          </button>
        ))}
      </div>

      {/* بحث — إطار شفّاف */}
      <div className="relative">
        <Search className={`absolute ${isAr ? "right-3" : "left-3"} top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none`} />
        <Input
          placeholder={isAr ? "ابحث" : "Search"}
          value={query}
          onChange={(e) => setUrl({ q: e.target.value }, { replace: true })}
          dir={isAr ? "rtl" : "ltr"}
          className="pl-10 pr-10 h-11 font-body bg-white border border-transparent rounded-none focus-visible:ring-0 focus-visible:ring-offset-0"
        />
      </div>

      {/* المحتوى */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>
      ) : line ? (
        /* داخل تصنيف مفتوح: خطّه الزمنيّ (قصص) أو قائمته الأبجدية (مصطلحات) */
        <div className="space-y-3 pt-1">
          <button
            onClick={() => setUrl({ line: "" })}
            className="inline-flex items-center gap-1 font-body text-xs hover:opacity-70 transition-opacity"
            style={{ color: GOLD, fontWeight: 600 }}
          >
            <Chevron className="w-3.5 h-3.5 rotate-180" />
            {isAr ? "التصانيف" : "Categories"}
          </button>
          <h2 className="font-body text-base font-semibold" style={{ color: GOLD }}>{lineName(line)}</h2>
          {lineItems.length === 0 ? (
            <div className="text-center py-10 text-muted-foreground font-body text-sm">{isAr ? "لا مدخلات" : "No entries"}</div>
          ) : tab === "story" ? (
            <Timeline items={lineItems} />
          ) : (
            <AlphaList items={lineItems} />
          )}
        </div>
      ) : (
        /* قائمة التصانيف — كلّ تصنيف يفتح خطّه (بلا «الكل»، بلا أحرف) */
        <div className="flex flex-col pt-1">
          {matchedLines.length === 0 ? (
            <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "لا تصانيف" : "No categories"}</div>
          ) : (
            matchedLines.map((k) => (
              <button key={k}
                onClick={() => setUrl({ line: k })}
                className="flex items-center justify-between py-2 text-start hover:opacity-70 transition-opacity"
                style={{ color: GOLD }}
              >
                <span className="text-sm font-body font-semibold">{lineName(k)}</span>
                <Chevron className="w-4 h-4 opacity-60" />
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
