import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { PERFUME_TYPES } from "@/lib/perfumeTypes";
import { compareEnglish } from "@/lib/sortName";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import Pagination from "@/components/Pagination";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { useLang } from "@/lib/LanguageContext";

const GOLD = "var(--brand)";

// لوحة ألوان نصّية متكرّرة للأنواع (يحصل كل نوع على لون ثابت من القائمة).
const TYPE_COLORS = [
  "#dc2626", "#ea580c", "#d97706", "#059669",
  "#0891b2", "#2563eb", "#4f46e5", "#7c3aed",
  "#c026d3", "#db2777", "#16a34a", "#0284c7",
];

// تقسيم اسم النوع إلى اسم أساسي وشرح اختياري بين قوسين.
function splitLabel(label) {
  const m = String(label || "").match(/^(.*?)\s*\(([^)]+)\)\s*$/);
  if (m) return { main: m[1].trim(), hint: m[2].trim() };
  return { main: String(label || "").trim(), hint: "" };
}

/**
 * Classify — صفحة التصنيف:
 * - بلا إطارات، بلا خلفيات؛ خلفية بيضاء كاملة.
 * - أنواع العطور كأزرار نصّية بألوان مختلفة. مطويّة افتراضياً (يظهر "All" فقط)
 *   وعند الضغط على "All" تنفتح؛ وعند اختيار نوع يبقى هو وحده مع "All".
 * - فرز يحترم الـ compareEnglish الموحّد.
 * - تحليل تلقائي مختصر أعلى الصفحة.
 * - ثنائية اللغة معالَجة: عنوان أساسي مختصر بكل لغة + شرح اختياري بين قوسين.
 */
export default function Classify() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const [selectedType, setSelectedType] = useState("all");
  const [typesOpen, setTypesOpen] = useState(true); // الرقائق ظاهرة فوراً بلا تحميل
  const [loaded, setLoaded] = useState(false);       // الكتالوج لا يُحمَّل حتى يضغط المستخدم

  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
    enabled: loaded, // تحميل كسول عند أوّل ضغط فقط
  });

  // خريطة العدد لكل نوع.
  const typeCounts = useMemo(() => {
    const m = new Map();
    for (const p of perfumes) {
      const t = p.type || "Uncategorized";
      m.set(t, (m.get(t) || 0) + 1);
    }
    return m;
  }, [perfumes]);

  // ترتيب الأنواع لعرض الشريط: الأكثر استخداماً أوّلاً (للراحة البصرية)،
  // مع إبقاء الأنواع الفارغة في النهاية.
  const orderedTypes = useMemo(() => {
    const known = PERFUME_TYPES.map((t) => t.value);
    return [...known].sort((a, b) => (typeCounts.get(b) || 0) - (typeCounts.get(a) || 0));
  }, [typeCounts]);

  // التحليل التلقائي.
  const analysis = useMemo(() => {
    if (!perfumes.length) return null;
    const sortedByCount = [...PERFUME_TYPES]
      .map((t) => ({ value: t.value, count: typeCounts.get(t.value) || 0 }))
      .sort((a, b) => b.count - a.count);
    const top = sortedByCount.slice(0, 3).filter((x) => x.count > 0);
    return {
      totalPerfumes: perfumes.length,
      activeTypes: sortedByCount.filter((x) => x.count > 0).length,
      top, // [{value, count}]
    };
  }, [perfumes, typeCounts]);

  // العطور المعروضة وفق النوع المختار، مرتّبة بـ compareEnglish الموحّد.
  const sortedData = useMemo(() => {
    const base = selectedType === "all"
      ? perfumes
      : perfumes.filter((p) => (p.type || "Uncategorized") === selectedType);
    return [...base].sort((a, b) => compareEnglish(a, b, 1));
  }, [selectedType, perfumes]);

  const getColor = (idx) => TYPE_COLORS[idx % TYPE_COLORS.length];

  const onPickType = (val) => {
    setLoaded(true); // أوّل ضغط يبدأ تحميل الكتالوج (مرّة واحدة)
    if (val === "all") {
      setSelectedType("all");
      setTypesOpen(true);
      return;
    }
    if (!typesOpen && val === selectedType) {
      setTypesOpen(true);
      return;
    }
    setSelectedType(val);
    setTypesOpen(false);
  };

  const renderTypeButton = (typeValue, idx) => {
    const item = PERFUME_TYPES.find((t) => t.value === typeValue);
    const enParts = splitLabel(item?.label_en || typeValue);
    const arParts = splitLabel(item?.label_ar || typeValue);
    const main = isAr ? arParts.main : enParts.main;
    const hint = isAr ? arParts.hint : enParts.hint;
    const count = typeCounts.get(typeValue) || 0;
    const active = selectedType === typeValue;
    const color = getColor(idx);
    return (
      <button
        key={typeValue}
        onClick={() => onPickType(typeValue)}
        className="text-start py-1 hover:opacity-70 transition-opacity"
        style={{ color, opacity: active ? 1 : 0.85, fontWeight: active ? 700 : 500 }}
      >
        <span className="text-xs font-body">{main}</span>
        {hint && <span className="text-[10px] font-body opacity-70 ms-1">({hint})</span>}
        <span className="text-[10px] font-body text-muted-foreground ms-1">{count}</span>
      </button>
    );
  };

  return (
    <div className="px-5 pt-12 pb-24 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className={`flex items-center gap-2.5 ${isAr ? "flex-row-reverse" : ""}`}>
          <button
            onClick={() => navigate(-1)}
            className="w-9 h-9 flex items-center justify-center hover:opacity-70 transition-opacity"
            title={isAr ? "رجوع" : "Back"}
          >
            <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} style={{ color: GOLD }} />
          </button>
          <h1 className="font-heading text-lg font-semibold" style={{ color: GOLD }}>
            {isAr ? "التصنيف والتناغمات" : "Classify & Accord"}
          </h1>
        </div>
        <SettingsSheet>
          <UserAvatarButton size={28} />
        </SettingsSheet>
      </div>

      {/* Auto-analysis */}
      {analysis && !isLoading && (
        <p className="text-[11px] font-body" style={{ color: GOLD }}>
          {isAr
            ? `${analysis.totalPerfumes} عطر ${analysis.activeTypes} نوع نشط${analysis.top.length ? ` الأكثر: ${analysis.top.map(t => splitLabel(PERFUME_TYPES.find(p => p.value === t.value)?.label_ar || t.value).main).join("، ")}` : ""}`
            : `${analysis.totalPerfumes} perfumes · ${analysis.activeTypes} active types${analysis.top.length ? ` · top: ${analysis.top.map(t => splitLabel(PERFUME_TYPES.find(p => p.value === t.value)?.label_en || t.value).main).join(", ")}` : ""}`}
        </p>
      )}

      {/* Type chooser — مطوي افتراضياً، يفتح بضغط All؛ عند اختيار نوع يطوي الباقي */}
      <div className="flex flex-col gap-1">
        <button
          onClick={() => onPickType("all")}
          className="text-start py-1 hover:opacity-70 transition-opacity"
          style={{ color: GOLD, fontWeight: selectedType === "all" ? 700 : 500 }}
        >
          <span className="text-xs font-body font-semibold">{isAr ? "الكل" : "All"}</span>
          <span className="text-[10px] font-body text-muted-foreground ms-1">{perfumes.length}</span>
        </button>
        {typesOpen
          ? orderedTypes.map((tv, i) => renderTypeButton(tv, i))
          : (selectedType !== "all" &&
              renderTypeButton(selectedType, orderedTypes.indexOf(selectedType) >= 0 ? orderedTypes.indexOf(selectedType) : 0))}
      </div>

      {selectedType !== "all" && (
        <p className="text-xs text-muted-foreground font-body">
          {sortedData.length} {isAr ? "عطر" : `perfume${sortedData.length !== 1 ? "s" : ""}`}
        </p>
      )}

      {!loaded ? (
        <div className="text-center py-12 space-y-2">
          <p className="text-3xl">🗂️</p>
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? "اختر تصنيفاً لعرض عطوره" : "Pick a classification to load its perfumes"}
          </p>
        </div>
      ) : isLoading ? (
        <div className="text-center py-12 text-muted-foreground font-body text-sm">{isAr ? "جارٍ التحميل…" : "Loading…"}</div>
      ) : sortedData.length === 0 ? (
        <div className="text-center py-12 space-y-2">
          <p className="text-4xl">📭</p>
          <p className="text-sm font-body text-muted-foreground">
            {isAr ? "لا توجد عطور في هذا التصنيف" : "No perfumes in this category"}
          </p>
        </div>
      ) : (
        <Pagination
          items={sortedData}
          itemsPerPage={50}
          renderItem={(items) => (
            <div className="grid grid-cols-2 gap-3">
              {items.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
            </div>
          )}
          emptyMessage={isAr ? "لا توجد عطور" : "No perfumes"}
        />
      )}
    </div>
  );
}
