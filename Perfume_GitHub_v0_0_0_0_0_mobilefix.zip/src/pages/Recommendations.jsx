import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  ArrowLeftIcon as ArrowLeft, SparklesIcon as Sparkles, SearchIcon as Search,
  XIcon as X, LibraryIcon as Library, DatabaseIcon as Database,
  DownloadIcon as Download, FileTextIcon as FileText, ImageIcon, PdfIcon as FileType2,
  CheckSquareIcon as CheckSquare, SquareIcon as Square,
} from "@/components/icons/LineIcons";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { recommend } from "@/lib/perfumeRecommend";
import { DEFAULT_USER_MARK, getExportSettings } from "@/lib/exportSettings";
import { getAppName } from "@/lib/useAppName";
import { exportElementAsImage, exportElementAsPDF, downloadText } from "@/lib/collectionExport";
import { toast } from "sonner";
import { format } from "date-fns";

function pTitle(p, isAr) {
  if (!p) return "";
  return (isAr ? (p.name_ar || p.name_en) : (p.name_en || p.name_ar)) || p.name || "";
}

export default function Recommendations() {
  const navigate = useNavigate();
  const { isAr } = useLang();
  const { names } = usePersonNames();

  const [source, setSource] = useState("library");   // library | database
  const [person, setPerson] = useState("all");        // all | person1 | person2
  const [query, setQuery] = useState("");
  const [seedId, setSeedId] = useState(null);

  // export
  const [fmt, setFmt] = useState("image");
  const [bg, setBg] = useState("#ffffff");
  const [busy, setBusy] = useState(false);
  const [showMark, setShowMark] = useState(() => {
    try { return getExportSettings()?.showUserMark !== false; } catch { return true; }
  });

  const { data: userPerfumes = [], isLoading: upLoading } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: allPerfumes = [], isLoading: pLoading } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const ownedIds = useMemo(
    () => new Set(userPerfumes.map((u) => String(u.perfume_id))),
    [userPerfumes]
  );

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q || source !== "database") return [];
    return allPerfumes
      .filter((p) =>
        [p.name_en, p.name_ar, p.name, p.brand_name]
          .filter(Boolean)
          .some((f) => String(f).toLowerCase().includes(q))
      )
      .slice(0, 12);
  }, [query, allPerfumes, source]);

  const seedPerfume = useMemo(
    () => (seedId ? allPerfumes.find((p) => String(p.id) === String(seedId)) : null),
    [seedId, allPerfumes]
  );

  const { results, profile, empty, hint } = useMemo(() => {
    if (allPerfumes.length === 0) return { results: [], empty: true, hint: "loading", profile: { notes: new Set(), families: new Set() } };

    if (source === "library") {
      const mine = person === "all" ? userPerfumes : userPerfumes.filter((u) => u.person === person);
      const positives = mine.filter(
        (u) =>
          u.other_rating === "love_it" || u.other_rating === "like_it" ||
          u.list === "favorite" || (u.rating && u.rating >= 4)
      );
      const seedUser = positives.length > 0 ? positives : mine;
      const seedIds = new Set(seedUser.map((u) => String(u.perfume_id)));
      const seeds = allPerfumes.filter((p) => seedIds.has(String(p.id)));

      const bad = mine.filter(
        (u) => (u.headache && u.headache !== "none") ||
          (u.sinus_sensitivity && u.sinus_sensitivity === "yes")
      );
      const badIds = new Set(bad.map((u) => String(u.perfume_id)));
      const badPerfumes = allPerfumes.filter((p) => badIds.has(String(p.id)));
      const avoidNotes = badPerfumes.flatMap((p) =>
        [p.top_notes, p.heart_notes, p.base_notes].filter(Boolean).join(",").split(",")
      );

      if (seeds.length === 0) return { results: [], empty: true, hint: "no-library", profile: { notes: new Set(), families: new Set() } };

      const out = recommend({ seeds, candidates: allPerfumes, excludeIds: [...ownedIds], avoidNotes, limit: 15 });
      return { ...out, hint: null };
    }

    if (!seedPerfume) return { results: [], empty: true, hint: "no-seed", profile: { notes: new Set(), families: new Set() } };
    const out = recommend({
      seeds: [seedPerfume],
      candidates: allPerfumes,
      excludeIds: [String(seedPerfume.id), ...ownedIds],
      avoidNotes: [],
      limit: 15,
    });
    return { ...out, hint: null };
  }, [source, person, userPerfumes, allPerfumes, ownedIds, seedPerfume]);

  const loading = upLoading || pLoading;

  const sourceLabel = source === "library"
    ? (isAr ? "مكتبتي" : "My library")
    : (seedPerfume ? pTitle(seedPerfume, isAr) : (isAr ? "قاعدة العطور" : "Database"));

  const headerMark = () => {
    let settings = {};
    try { settings = getExportSettings() || {}; } catch { settings = {}; }
    const bits = [];
    if (showMark) bits.push(DEFAULT_USER_MARK);
    if (settings.showAppName !== false) {
      try { const n = getAppName().name_en; if (n) bits.push(n); } catch { /* ignore */ }
    }
    bits.push(new Date().toLocaleDateString());
    return bits.join("  ·  ");
  };

  const buildText = () => {
    const lines = [];
    lines.push(isAr ? "ترشيحات مختارة لك" : "Curated for you");
    lines.push(headerMark());
    lines.push(`${isAr ? "المصدر" : "Source"}: ${sourceLabel}`);
    lines.push("");
    results.forEach((r, i) => {
      lines.push(`${i + 1}. ${pTitle(r.perfume, isAr)} — ${r.perfume.brand_name || ""}  (${r.percent}%)`);
      if (r.sharedNotes.length) lines.push(`   ${isAr ? "يشترك في" : "shares"}: ${r.sharedNotes.slice(0, 4).join(", ")}`);
    });
    return lines.join("\n");
  };

  const handleExport = async () => {
    if (results.length === 0) { toast.error(isAr ? "لا ترشيحات للتصدير" : "Nothing to export"); return; }
    setBusy(true);
    try {
      const stamp = format(new Date(), "yyyy-MM-dd");
      if (fmt === "text") {
        await downloadText(buildText(), `recommendations-${stamp}.txt`);
      } else {
        const el = document.getElementById("recs-export-card");
        if (!el) throw new Error("card missing");
        if (fmt === "image") await exportElementAsImage(el, `recommendations-${stamp}.png`, bg);
        else await exportElementAsPDF(el, `recommendations-${stamp}.pdf`, bg);
      }
      toast.success(isAr ? "تم التصدير" : "Exported");
    } catch (e) {
      console.error("export failed", e);
      toast.error(isAr ? "فشل التصدير" : "Export failed");
    } finally {
      setBusy(false);
    }
  };

  const dark = bg === "#1c1917";

  return (
    <div className="px-5 pt-12 pb-24">
      <div className="flex items-center gap-3 mb-5">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-heading text-2xl font-bold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" /> {isAr ? "ترشيحات العطور" : "Recommendations"}
          </h1>
          <p className="text-xs text-muted-foreground mt-1">{isAr ? "تشابه محلّي — بلا إنترنت" : "Local similarity — offline"}</p>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-2 mb-4">
        <button
          onClick={() => setSource("library")}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-none text-xs font-body font-medium transition-all ${source === "library" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
        >
          <Library className="w-4 h-4" /> {isAr ? "مكتبتي" : "My library"}
        </button>
        <button
          onClick={() => setSource("database")}
          className={`flex items-center justify-center gap-2 py-2.5 rounded-none text-xs font-body font-medium transition-all ${source === "database" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
        >
          <Database className="w-4 h-4" /> {isAr ? "قاعدة العطور" : "Database"}
        </button>
      </div>

      {source === "library" && (
        <div className="flex gap-2 mb-4">
          {[
            { v: "all", label: isAr ? "الكل" : "All" },
            { v: "person1", label: names.person1 },
            { v: "person2", label: names.person2 },
          ].map((o) => (
            <button
              key={o.v}
              onClick={() => setPerson(o.v)}
              className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${person === o.v ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
            >
              {o.label}
            </button>
          ))}
        </div>
      )}

      {source === "database" && (
        <div className="mb-4">
          {seedPerfume ? (
            <div className="flex items-center gap-2 bg-primary/10 rounded-none p-3">
              <Sparkles className="w-4 h-4 text-primary flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-body font-bold truncate">{pTitle(seedPerfume, isAr)}</p>
                <p className="text-[10px] text-muted-foreground truncate">{seedPerfume.brand_name}</p>
              </div>
              <button onClick={() => { setSeedId(null); setQuery(""); }} aria-label="clear">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          ) : (
            <div>
              <div className="flex items-center gap-2 bg-secondary/50 rounded-none px-3 py-2">
                <Search className="w-4 h-4 text-muted-foreground" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder={isAr ? "ابحث عن عطر تحبّه..." : "Search a perfume you like..."}
                  className="flex-1 bg-transparent outline-none text-xs font-body"
                />
              </div>
              {searchResults.length > 0 && (
                <div className="mt-2 space-y-1">
                  {searchResults.map((p) => (
                    <button
                      key={p.id}
                      onClick={() => setSeedId(p.id)}
                      className="w-full flex items-center gap-2 bg-secondary/30 hover:bg-secondary/60 rounded-none p-2 text-left transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-body font-medium truncate">{pTitle(p, isAr)}</p>
                        <p className="text-[10px] text-muted-foreground truncate">{p.brand_name}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : empty ? (
        <div className="text-center py-12 bg-secondary/30 rounded-none px-4">
          <p className="text-sm text-muted-foreground font-body">
            {hint === "no-library"
              ? (isAr ? "أضف عطوراً لمكتبتك أو قيّمها لنرشّح لك" : "Add or rate perfumes in your library first")
              : hint === "no-seed"
                ? (isAr ? "ابحث واختر عطراً لنجد ما يشبهه" : "Search and pick a perfume to find similar ones")
                : (isAr ? "لا ترشيحات متاحة" : "No recommendations available")}
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-2">
            <p className="text-[11px] text-muted-foreground font-body mb-1">
              {isAr
                ? `بناءً على ${profile.notes.size} نوتة و${profile.families.size} عائلة`
                : `Based on ${profile.notes.size} notes and ${profile.families.size} families`}
            </p>
            {results.map((r, i) => (
              <div
                key={r.perfume.id}
                onClick={() => navigate(`/perfume?id=${r.perfume.id}`)}
                className="flex items-center gap-3 bg-secondary/40 hover:bg-secondary/60 rounded-none p-3 cursor-pointer transition-colors"
              >
                <div className="w-6 text-center text-xs font-heading font-bold text-muted-foreground flex-shrink-0">{i + 1}</div>
                <div className="w-11 h-11 rounded-none bg-white dark:bg-slate-800 flex-shrink-0 overflow-hidden flex items-center justify-center">
                  {r.perfume.image_url
                    ? <img src={r.perfume.image_url} alt="" className="w-full h-full object-cover" />
                    : <span className="text-sm">💧</span>}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-body font-bold truncate">{pTitle(r.perfume, isAr)}</p>
                  <p className="text-[10px] text-muted-foreground truncate">{r.perfume.brand_name}</p>
                  {r.sharedNotes.length > 0 && (
                    <p className="text-[10px] text-primary truncate mt-0.5">
                      {isAr ? "يشترك في: " : "Shares: "}{r.sharedNotes.slice(0, 3).join(" ")}
                    </p>
                  )}
                </div>
                <div className="text-right flex-shrink-0">
                  <div className="text-sm font-heading font-bold text-primary">{r.percent}%</div>
                  <div className="text-[9px] text-muted-foreground uppercase">{isAr ? "تطابق" : "match"}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Export controls */}
          <div className="mt-8 pt-6 border-t border-border space-y-4">
            <p className="text-sm font-body font-medium">{isAr ? "تصدير كبطاقة أنيقة" : "Export as an elegant card"}</p>
            <div className="flex gap-2">
              {[
                { v: "image", label: isAr ? "صورة" : "Image", icon: ImageIcon },
                { v: "pdf", label: "PDF", icon: FileType2 },
                { v: "text", label: isAr ? "نص" : "Text", icon: FileText },
              ].map((o) => {
                const Icon = o.icon;
                return (
                  <button
                    key={o.v}
                    onClick={() => setFmt(o.v)}
                    className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-none text-xs font-body font-medium transition-all ${fmt === o.v ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}
                  >
                    <Icon className="w-3.5 h-3.5" /> {o.label}
                  </button>
                );
              })}
            </div>

            {fmt !== "text" && (
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground font-body">{isAr ? "الخلفية" : "Background"}</span>
                {["#ffffff", "#faf5ec", "#1c1917"].map((c) => (
                  <button
                    key={c}
                    onClick={() => setBg(c)}
                    className={`w-7 h-7 rounded-none border-2 ${bg === c ? "border-primary" : "border-border"}`}
                    style={{ background: c }}
                    aria-label={c}
                  />
                ))}
              </div>
            )}

            <button onClick={() => setShowMark((v) => !v)} className="flex items-center gap-2 text-xs font-body">
              {showMark ? <CheckSquare className="w-4 h-4 text-primary" /> : <Square className="w-4 h-4 text-muted-foreground" />}
              <span className={showMark ? "text-foreground" : "text-muted-foreground"}>
                {isAr ? `علامة المستخدم (${DEFAULT_USER_MARK})` : `User mark (${DEFAULT_USER_MARK})`}
              </span>
            </button>

            <Button onClick={handleExport} disabled={busy} className="w-full h-11 rounded-none font-body gap-2">
              <Download className="w-4 h-4" />
              {busy ? (isAr ? "جارٍ..." : "Working...") : `${isAr ? "تنزيل" : "Download"} (${results.length})`}
            </Button>
          </div>

          {/* Hidden elegant export card */}
          <div style={{ position: "fixed", left: 0, top: 0, zIndex: -1, opacity: 1, pointerEvents: "none" }} aria-hidden="true">
            <div
              id="recs-export-card"
              dir={isAr ? "rtl" : "ltr"}
              style={{
                width: "640px",
                boxSizing: "border-box",
                padding: "44px 40px",
                background: bg,
                color: dark ? "#f5f0e6" : "#241c12",
                fontFamily: "'Cairo','Amiri','Segoe UI',sans-serif",
              }}
            >
              <div style={{ textAlign: "center", marginBottom: "10px", fontSize: "13px", color: dark ? "#cbb98a" : "#9a8a6a" }}>
                {headerMark()}
              </div>
              <h2 style={{ textAlign: "center", fontSize: "30px", fontWeight: 700, margin: "0 0 4px" }}>
                ✨ {isAr ? "ترشيحات مختارة لك" : "Curated for you"}
              </h2>
              <p style={{ textAlign: "center", fontSize: "13px", margin: "0 0 28px", color: dark ? "#a8a097" : "#8a7d63" }}>
                {isAr ? "المصدر" : "Source"}: {sourceLabel}
              </p>

              {results.map((r, i) => (
                <div
                  key={r.perfume.id}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: "14px",
                    padding: "11px 6px",
                    borderBottom: `0.5px solid ${dark ? "#332d26" : "#efe7d4"}`,
                  }}
                >
                  <div
                    style={{
                      width: "30px", height: "30px", flexShrink: 0, borderRadius: "999px",
                      display: "flex", alignItems: "center", justifyContent: "center",
                      fontSize: "14px", fontWeight: 700,
                      background: dark ? "#3a2e10" : "#fdf0d4", color: dark ? "#f0c674" : "#a16207",
                    }}
                  >
                    {i + 1}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: "16px", fontWeight: 700 }}>{pTitle(r.perfume, isAr)}</div>
                    <div style={{ fontSize: "12px", color: dark ? "#a8a097" : "#8a7d63" }}>{r.perfume.brand_name}</div>
                    {r.sharedNotes.length > 0 && (
                      <div style={{ fontSize: "11px", color: dark ? "#9bb8d8" : "#5a7fa0", marginTop: "2px" }}>
                        {isAr ? "يشترك في: " : "Shares: "}{r.sharedNotes.slice(0, 4).join(" ")}
                      </div>
                    )}
                  </div>
                  <div style={{ textAlign: "center", flexShrink: 0 }}>
                    <div style={{ fontSize: "18px", fontWeight: 700, color: dark ? "#e8c97a" : "#a16207" }}>{r.percent}%</div>
                    <div style={{ fontSize: "9px", textTransform: "uppercase", color: dark ? "#a8a097" : "#8a7d63" }}>
                      {isAr ? "تطابق" : "match"}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
