import { useState, useEffect, useMemo } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { useNumberEncryption } from "@/lib/useNumberEncryption";
import { DEFAULT_MAIN_CATEGORIES, ALL_SUB_CATEGORIES, DEFAULT_SHOP_QUOTES } from "@/lib/shopCategories";
import { Search, Store, Package, BarChart3, Settings2, FileText, EyeOff, Eye, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import ShopHeroQuote from "@/components/shopping/ShopHeroQuote";
import ShopCategoryManager from "@/components/shopping/ShopCategoryManager";
import ShopBrandList from "@/components/shopping/ShopBrandList";
import ShopProductList from "@/components/shopping/ShopProductList";
import ShopAnalytics from "@/components/shopping/ShopAnalytics";
import AddShopBrandDialog from "@/components/shopping/AddShopBrandDialog";
import AddShopProductDialog from "@/components/shopping/AddShopProductDialog";
import ShopPurchaseLog from "@/components/shopping/ShopPurchaseLog";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import SettingsSheet from "@/components/layout/SettingsSheet";
import SectionDivider from "@/components/shared/SectionDivider";
import { resolveUserMark } from "@/lib/exportSettings";

const TABS = [
  { id: "log", icon: FileText, en: "Purchase Log", ar: "سجل الشراء" },
  { id: "products", icon: Package, en: "Product Log", ar: "سجل المنتجات" },
  { id: "brands", icon: Store, en: "Brands & Store", ar: "المتاجر" },
  { id: "categories", icon: Settings2, en: "Categories", ar: "الأقسام" },
  { id: "analytics", icon: BarChart3, en: "Console", ar: "لوحة التحكم" },
];

export default function Shopping() {
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const { encryptNumbers } = useNumberEncryption();
  const queryClient = useQueryClient();
  const [tab, setTab] = useState(() => {
    try { return new URLSearchParams(window.location.search).get("tab") || "log"; }
    catch { return "log"; }
  });
  const [search, setSearch] = useState("");
  const [showAddBrand, setShowAddBrand] = useState(false);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [viewMode, setViewMode] = useState(() => localStorage.getItem("shopViewMode") || "magazine");
  const [hiddenCats, setHiddenCats] = useState(() => {
    try { return JSON.parse(localStorage.getItem("hiddenShopCats") || "[]"); } catch { return []; }
  });
  const [managingCats, setManagingCats] = useState(false);
  // علامة المستخدم المخصّصة تُجلب من ملفّ المستخدم (auth.me().mark) لا من مفتاح قديم خاطئ
  const [mark, setMark] = useState("");
  useEffect(() => {
    let alive = true;
    resolveUserMark().then((m) => { if (alive) setMark(m || ""); }).catch(() => {});
    return () => { alive = false; };
  }, []);
  const navigate = useNavigate();

  const { data: brands = [] } = useQuery({
    queryKey: ["shop-brands"],
    queryFn: () => apphost.entities.ShopBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const { data: products = [] } = useQuery({
    queryKey: ["shop-products"],
    queryFn: () => apphost.entities.ShopProduct.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  // الحكمة تأتي مباشرة من قاعدة بيانات الحكمة الكاملة (Wisdom) — لا من نمط
  // الحكم الستّ القديم. نطابق حقول Wisdom (wisdom/wisdom_ar) لشكل الهيرو
  // (text_en/text_ar) مع الاحتفاظ بالمعرّف للتحرير.
  const { data: wisdomRows = [] } = useQuery({
    queryKey: ["wisdom"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });

  const quotes = useMemo(
    () => wisdomRows.map((w) => ({
      id: w.id,
      text_en: w.wisdom || w.text_en || "",
      text_ar: w.wisdom_ar || w.text_ar || "",
      is_active: true,
    })).filter((q) => q.text_en || q.text_ar),
    [wisdomRows]
  );

  // نضمن وجود الحكم الافتراضية (DEFAULT_SHOP_QUOTES) داخل قاعدة Wisdom.
  useEffect(() => {
    if (wisdomRows.length === 0) return; // ننتظر تحميل القاعدة قبل المقارنة
    seedDefaultWisdom();
     
  }, [wisdomRows.length]);

  const seedDefaultWisdom = async () => {
    try {
      const existing = new Set(
        wisdomRows.map((w) => (w.wisdom || w.text_en || "").trim().toLowerCase())
      );
      let added = false;
      for (const q of DEFAULT_SHOP_QUOTES) {
        if (existing.has((q.text_en || "").trim().toLowerCase())) continue;
        await apphost.entities.Wisdom.create({
          wisdom: q.text_en, wisdom_ar: q.text_ar, category: "shopping", is_default: true,
        });
        added = true;
      }
      if (added) queryClient.invalidateQueries({ queryKey: ["wisdom"] });
    } catch (e) { console.error(e); }
  };

  // Always use static built-in categories — no DB dependency
  const mainCategories = DEFAULT_MAIN_CATEGORIES;
  const subCategories = ALL_SUB_CATEGORIES;

  // Note: Stats will show encrypted costs until decrypted in individual components
  // Each component (ShopPurchaseLog, ShopAnalytics) handles decryption independently
  const stats = useMemo(() => {
    const total = products.reduce((s, p) => s + (p.cost || 0), 0);
    const thisMonth = products.filter(p => {
      if (!p.purchase_date) return false;
      const d = new Date(p.purchase_date);
      const now = new Date();
      return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear();
    }).reduce((s, p) => s + (p.cost || 0), 0);
    return { total, thisMonth, count: products.length, brandsCount: brands.length };
  }, [products, brands]);

  return (
    <div className={`relative min-h-screen bg-background pb-28 ${isAr ? "rtl" : ""}`}>
      {/* User box — top corner, usual place (blends with hero, gold frame) */}
      <div
        className={`absolute z-50 ${isAr ? "left-3" : "right-3"}`}
        style={{ top: "calc(env(safe-area-inset-top, 0px) + 0.6rem)" }}
      >
        <SettingsSheet>
          <UserAvatarButton size={30} />
        </SettingsSheet>
      </div>

      {/* Hero Quote */}
      <ShopHeroQuote quotes={quotes} isAr={isAr} viewMode={viewMode} setViewMode={setViewMode} mark={mark} />

      {/* روابط: أزرار نصّية بجانب بعضها (تلتفّ عند الحاجة) بلا أيقونات ولا صناديق */}
      <div className="px-4 pt-2 flex flex-wrap gap-x-4 gap-y-1">
        <button onClick={() => navigate("/shop-report")}
          className="font-body text-xs font-medium text-emerald-700 dark:text-emerald-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "تقارير التسوق و المتاجر" : "Shopping & Stores Reports"}
        </button>
        <Link to="/budget"
          className="font-body text-xs font-medium text-blue-700 dark:text-blue-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "إدارة الميزانية" : "Budget Management"}
        </Link>
        <Link to="/marketing-card"
          className="font-body text-xs font-medium text-fuchsia-700 dark:text-fuchsia-400 py-1.5 hover:opacity-70 transition-opacity">
          {isAr ? "إنشاء بطاقة تسويقية" : "Create Marketing Card"}
        </Link>
      </div>

      <div className="px-4"><SectionDivider className="my-3" /></div>

      {/* المتاجر المثبّتة — فوق الأقسام الرئيسية */}
      {brands.filter((b) => b.pinned && !b.hidden).length > 0 && (
        <div className="px-4 pt-1 pb-1">
          <p className="text-[9px] text-muted-foreground font-body uppercase tracking-wider mb-1.5">{isAr ? "متاجر مثبّتة" : "Pinned Stores"}</p>
          <div className="flex gap-2 overflow-x-auto pb-1 px-0.5">
            {brands.filter((b) => b.pinned && !b.hidden).map((s) => (
              <button
                key={s.id}
                onClick={() => navigate(`/store?id=${s.id}`)}
                className="flex items-center gap-2 flex-shrink-0 bg-secondary/50 hover:bg-secondary rounded-none pl-1.5 pr-3 py-1.5 transition-colors border border-primary/30"
              >
                {s.logo_url ? (
                  <img src={s.logo_url} alt={s.name} className="w-7 h-7 rounded-none object-cover flex-shrink-0" />
                ) : (
                  <div className="w-7 h-7 rounded-none bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Store className="w-3.5 h-3.5 text-primary/70" />
                  </div>
                )}
                <span className="text-xs font-body font-semibold whitespace-nowrap">{isAr ? (s.name_ar || s.name) : s.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Categories (catalog) */}
      {mainCategories.length > 0 && (
        <div className="px-4 pt-3 pb-1">
          <div className="flex items-center justify-between mb-1.5">
            <p className="text-[9px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "الأقسام" : "Categories"}</p>
            <button onClick={() => setManagingCats(m => !m)} className="text-[10px] text-primary font-body">
              {managingCats ? (isAr ? "تم" : "Done") : (isAr ? "تعديل" : "Manage")}
            </button>
          </div>
          <div className="grid gap-1.5" style={{ gridTemplateColumns: `repeat(${Math.min(mainCategories.length || 5, 5)}, 1fr)` }}>
            {mainCategories.sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0)).map(cat => {
              const isHidden = hiddenCats.includes(cat.id);
              if (!managingCats && isHidden) return null;
              return (
                <div key={cat.id} className="relative">
                  <button
                    onClick={() => {
                      if (managingCats) return;
                      navigate(`/shop-category/${cat.id}`);
                    }}
                    className={`flex flex-col items-center gap-0.5 px-0.5 py-2 transition-all w-full min-w-0 ${isHidden ? "opacity-40" : "hover:opacity-70"}`}>
                    <span className="text-base">{cat.icon}</span>
                    <span className="text-[7px] font-body font-medium text-foreground leading-tight text-center line-clamp-2 w-full">
                      {isAr ? cat.name_ar : cat.name_en}
                    </span>
                  </button>
                  {managingCats && (
                    <div className="absolute -top-1 -right-1 flex gap-0.5">
                      <button onClick={() => {
                        const next = isHidden ? hiddenCats.filter(id => id !== cat.id) : [...hiddenCats, cat.id];
                        setHiddenCats(next);
                        localStorage.setItem("hiddenShopCats", JSON.stringify(next));
                      }} className="w-4 h-4 rounded-none bg-blue-500 flex items-center justify-center shadow">
                        {isHidden ? <Eye className="w-2.5 h-2.5 text-white" /> : <EyeOff className="w-2.5 h-2.5 text-white" />}
                      </button>
                      {!cat.is_default && /^\d+$/.test(String(cat.id)) && (
                        <button onClick={async () => {
                          if (!confirm(isAr ? "حذف القسم؟" : "Delete category?")) return;
                          try {
                            await apphost.entities.ShopCategory.delete(cat.id);
                            queryClient.invalidateQueries({ queryKey: ["shop-categories"] });
                          } catch (e) {
                            toast.error(isAr ? "تعذّر الحذف" : "Could not delete");
                          }
                        }} className="w-4 h-4 rounded-none bg-red-500 flex items-center justify-center shadow">
                          <Trash2 className="w-2.5 h-2.5 text-white" />
                        </button>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Stats Row */}
      <div className="px-4 py-1.5 grid grid-cols-4 gap-1">
        {[
          { label: isAr ? "الإجمالي" : "Total", value: `${stats.total.toFixed(0)}`, color: "text-primary" },
          { label: isAr ? "هذا الشهر" : "Month", value: `${stats.thisMonth.toFixed(0)}`, color: "text-amber-600" },
          { label: isAr ? "منتجات" : "Items", value: stats.count, color: "text-blue-600" },
          { label: isAr ? "متاجر" : "Stores", value: stats.brandsCount, color: "text-purple-600" },
        ].map((s, i) => (
          <div key={i} className="p-1.5 text-center">
            <p className={`text-xs font-bold font-heading ${s.color}`}>{s.value}</p>
            <p className="text-[7px] text-muted-foreground font-body mt-0.5 leading-tight">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="px-4"><SectionDivider className="my-2" /></div>

      {/* Tabs — fit to screen */}
      <div className="px-4 grid pb-1.5" style={{ gridTemplateColumns: `repeat(${TABS.length}, 1fr)`, gap: "4px" }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn("flex flex-col items-center gap-0.5 px-0.5 py-1.5 text-[9px] font-body font-medium transition-colors",
              tab === t.id ? "text-primary font-semibold" : "text-muted-foreground hover:text-foreground")}>
            <t.icon className="w-3 h-3" />
            <span className="leading-tight text-center">{isAr ? t.ar : t.en}</span>
          </button>
        ))}
      </div>

      {/* Search + Add */}
      {(tab === "brands" || tab === "products" || tab === "log") && (
        <div className="px-4 pb-2 flex gap-1.5">
          <div className="flex-1 relative">
            <Search className="absolute left-2.5 top-2 w-3.5 h-3.5 text-muted-foreground" />
            <Input value={search} onChange={e => setSearch(e.target.value)}
              placeholder={isAr ? "ابحث" : "Search"}
              className="pl-8 h-9 font-body text-sm bg-white border border-transparent rounded-none" />
          </div>
          {tab !== "log" && (
            <Button variant="ghost" className="h-9 px-2 font-body text-[11px] whitespace-nowrap font-semibold text-[var(--brand)] hover:text-[var(--brand)] hover:opacity-80"
              onClick={() => tab === "brands" ? setShowAddBrand(true) : setShowAddProduct(true)}>
              {tab === "brands"
                ? (isAr ? "إضافة متجر" : "Add Store")
                : (isAr ? "إضافة منتج" : "Add Product")}
            </Button>
          )}
        </div>
      )}

      {/* Tab Content */}
      <div className="px-4 pb-2">
        {tab === "log" && (
          <ShopPurchaseLog products={products} brands={brands} search={search} isAr={isAr}
            onRefresh={() => { queryClient.invalidateQueries({ queryKey: ["shop-products"] }); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
        )}
        {tab === "products" && (
          <ShopProductList products={products} brands={brands} search={search} isAr={isAr}
            names={names} currency={currency} categories={ALL_SUB_CATEGORIES}
            viewMode={viewMode}
            onRefresh={() => { queryClient.invalidateQueries({ queryKey: ["shop-products"] }); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
        )}
        {tab === "brands" && (
          <ShopBrandList brands={brands} search={search} isAr={isAr} names={names} currency={currency}
            mainCategories={mainCategories} products={products}
            viewMode={viewMode}
            onRefresh={() => queryClient.invalidateQueries({ queryKey: ["shop-brands"] })} />
        )}
        {tab === "categories" && (
          <ShopCategoryManager isAr={isAr} />
        )}
        {tab === "analytics" && (
          <ShopAnalytics products={products} brands={brands} categories={ALL_SUB_CATEGORIES}
            isAr={isAr} currency={currency} names={names} />
        )}
      </div>


      {/* Dialogs */}
      {showAddBrand && (
        <AddShopBrandDialog isAr={isAr} categories={mainCategories}
          onClose={() => setShowAddBrand(false)}
          onSaved={() => { setShowAddBrand(false); queryClient.invalidateQueries({ queryKey: ["shop-brands"] }); }} />
      )}
      {showAddProduct && (
        <AddShopProductDialog isAr={isAr} brands={brands} categories={ALL_SUB_CATEGORIES}
          mainCategories={mainCategories} subCategories={ALL_SUB_CATEGORIES}
          onClose={() => setShowAddProduct(false)}
          onSaved={() => { setShowAddProduct(false); queryClient.invalidateQueries({ queryKey: ["shop-products"] }); }} />
      )}
    </div>
  );
}