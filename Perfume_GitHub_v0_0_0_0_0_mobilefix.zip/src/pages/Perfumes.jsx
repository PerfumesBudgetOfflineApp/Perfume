import { useState, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { Link, useNavigate } from "react-router-dom";
import { Droplets, Search, Heart, Store, Music, FlaskConical, BottleWine, ShoppingBag, Book, SprayCan, PaintbrushVertical, Axe, BookHeart, Blend, Wine, Utensils, Tag, NotebookPen, BookA, PenTool, Music2, BookOpen, Quote, Lightbulb, TestTubes, ListChecks, Wallet } from "lucide-react";
import AppLogo from "@/components/icons/AppLogo";
import { useTranslations } from "@/lib/useTranslations";
import { compareEnglish } from "@/lib/sortName";
import { useLang } from "@/lib/LanguageContext";
import { cn } from "@/lib/utils";
import Pagination from "@/components/Pagination";

function PerfumeBottleIcon({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 3h8v2H8z" />
      <path d="M10 5v3h4V5" />
      <path d="M9 8h6v10c0 1.1-.9 2-2 2h-2c-1.1 0-2-.9-2-2V8z" />
    </svg>
  );
}

// Borderless quick link: icon + label only, no box/frame/background.
// Color shifts on hover/press. `color` is the Tailwind text-color class set.
function GlossaryDots({ className }) {
  const xs = [3.5, 7.3, 11.1, 14.9, 18.7, 22.5];
  const ys = [5, 8.5, 12, 15.5, 19];
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      {ys.flatMap((y) => xs.map((x) => <circle key={`${x}-${y}`} cx={x} cy={y} r="0.9" />))}
    </svg>
  );
}

// قصص = لوتس ملوّن (٧ خطوط خلفية + هالة ذهبية + لوتس وردي بمركز ماسي) — inline، ألوان صريحة
function StoryLotus({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <clipPath id="storyLotusSq"><rect x="0" y="0" width="24" height="24" /></clipPath>
      <g clipPath="url(#storyLotusSq)">
        <rect x="0" y="0" width="3.4286" height="24" fill="#FFFFFF" />
        <rect x="3.4286" y="0" width="3.4286" height="24" fill="#FBBF24" />
        <rect x="6.8571" y="0" width="3.4286" height="24" fill="#2563EB" />
        <rect x="10.2857" y="0" width="3.4286" height="24" fill="#EC4899" />
        <rect x="13.7143" y="0" width="3.4286" height="24" fill="#7DD3FC" />
        <rect x="17.1429" y="0" width="3.4286" height="24" fill="#0891B2" />
        <rect x="20.5714" y="0" width="3.4286" height="24" fill="#9333EA" />
        <circle cx="12" cy="12.5" r="8.6" fill="#E6B422" opacity="0.3" />
        <g transform="translate(0,-0.5)">
          <ellipse cx="12" cy="19" rx="9" ry="2.4" fill="#22C55E" />
          <path d="M12 7 C10.5 12 10.5 15 12 17 C13.5 15 13.5 12 12 7 Z" fill="#F472B6" />
          <path d="M12 17 C8.5 14 5 13.5 4 14.5 C4.5 16.5 7.5 17.5 12 17 Z" fill="#EC4899" />
          <path d="M12 17 C15.5 14 19 13.5 20 14.5 C19.5 16.5 16.5 17.5 12 17 Z" fill="#EC4899" />
          <path d="M12 17 C9.5 15 6.5 16 6 18 C8 19 11 18 12 17 Z" fill="#F9A8D4" />
          <path d="M12 17 C14.5 15 17.5 16 18 18 C16 19 13 18 12 17 Z" fill="#F9A8D4" />
          <path d="M12 13.1 L14.2 15.5 L12 17.9 L9.8 15.5 Z" fill="none" stroke="#D4AF37" strokeWidth="0.45" />
          <path d="M12 13.8 L13.5 15.5 L12 17.2 L10.5 15.5 Z" fill="#FFFFFF" stroke="#EC4899" strokeWidth="0.45" />
        </g>
      </g>
    </svg>
  );
}

// الحكمة = حجر الفلاسفة الذهبي (ماسة ذهبية بأوجه) — inline، ألوان صريحة (لا تُستورد من lucide)
function GoldenStone({ className }) {
  return (
    <svg className={className} viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      {/* السطح العلوي (table) */}
      <polygon points="6,8 18,8 15,11 9,11" fill="#FCD884" stroke="#D4AF37" strokeWidth="0.4" />
      {/* أوجه التاج (crown) */}
      <polygon points="6,8 9,11 4,11" fill="#F6B23F" />
      <polygon points="18,8 20,11 15,11" fill="#F6B23F" />
      {/* القاعدة (pavilion) */}
      <polygon points="4,11 20,11 12,21" fill="#E89A24" />
      <polygon points="9,11 15,11 12,21" fill="#F6B23F" />
      <polygon points="4,11 9,11 12,21" fill="#D98B12" />
      <polygon points="15,11 20,11 12,21" fill="#D98B12" />
      {/* لمعة خيط ذهبي */}
      <polygon points="6,8 18,8 12,21" fill="none" stroke="#D4AF37" strokeWidth="0.4" opacity="0.5" />
      <path d="M9 11 L8 8.6" stroke="#FFF3D6" strokeWidth="0.5" opacity="0.6" />
    </svg>
  );
}

function QuickLink({ to, icon: Icon, label, color, iconClassName, labelClassName, labelStyle, reverse, flip, horizontal }) {
  return (
    <Link
      to={to}
      className={cn(
        "flex items-center justify-center gap-2 py-1 select-none transition-transform active:scale-95",
        horizontal ? "flex-row" : "flex-col",
        reverse && (horizontal ? "flex-row-reverse" : "flex-col-reverse"),
        color
      )}
    >
      <Icon className={cn("w-[22px] h-[22px] shrink-0", iconClassName, flip && "rotate-180")} />
      <span style={labelStyle} className={cn("text-[11px] font-body font-semibold text-center leading-tight", labelClassName, flip && "rotate-180")}>{label}</span>
    </Link>
  );
}
import { Input } from "@/components/ui/input";
import PerfumeCard from "@/components/perfume/PerfumeCard";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { getSecureStorage } from "@/lib/storageEncryption";


export default function Perfumes() {
  const [search, setSearch] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [linkSettings, setLinkSettings] = useState(() => {
    const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, quotes: true, wisdom: true, glossary: true };
    return getSecureStorage("perfumeLinkSettings", defaults);
  });
  const { names } = usePersonNames();
  const { t } = useTranslations();
  const { isAr } = useLang();
  const navigate = useNavigate();

  // debounce: لا نعيد الترتيب على كل ضغطة حرف — ننتظر توقف الكتابة 250ms
  useEffect(() => {
    const id = setTimeout(() => setDebouncedSearch(search), 250);
    return () => clearTimeout(id);
  }, [search]);

  useEffect(() => {
    const handler = () => {
      const defaults = { brands: true, mixer: true, culture: true, budget: true, stores: true, lists: true, blog: true, perfumers: true, notes: true, quotes: true, wisdom: true, glossary: true };
      setLinkSettings(getSecureStorage("perfumeLinkSettings", defaults));
    };
    window.addEventListener("perfumeLinkSettingsChanged", handler);
    return () => {
      window.removeEventListener("perfumeLinkSettingsChanged", handler);
    };
  }, []);

  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
    // الصفحة لا تعرض القائمة إلا عند البحث؛ لذا لا نحمّل الـ130 ألف عند الفتح.
    enabled: !!debouncedSearch.trim(),
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("-created_date"),
    staleTime: 1000 * 60 * 5,
  });



  const filtered = useMemo(() => {
    // الصفحة لا تعرض القائمة إلا عند البحث؛ فلا نفرز الكتالوج المخزّن (130 ألف)
    // عند مجرّد الدخول/الرجوع للصفحة — هذا كان سبب تعليق العودة لصفحة العطور.
    if (!debouncedSearch.trim()) return [];
    const q = debouncedSearch.toLowerCase();
    const visible = perfumes.filter((p) => !p.hidden);
    const filteredRaw = visible.filter(
      (p) =>
        p.name?.toLowerCase().includes(q) ||
        p.name_en?.toLowerCase().includes(q) ||
        p.name_ar?.includes(debouncedSearch) ||
        p.brand_name?.toLowerCase().includes(q) ||
        p.brand_name_ar?.includes(debouncedSearch)
    );

    // الفرز يعتمد الاسم الإنجليزي (name_en) عبر المكتبة المشتركة — للغتين،
    // بمراتب: إنجليزي → أرقام → لغات أخرى → رموز (مثل ":p" آخراً).
    return [...filteredRaw].sort((a, b) => compareEnglish(a, b, 1));
  }, [perfumes, debouncedSearch]);

  return (
    <div className="px-4 pt-12 pb-4 space-y-5">
      {/* Header - App branding only */}
      <div className={cn("flex items-center justify-between", isAr && "flex-row-reverse")}>
        <div className="flex items-center gap-2.5">
          <AppLogo className="w-7 h-7" style={{ color: "var(--brand)" }} />
        </div>
        <div className="flex items-center gap-2">
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder={isAr ? "ابحث" : "Search"}
          className="pl-9 h-10 font-body text-sm bg-white border border-transparent rounded-none"
        />
      </div>

      {/* Loading */}
      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {/* Empty collection */}
      {!isLoading && debouncedSearch.trim() && perfumes.length === 0 && (
        <div className="text-center py-16 space-y-4">
          <div className="w-20 h-20 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <Droplets className="w-10 h-10 text-primary/40" />
          </div>
          <div className="space-y-2">
            <h2 className="font-heading text-xl font-semibold">{t('perfumes.startExploring')}</h2>
            <p className="text-muted-foreground text-sm font-body max-w-xs mx-auto">
              {isAr ? 'استخدم القائمة (أعلى اليمين) لإضافة عطرك الأول' : 'Use the menu (top right) to add your first perfume.'}
            </p>
          </div>
          <Link to="/add" className="inline-flex items-center gap-2 bg-primary text-primary-foreground rounded-none px-5 py-2.5 text-sm font-body font-medium hover:bg-primary/90 transition-colors">
            {t('perfumes.addPerfume')}
          </Link>
        </div>
      )}

      {/* Search results */}
      {!isLoading && search.trim() && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground font-body">{filtered.length} {isAr ? 'نتيجة' : 'result' + (filtered.length !== 1 ? "s" : "")}</p>
          {filtered.length === 0 ? (
            <p className="text-center text-sm text-muted-foreground font-body py-8">{isAr ? 'لا توجد عطور' : 'No perfumes found'}</p>
          ) : (
            <Pagination
              items={filtered}
              itemsPerPage={50}
              renderItem={(items) => (
                <div className="grid grid-cols-2 gap-3">
                  {items.map((p) => <PerfumeCard key={p.id} perfume={p} />)}
                </div>
              )}
              emptyMessage="No perfumes found"
            />
          )}
        </div>
      )}

      {/* Sections (no search active) */}
      {!isLoading && !search.trim() && (
        <>

          {/* Favorites + Samples moved below the Glossary box */}

          {/* Traditional uniform 2-per-row grid (includes Perfumes + Stores; Culture stays as its own link below) */}
          {(() => {
            const G = "text-[color:var(--brand)] hover:opacity-70";
            const tradLinks = [
              { to: "/explore", icon: SprayCan, label: isAr ? 'عطور' : 'Perfumes', color: G },
              linkSettings.lists && { to: "/brands", icon: Tag, label: isAr ? 'ماركات' : 'Brands', color: G },
              { to: "/collection-view?tab=favorites", icon: Heart, label: isAr ? 'مفضلة' : 'Favorites', color: G },
              linkSettings.stores && { to: "/shopping", icon: Store, label: isAr ? 'متاجر' : 'Stores', color: G },
              linkSettings.blog && { to: "/blog", icon: NotebookPen, label: isAr ? 'مدونة' : t('navigation.blog'), color: G },
              linkSettings.glossary && { to: "/glossary", icon: BookA, label: isAr ? 'معجم' : 'Glossary', color: G },
              linkSettings.perfumers && { to: "/perfumers", icon: PenTool, label: isAr ? 'مصممون' : 'Designers', color: G },
              linkSettings.notes && { to: "/notes", icon: Music2, label: isAr ? 'نوتات عطرية' : t('navigation.notes'), color: G },
              linkSettings.glossary && { to: "/glossary?tab=story", icon: BookOpen, label: isAr ? 'قصص' : 'Story', color: G },
              linkSettings.quotes && { to: "/quotes", icon: Quote, label: isAr ? 'اقتباسات' : 'Quotes', color: G },
              linkSettings.wisdom && { to: "/incomplete-wisdom", icon: Lightbulb, label: isAr ? 'حكم' : 'Wisdom', color: G },
              { to: "/samples", icon: TestTubes, label: isAr ? 'عينات' : t('navigation.samples'), color: G },
              linkSettings.lists && { to: "/lists", icon: ListChecks, label: isAr ? 'قوائم' : t('navigation.lists'), color: G },
              linkSettings.mixer && { to: "/layering", icon: Blend, label: isAr ? 'مزج' : 'The Mixer', color: G },
              linkSettings.budget && { to: "/budget", icon: Wallet, label: isAr ? 'ميزانية' : 'Budget', color: G },
            ].filter(Boolean);
            return (
              <div className="grid grid-cols-2 gap-x-8 gap-y-6 pt-1">
                {tradLinks.map((lnk) => (
                  <QuickLink key={lnk.to} to={lnk.to} icon={lnk.icon} label={lnk.label} color={lnk.color} />
                ))}
              </div>
            );
          })()}

          {/* Lists / The Mixer / Budget moved into the quick-links grid above */}

          {linkSettings.culture && (
          <Link to="/perfume-culture" className="flex items-center justify-between px-4 py-2 hover:opacity-80 transition-opacity bg-transparent">
            <div className="flex items-center gap-3">
              <Axe className="w-5 h-5 text-blue-600 dark:text-blue-400 shrink-0" />
              <p className="text-sm font-body font-semibold text-blue-600 dark:text-blue-400">{isAr ? 'ثقافة، قواعد & آداب' : 'Culture, Rules & Courtesy'}</p>
            </div>
          </Link>
          )}

           </>
           )}


          </div>
          );
          }

function PersonSection({ title, person, personName, count, linkTo, children }) {
  const { isAr } = useLang();
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-none ${person === "person2" ? "bg-violet-500" : "bg-primary"}`} />
          <div>
            <h2 className="font-heading text-base font-semibold">{isAr ? `${title} ${personName}` : `${personName}'s ${title}`}</h2>
            <p className="text-xs text-muted-foreground font-body">{count} {isAr ? 'عنصر' : 'items'}</p>
          </div>
        </div>
        <Link to={linkTo} className="text-primary text-sm font-body hover:underline">
          {isAr ? 'عرض الكل' : 'See all'}
        </Link>
      </div>
      {children}
    </div>
  );
}

function Section({ title, linkTo, children }) {
  const { isAr } = useLang();
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h2 className="font-heading text-lg font-semibold">{title}</h2>
        <Link to={linkTo} className="text-primary text-sm font-body hover:underline">
          {isAr ? 'عرض الكل' : 'See all'}
        </Link>
      </div>
      {children}
    </div>
  );
}
