import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, ScrollText, BookOpen, MessageCircle, Sparkles, RotateCw, Trash2, SprayCan, Store, User, Blend } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";
import { toast } from "sonner";

/**
 * CastAway (المهملات) — الحذف المؤقّت القابل للاستعادة عبر عدّة أنواع.
 * يجمع المدخلات المخفيّة (hidden): مفردات/قصص المعجم + الاقتباسات.
 * لكل مدخل: أيقونة نوعه + اسمه + سطر صغير بالنوع، مع: استعادة · حذف نهائي.
 * قابل للتوسعة: أضِف استعلام كيان آخر وادمج عناصره المخفيّة في items.
 */
export default function CastAway() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const { isAr } = useLang();
  const [confirmKey, setConfirmKey] = useState(null);

  const { data: terms = [] } = useQuery({
    queryKey: ["glossary-terms"],
    queryFn: () => apphost.entities.GlossaryTerm.list("-created_date"),
  });
  const { data: quotes = [] } = useQuery({
    queryKey: ["quotes"],
    queryFn: () => apphost.entities.Quote.list("-created_date"),
  });
  const { data: wisdoms = [] } = useQuery({
    queryKey: ["wisdom"],
    queryFn: () => apphost.entities.Wisdom.list("-created_date"),
  });
  // الكيانات الكبيرة: نجلب المخفيّ فقط عبر filter (لا list كامل) تفادياً للبطء.
  const { data: hiddenPerfumes = [] } = useQuery({
    queryKey: ["castaway-perfumes"],
    queryFn: () => apphost.entities.Perfume.filter({ hidden: true }),
  });
  const { data: hiddenBrands = [] } = useQuery({
    queryKey: ["castaway-brands"],
    queryFn: () => apphost.entities.PerfumeBrand.filter({ hidden: true }),
  });
  const { data: hiddenPerfumers = [] } = useQuery({
    queryKey: ["castaway-perfumers"],
    queryFn: () => apphost.entities.Perfumer.filter({ hidden: true }),
  });
  const { data: hiddenNotes = [] } = useQuery({
    queryKey: ["castaway-notes"],
    queryFn: () => apphost.entities.PerfumeNote.filter({ hidden: true }),
  });
  const { data: hiddenShopStores = [] } = useQuery({
    queryKey: ["castaway-stores"],
    queryFn: () => apphost.entities.ShopBrand.filter({ hidden: true }),
  });

  const ENTITY_OF = {
    glossary: "GlossaryTerm", quote: "Quote", wisdom: "Wisdom",
    perfume: "Perfume", brand: "PerfumeBrand", perfumer: "Perfumer", note: "PerfumeNote",
    store: "ShopBrand",
  };

  const quoteSnippet = (q) => {
    const t = (isAr ? (q.text_ar || q.text_en) : (q.text_en || q.text_ar)) || q.text_enar || "";
    return String(t).replace(/\s+/g, " ").trim();
  };
  const wisdomSnippet = (w) => {
    const t = (isAr ? (w.wisdom_ar || w.title_ar || w.wisdom || w.title) : (w.wisdom || w.title || w.wisdom_ar || w.title_ar)) || "";
    return String(t).replace(/\s+/g, " ").trim();
  };

  // قائمة موحّدة من المهملات عبر الأنواع.
  const items = [
    ...terms.filter((t) => t.hidden).map((t) => ({
      key: `glossary:${t.id}`,
      entity: "glossary",
      id: t.id,
      Icon: t.entry_type === "story" ? BookOpen : ScrollText,
      name: (isAr ? (t.term_ar || t.term_en) : (t.term_en || t.term_ar)) || (isAr ? "بدون عنوان" : "Untitled"),
      sub: t.entry_type === "story" ? (isAr ? "قصة" : "Story") : (isAr ? "مفردة" : "Term"),
    })),
    ...quotes.filter((q) => q.hidden).map((q) => ({
      key: `quote:${q.id}`,
      entity: "quote",
      id: q.id,
      Icon: MessageCircle,
      name: quoteSnippet(q) || (isAr ? "اقتباس" : "Quote"),
      sub: isAr ? "اقتباس" : "Quote",
    })),
    ...wisdoms.filter((w) => w.hidden).map((w) => ({
      key: `wisdom:${w.id}`,
      entity: "wisdom",
      id: w.id,
      Icon: Sparkles,
      name: wisdomSnippet(w) || (isAr ? "حكمة" : "Wisdom"),
      sub: isAr ? "حكمة" : "Wisdom",
    })),
    ...hiddenPerfumes.map((p) => ({
      key: `perfume:${p.id}`, entity: "perfume", id: p.id, Icon: SprayCan,
      name: (isAr ? (p.name_ar || p.name_en) : (p.name_en || p.name_ar)) || p.name || (isAr ? "عطر" : "Perfume"),
      sub: isAr ? "عطر" : "Perfume",
    })),
    ...hiddenBrands.map((b) => ({
      key: `brand:${b.id}`, entity: "brand", id: b.id, Icon: Store,
      name: (isAr ? (b.name_ar || b.name) : (b.name || b.name_ar)) || (isAr ? "براند" : "Brand"),
      sub: isAr ? "براند" : "Brand",
    })),
    ...hiddenPerfumers.map((x) => ({
      key: `perfumer:${x.id}`, entity: "perfumer", id: x.id, Icon: User,
      name: (isAr ? (x.name_ar || x.name) : (x.name || x.name_ar)) || (isAr ? "عطّار" : "Perfumer"),
      sub: isAr ? "عطّار" : "Perfumer",
    })),
    ...hiddenNotes.map((n) => ({
      key: `note:${n.id}`, entity: "note", id: n.id, Icon: Blend,
      name: (isAr ? (n.name_ar || n.name_en || n.name) : (n.name_en || n.name || n.name_ar)) || (isAr ? "نوتة" : "Note"),
      sub: isAr ? "نوتة" : "Note",
    })),
    ...hiddenShopStores.map((s) => ({
      key: `store:${s.id}`, entity: "store", id: s.id, Icon: Store,
      name: (isAr ? (s.name_ar || s.name) : (s.name || s.name_ar)) || (isAr ? "متجر" : "Store"),
      sub: isAr ? "متجر" : "Store",
    })),
  ];

  const invalidateAll = () => {
    ["glossary-terms", "quotes", "wisdom",
     "castaway-perfumes", "castaway-brands", "castaway-perfumers", "castaway-notes", "castaway-stores",
     "perfumes", "brands", "perfumers", "notes", "shop-brands"].forEach((k) =>
      qc.invalidateQueries({ queryKey: [k] })
    );
  };

  const restoreMutation = useMutation({
    mutationFn: (item) => apphost.entities[ENTITY_OF[item.entity]].update(item.id, { hidden: false }),
    onSuccess: () => { invalidateAll(); toast.success(isAr ? "استُعيد" : "Restored"); },
  });

  const deleteMutation = useMutation({
    mutationFn: (item) => apphost.entities[ENTITY_OF[item.entity]].delete(item.id),
    onSuccess: () => { invalidateAll(); setConfirmKey(null); toast.success(isAr ? "حُذف نهائياً" : "Deleted permanently"); },
  });

  return (
    <div className="px-4 pt-12 pb-24 space-y-4 max-w-xl mx-auto">
      {/* Header */}
      <div className={`flex items-center gap-3 ${isAr ? "flex-row-reverse" : ""}`}>
        <button
          onClick={() => navigate(-1)}
          className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-secondary transition-colors"
          title={isAr ? "رجوع" : "Back"}
        >
          <ArrowLeft className={`w-5 h-5 ${isAr ? "rotate-180" : ""}`} />
        </button>
        <div className={isAr ? "text-right" : ""}>
          <h1 className="font-heading text-lg font-semibold">{isAr ? "المهملات" : "Cast Away"}</h1>
          <p className="text-[11px] text-muted-foreground font-body">
            {isAr ? "المحذوف مؤقتاً — استعادة أو حذف نهائي" : "Temporarily removed — restore or delete permanently"}
          </p>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground font-body text-sm">
          {isAr ? "المهملات فارغة" : "Cast Away is empty"}
        </div>
      ) : (
        <div className="space-y-2">
          {items.map((item) => {
            const Icon = item.Icon;
            return (
              <div key={item.key} className="flex items-center gap-3 bg-card rounded-none px-3 py-2.5">
                <Icon className="w-4 h-4 text-muted-foreground shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-body font-medium truncate" dir="auto">{item.name}</p>
                  {/* سطر صغير تحت كل مدخل — نوعه بلغة الواجهة */}
                  <p className="text-[10px] text-muted-foreground font-body">{item.sub}</p>
                </div>
                {confirmKey === item.key ? (
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => deleteMutation.mutate(item)}
                      className="text-[11px] font-body rounded-none text-destructive-foreground "
                    >
                      {isAr ? "تأكيد الحذف" : "Confirm"}
                    </button>
                    <button
                      onClick={() => setConfirmKey(null)}
                      className="text-[11px] font-body rounded-none "
                    >
                      {isAr ? "إلغاء" : "Cancel"}
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      onClick={() => restoreMutation.mutate(item)}
                      title={isAr ? "استعادة" : "Restore"}
                      aria-label={isAr ? "استعادة" : "Restore"}
                      className="w-8 h-8 rounded-none flex items-center justify-center text-emerald-600 hover:bg-emerald-600/10 transition-colors"
                    >
                      <RotateCw className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => setConfirmKey(item.key)}
                      title={isAr ? "حذف نهائي" : "Delete permanently"}
                      aria-label={isAr ? "حذف نهائي" : "Delete permanently"}
                      className="w-8 h-8 rounded-none flex items-center justify-center text-destructive hover:bg-destructive/10 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
