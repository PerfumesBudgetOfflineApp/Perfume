import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Download, Upload, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { initDB, processes, steps } from '@/lib/indexedDB';
import { downloadBlob } from '@/lib/exportHelper';
import { toast } from 'sonner';

export default function ProcessBackup() {
  const navigate = useNavigate();
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);
  const [stats, setStats] = useState({ processes: 0, steps: 0 });

  useEffect(() => {
    const load = async () => {
      try {
        await initDB();
        const allProcs = await processes.getAll();
        const allSteps = await steps.getAll();
        setStats({ processes: allProcs.length, steps: allSteps.length });
      } catch (error) {
        console.error('Failed to load:', error);
      }
    };
    load();
  }, []);

  const handleExport = async () => {
    setExporting(true);
    try {
      await initDB();
      const allProcs = await processes.getAll();
      const allSteps = await steps.getAll();
      
      const backup = {
        version: '1.0',
        exported_at: new Date().toISOString(),
        data: {
          processes: allProcs,
          steps: allSteps
        }
      };

      const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
      await downloadBlob(blob, `process-backup-${new Date().toISOString().split('T')[0]}.json`);
      toast.success('تم تصدير البيانات بنجاح');
    } catch (error) {
      toast.error('فشل التصدير');
    } finally {
      setExporting(false);
    }
  };

  const handleExportCSV = async () => {
    setExporting(true);
    try {
      await initDB();
      const allProcs = await processes.getAll();
      
      let csv = 'الاسم,الوصف,الحالة,التقدم\n';
      allProcs.forEach(p => {
        csv += `"${p.name}","${p.description || ''}","${p.status}","${p.progress || 0}%"\n`;
      });

      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
      await downloadBlob(blob, `processes-${new Date().toISOString().split('T')[0]}.csv`);
      toast.success('تم التصدير إلى CSV');
    } catch (error) {
      toast.error('فشل التصدير');
    } finally {
      setExporting(false);
    }
  };

  const handleImport = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setImporting(true);
    try {
      const text = await file.text();
      const backup = JSON.parse(text);
      
      if (!backup.data || !backup.data.processes) {
        throw new Error('صيغة الملف غير صحيحة');
      }

      await initDB();
      
      // Import processes
      for (const p of backup.data.processes) {
        delete p.id;
        await processes.add(p);
      }
      
      // Import steps
      if (backup.data.steps && backup.data.steps.length > 0) {
        for (const s of backup.data.steps) {
          delete s.id;
          await steps.add(s);
        }
      }

      setStats(prev => ({ ...prev, processes: prev.processes + backup.data.processes.length }));
      toast.success(`تم استيراد ${backup.data.processes.length} عملية`);
      
      // Reload page
      setTimeout(() => window.location.reload(), 1500);
    } catch (error) {
      toast.error('فشل الاستيراد - تأكد من صيغة الملف');
      console.error(error);
    } finally {
      setImporting(false);
      e.target.value = '';
    }
  };

  return (
    <div className="px-4 pt-12 pb-8 space-y-6 max-w-3xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate('/process')}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-2xl font-bold">النسخ الاحتياطية و الاستعادة</h1>
      </div>

      {/* Stats */}
      <div className="bg-card rounded-none border border-border p-5 space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-100/50 dark:bg-blue-900/30 rounded-none flex items-center justify-center">
            <span className="text-lg">📊</span>
          </div>
          <div>
            <p className="font-heading font-semibold">ملخص البيانات</p>
            <p className="text-xs text-muted-foreground">إجمالي السجلات المحفوظة</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="bg-secondary/50 rounded-none px-3 py-2">
            <p className="text-lg font-bold text-primary">{stats.processes}</p>
            <p className="text-[11px] text-muted-foreground">عملية</p>
          </div>
          <div className="bg-secondary/50 rounded-none px-3 py-2">
            <p className="text-lg font-bold text-primary">{stats.steps}</p>
            <p className="text-[11px] text-muted-foreground">خطوة</p>
          </div>
        </div>
      </div>

      {/* Export */}
      <div className="bg-card rounded-none border border-border p-5 space-y-4">
        <div className="flex items-center gap-3 mb-1">
          <Download className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">تصدير النسخة الاحتياطية</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          قم بتنزيل جميع بياناتك (العمليات و الخطوات) كملف JSON أو CSV
        </p>
        <div className="flex gap-2">
          <Button className="flex-1 h-11 rounded-none gap-2" onClick={handleExport} disabled={exporting}>
            <Download className="w-4 h-4" />
            {exporting ? 'جاري التصدير...' : 'تصدير JSON'}
          </Button>
          <Button variant="outline" className="flex-1 h-11 rounded-none gap-2" onClick={handleExportCSV} disabled={exporting}>
            <Download className="w-4 h-4" />
            {exporting ? 'جاري...' : 'تصدير CSV'}
          </Button>
        </div>
      </div>

      {/* Import */}
      <div className="bg-card rounded-none border border-border p-5 space-y-4">
        <div className="flex items-center gap-3 mb-1">
          <Upload className="w-4 h-4 text-primary" />
          <h2 className="font-heading font-semibold">استيراد من نسخة احتياطية</h2>
        </div>
        <p className="text-sm font-body text-muted-foreground">
          رفع ملف نسخة احتياطية تم تصديره مسبقاً
        </p>
        <div className="bg-amber-50 border border-amber-200 rounded-none px-4 py-3 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs font-body text-amber-700">
            سيتم إضافة البيانات فوق السجلات الموجودة. قد تظهر إدخالات مكررة.
          </p>
        </div>
        <label className="w-full block">
          <input 
            type="file" 
            accept=".json" 
            className="hidden" 
            onChange={handleImport} 
            disabled={importing}
          />
          <div className="w-full h-12 rounded-none font-body border-2 border-dashed border-border flex items-center justify-center gap-2 text-sm text-muted-foreground hover:border-primary hover:text-primary cursor-pointer transition-colors">
            <Upload className="w-4 h-4" />
            {importing ? 'جاري القراءة...' : 'اختر ملف JSON'}
          </div>
        </label>
      </div>
    </div>
  );
}