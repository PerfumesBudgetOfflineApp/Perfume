import { useState, useEffect } from 'react';
import { BarChart3, Download } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { initDB, processes } from '@/lib/indexedDB';
import ProcessCard from '@/components/process/ProcessCard';
import SettingsSheet from '@/components/layout/SettingsSheet';
import UserAvatarButton from '@/components/layout/UserAvatarButton';

export default function ProcessDashboard() {
  const navigate = useNavigate();
  const [allProcesses, setAllProcesses] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        await initDB();
        let data = await processes.getAll();
        
        // Initialize with sample data if empty
        if (data.length === 0) {
          const samples = [
            { name: 'تطوير التطبيق', description: 'بناء نسخة جديدة من التطبيق الرئيسي', status: 'active', progress: 45 },
            { name: 'مراجعة المشروع', description: 'فحص شامل للمتطلبات و التصاميم', status: 'active', progress: 80 },
            { name: 'اختبار البرنامج', description: 'اختبار جميع الميزات و الحالات الخاصة', status: 'paused', progress: 20 },
            { name: 'إطلاق النسخة', description: 'نشر البرنامج للمستخدمين', status: 'paused', progress: 0 },
          ];
          
          for (const sample of samples) {
            await processes.add(sample);
          }
          data = await processes.getAll();
        }
        
        setAllProcesses(data);
      } catch (error) {
        console.error('Failed to load processes:', error);
      } finally {
        setLoading(false);
      }
    };

    loadData();
  }, []);

  const filtered = search.trim()
    ? allProcesses.filter(p =>
        p.name?.toLowerCase().includes(search.toLowerCase()) ||
        p.description?.toLowerCase().includes(search.toLowerCase())
      )
    : allProcesses;

  const activeCount = allProcesses.filter(p => p.status === 'active').length;
  const completedCount = allProcesses.filter(p => p.status === 'completed').length;

  return (
    <div className="px-4 pt-12 pb-4 space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <BarChart3 className="w-6 h-6 text-amber-300" />
        </div>
        <div className="flex items-center gap-2">
          <Link to="/process-backup">
            <button className="w-9 h-9 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors">
              <Download className="w-4 h-4 text-foreground/60 hover:text-foreground transition-colors" />
            </button>
          </Link>
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="بحث عن عملية..."
          className="pl-9 rounded-none h-10 font-body text-sm"
        />
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
        <div className="flex flex-col items-center gap-2 bg-blue-50 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/50 rounded-none px-3 py-3">
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/60 rounded-none flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-blue-600" />
          </div>
          <p className="text-xs font-body font-semibold text-blue-700 dark:text-blue-400 text-center">{allProcesses.length} عملية</p>
        </div>
        <div className="flex flex-col items-center gap-2 bg-green-50 dark:bg-green-950/30 border border-green-100 dark:border-green-900/50 rounded-none px-3 py-3">
          <div className="w-10 h-10 bg-green-100 dark:bg-green-900/60 rounded-none flex items-center justify-center">
            Add</div>
          <p className="text-xs font-body font-semibold text-green-700 dark:text-green-400 text-center">{activeCount} نشطة</p>
        </div>
        <div className="flex flex-col items-center gap-2 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50 rounded-none px-3 py-3">
          <div className="w-10 h-10 bg-emerald-100 dark:bg-emerald-900/60 rounded-none flex items-center justify-center">
            Add</div>
          <p className="text-xs font-body font-semibold text-emerald-700 dark:text-emerald-400 text-center">{completedCount} مكتملة</p>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {/* Empty state */}
      {!loading && allProcesses.length === 0 && (
        <div className="text-center py-16 space-y-4">
          <div className="w-20 h-20 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <BarChart3 className="w-10 h-10 text-primary/40" />
          </div>
          <div className="space-y-2">
            <h2 className="font-heading text-xl font-semibold">ابدأ بعملية جديدة</h2>
            <p className="text-muted-foreground text-sm font-body max-w-xs mx-auto">
              أنشئ عملية جديدة لتتبع و إدارة عملك بكفاءة
            </p>
          </div>
        </div>
      )}

      {/* Results count */}
      {!loading && search.trim() && (
        <p className="text-xs text-muted-foreground font-body">{filtered.length} نتيجة</p>
      )}

      {/* Add Button */}
      {!loading && (
        <Link to="/add-process" className="sticky bottom-20 block">
          <Button className="w-full h-11 rounded-none gap-2 bg-amber-500 hover:bg-amber-600 text-black font-semibold">
            عملية جديدة
          </Button>
        </Link>
      )}

      {/* Processes Grid */}
      {!loading && filtered.length > 0 && (
        <div className="grid grid-cols-2 gap-3">
          {filtered.map(process => (
            <ProcessCard key={process.id} process={process} />
          ))}
        </div>
      )}
      </div>
      );
      }