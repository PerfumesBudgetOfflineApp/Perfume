import { useState, useMemo } from "react";
import BackButton from "@/components/shared/BackButton";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { format } from "date-fns";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { toast } from "sonner";
import { Layers, Star, Sparkles, X } from "lucide-react";
import SettingsSheet from "@/components/layout/SettingsSheet";
import UserAvatarButton from "@/components/layout/UserAvatarButton";
import { usePersonNames } from "@/lib/usePersonNames";
import { useLang } from "@/lib/LanguageContext";
import PerfumePicker from "@/components/wearlog/PerfumePicker";
import LayerCard from "@/components/layering/LayerCard";

export default function Layering() {
   const qc = useQueryClient();
   const { names } = usePersonNames();
   const { isAr } = useLang();
   const [dialogOpen, setDialogOpen] = useState(false);
  const [logDialogOpen, setLogDialogOpen] = useState(false);
  const [logTarget, setLogTarget] = useState(null);
  const [logDate, setLogDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [logPerson, setLogPerson] = useState("person1");
  const [logNote, setLogNote] = useState("");

  // Multi-perfume form state (up to 5)
  const [selectedPerfumes, setSelectedPerfumes] = useState([null, null]);
  const [comboName, setComboName] = useState("");
  const [comboNotes, setComboNotes] = useState("");
  const [comboRating, setComboRating] = useState(0);
  const [comboPerson, setComboPerson] = useState("person1");

  const { data: perfumes = [] } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("name"),
  });

  const { data: layers = [], isLoading } = useQuery({
    queryKey: ["layers"],
    queryFn: () => apphost.entities.PerfumeLayer.list("-created_date"),
  });

  const createLayer = useMutation({
    mutationFn: (data) => apphost.entities.PerfumeLayer.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["layers"] });
      toast.success((isAr ? "حُفظ المزج" : "Layer combo saved"));
      setDialogOpen(false);
      resetForm();
    },
  });

  const deleteLayer = useMutation({
    mutationFn: (id) => apphost.entities.PerfumeLayer.delete(id),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["layers"] }); toast.success((isAr ? "أُزيل" : "Removed")); },
  });

  const updateLayer = useMutation({
    mutationFn: ({ id, data }) => apphost.entities.PerfumeLayer.update(id, data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["layers"] }),
  });

  const createWearLog = useMutation({
    mutationFn: (data) => apphost.entities.WearLog.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wear-logs"] });
      toast.success((isAr ? "سُجّل لي و لنا" : "Logged to Me/We"));
      setLogDialogOpen(false);
      setLogNote("");
    },
  });

  const resetForm = () => {
    setSelectedPerfumes([null, null]);
    setComboName(""); setComboNotes("");
    setComboRating(0); setComboPerson("person1");
  };

  const validPerfumes = selectedPerfumes.filter(Boolean);

  const handleCreate = () => {
    if (validPerfumes.length < 2) { toast.error((isAr ? "اختر عطرين على الأقل" : "Pick at least 2 perfumes")); return; }
    const uniqueIds = new Set(validPerfumes.map((p) => p.id));
    if (uniqueIds.size !== validPerfumes.length) { toast.error((isAr ? "اختر عطوراً مختلفة" : "Pick different perfumes")); return; }

    const ids = validPerfumes.map((p) => p.id).join(",");
    const names_ = validPerfumes.map((p) => p.name).join(",");
    const brands = validPerfumes.map((p) => p.brand_name || "").join(",");

    createLayer.mutate({
      perfume_ids: ids,
      perfume_names: names_,
      perfume_brands: brands,
      // keep legacy fields for compat with LayerCard
      perfume1_id: validPerfumes[0].id,
      perfume1_name: validPerfumes[0].name,
      perfume1_brand: validPerfumes[0].brand_name,
      perfume2_id: validPerfumes[1]?.id || "",
      perfume2_name: validPerfumes[1]?.name || "",
      perfume2_brand: validPerfumes[1]?.brand_name || "",
      name: comboName, notes: comboNotes, rating: comboRating, person: comboPerson, wear_count: 0,
    });
  };

  const handleLogWear = (layer) => {
    setLogTarget(layer);
    setLogPerson("person1");
    setLogDate(format(new Date(), "yyyy-MM-dd"));
    setLogNote("");
    setLogDialogOpen(true);
  };

  const handleConfirmLog = () => {
    const allNames = logTarget.perfume_names
      ? logTarget.perfume_names.split(",").join(" + ")
      : `${logTarget.perfume1_name} + ${logTarget.perfume2_name}`;
    const comboLabel = logTarget.name || allNames;
    createWearLog.mutate({
      date: logDate,
      perfume_id: logTarget.perfume1_id,
      perfume_name: `[Layer] ${comboLabel}`,
      brand_name: logTarget.perfume1_brand,
      person: logPerson,
      note: logNote || `Layered: ${allNames}`,
    });
    updateLayer.mutate({
      id: logTarget.id,
      data: { wear_count: (logTarget.wear_count || 0) + 1, last_worn: logDate },
    });
  };

  const topRated = useMemo(() => [...layers].filter((l) => l.rating > 0).sort((a, b) => b.rating - a.rating).slice(0, 1), [layers]);
  const mostWorn = useMemo(() => [...layers].filter((l) => l.wear_count > 0).sort((a, b) => b.wear_count - a.wear_count).slice(0, 1), [layers]);

  // Helper: get display label for a layer
  const getLayerLabel = (layer) => {
    if (layer.name) return layer.name;
    if (layer.perfume_names) return layer.perfume_names.split(",").join(" + ");
    return `${layer.perfume1_name} + ${layer.perfume2_name}`;
  };

  const addSlot = () => {
    if (selectedPerfumes.length < 5) setSelectedPerfumes((prev) => [...prev, null]);
  };

  const removeSlot = (i) => {
    setSelectedPerfumes((prev) => prev.filter((_, idx) => idx !== i));
  };

  const setSlot = (i, perfume) => {
    setSelectedPerfumes((prev) => prev.map((p, idx) => (idx === i ? perfume : p)));
  };

  // IDs already selected (to exclude from pickers)
  const selectedIds = selectedPerfumes.filter(Boolean).map((p) => p.id);

  return (
    <div className="px-4 pt-12 pb-4 space-y-5">
      <BackButton fallback="/" />
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="space-y-0.5">
          <h1 className="font-heading text-2xl font-bold">{isAr ? 'الخلاط' : 'The Mixer'}</h1>
          <p className="text-xs text-muted-foreground font-body">{layers.length} {isAr ? 'تركيبات' : 'combinations'}</p>
        </div>
        <div className="flex items-center gap-2">
          <button className="rounded-none font-body h-9 px-3 text-xs font-medium bg-secondary text-muted-foreground hover:text-foreground hover:bg-accent transition-colors" onClick={() => { resetForm(); setDialogOpen(true); }}>
            {isAr ? "اضف مزيج" : "Add Combo"}
          </button>
          <SettingsSheet>
              <UserAvatarButton size={28} />
            </SettingsSheet>
        </div>
      </div>

      {/* Layering Combo Box with Highlights */}
      {(topRated.length > 0 || mostWorn.length > 0) && (
      <div className="group block relative overflow-hidden rounded-none">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-900 via-teal-800 to-emerald-950 dark:from-emerald-950 dark:via-teal-900 dark:to-black" />
        <div className="absolute inset-0 opacity-10" style={{
          backgroundImage: "radial-gradient(circle at 20% 50%, #fff 1px, transparent 1px), radial-gradient(circle at 80% 20%, #fff 1px, transparent 1px), radial-gradient(circle at 60% 80%, #fff 1px, transparent 1px)",
          backgroundSize: "60px 60px, 80px 80px, 50px 50px"
        }} />
        <div className="absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-amber-400/70 to-transparent" />
        <div className="absolute bottom-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-amber-400/70 to-transparent" />
        <div className="absolute -top-8 left-1/2 -translate-x-1/2 w-6 h-6 bg-gradient-to-br from-amber-400 to-amber-500 shadow-lg" />
        <div className="relative px-6 py-8 space-y-6">
          <div className="text-center">
            <h2 style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "2rem",
              fontWeight: 700,
              fontStyle: "italic",
              letterSpacing: "0.12em",
              lineHeight: 1,
              background: "linear-gradient(135deg, #f6d365 0%, #fda085 40%, #f6d365 100%)",
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
              backgroundClip: "text",
            }}>
              Layering
            </h2>
            <p style={{
              fontFamily: "'Playfair Display', serif",
              fontSize: "0.95rem",
              fontStyle: "italic",
              letterSpacing: "0.16em",
              color: "rgba(246, 211, 101, 0.6)",
              lineHeight: 1,
              marginTop: "0.5rem"
            }}>
              {isAr ? 'اخلط و استمتع' : 'Mix It'}
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            {topRated[0] && (
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-none p-3 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-amber-300 font-body font-medium flex items-center gap-1"><Star className="w-3 h-3" /> Top Rated</p>
                <p className="text-xs font-body font-semibold truncate text-white">{getLayerLabel(topRated[0])}</p>
                <p className="text-[10px] text-amber-200 font-body">{"■".repeat(topRated[0].rating)}{"□".repeat(5 - topRated[0].rating)}</p>
              </div>
            )}
            {mostWorn[0] && (
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-none p-3 space-y-1">
                <p className="text-[10px] uppercase tracking-wider text-amber-300 font-body font-medium flex items-center gap-1"><Sparkles className="w-3 h-3" /> Most Worn</p>
                <p className="text-xs font-body font-semibold truncate text-white">{getLayerLabel(mostWorn[0])}</p>
                <p className="text-[10px] text-amber-200 font-body">{mostWorn[0].wear_count}× worn</p>
              </div>
            )}
          </div>
        </div>
      </div>
      )}



      {isLoading && (
        <div className="flex items-center justify-center py-16">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      )}

      {!isLoading && layers.length === 0 && (
        <div className="text-center py-14 space-y-3">
          <div className="w-16 h-16 bg-secondary rounded-none flex items-center justify-center mx-auto">
            <Layers className="w-8 h-8 text-primary/40" />
          </div>
          <p className="font-heading text-lg font-semibold">{isAr ? "لا مزجات بعد" : "No combos yet"}</p>
          <p className="text-xs text-muted-foreground font-body max-w-xs mx-auto">Mix 2–5 perfumes and rate how they smell together.</p>
          <Button className="rounded-none font-body text-sm h-10" onClick={() => { resetForm(); setDialogOpen(true); }}>
            Create First Combo
          </Button>
        </div>
      )}

      {layers.length > 0 && (
        <div className="space-y-3">
          {layers.map((layer) => (
            <LayerCard
              key={layer.id}
              layer={layer}
              names={names}
              onDelete={() => deleteLayer.mutate(layer.id)}
              onLogWear={() => handleLogWear(layer)}
              onRateUpdate={(rating) => updateLayer.mutate({ id: layer.id, data: { rating } })}
            />
          ))}
        </div>
      )}

      {/* Create dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-sm w-[calc(100vw-2rem)] rounded-none !top-[2vh] !translate-y-0 max-h-[94vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-heading text-base flex items-center gap-2">
              <Layers className="w-4 h-4 text-primary" /> {isAr ? "اضف مزيج طبقات" : "Add Layer Combo"}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            {/* Perfume slots */}
            {selectedPerfumes.map((slot, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">
                    Perfume {i + 1} {i < 2 ? "(required)" : "(optional)"}
                  </p>
                  {i >= 2 && (
                    <button onClick={() => removeSlot(i)} className="text-muted-foreground hover:text-destructive">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                <PerfumePicker
                  perfumes={perfumes}
                  excludeIds={selectedIds.filter((id) => id !== slot?.id)}
                  selected={slot}
                  onSelect={(p) => setSlot(i, p)}
                />
              </div>
            ))}

            {/* Add more perfume slot */}
            {selectedPerfumes.length < 5 && (
              <button onClick={addSlot} className="w-full flex items-center justify-center gap-2 py-2.5 rounded-none border border-dashed border-border text-xs font-body text-muted-foreground hover:border-primary hover:text-primary transition-colors">
                Add another perfume
              </button>
            )}

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">Combo Name (optional)</p>
              <Input value={comboName} onChange={(e) => setComboName(e.target.value)} placeholder='e.g. "Evening Mystery"' className="rounded-none h-9 font-body text-sm" />
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "كيف رائحتهما معاً" : "How do they smell together?"}</p>
              <Textarea value={comboNotes} onChange={(e) => setComboNotes(e.target.value)} placeholder="صف المزيج... / Describe the blend..." className="rounded-none font-body text-xs min-h-[64px] resize-none" />
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "التقييم" : "Rating"}</p>
              <div className="flex gap-1.5">
                {[1, 2, 3, 4, 5].map((s) => (
                  <button key={s} onClick={() => setComboRating(comboRating === s ? 0 : s)}
                    className={`text-xl transition-all ${s <= comboRating ? "text-primary" : "text-border hover:text-primary/40"}`}>{s <= comboRating ? "■" : "□"}</button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "من جرّبه" : "Who tried it?"}</p>
              <div className="flex gap-2">
                {[
                  { val: "person1", label: names.person1 },
                  { val: "person2", label: names.person2 },
                  { val: "both", label: "Both" },
                ].map(({ val, label }) => (
                  <button key={val} onClick={() => setComboPerson(val)}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${comboPerson === val ? val === "person2" ? "bg-violet-500 text-white shadow" : "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <Button className="w-full h-10 rounded-none font-body" onClick={handleCreate} disabled={validPerfumes.length < 2 || createLayer.isPending}>
              {createLayer.isPending ? "Saving..." : `Save Combo (${validPerfumes.length} perfumes)`}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Log wear dialog */}
      <Dialog open={logDialogOpen} onOpenChange={setLogDialogOpen}>
        <DialogContent className="max-w-xs rounded-none">
          <DialogHeader>
            <DialogTitle className="font-heading text-base">سجّل هذا المزج Log This Combo</DialogTitle>
          </DialogHeader>
          {logTarget && (
            <div className="space-y-4">
              <div className="bg-secondary/50 rounded-none p-3 text-center">
                <p className="text-xs font-body font-semibold">{getLayerLabel(logTarget)}</p>
                {logTarget.perfume_names && (
                  <p className="text-[10px] text-muted-foreground font-body mt-0.5">
                    {logTarget.perfume_names.split(",").length} perfumes
                  </p>
                )}
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "التاريخ" : "Date"}</p>
                {/* لا يمكن تسجيل ارتداء في المستقبل */}
                <Input type="date" max={format(new Date(), "yyyy-MM-dd")} value={logDate} onChange={(e) => setLogDate(e.target.value)} className="rounded-none h-9 font-body text-sm" />
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">{isAr ? "من ارتداه" : "Who wore it?"}</p>
                <div className="flex gap-2">
                  <button onClick={() => setLogPerson("person1")}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person1" ? "bg-primary text-primary-foreground shadow" : "bg-secondary text-muted-foreground"}`}>
                    {names.person1}
                  </button>
                  <button onClick={() => setLogPerson("person2")}
                    className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${logPerson === "person2" ? "bg-violet-500 text-white shadow" : "bg-secondary text-muted-foreground"}`}>
                    {names.person2}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground font-body">Note (optional)</p>
                <Textarea value={logNote} onChange={(e) => setLogNote(e.target.value)} placeholder="كيف كانت الرائحة اليوم؟ How did it smell today?" className="rounded-none font-body text-xs min-h-[48px] resize-none" />
              </div>
              <Button className="w-full h-10 rounded-none font-body" onClick={handleConfirmLog} disabled={createWearLog.isPending}>
                {createWearLog.isPending ? "Logging..." : "Log to Me/We"}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}