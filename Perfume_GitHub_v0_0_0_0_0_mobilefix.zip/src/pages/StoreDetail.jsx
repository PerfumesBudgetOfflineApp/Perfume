import { useState, useMemo } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { ArrowLeft, Globe, Download, Search, ExternalLink } from "lucide-react";
import { Input } from "@/components/ui/input";
import SettingsSheet from "@/components/layout/SettingsSheet";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { toast } from "sonner";
import Pagination from "@/components/Pagination";
import { openExternalUrl, downloadBlob } from "@/lib/exportHelper";

export default function StoreDetail() {
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { currency } = useCurrency();
  const [searchParams] = useSearchParams();
  const storeId = searchParams.get("id");
  const [search, setSearch] = useState("");

  const { data: store } = useQuery({
    queryKey: ["store", storeId],
    queryFn: () => storeId ? apphost.entities.ShopBrand.get(storeId) : null,
    enabled: !!storeId,
  });

  const { data: purchases = [] } = useQuery({
    queryKey: ["store-purchases", storeId],
    queryFn: async () => {
      if (!storeId) return [];
      return apphost.entities.PurchaseRecord.filter({ store_id: storeId });
    },
    enabled: !!storeId,
  });

  const { data: expenses = [] } = useQuery({
    queryKey: ["store-expenses", storeId],
    queryFn: async () => {
      if (!storeId) return [];
      return apphost.entities.BudgetExpense.filter({ store_id: storeId });
    },
    enabled: !!storeId,
  });

  // البراندات المرتبطة بهذا المتجر (عدّة براندات لمتجر واحد).
  const linkedBrandIds = (store?.linked_brand_ids || "").split(",").map((s) => s.trim()).filter(Boolean);
  const { data: allBrandsForLinks = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
    enabled: linkedBrandIds.length > 0,
    staleTime: 1000 * 60 * 5,
  });
  const linkedBrands = allBrandsForLinks.filter((b) => linkedBrandIds.includes(String(b.id)));

  const filtered = useMemo(() => {
    const allItems = [
      ...purchases.map((p) => ({
        ...p,
        type: "purchase",
        amount: p.cost,
        date: p.purchase_date,
      })),
      ...expenses.map((e) => ({
        ...e,
        type: "expense",
      })),
    ];

    return allItems
      .filter((item) =>
        search === ""
          ? true
          : item.perfume_name?.toLowerCase().includes(search.toLowerCase()) ||
            item.description?.toLowerCase().includes(search.toLowerCase())
      )
      .sort((a, b) => new Date(b.date) - new Date(a.date));
  }, [purchases, expenses, search]);

  const stats = useMemo(() => {
    const total = filtered.reduce((sum, item) => sum + (item.amount || 0), 0);
    const byPerson = {};
    filtered.forEach((item) => {
      const person = item.person || "unknown";
      byPerson[person] = (byPerson[person] || 0) + (item.amount || 0);
    });
    return { total, byPerson };
  }, [filtered]);

  const handleExport = async () => {
    const rows = [
      [
        "Date",
        "Type",
        "Item",
        "Person",
        "Amount",
        "Details",
      ],
      ...filtered.map((item) => [
        item.date,
        item.type === "purchase" ? "Purchase" : "Expense",
        item.perfume_name || item.category || item.description || "-",
        (names[item.person] || item.person).toUpperCase(),
        item.amount.toFixed(2),
        item.type === "purchase"
          ? `${item.ml}ml - ${item.type === "sample" ? "Sample" : "Bottle"}`
          : item.description || "-",
      ]),
    ];

    const csv = rows
      .map((row) => row.map((cell) => `"${String(cell || "").replace(/"/g, '""')}"`).join(","))
      .join("\n");

    const blob = new Blob([csv], { type: "text/csv" });
    await downloadBlob(blob, `${store?.name || "store"}-invoices.csv`);
    toast.success((isAr ? "تم التصدير" : "Exported"));
  };

  if (!store)
    return (
      <div className="p-4 text-center">
        <p className="text-muted-foreground">{isAr ? "المتجر غير موجود" : "Store not found"}</p>
      </div>
    );

  return (
    <div className={`px-4 pt-12 pb-4 space-y-4 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <Link to="/budget" className="p-2 hover:bg-secondary rounded-none">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex items-center gap-2">
          {store.logo_url && (
            <img
              src={store.logo_url}
              alt={store.name}
              className="w-8 h-8 rounded-none"
            />
          )}
          <h1 className="font-heading text-xl font-bold">{store.name}</h1>
        </div>
        <div className="flex gap-2">
          <button
            onClick={handleExport}
            className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center hover:bg-accent transition-colors"
            title="Export invoices"
          >
            <Download className="w-4 h-4" />
          </button>
          <SettingsSheet>
            <button className="w-9 h-9 rounded-none bg-secondary flex items-center justify-center">
              ⚙️
            </button>
          </SettingsSheet>
        </div>
      </div>

      {/* Store Info */}
      {(store.description || store.website) && (
        <div className="bg-secondary/50 rounded-none p-3 space-y-2">
          {store.description && (
            <p className="text-xs font-body text-foreground">{store.description}</p>
          )}
          {store.website && (
            <button type="button" onClick={(e) => { e.preventDefault(); openExternalUrl(store.website); }}className="flex items-center gap-2 text-xs text-primary hover:underline font-body"
            >
              <Globe className="w-3.5 h-3.5" /> Visit Website
              <ExternalLink className="w-3 h-3" />
            </button>
          )}
        </div>
      )}

      {/* البراندات المرتبطة بالمتجر (عدّة براندات لمتجر واحد) */}
      {linkedBrands.length > 0 && (
        <div className="space-y-1.5">
          <p className="text-[10px] text-muted-foreground font-body uppercase tracking-wider">{isAr ? "براندات المتجر" : "Store Brands"}</p>
          <div className="flex flex-wrap gap-1.5">
            {linkedBrands.map((b) => (
              <Link key={b.id} to={`/brand?id=${b.id}`} className="inline-flex items-center gap-1.5 rounded-none text-xs font-body transition-colors ">
                {b.logo_url && <img src={b.logo_url} alt={b.name} className="w-4 h-4 rounded object-cover" />}
                {isAr ? (b.name_ar || b.name) : b.name}
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* Stats */}
      <div className="grid grid-cols-2 gap-2">
        <div className="bg-gradient-to-br from-emerald-50 to-emerald-100/50 dark:from-emerald-900/20 dark:to-emerald-800/10 rounded-none p-3 border border-emerald-200/50 dark:border-emerald-800/30">
          <p className="text-[10px] text-emerald-700 dark:text-emerald-300 font-body uppercase">
            Total Spent
          </p>
          <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {stats.total.toFixed(0)} {currency}
          </p>
        </div>
        <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 dark:from-blue-900/20 dark:to-blue-800/10 rounded-none p-3 border border-blue-200/50 dark:border-blue-800/30">
          <p className="text-[10px] text-blue-700 dark:text-blue-300 font-body uppercase">
            Items
          </p>
          <p className="text-lg font-bold text-blue-600 dark:text-blue-400 mt-1">
            {filtered.length}
          </p>
        </div>
      </div>

      {/* Person Breakdown */}
      <div className="bg-secondary/30 rounded-none p-3 space-y-2">
        <p className="text-xs font-body font-semibold text-muted-foreground uppercase">
          By Person
        </p>
        {Object.entries(stats.byPerson).map(([person, amount]) => (
          <div key={person} className="flex justify-between text-sm">
            <span className="font-body">
              {names[person] || person.toUpperCase()}
            </span>
            <span className="font-semibold">
              {amount.toFixed(0)} {currency}
            </span>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative">
        <Search className="absolute left-3 top-2.5 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder={isAr ? "ابحث في المشتريات" : "Search purchases..."}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-9 rounded-none h-10 font-body"
        />
      </div>

      {/* Items */}
      <Pagination
        items={filtered}
        itemsPerPage={50}
        renderItem={(items) => (
          <div className="space-y-2 pb-20">
            {items.map((item, idx) => (
              <div
                key={`${item.type}-${item.id || idx}`}
                className="bg-card rounded-none p-3 border border-border/50"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-body font-semibold truncate">
                      {item.perfume_name || item.category || "General"}
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {names[item.person] || item.person} •{" "}
                      {item.date}
                    </p>
                    {item.type === "purchase" && (
                      <p className="text-[10px] text-muted-foreground">
                        {item.ml}ml •{" "}
                        {item.type === "sample" ? "Sample" : "Bottle"}
                      </p>
                    )}
                    {item.description && item.type === "expense" && (
                      <p className="text-[10px] text-muted-foreground mt-1">
                        {item.description}
                      </p>
                    )}
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-sm font-bold text-primary">
                      {item.amount.toFixed(0)} {currency}
                    </p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      {item.type === "purchase" ? "Purchase" : "Expense"}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
        emptyMessage={search ? "No matches" : "No purchases or expenses"}
      />
    </div>
  );
}