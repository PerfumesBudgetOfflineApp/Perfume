import React, { useState } from 'react';
import { apphost } from '@/api/apphostClient';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Search, User, AArrowUp, AArrowDown } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import Pagination from "@/components/Pagination";
import { getAppName } from "@/lib/useAppName";
import { openHtmlReport } from "@/lib/exportHelper";

export default function Perfumers() {
  const navigate = useNavigate();
  const [view, setView] = useState("manage");
  const [search, setSearch] = useState("");
  const [genderFilter, setGenderFilter] = useState("all");
  const [yearSort, setYearSort] = useState("none");
  const currentYear = new Date().getFullYear();

  const { data: perfumers = [], isLoading } = useQuery({
    queryKey: ["perfumers"],
    queryFn: async () => {
      try {
        return await apphost.entities.Perfumer.list("name");
      } catch (error) {
        console.error("Error fetching perfumers:", error);
        return [];
      }
    },
  });

  const handleExportPerfumers = async (format) => {
    const sortedPerfumers = [...perfumers].sort((a, b) => {
      const yearA = a.birth_year || 9999;
      const yearB = b.birth_year || 9999;
      return yearA - yearB;
    });
    
    if (format === "pdf") {
            const perfumerRows = sortedPerfumers.map((p) => `
        <div class="perfumer-card">
          <div class="perfumer-header">
            <div class="perfumer-name">${p.name || ''}</div>
            <div class="perfumer-name-ar">${p.name_ar || ''}</div>
          </div>
          <div class="perfumer-info">
            <div class="info-row">
              <span class="label">الجنسية Nationality:</span>
              <span class="value">${p.nationality || '—'}</span>
            </div>
            <div class="info-row">
              <span class="label">الميلاد Birth Year:</span>
              <span class="value">${p.birth_year ? `${p.birth_year}${p.death_year ? ` – ${p.death_year}` : ''}` : '—'}</span>
            </div>
            <div class="info-row">
              <span class="label">الجنس Gender:</span>
              <span class="value">${p.gender || '—'}</span>
            </div>
            ${p.famous_works ? `<div class="info-row">
              <span class="label">الأعمال الشهيرة Famous Works:</span>
              <span class="value">${p.famous_works}</span>
            </div>` : ''}
            ${p.brand_names ? `<div class="info-row">
              <span class="label">العلامات التجارية Brands:</span>
              <span class="value">${p.brand_names}</span>
            </div>` : ''}
            ${p.bio ? `<div class="info-row bio">
              <span class="label">النبذة Bio:</span>
              <span class="value">${p.bio}</span>
            </div>` : ''}
          </div>
        </div>
      `).join('');
      
      await openHtmlReport(`<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8"/>
  <link rel="preconnect" href="https://fonts.googleapis.com"/>
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800&display=swap" rel="stylesheet"/>
  <title>الأنف العطرية Perfumers</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { 
      font-family: 'Cairo', 'Segoe UI', Arial, sans-serif; 
      direction: rtl; 
      unicode-bidi: embed;
      padding: 32px; 
      color: #1a1a1a; 
      background: #fff; 
      font-size: 13px; 
      line-height: 1.8;
    }
    h1 { 
      font-size: 18px; 
      font-weight: 700; 
      text-align: center; 
      margin-bottom: 6px; 
      letter-spacing: -0.3px;
      color: #0f5f3f;
    }
    .subtitle { 
      text-align: center; 
      color: #666; 
      margin-bottom: 24px; 
      font-size: 10px;
    }
    .perfumer-card {
      background: transparent;
      border: 1px solid #ddd;
      border-radius: 8px;
      padding: 12px;
      margin-bottom: 12px;
      page-break-inside: avoid;
    }
    .perfumer-header {
      margin-bottom: 10px;
    }
    .perfumer-name {
      font-size: 13px;
      font-weight: 600;
      color: #0f5f3f;
      margin-bottom: 2px;
      letter-spacing: -0.2px;
    }
    .perfumer-name-ar {
      font-size: 11px;
      color: #555;
      font-weight: 500;
    }
    .perfumer-info {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .info-row {
      display: grid;
      grid-template-columns: 140px 1fr;
      gap: 10px;
      align-items: start;
      font-size: 10px;
    }
    .info-row.bio {
      grid-template-columns: 1fr;
      gap: 4px;
    }
    .info-row.bio .label {
      display: block;
      margin-bottom: 2px;
    }
    .label {
      font-weight: 600;
      color: #333;
      white-space: nowrap;
    }
    .value {
      color: #555;
      line-height: 1.5;
    }
    @media print {
      body { padding: 20px; }
      @page { 
        margin: 1.2cm;
        size: A4;
      }
      .perfumer-card {
        page-break-inside: avoid;
        margin-bottom: 16px;
      }
    }
  </style>
</head>
<body>
<h1>الأنف العطرية Perfumers</h1>
<div class="subtitle">${getAppName().name_en} > الأنف العطرية Perfumers</div>
${perfumerRows}
<script>
  /* auto-print disabled — user prints via overlay Print button */
<\/script>
</body></html>`, 'process-app_export');
    }
  };

  const filtered = perfumers
    .filter((p) => {
      if (p.hidden) return false;
      const matchSearch = !search || p.name?.toLowerCase().includes(search.toLowerCase()) || p.nationality?.toLowerCase().includes(search.toLowerCase()) || p.name_ar?.includes(search);
      const matchGender = genderFilter === "all" || p.gender === genderFilter;
      return matchSearch && matchGender;
    })
    .sort((a, b) => {
      if (yearSort === "asc") return (a.birth_year || 9999) - (b.birth_year || 9999);
      if (yearSort === "desc") return (b.birth_year || 0) - (a.birth_year || 0);
      // افتراضي: A → Z
      return (String(a.name || "")).localeCompare(b.name || "", "en", { sensitivity: "base" });
    });

  // أعداد الربط (مرحلة 3): عطّار «مرتبط» = له معرّفات عطور مخزّنة (perfume_ids) أو
  // أسماء عطور قديمة (perfume_names). تُحسب من العطّارين غير المخفيين.
  const visiblePerfumers = perfumers.filter((p) => !p.hidden);
  const linkedCount = visiblePerfumers.filter(
    (p) => (p.perfume_ids && String(p.perfume_ids).trim()) || (p.perfume_names && String(p.perfume_names).trim())
  ).length;
  const unlinkedCount = visiblePerfumers.length - linkedCount;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div
        className="px-4 pt-12 pb-0 sticky top-0 bg-background/95 backdrop-blur-sm z-10 border-b border-border/40"
        style={{ paddingTop: "max(3rem, env(safe-area-inset-top))" }}
      >
        <div className="flex items-center justify-between gap-1.5 mb-4 flex-wrap">
          <h1 className="font-heading text-sm font-bold shrink-0">Perfumers</h1>
          <div className="flex gap-1.5 items-center flex-wrap">
            <button type="button" onClick={() => navigate("/create-sample")}
              className="px-2.5 py-1.5 rounded-none border border-[color:var(--brand)] text-[color:var(--brand)] font-body text-[11px] font-medium hover:opacity-70 active:opacity-90 transition-opacity whitespace-nowrap">
              Create Perfume
            </button>
            <button type="button" onClick={() => navigate("/perfumers-index")}
              className="px-2.5 py-1.5 rounded-none border border-[color:var(--brand)] text-[color:var(--brand)] font-body text-[11px] font-medium hover:opacity-70 active:opacity-90 transition-opacity whitespace-nowrap">
              index
            </button>
            <button type="button" onClick={() => handleExportPerfumers("pdf")}
              className="px-2.5 py-1.5 rounded-none border border-[color:var(--brand)] text-[color:var(--brand)] font-body text-[11px] font-medium hover:opacity-70 active:opacity-90 transition-opacity whitespace-nowrap">
              PDF
            </button>
          </div>
        </div>
      </div>
      
      <div className="px-5 pb-4 space-y-5">
      {/* Manage content shown directly (tabs removed; index is a standalone page) */}
      <div className="space-y-5 mt-2">

      <div className="space-y-2">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث" className="pl-9 h-11 rounded-none font-body bg-secondary/50 border-0" />
        </div>
        <div className="flex gap-2">
          {["all", "Male", "Female"].map((g) => (
            <button key={g} onClick={() => setGenderFilter(g)}
              className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${genderFilter === g ? "bg-green-800 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {g === "all" ? "All" : g === "Male" ? "Male" : "Female"}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          {[
            { value: "none", label: "Year" },
            { value: "asc", label: "↑ Oldest" },
            { value: "desc", label: "↓ Youngest" },
          ].map(({ value, label }) => (
            <button key={value} onClick={() => setYearSort(value)}
              className={`flex-1 py-1.5 rounded-none text-xs font-body font-medium transition-all ${yearSort === value ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-green-200 border-t-green-800 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <div className="w-16 h-16 bg-green-50 dark:bg-green-900/20 rounded-none flex items-center justify-center mx-auto">
            <User className="w-8 h-8 text-green-700" />
          </div>
          <p className="text-muted-foreground font-body text-sm">لا معطّرين No perfumers found</p>
        </div>
      ) : (
        <Pagination
           items={filtered}
           itemsPerPage={50}
           renderItem={(items) => (
            <div className="space-y-2">
              {items.map((perfumer) => {
                const brandList = perfumer.brand_names ? perfumer.brand_names.split(",").map(b => b.trim()).filter(Boolean) : [];
                return (
                  <Link key={perfumer.id} to={`/perfumer?id=${perfumer.id}`}>
                    <div className="bg-card p-4 border-t border-b border-border flex items-start gap-3 relative">
                      {perfumer.gender && (
                        <span className={`absolute top-3 right-3 text-[9px] rounded-none font-body font-bold ${perfumer.gender === "Female" ? " text-pink-600" : " text-blue-900"}`}>
                          {perfumer.gender === "Female" ? "♀" : "♂"}
                        </span>
                      )}
                      <div className="w-11 h-11 rounded-none flex items-center justify-center flex-shrink-0 overflow-hidden bg-white dark:bg-white/95" style={{ border: "1.5px solid #d4af37" }}>
                        {perfumer.photo_url ? (
                          <img src={perfumer.photo_url} alt={perfumer.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-white" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-body font-semibold text-sm">{perfumer.name}</p>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>
          )}
          emptyMessage="No perfumers found"
        />
      )}

        {/* Action Buttons */}
         {view === "manage" && (
           <div className="flex gap-2 pt-4 pb-4 border-t border-border/50">
             <Button className="flex-1 rounded-none font-body bg-green-700 hover:bg-green-800" onClick={() => navigate("/add-perfumer")}>
               إضافة Add
             </Button>
           </div>
         )}

        {/* Create Sample Section */}
         <div className="pt-8 border-t border-border/50 space-y-4">
           <div>
             <h2 className="font-heading text-lg font-semibold">إنشاء عيّنة Create Sample</h2>
             <p className="text-xs text-muted-foreground font-body">اجعل نسختك الخاصة</p>
           </div>
           <div className="bg-gradient-to-br from-amber-50 dark:from-amber-950/30 to-orange-50 dark:to-orange-950/30 border border-amber-200 dark:border-amber-800 rounded-none p-6 space-y-4">
             <div className="grid grid-cols-2 gap-3">
               <Input placeholder="نوتة القاعدة Base Note" className="rounded-none font-body" />
               <Input placeholder="نوتة القلب Heart Note" className="rounded-none font-body" />
               <Input placeholder="نوتة المقدمة Top Note" className="rounded-none font-body" />
               <Input placeholder="لون التمييز Accent" className="rounded-none font-body" />
             </div>
             <Textarea placeholder="أضف إبداعك هنا Add your creativity here..." className="rounded-none font-body min-h-[80px]" />
           </div>
         </div>
        </div>

      {/* Count Footer — counts on one line, small font, no dots */}
      <div className="text-center text-[10px] text-muted-foreground font-body pt-6 space-x-3">
        <span>{perfumers.length} noses</span>
        <span className="text-emerald-700">{linkedCount} linked</span>
        <span>{unlinkedCount} unlinked</span>
      </div>

      {/* Add Perfumer moved to a standalone page (/add-perfumer) — modal removed */}
      </div>
    </div>
  );
}

export function PerfumersIndexContent({ perfumers, isLoading, search, setSearch, genderFilter, setGenderFilter, yearSort, setYearSort }) {
  const currentYear = new Date().getFullYear();
  const [alphaDir, setAlphaDir] = useState("asc");           // 'asc' | 'desc'
  const [scriptBucket, setScriptBucket] = useState("all");   // 'all' | 'latin' | 'numbers' | 'other' | 'symbols'

  // Classify a name's first character into a script bucket. Used both for
  // filtering (when user picks a single bucket) and for the section header
  // shown above each block of names.
  const bucketOf = (name) => {
    const c = String(name || "")[0] || "";
    if (!c) return "symbols";
    if (/[A-Za-z]/.test(c)) return "latin";
    if (/[0-9]/.test(c)) return "numbers";
    if (/\p{L}/u.test(c)) return "other";            // any letter outside ASCII (Arabic, CJK, Cyrillic…)
    return "symbols";                                // /, :, #, …
  };

  const filtered = perfumers
    .filter((p) => {
      if (p.hidden) return false;
      const matchSearch = !search || p.name?.toLowerCase().includes(search.toLowerCase()) || p.nationality?.toLowerCase().includes(search.toLowerCase()) || p.name_ar?.includes(search);
      const matchGender = genderFilter === "all" || p.gender === genderFilter;
      const matchBucket = scriptBucket === "all" || bucketOf(p.name) === scriptBucket;
      return matchSearch && matchGender && matchBucket;
    })
    .sort((a, b) => {
      if (yearSort === "asc") return (a.birth_year || 9999) - (b.birth_year || 9999);
      if (yearSort === "desc") return (b.birth_year || 0) - (a.birth_year || 0);
      // Alphabetical — direction controlled by alphaDir
      const cmp = String(a.name || "").localeCompare(b.name || "", "en", { sensitivity: "base" });
      return alphaDir === "desc" ? -cmp : cmp;
    });

  return (
    <div className="space-y-3">
      {/* Filters */}
      <div className="space-y-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="بحث" className="pl-9 h-11 rounded-none font-body bg-secondary/50 border-0" />
        </div>
        <div className="flex gap-2">
          {["all", "Male", "Female"].map((g) => (
            <button key={g} onClick={() => setGenderFilter(g)}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${genderFilter === g ? "bg-green-800 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {g === "all" ? "All" : g === "Male" ? "Male" : "Female"}
            </button>
          ))}
        </div>
        {/* Alpha direction + Year (matches sort-icon convention from /glossary) */}
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => { setAlphaDir("asc"); setYearSort("none"); }}
            className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all inline-flex items-center justify-center gap-1 ${alphaDir === "asc" && yearSort === "none" ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            aria-label="Sort A-Z"
          >
            A <AArrowUp className="w-3.5 h-3.5" />
          </button>
          <button
            type="button"
            onClick={() => { setAlphaDir("desc"); setYearSort("none"); }}
            className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all inline-flex items-center justify-center gap-1 ${alphaDir === "desc" && yearSort === "none" ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            aria-label="Sort Z-A"
          >
            A <AArrowDown className="w-3.5 h-3.5" />
          </button>
          {[
            { value: "asc", label: "↑ Oldest" },
            { value: "desc", label: "↓ Youngest" },
          ].map(({ value, label }) => (
            <button key={value} onClick={() => setYearSort(value)}
              className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${yearSort === value ? "bg-green-300 text-green-900 shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}>
              {label}
            </button>
          ))}
        </div>
        {/* Script bucket filter — A-Z / Numbers / Other / Symbols / All */}
        <div className="flex gap-2 flex-wrap">
          {[
            { value: "all",     label: "All" },
            { value: "latin",   label: "A–Z" },
            { value: "numbers", label: "0–9" },
            { value: "other",   label: "أبجد" },
            { value: "symbols", label: ": / #" },
          ].map(({ value, label }) => (
            <button
              key={value}
              type="button"
              onClick={() => setScriptBucket(value)}
              className={`flex-1 min-w-[3rem] py-1.5 rounded-none text-[11px] font-body font-medium transition-all ${scriptBucket === value ? "bg-amber-600 text-white shadow" : "bg-secondary text-muted-foreground hover:text-foreground"}`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {isLoading ? (
        <div className="flex justify-center py-16">
          <div className="w-6 h-6 border-2 border-green-200 border-t-green-800 rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 space-y-3">
          <p className="text-muted-foreground font-body text-sm">لا نتائج No results</p>
        </div>
      ) : (
        <PerfumerChipsList items={filtered} />
      )}
     </div>
   );
}

/**
 * Compact chip list mirroring the Brands index layout. Each perfumer is a
 * small pill — no image, no gender icon — and the *name itself* is tinted to
 * indicate gender:
 *   - Male   → blue   #1d4ed8
 *   - Female → pink   #db2777
 *   - Other  → black  (foreground)
 * No pagination: the whole list renders continuously, virtualized via CSS
 * content-visibility (off-screen ~80-chip chunks skip layout/paint).
 */
function PerfumerChipsList({ items }) {
  const colorFor = (g) => g === "Male" ? "#1d4ed8" : g === "Female" ? "#db2777" : undefined;
  const CHUNK = 80, groups = [];
  for (let i = 0; i < items.length; i += CHUNK) groups.push(items.slice(i, i + CHUNK));
  return (
    <div className="space-y-1.5">
      {groups.map((group, gi) => (
        <div
          key={gi}
          className="flex flex-wrap gap-1.5"
          style={{ contentVisibility: "auto", containIntrinsicSize: `${Math.ceil(group.length / 3) * 30}px` }}
        >
          {group.map((p) => (
            <Link
              key={p.id}
              to={`/perfumer?id=${p.id}`}
              className="text-xs rounded-none font-body transition-colors"
              style={{ color: colorFor(p.gender) }}
            >
              {p.name}
            </Link>
          ))}
        </div>
      ))}
    </div>
  );
 }