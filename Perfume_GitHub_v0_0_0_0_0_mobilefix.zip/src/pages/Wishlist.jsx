import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLang } from "@/lib/LanguageContext";
import { usePersonNames } from "@/lib/usePersonNames";
import { useCurrency } from "@/lib/useCurrency";
import { toast } from "sonner";

export default function Wishlist() {
  const { isAr } = useLang();
  const { names } = usePersonNames();
  const { formatPrice, currency } = useCurrency();
  const navigate = useNavigate();
  const qc = useQueryClient();

  const [selectedPerson, setSelectedPerson] = useState("all");

  // Fetch wishlist
  const { data: wishes = [], isLoading } = useQuery({
    queryKey: ["wishlist"],
    queryFn: () => apphost.entities.Wishlist.list("-added_date"),
  });

  // Delete mutation
  const deleteMutation = useMutation({
    mutationFn: (id) => apphost.entities.Wishlist.delete(id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["wishlist"] });
      toast.success(isAr ? "تمت الإزالة" : "Removed");
    },
  });

  // Filter by person
  const filtered = selectedPerson === "all"
    ? wishes
    : wishes.filter(w => w.person === selectedPerson);

  // Calculate totals
  const totalCost = filtered.reduce((sum, w) => sum + (w.estimated_price || 0), 0);
  const byPriority = {
    high: filtered.filter(w => w.priority === "high").length,
    medium: filtered.filter(w => w.priority === "medium").length,
    low: filtered.filter(w => w.priority === "low").length,
  };

  // Calculate per-person costs
  const person1Cost = wishes.filter(w => w.person === "person1").reduce((sum, w) => sum + (w.estimated_price || 0), 0);
  const person2Cost = wishes.filter(w => w.person === "person2").reduce((sum, w) => sum + (w.estimated_price || 0), 0);
  const allPersonsCost = person1Cost + person2Cost;

  return (
    <div className={`px-5 pt-12 pb-12 space-y-4 ${isAr ? "rtl" : ""}`}>
      {/* Header */}
      <div className="flex items-center gap-3 mb-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/budget")}
          className="rounded-none"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="font-heading text-2xl font-bold">💕 {isAr ? "أرغب بالشراء" : "I Want To Buy"}</h1>
          <p className="text-xs text-muted-foreground">{filtered.length} {isAr ? "عنصر" : "items"}</p>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
        <div className="bg-blue-100/50 dark:bg-blue-900/20 rounded-none p-3">
          <p className="text-[10px] text-blue-700 dark:text-blue-300 font-body uppercase">{isAr ? "التكلفة المختارة" : "Selected Cost"}</p>
          <p className="text-sm font-bold text-blue-600 dark:text-blue-400">
            {formatPrice(totalCost)}
          </p>
        </div>
        <div className="bg-green-100/50 dark:bg-green-900/20 rounded-none p-3">
          <p className="text-[10px] text-green-700 dark:text-green-300 font-body uppercase">{names.person1}</p>
          <p className="text-sm font-bold text-green-600 dark:text-green-400">
            {formatPrice(person1Cost)}
          </p>
        </div>
        <div className="bg-violet-100/50 dark:bg-violet-900/20 rounded-none p-3">
          <p className="text-[10px] text-violet-700 dark:text-violet-300 font-body uppercase">{names.person2}</p>
          <p className="text-sm font-bold text-violet-600 dark:text-violet-400">
            {formatPrice(person2Cost)}
          </p>
        </div>
      </div>

      {/* Overall Total */}
      <div className="bg-amber-100/50 dark:bg-amber-900/20 rounded-none p-4 border-2 border-amber-200 dark:border-amber-800">
        <p className="text-[10px] text-amber-700 dark:text-amber-300 font-body uppercase tracking-wide mb-1">{isAr ? "الإجمالي الكلي" : "Grand Total"}</p>
        <p className="text-2xl font-bold text-amber-600 dark:text-amber-400">
          {formatPrice(allPersonsCost)}
        </p>
      </div>

      {/* Person Filter */}
      <div className="flex gap-2">
        {[
          { val: "all", label: isAr ? "الكل" : "All" },
          { val: "person1", label: names.person1 },
          { val: "person2", label: names.person2 },
        ].map(({ val, label }) => (
          <button
            key={val}
            onClick={() => setSelectedPerson(val)}
            className={`flex-1 rounded-none text-xs font-body font-medium transition-all ${
 selectedPerson === val
 ? " text-primary-foreground "
 : " text-muted-foreground"
 }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* Wishlist Items */}
      {isLoading ? (
        <div className="flex justify-center py-12">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-5xl mb-3 opacity-30">💕</div>
          <p className="text-muted-foreground text-sm font-body">{isAr ? "لا توجد رغبات شراء حالياً" : "No wish to buy items yet"}</p>
        </div>
      ) : (
        <div className="space-y-3">
          {/* Group by priority */}
          {["high", "medium", "low"].map((priority) => {
            const itemsInPriority = filtered.filter(w => w.priority === priority);
            if (itemsInPriority.length === 0) return null;

            const priorityLabels = {
              high: { emoji: "🔴", text: "High Priority" },
              medium: { emoji: "🟡", text: "Medium Priority" },
              low: { emoji: "🔵", text: "Low Priority" },
            };

            return (
              <div key={priority}>
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{priorityLabels[priority].emoji}</span>
                  <h3 className="text-xs font-heading font-semibold text-muted-foreground uppercase">
                    {priorityLabels[priority].text}
                  </h3>
                  <span className="text-[10px] text-muted-foreground">({itemsInPriority.length})</span>
                </div>

                <div className="space-y-2">
                  {itemsInPriority.map((wish) => (
                    <div
                      key={wish.id}
                      className="bg-card rounded-none border border-border/50 p-3 flex gap-3 hover:shadow-md transition-shadow"
                    >
                      {/* Image */}
                      {wish.image_url && (
                        <button
                          onClick={() => navigate(`/perfume?id=${wish.perfume_id}`)}
                          className="flex-shrink-0 w-16 h-16 rounded-none overflow-hidden bg-secondary/40 hover:opacity-80 transition-opacity"
                        >
                          <img
                            src={wish.image_url}
                            alt={wish.perfume_name}
                            className="w-full h-full object-cover"
                          />
                        </button>
                      )}

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <button
                          onClick={() => navigate(`/perfume?id=${wish.perfume_id}`)}
                          className="text-sm font-heading font-bold hover:text-primary transition-colors text-left"
                        >
                          {wish.perfume_name}
                        </button>
                        <p className="text-xs text-muted-foreground font-body">{wish.brand_name}</p>

                        {wish.notes && (
                          <p className="text-[10px] text-foreground/70 mt-1 line-clamp-2">{wish.notes}</p>
                        )}

                        {wish.estimated_price && (
                          <p className="text-xs font-body font-semibold text-primary mt-1">
                            {formatPrice(wish.estimated_price)}
                          </p>
                        )}

                        <div className="flex items-center gap-1 mt-1.5">
                          <span
                            className={`text-[9px] rounded-none font-body font-medium ${
 wish.person === "person2"
 ? " text-violet-600"
 : " text-primary"
 }`}
                          >
                            {wish.person === "person2" ? names.person2 : names.person1}
                          </span>
                          {wish.added_date && (
                            <span className="text-[9px] text-muted-foreground font-body">
                              {wish.added_date}
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-1 justify-between">
                        <button
                          onClick={() => {
                            if (confirm(isAr ? "إزالة من الأمنيات؟" : "Remove from wishlist?")) {
                              deleteMutation.mutate(wish.id);
                            }
                          }}
                          className="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-none transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>

                        <Button
                          size="sm"
                          variant="outline"
                          className="h-7 text-[10px] font-body rounded-none"
                          onClick={() => navigate(`/perfume?id=${wish.perfume_id}`)}
                        >
                          View
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Statistics */}
      {filtered.length > 0 && (
        <div className="bg-secondary/30 rounded-none p-4 space-y-2 mt-6">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4" />
            <h3 className="text-sm font-heading font-semibold">{isAr ? "الإحصائيات" : "Statistics"}</h3>
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs font-body">
            <div className="bg-card rounded-none p-2">
              <p className="text-muted-foreground mb-0.5 uppercase tracking-wider text-[9px] font-semibold">{isAr ? "عالٍ" : "High"}</p>
              <p className="font-bold text-lg">{byPriority.high}</p>
            </div>
            <div className="bg-card rounded-none p-2">
              <p className="text-muted-foreground mb-0.5 uppercase tracking-wider text-[9px] font-semibold">{isAr ? "متوسط" : "Medium"}</p>
              <p className="font-bold text-lg">{byPriority.medium}</p>
            </div>
            <div className="bg-card rounded-none p-2">
              <p className="text-muted-foreground mb-0.5 uppercase tracking-wider text-[9px] font-semibold">Low</p>
              <p className="font-bold text-lg">{byPriority.low}</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-border/50">
            <p className="text-xs text-muted-foreground">{isAr ? "المجموع" : "Total Items"}: <span className="font-bold text-foreground">{filtered.length}</span></p>
            <p className="text-xs text-muted-foreground">{isAr ? "إجمالي التكلفة المتوقعة" : "Total Est. Cost"}: <span className="font-bold text-primary">{formatPrice(totalCost)}</span></p>
          </div>
        </div>
      )}
    </div>
  );
}