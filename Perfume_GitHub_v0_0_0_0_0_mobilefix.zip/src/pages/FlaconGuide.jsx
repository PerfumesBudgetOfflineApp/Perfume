import { ArrowLeft } from "lucide-react";
import { useNavigate, Link } from "react-router-dom";
import AccordFlaconCard from "@/components/perfume/AccordFlaconCard";
import ACCORDS from "@/data/builtin_database/accords_builtin.json";
import { useLang } from "@/lib/LanguageContext";

/**
 * FlaconGuide — صفحة شرح «قنينة العطر»: ماذا يمثّل كل عنصر في الرسم.
 * نص على خلفية بيضاء، بلا إطارات/صناديق، عناوين ذهبية، عربي ثم إنجليزي.
 */

// عيّنات: id:weight للأكوردات (موجودة في accords_builtin)
const SAMPLE = { id: "guide-main", accords: "a4:100;a8:55;a7:35", gender: "Men", type: "Eau de Parfum", release_year: 2100, brand_name: "Brand" };
const SAMPLES = [
  { id: "g-men",   accords: "a8:100;a4:50", gender: "Men",    type: "Eau de Parfum",   release_year: 2100, brand_name: "Men", labelAr: "رجالي", labelEn: "Men", col: "#22c55e" },
  { id: "g-women", accords: "a7:100",       gender: "Women",  type: "Eau de Toilette", release_year: 2100, brand_name: "Women", labelAr: "نسائي", labelEn: "Women", col: "#f472b6" },
  { id: "g-uni",   accords: "a4:80;a7:60;a8:40", gender: "Unisex", type: "Parfum",     release_year: 2100, brand_name: "Unisex", labelAr: "للجنسين", labelEn: "Unisex", col: "#fcd34d" },
];

export default function FlaconGuide() {
  const navigate = useNavigate();
  const { isAr } = useLang();

  const legend = [
    { ar: "الغطاء و العنق", en: "Cap & neck", da: "علوي القنينة ذهبيّ دائماً.", de: "Always a unified gold top." },
    { ar: "جسم القنينة", en: "Bottle body", da: "أبيض، يحمل السائل و التسميات.", de: "White, holds the liquid and labels." },
    { ar: "الموجة الكبرى = الأكورد المسيطر", en: "Large band = dominant accord", da: "أكبر طبقة لون، و لونها هو لون أقوى أكورد في العطر.", de: "The largest color layer; its color is the strongest accord." },
    { ar: "طبقات القاع = بقية الأكوردات", en: "Base layers = other accords", da: "طبقات رفيعة أسفل القنينة، عرض كلٍّ منها بحسب وزنه.", de: "Thin layers at the base, each sized by its weight." },
    { ar: "الشريط الرفيع = الفئة", en: "Thin strip = gender", da: "فوق الموجة الكبرى مباشرة (انظر الألوان أدناه).", de: "Right above the large band (see colors below)." },
    { ar: "أعلى اليسار = النوع", en: "Top-left = type", da: "EDP EDT Parfum … بلون الفئة.", de: "EDP / EDT / Parfum … in the gender color." },
    { ar: "أعلى اليمين = سنة الإصدار", en: "Top-right = release year", da: "بلون الفئة أيضاً.", de: "Also in the gender color." },
    { ar: "الوسط = اسم الأكورد المسيطر", en: "Center = dominant accord name", da: "الإنجليزي يساراً و العربي يميناً.", de: "English on the left, Arabic on the right." },
    { ar: "الأسفل = البراند", en: "Bottom = brand", da: "اسم العلامة في وسط الأسفل.", de: "The brand name, bottom-center." },
  ];

  // شرح صفحة العطر — أقسامها بالترتيب
  const perfumePage = [
    { ar: "الاسم", en: "Name", da: "الاسم الإنجليزي بلون ذهبيّ و العربي بلون ورديّ، و اسم البراند فوقهما صغيراً ذهبيّاً.", de: "English name in gold, Arabic in rose, with the small gold brand above." },
    { ar: "الخصائص في «عن العطر»", en: "Traits inside About", da: "التصنيف العطري و التركيز و سنة الإصدار، تظهر بعد وصف العطر بإطارات ذهبية.", de: "Scent class, concentration and year appear after the description as gold chips." },
    { ar: "بطاقة عطر", en: "Perfume Card", da: "رأي الجمهور: الثبات و الفوحان و القيمة، و شريط الفئة، و الفصول بجانب اليوم، و مناسبات العطر.", de: "Crowd view: longevity, sillage, value, a gender bar, seasons beside time, and occasions." },
    { ar: "العائلة العطرية", en: "Odor Family", da: "أشرطة الأكوردات، طول كلٍّ بحسب قوّته في العطر.", de: "Accord bars, each sized by its strength." },
    { ar: "هرم النوتات", en: "Notes Pyramid", da: "صور النوتات بإطار ذهبي و اسمها بلغتين، و مثلّث في الزاوية يبدّل العرض إلى نص.", de: "Note images with gold frames and bilingual names; a corner triangle switches to text." },
    { ar: "العطّارون و العطور المشابهة", en: "Perfumers & Similar", da: "صانعو العطر، و عطور تشبهه، مجموعة في المقدمة.", de: "The perfume's makers and look-alikes, grouped in the intro." },
    { ar: "تخصيص المستخدم", en: "User Customization", da: "لكل شخص خلفية لون خاصة: الانطباع و التفاعل و التقييم العام و التفصيلي و المناسبات و المراجعة.", de: "Each person has a tinted area: impression, reaction, overall and detailed ratings, occasions, review." },
    { ar: "العمليات", en: "Operations", da: "شراء عينة أو علبة (مل و تكلفة و متجر)، و تسجيل ملاحظة، و تسجيل ارتداء.", de: "Buy a sample or bottle (ml, cost, store), add a note, log a wear." },
    { ar: "التصدير", en: "Export", da: "صندوق ذهبي واحد: تصدير مراجعة و مطوّر و بطاقة و كاست أواي، مع نوتبوك و حفظ و نسخ.", de: "One gold box: Review, Advanced, Card and Cast Away exports, plus Notebook, Bookmark and Copy." },
    { ar: "تعديل العطر", en: "Edit Perfume", da: "في أسفل الصفحة، منفصلاً في الفوتر.", de: "At the very bottom, separated in the footer." },
  ];

  // بطاقة العطر أينما ظهرت (صفحة العطور · صفحة البراند · أعلى صفحة العطر)
  const cards = [
    { ar: "بطاقة العطر — القنينة", en: "Perfume Card — the flacon",
      da: "تظهر في صفحة العطور و صفحة البراند و أعلى صفحة العطر و في بطاقتها الإضافية: قنينة ملوّنة تختصر العطر برسمها (الأكورد المسيطر و الفئة و النوع و السنة).",
      de: "Appears in the perfumes page, the brand page, atop the perfume page and in its extra card: a colored flacon summing up the perfume in one drawing." },
    { ar: "النوتة المسيطرة و الشارات", en: "Dominant note & badges",
      da: "تحت البطاقة الإضافية سطرٌ بمؤشّر مربّع للأكورد المسيطر، و شارات مربّعة: منقطع (بنّي)، ضمن مجموعة (ذهبي)، نوتة مقيّدة (أحمر).",
      de: "Under the extra card: a square marker for the dominant accord, plus square badges — discontinued (brown), in a collection (gold), restricted note (red)." },
  ];

  // المميزات المتعلقة بالعطور
  const features = [
    { ar: "التثبيت", en: "Pinning",
      da: "ثبّتي عطراً أو برانداً ليظهر مختصراً في أعلى صفحة الاستكشاف للوصول السريع.",
      de: "Pin a perfume or brand so it shows, shrunk, at the top of the Explore page for quick access." },
    { ar: "المجموعات", en: "Collections",
      da: "اجمعي عطورك في مجموعات؛ العطر ضمن مجموعة يحمل شارة ذهبية على بطاقته.",
      de: "Group your perfumes into collections; a perfume in a collection carries a gold badge on its card." },
    { ar: "النوتبوك", en: "Notebook",
      da: "دوّني ملاحظة حرّة مرتبطة بالعطر من زرّ النوتبوك في صندوق التصدير.",
      de: "Jot a free note tied to the perfume via the Notebook button in the export box." },
    { ar: "الكاست أواي", en: "Cast Away",
      da: "صدّري بطاقة «كاست أواي» للعطر لمشاركتها خارج التطبيق.",
      de: "Export a Cast-Away card of the perfume to share it outside the app." },
    { ar: "الحفظ و النسخ", en: "Bookmark & Copy",
      da: "احفظي العطر في مرجعياتك، أو انسخي بياناته نصّاً من صندوق التصدير.",
      de: "Bookmark the perfume, or copy its data as text from the export box." },
  ];

  // مفتاح كل التناغمات بألوانها (منسوخ من دليل التناغمات، مرتّب أبجدياً بالإنجليزي)
  const allAccords = Object.values(ACCORDS)
    .filter((a) => a && (a.en || a.ar))
    .sort((a, b) => (a.en || "").localeCompare(b.en || ""));

  return (
    <div className="px-5 pt-12 pb-10 space-y-7">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="w-8 h-8 rounded-none flex items-center justify-center hover:bg-muted/40 transition-colors -ml-1">
          <ArrowLeft className="w-5 h-5" />
        </button>
        <div>
          <h1 className="font-heading text-2xl font-bold text-[var(--brand)]">شرح المميزات</h1>
          <p className="text-xs text-muted-foreground font-body mt-0.5" dir="ltr">Features Definition</p>
        </div>
      </div>

      {/* عيّنة كبيرة */}
      <div className="flex justify-center">
        <div className="w-44 h-44">
          <AccordFlaconCard perfume={SAMPLE} className="w-full h-full" />
        </div>
      </div>
      <p className="text-center text-xs text-muted-foreground font-body leading-relaxed" dir="rtl">
        كل قنينة في الكاتلوج تَحمل معلومات العطر برسمها
      </p>
      <p className="text-center text-xs text-muted-foreground font-body leading-relaxed" dir="ltr">
        Every bottle in the catalog carries the perfume's data in its drawing
      </p>

      {/* المفتاح */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">المفتاح</span>
          <span dir="ltr" className="block">The Key</span>
        </h2>
        <div className="space-y-3">
          {legend.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ألوان الفئة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">ألوان الفئة</span>
          <span dir="ltr" className="block">Gender Colors</span>
        </h2>
        <div className="flex flex-wrap gap-x-6 gap-y-2">
          {[
            { c: "#22c55e", ar: "رجالي", en: "Men" },
            { c: "#f472b6", ar: "نسائي", en: "Women" },
            { c: "#fcd34d", ar: "للجنسين", en: "Unisex" },
          ].map((g, i) => (
            <div key={i} className="flex items-center gap-2">
              <span className="inline-block w-4 h-4 rounded-none" style={{ background: g.c }} />
              <span className="text-sm font-body" dir="auto">{isAr ? g.ar : g.en}</span>
            </div>
          ))}
        </div>
      </section>

      {/* أمثلة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">أمثلة</span>
          <span dir="ltr" className="block">Examples</span>
        </h2>
        <div className="grid grid-cols-3 gap-3">
          {SAMPLES.map((s) => (
            <div key={s.id} className="flex flex-col items-center">
              <div className="w-full aspect-square">
                <AccordFlaconCard perfume={s} className="w-full h-full" />
              </div>
              <span className="text-[11px] font-body mt-1" style={{ color: s.col }} dir="auto">{isAr ? s.labelAr : s.labelEn}</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-muted-foreground font-body leading-relaxed" dir="rtl">
          عطر بأتناغم منفرد تملأ موجته القنينة، و عطر بعدّة تناغمات عطرية تتوزّع طبقاته بحسب أوزانها
        </p>
        <p className="text-xs text-muted-foreground font-body leading-relaxed" dir="ltr">
          A single-accord perfume fills the bottle; a multi-accord one splits into weighted layers
        </p>
      </section>

      {/* شرح صفحة العطر */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">شرح صفحة العطر</span>
          <span dir="ltr" className="block">The Perfume Page</span>
        </h2>
        <div className="space-y-3">
          {perfumePage.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* بطاقات العطر و مميزاتها */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">بطاقات العطر و مميزاتها</span>
          <span dir="ltr" className="block">Perfume Cards & Features</span>
        </h2>
        <div className="space-y-3">
          {cards.map((it, i) => (
            <div key={i} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
          {features.map((it, i) => (
            <div key={`f${i}`} className="leading-relaxed">
              <p className="text-sm font-body font-semibold text-foreground" dir="rtl">{it.ar}</p>
              <p className="text-sm font-body font-semibold text-foreground/80" dir="ltr">{it.en}</p>
              <p className="text-xs text-muted-foreground font-body" dir="rtl">{it.da}</p>
              <p className="text-xs text-muted-foreground font-body" dir="ltr">{it.de}</p>
            </div>
          ))}
        </div>
      </section>

      {/* مفتاح كل التناغمات بألوانها — منسوخ من دليل التناغمات، ثنائي اللغة بلا نقطة */}
      <section className="space-y-3">
        <h2 className="font-heading font-bold text-lg text-[var(--brand)] leading-tight">
          <span dir="rtl" className="block">مفتاح كل التناغمات بألوانها</span>
          <span dir="ltr" className="block">All Accord Colors</span>
        </h2>
        <p className="text-xs text-muted-foreground font-body" dir="rtl">الألوان نفسها المستخدمة على كل قنينة في الكاتلوج، لكل تناغمٍ لونه المميّز</p>
        <p className="text-xs text-muted-foreground font-body" dir="ltr">The exact colors used on every flacon in the catalog</p>
        <div className="grid grid-cols-2 gap-x-4 gap-y-1.5">
          {allAccords.map((a, i) => (
            <div key={i} className="flex items-center gap-2 min-w-0">
              <span className="w-3.5 h-3.5 rounded-none shrink-0 ring-1 ring-black/10" style={{ background: a.bar }} />
              <span className="text-xs font-body text-foreground/85 truncate" dir="auto">{a.en} {a.ar}</span>
            </div>
          ))}
        </div>
      </section>

      {/* ترابط: صفحة التناغمات */}
      <Link
        to="/accords-guide"
        className="flex items-center justify-between py-3 px-1 border-t border-border/40 hover:bg-secondary/30 transition-colors"
        dir={isAr ? "rtl" : "ltr"}
      >
        <span className="text-sm font-body font-semibold text-[var(--brand)]">
          {isAr ? "ما هو التناغم العطري" : "What Is An Accord"}
        </span>
        <span className="text-xs text-muted-foreground font-body">{isAr ? "دليل تناغم" : "Accords Guide"}</span>
      </Link>
    </div>
  );
}
