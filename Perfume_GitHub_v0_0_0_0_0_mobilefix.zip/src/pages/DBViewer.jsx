import { useState, useMemo } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  ArrowLeft, Search, Database, ChevronDown, ChevronRight,
  Download, RefreshCw,
} from "lucide-react";
import { apphost } from "@/api/apphostClient";
import { useLang } from "@/lib/LanguageContext";
import { downloadBlob } from "@/lib/exportHelper";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function DBViewer() {
  const { lang } = useLang();
  const isAr = lang === "ar";
  const [search, setSearch] = useState("");
  const [expandedBrands, setExpandedBrands] = useState(new Set(["Chanel", "Dior"]));
  const [view, setView] = useState("perfumes"); // perfumes | notes | perfumers

  // ─── Fetch all data ─────────────────────────────────────────
  const { data: brands = [], isLoading: brandsLoading } = useQuery({
    queryKey: ["dbviewer-brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: perfumes = [], isLoading: perfumesLoading } = useQuery({
    queryKey: ["dbviewer-perfumes"],
    queryFn: () => apphost.entities.Perfume.list("name_en"),
  });

  const { data: notes = [], isLoading: notesLoading } = useQuery({
    queryKey: ["dbviewer-notes"],
    queryFn: () => apphost.entities.PerfumeNote.list("name"),
  });

  const { data: perfumers = [] } = useQuery({
    queryKey: ["dbviewer-perfumers"],
    queryFn: () => apphost.entities.Perfumer.list("name"),
  });

  // ─── Group perfumes by brand ─────────────────────────────────
  const perfumesByBrand = useMemo(() => {
    const grouped = {};
    for (const p of perfumes) {
      const brand = p.brand_name || "Unknown";
      if (!grouped[brand]) grouped[brand] = [];
      grouped[brand].push(p);
    }
    return Object.entries(grouped)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .filter(([brand]) => {
        if (!search) return true;
        const q = search.toLowerCase();
        return brand.toLowerCase().includes(q) ||
          grouped[brand].some(p => (p.name_en || "").toLowerCase().includes(q));
      });
  }, [perfumes, search]);

  // ─── Group notes by category ────────────────────────────────
  const notesByCategory = useMemo(() => {
    const grouped = {};
    for (const n of notes) {
      const cat = n.category || "Other";
      if (!grouped[cat]) grouped[cat] = [];
      grouped[cat].push(n);
    }
    return Object.entries(grouped)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .filter(([cat]) => {
        if (!search) return true;
        const q = search.toLowerCase();
        return cat.toLowerCase().includes(q) ||
          grouped[cat].some(n => (n.name || "").toLowerCase().includes(q));
      });
  }, [notes, search]);

  // ─── Group perfumers by gender ──────────────────────────────
  const perfumersByGender = useMemo(() => {
    const grouped = { Male: [], Female: [], Organization: [], Other: [] };
    for (const p of perfumers) {
      const g = p.gender || "Other";
      const bucket = g === "Male" || g === "Female" || g === "Organization" ? g : "Other";
      grouped[bucket].push(p);
    }
    return Object.entries(grouped)
      .filter(([_, items]) => items.length > 0)
      .filter(([cat]) => {
        if (!search) return true;
        const q = search.toLowerCase();
        return grouped[cat].some(p => (p.name || "").toLowerCase().includes(q));
      });
  }, [perfumers, search]);

  const toggleBrand = (name) => {
    setExpandedBrands(prev => {
      const next = new Set(prev);
      if (next.has(name)) next.delete(name); else next.add(name);
      return next;
    });
  };

  const expandAll = () => {
    const all = view === "perfumes"
      ? new Set(perfumesByBrand.map(([b]) => b))
      : view === "notes"
        ? new Set(notesByCategory.map(([c]) => c))
        : new Set(perfumersByGender.map(([c]) => c));
    setExpandedBrands(all);
  };

  const collapseAll = () => setExpandedBrands(new Set());

  const exportJSON = async () => {
    let data;
    if (view === "perfumes") {
      data = Object.fromEntries(
        perfumesByBrand.map(([brand, perfs]) => [brand, perfs])
      );
    } else if (view === "notes") {
      data = Object.fromEntries(notesByCategory);
    } else {
      data = Object.fromEntries(perfumersByGender);
    }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
    await downloadBlob(blob, `process-app_${view}_${new Date().toISOString().split("T")[0]}.json`);
  };

  return (
    <div className="container max-w-6xl mx-auto p-4 pb-32" dir={isAr ? "rtl" : "ltr"}>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <Link to="/maestro">
          <Button variant="ghost" size="sm" className="gap-1">
            <ArrowLeft className="w-4 h-4" />
            <span className="font-body">{isAr ? "رجوع" : "Back"}</span>
          </Button>
        </Link>
        <div className="flex items-center gap-2">
          <Database className="w-5 h-5 text-primary" />
          <h1 className="font-heading text-xl font-bold">
            {isAr ? "عارض قاعدة البيانات" : "Database Viewer"}
          </h1>
        </div>
        <div className="w-16" />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <StatCard label_en="Brands" label_ar="براندات" count={brands.length} icon="🏛️" color="amber" isAr={isAr} />
        <StatCard label_en="Perfumes" label_ar="عطور" count={perfumes.length} icon="🌹" color="rose" isAr={isAr} />
        <StatCard label_en="Notes" label_ar="نوتات" count={notes.length} icon="🌿" color="emerald" isAr={isAr} />
        <StatCard label_en="Perfumers" label_ar="عطارون" count={perfumers.length} icon="👑" color="violet" isAr={isAr} />
      </div>

      {/* View tabs */}
      <div className="flex items-center gap-2 mb-4 overflow-x-auto pb-1">
        {[
          { id: "perfumes", icon: "🌹", label_en: "Perfumes by Brand", label_ar: "العطور حسب البراند" },
          { id: "notes", icon: "🌿", label_en: "Notes by Category", label_ar: "النوتات حسب الفئة" },
          { id: "perfumers", icon: "👑", label_en: "Perfumers by Type", label_ar: "العطارون حسب النوع" },
        ].map(t => (
          <button
            key={t.id}
            onClick={() => { setView(t.id); setExpandedBrands(new Set()); }}
            className={`px-4 py-2 rounded-none text-sm font-body whitespace-nowrap transition-all ${
              view === t.id
                ? "bg-primary text-primary-foreground shadow-md"
                : "bg-secondary hover:bg-secondary/70"
            }`}
          >
            {t.icon} {isAr ? t.label_ar : t.label_en}
          </button>
        ))}
      </div>

      {/* Search bar */}
      <div className="flex gap-2 mb-4">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 -translate-y-1/2 left-3 w-4 h-4 text-muted-foreground" />
          <Input
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={isAr ? "ابحث..." : "Search..."}
            className="pl-10 font-body"
          />
        </div>
        <Button onClick={expandAll} variant="outline" size="sm" className="gap-1">
          <ChevronDown className="w-4 h-4" />
          <span className="hidden md:inline font-body">{isAr ? "افتح الكل" : "Expand"}</span>
        </Button>
        <Button onClick={collapseAll} variant="outline" size="sm" className="gap-1">
          <ChevronRight className="w-4 h-4" />
          <span className="hidden md:inline font-body">{isAr ? "أغلق الكل" : "Collapse"}</span>
        </Button>
        <Button onClick={exportJSON} variant="outline" size="sm" className="gap-1">
          <Download className="w-4 h-4" />
          <span className="hidden md:inline font-body">{isAr ? "JSON" : "JSON"}</span>
        </Button>
      </div>

      {/* Content — perfumes view */}
      {view === "perfumes" && (
        <div className="space-y-2">
          {perfumesLoading && <LoadingMsg isAr={isAr} />}
          {!perfumesLoading && perfumesByBrand.length === 0 && (
            <EmptyMsg isAr={isAr} />
          )}
          {perfumesByBrand.map(([brand, perfs]) => {
            const isOpen = expandedBrands.has(brand);
            return (
              <BrandGroup
                key={brand}
                title={brand}
                count={perfs.length}
                isOpen={isOpen}
                onToggle={() => toggleBrand(brand)}
                isAr={isAr}
              >
                <div className="space-y-1 p-3 bg-secondary/30">
                  {perfs.map(p => (
                    <Link
                      key={p.id}
                      to={`/perfume?id=${p.id}`}
                      className="flex items-center justify-between gap-3 p-2.5 rounded-none hover:bg-card transition-colors group"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="font-body font-medium text-sm truncate">
                          {p.name_en || p.name}
                          {p.name_ar && (
                            <span className="text-muted-foreground mx-2">·</span>
                          )}
                          {p.name_ar && (
                            <span className="text-muted-foreground font-body" dir="rtl">{p.name_ar}</span>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 mt-1">
                          {p.type && <Tag2>{p.type}</Tag2>}
                          {p.gender && <Tag2>{p.gender}</Tag2>}
                          {p.release_year && <Tag2>{p.release_year}</Tag2>}
                        </div>
                      </div>
                      <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-primary shrink-0" />
                    </Link>
                  ))}
                </div>
              </BrandGroup>
            );
          })}
        </div>
      )}

      {/* Content — notes view */}
      {view === "notes" && (
        <div className="space-y-2">
          {notesLoading && <LoadingMsg isAr={isAr} />}
          {notesByCategory.map(([cat, items]) => {
            const isOpen = expandedBrands.has(cat);
            return (
              <BrandGroup
                key={cat}
                title={cat}
                count={items.length}
                isOpen={isOpen}
                onToggle={() => toggleBrand(cat)}
                isAr={isAr}
              >
                <div className="grid grid-cols-2 md:grid-cols-3 gap-1.5 p-3 bg-secondary/30">
                  {items.map(n => (
                    <Link
                      key={n.id}
                      to={`/note?id=${n.id}`}
                      className="block p-2 rounded-none bg-card hover:bg-primary/10 transition-colors text-xs font-body"
                    >
                      {n.name}
                    </Link>
                  ))}
                </div>
              </BrandGroup>
            );
          })}
        </div>
      )}

      {/* Content — perfumers view */}
      {view === "perfumers" && (
        <div className="space-y-2">
          {perfumersByGender.map(([cat, items]) => {
            const isOpen = expandedBrands.has(cat);
            return (
              <BrandGroup
                key={cat}
                title={cat}
                count={items.length}
                isOpen={isOpen}
                onToggle={() => toggleBrand(cat)}
                isAr={isAr}
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-1.5 p-3 bg-secondary/30">
                  {items.map(p => (
                    <Link
                      key={p.id}
                      to={`/perfumer?id=${p.id}`}
                      className="block p-2.5 rounded-none bg-card hover:bg-primary/10 transition-colors"
                    >
                      <div className="font-body font-medium text-sm">{p.name}</div>
                      {p.country && <div className="text-xs text-muted-foreground">{p.country}</div>}
                    </Link>
                  ))}
                </div>
              </BrandGroup>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── Sub-components ────────────────────────────────────────────
function StatCard({ label_en, label_ar, count, icon, color, isAr }) {
  return (
    <div className={`p-3 rounded-none bg-card border-2 border-${color}-200/50 dark:border-${color}-800/50`}>
      <div className="flex items-center justify-between">
        <span className="text-2xl">{icon}</span>
        <span className="text-2xl font-heading font-bold">{count.toLocaleString()}</span>
      </div>
      <div className="text-xs font-body text-muted-foreground mt-1">
        {isAr ? label_ar : label_en}
      </div>
    </div>
  );
}

function BrandGroup({ title, count, isOpen, onToggle, isAr, children }) {
  return (
    <div className="rounded-none border border-border bg-card overflow-hidden">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-between gap-3 p-3 hover:bg-secondary/50 transition-colors"
      >
        <div className="flex items-center gap-2">
          {isOpen ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          <span className="font-heading font-bold text-sm">{title}</span>
        </div>
        <span className="text-xs font-body text-muted-foreground rounded-none">
          {count}
        </span>
      </button>
      {isOpen && children}
    </div>
  );
}

function Tag2({ children }) {
  return (
    <span className="text-[10px] font-body text-muted-foreground rounded-none">
      {children}
    </span>
  );
}

function LoadingMsg({ isAr }) {
  return (
    <div className="text-center text-muted-foreground font-body py-8">
      <RefreshCw className="w-5 h-5 mx-auto mb-2 animate-spin" />
      {isAr ? "جاري التحميل..." : "Loading..."}
    </div>
  );
}

function EmptyMsg({ isAr }) {
  return (
    <div className="text-center text-muted-foreground font-body py-8">
      {isAr ? "لا توجد بيانات" : "No data"}
    </div>
  );
}
