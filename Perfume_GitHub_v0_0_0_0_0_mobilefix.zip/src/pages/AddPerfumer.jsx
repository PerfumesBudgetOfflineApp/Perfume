import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useNavigate } from "react-router-dom";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { ArrowLeft } from "lucide-react";
import { useLang } from "@/lib/LanguageContext";

// صفحة «إضافة عطّار» مستقلّة (غير منبثقة) — بديل حوار الإضافة القديم في Perfumers.jsx.
// نفس الحقول تماماً، بنمط الصفحة الداخلية (ArrowLeft للرجوع، min-h عبر الغلاف العام).
export default function AddPerfumer() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { isAr } = useLang();

  const [form, setForm] = useState({
    name: "",
    name_ar: "",
    nationality: "",
    gender: "",
    birth_year: "",
    death_year: "",
    famous_works: "",
    brand_names: "",
    bio: "",
    website: "",
    education: "",
  });

  const createMutation = useMutation({
    mutationFn: async (newPerfumer) => {
      return await apphost.entities.Perfumer.create({
        ...newPerfumer,
        birth_year: newPerfumer.birth_year ? Number(newPerfumer.birth_year) : null,
        death_year: newPerfumer.death_year ? Number(newPerfumer.death_year) : null,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["perfumers"] });
      toast.success(isAr ? "تمت إضافة العطّار" : "Perfumer added");
      navigate("/perfumers");
    },
    onError: (e) => {
      toast.error((isAr ? "تعذّر الحفظ: " : "Save failed: ") + (e?.message || ""));
    },
  });

  const canSave = !!form.name.trim() && !createMutation.isPending;

  return (
    <div className="px-5 pt-12 pb-24 space-y-6 max-w-md mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" className="rounded-none" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="font-heading text-xl font-bold">إضافة معطّر Add Perfumer</h1>
      </div>

      {/* Form */}
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-body">الاسم بالإنجليزية Name (EN)</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Jacques Polge" className="rounded-none font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">الاسم (AR)</Label>
            <Input value={form.name_ar} onChange={(e) => setForm({ ...form, name_ar: e.target.value })} placeholder="بالعربي" className="rounded-none font-body" dir="rtl" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-body">الجنسية Nationality</Label>
            <Input value={form.nationality} onChange={(e) => setForm({ ...form, nationality: e.target.value })} placeholder="e.g. French" className="rounded-none font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">سنة الميلاد Birth Year</Label>
            <Input type="number" value={form.birth_year} onChange={(e) => setForm({ ...form, birth_year: Number(e.target.value) || "" })} placeholder="1960" className="rounded-none font-body" />
          </div>
        </div>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1.5">
            <Label className="text-xs font-body">سنة الوفاة Death Year</Label>
            <Input type="number" value={form.death_year} onChange={(e) => setForm({ ...form, death_year: Number(e.target.value) || "" })} placeholder="(optional)" className="rounded-none font-body" />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs font-body">الفئة Gender</Label>
            <div className="flex gap-1">
              {["Male", "Female"].map((g) => (
                <button key={g} type="button" onClick={() => setForm({ ...form, gender: g })}
                  className={`flex-1 py-2 rounded-none text-xs font-body font-medium transition-all ${form.gender === g ? (g === "Female" ? "bg-pink-500 text-white" : "bg-blue-900 text-white") : "bg-secondary text-muted-foreground"}`}>
                  {g}
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-body">أعمال شهيرة Famous Works (comma-separated)</Label>
          <Input value={form.famous_works} onChange={(e) => setForm({ ...form, famous_works: e.target.value })} placeholder="e.g. No. 5, Sauvage" className="rounded-none font-body" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-body">البراندات Brands (comma-separated)</Label>
          <Input value={form.brand_names} onChange={(e) => setForm({ ...form, brand_names: e.target.value })} placeholder="e.g. Chanel, Dior" className="rounded-none font-body" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-body">نبذة Bio</Label>
          <Textarea value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} placeholder="نبذة مختصرة Short biography..." className="rounded-none font-body min-h-[60px]" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-body">🌐 الموقع Website (optional)</Label>
          <Input value={form.website} onChange={(e) => setForm({ ...form, website: e.target.value })} placeholder="https://..." className="rounded-none font-body" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs font-body">🎓 التعليم Education (optional)</Label>
          <Textarea value={form.education} onChange={(e) => setForm({ ...form, education: e.target.value })} placeholder="e.g. ISIPCA, apprentice of..." className="rounded-none font-body min-h-[56px]" />
        </div>

        <Button className="w-full rounded-none font-body bg-green-800 hover:bg-green-900" onClick={() => createMutation.mutate(form)} disabled={!canSave}>
          {createMutation.isPending ? (isAr ? "جارٍ الحفظ..." : "Saving...") : (isAr ? "إضافة العطّار" : "Add Perfumer")}
        </Button>
      </div>
    </div>
  );
}
