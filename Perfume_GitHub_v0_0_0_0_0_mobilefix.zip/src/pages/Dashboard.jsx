import { useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { apphost } from "@/api/apphostClient";
import { useCurrency } from "@/lib/useCurrency";
import { usePersonNames } from "@/lib/usePersonNames";
import StatCard from "@/components/dashboard/StatCard";
import BrandChart from "@/components/dashboard/BrandChart";
import RatingChart from "@/components/dashboard/RatingChart";
import DonutChart from "@/components/dashboard/DonutChart";
import ListDistribution from "@/components/dashboard/ListDistribution";

function ChartCard({ title, children }) {
  return (
    <div className="bg-card rounded-none p-4 border border-border/60 space-y-3">
      <h3 className="font-heading font-semibold text-sm">{title}</h3>
      {children}
    </div>
  );
}

export default function Dashboard() {
  const { formatPrice } = useCurrency();
  const { names } = usePersonNames();
  const { data: perfumes = [], isLoading } = useQuery({
    queryKey: ["perfumes"],
    queryFn: () => apphost.entities.Perfume.list("-created_date"),
    staleTime: Infinity,
  });

  const { data: brands = [] } = useQuery({
    queryKey: ["brands"],
    queryFn: () => apphost.entities.PerfumeBrand.list("name"),
  });

  const { data: wearLogs = [] } = useQuery({
    queryKey: ["wear-logs"],
    queryFn: () => apphost.entities.WearLog.list("-date"),
  });

  const { data: userPerfumes = [] } = useQuery({
    queryKey: ["user-perfumes"],
    queryFn: () => apphost.entities.UserPerfume.list("-created_date"),
  });

  const { data: purchaseRecords = [] } = useQuery({
    queryKey: ["purchase-records"],
    queryFn: () => apphost.entities.PurchaseRecord.list("-created_date"),
  });

  const { rated, avgRating, topRated, totalPrice, totalMl } = useMemo(() => {
    const rated = perfumes.filter((p) => p.rating > 0);
    const avgRating = rated.length
      ? (rated.reduce((s, p) => s + p.rating, 0) / rated.length).toFixed(1)
      : "—";
    const topRated = [...perfumes]
      .filter((p) => p.rating >= 4)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 5);
    const totalPrice = perfumes.reduce((sum, p) => sum + (p.price || 0), 0);
    const totalMl = perfumes.reduce((sum, p) => sum + (p.ml || 0), 0);
    return { rated, avgRating, topRated, totalPrice, totalMl };
  }, [perfumes]);

  const totalSampleMl = userPerfumes.reduce((sum, u) => sum + (u.sample_ml || 0), 0);

  // Sample stats per person
  const getSampleStats = (person) => {
    const items = userPerfumes.filter((u) => u.person === person);
    const volume = items.reduce((sum, u) => sum + (u.sample_ml || 0), 0);
    const cost = items.reduce((sum, u) => sum + (u.sample_cost || 0), 0);
    const avgCost = items.length > 0 ? (cost / items.length).toFixed(2) : 0;
    return { volume, cost, avgCost, count: items.length };
  };

  const p1Stats = getSampleStats("person1");
  const p2Stats = getSampleStats("person2");
  const allStats = {
    volume: totalSampleMl,
    cost: userPerfumes.reduce((sum, u) => sum + (u.sample_cost || 0), 0),
    avgCost: userPerfumes.length > 0 ? (userPerfumes.reduce((sum, u) => sum + (u.sample_cost || 0), 0) / userPerfumes.length).toFixed(2) : 0,
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="px-4 pt-12 pb-4 space-y-5">
      <div className="space-y-0.5">
        <h1 className="font-heading text-2xl font-bold">لوحة المعلومات Dashboard</h1>
        <p className="text-xs text-muted-foreground font-body">مجموعتك بلمحة Your collection at a glance</p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 gap-3">
        <StatCard
          label="Total Perfumes"
          value={perfumes.length}
          sub={`${brands.length} brands`}
        />
        <StatCard
          label="Avg Rating"
          value={avgRating}
          sub={`${rated.length} rated`}
        />
        <StatCard
          label="Favorites"
          value={perfumes.filter((p) => p.list === "favorite").length}
          sub="in favorites list"
        />
        <StatCard
          label="Own"
          value={perfumes.filter((p) => p.list === "own").length}
          sub="in collection"
        />
        <StatCard
          label="Days Tracked"
          value={new Set(wearLogs.map((l) => l.date)).size}
          sub={`${wearLogs.length} total logs`}
        />
        <StatCard
          label="This Month"
          value={wearLogs.filter((l) => l.date?.startsWith(new Date().toISOString().slice(0, 7))).length}
          sub="wear logs"
        />
        <StatCard
          label="Total Value"
          value={formatPrice(totalPrice.toFixed(0))}
          sub="collection worth"
        />
        <StatCard
          label="Total Sample Volume"
          value={`${totalSampleMl}ml`}
          sub="across all samples"
        />
        <StatCard
          label="Total ML"
          value={`${totalMl}ml`}
          sub="total volume"
        />
        <StatCard
          label="Total Purchases"
          value={purchaseRecords.length}
          sub="sample & bottle"
        />
      </div>

      {/* Sample Stats per person */}
      <div className="space-y-3">
        <h2 className="font-heading font-semibold text-sm">إحصاءات العيّنات Sample Stats</h2>
        <div className="grid grid-cols-3 gap-3">
          {/* Person 1 */}
          <ChartCard title={names.person1}>
            <div className="space-y-2">
              <StatCard label="Volume" value={`${p1Stats.volume}ml`} sub={`${p1Stats.count} items`} />
              <StatCard label="Cost" value={formatPrice(p1Stats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(p1Stats.avgCost)} sub="per sample" />
            </div>
          </ChartCard>

          {/* Person 2 */}
          <ChartCard title={names.person2}>
            <div className="space-y-2">
              <StatCard label="Volume" value={`${p2Stats.volume}ml`} sub={`${p2Stats.count} items`} />
              <StatCard label="Cost" value={formatPrice(p2Stats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(p2Stats.avgCost)} sub="per sample" />
            </div>
          </ChartCard>

          {/* Combined */}
          <ChartCard title="All">
            <div className="space-y-2">
              <StatCard label="Volume" value={`${allStats.volume}ml`} sub={`${userPerfumes.length} items`} />
              <StatCard label="Cost" value={formatPrice(allStats.cost.toFixed(0))} sub="total" />
              <StatCard label="Avg Cost/Item" value={formatPrice(allStats.avgCost)} sub="per sample" />
            </div>
          </ChartCard>
        </div>
      </div>

      {/* Brand Distribution */}
      <ChartCard title="By Brand">
        <BrandChart perfumes={perfumes} />
      </ChartCard>

      {/* Ratings Distribution */}
      <ChartCard title="Rating Distribution">
        <RatingChart perfumes={perfumes} />
      </ChartCard>

      {/* Two donuts side by side */}
      <div className="grid grid-cols-2 gap-3">
        <ChartCard title="By Type">
          <DonutChart perfumes={perfumes} field="type" />
        </ChartCard>
        <ChartCard title="By Gender">
          <DonutChart perfumes={perfumes} field="gender" />
        </ChartCard>
      </div>

      {/* Season donut */}
      <ChartCard title="By Season">
        <DonutChart perfumes={perfumes} field="season" />
      </ChartCard>

      {/* List distribution */}
      <ChartCard title="List Breakdown">
        <ListDistribution perfumes={perfumes} />
      </ChartCard>

      {/* Top rated */}
      {topRated.length > 0 && (
        <ChartCard title="Top Rated">
          <div className="space-y-2.5">
            {topRated.map((p, i) => (
              <div key={p.id} className="flex items-center gap-3">
                <span className="text-xs text-muted-foreground font-body w-4 text-right">{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-body font-medium truncate">{p.name}</p>
                  <p className="text-[10px] text-muted-foreground font-body">{p.brand_name}</p>
                </div>
                <div className="flex">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <span key={s} className={`text-xs ${s <= p.rating ? "text-primary" : "text-border"}`}>{s <= p.rating ? "■" : "□"}</span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </ChartCard>
      )}

      {/* Recent Purchases */}
      {purchaseRecords.length > 0 && (
        <ChartCard title="Recent Purchases">
          <div className="space-y-2">
            {purchaseRecords.slice(0, 8).map((record) => (
              <div key={record.id} className="flex items-center justify-between bg-secondary/40 rounded-none p-3">
                <div className="flex items-center gap-2 flex-1">
                  <span className="text-[10px] font-body font-bold rounded-none text-primary">
                    {record.type === "sample" ? "Sample" : "Bottle"}
                  </span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-body font-medium truncate">{record.perfume_name}</p>
                    <p className="text-[10px] text-muted-foreground font-body">{record.purchase_date}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs font-body font-medium">{record.ml}ml</p>
                  <p className="text-[10px] text-muted-foreground font-body">{formatPrice(record.cost)}</p>
                </div>
              </div>
            ))}
          </div>
        </ChartCard>
      )}
    </div>
  );
}