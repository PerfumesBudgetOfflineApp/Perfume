# License — Perfume Vault

## Proprietary License

**Copyright © 2025-2026 — All Rights Reserved**

Perfume Vault ("Software") is proprietary software owned and developed by the original creators. All rights are reserved.

---

## Terms of Use

### ✅ What You CAN Do
- Use this software for **personal** fragrance management
- Deploy to **Base44** for private family/couple use
- Customize UI colors, fonts, and branding for your instance
- Add your own perfume data and collections
- Export and backup your personal data
- Share with authorized family members via Base44 invitations

### ❌ What You CANNOT Do
- **Redistribute** — Do not copy, clone, or fork the repository for public distribution
- **Commercial Use** — Do not use for commercial or SaaS purposes
- **Remove Attribution** — Do not remove copyright notices or credits
- **Resell** — Do not sell or lease this software or modified versions
- **Sublicense** — Do not sublicense or grant rights to third parties
- **Decompile** — Do not decompile, reverse-engineer, or disassemble the code

### Permitted Modifications
- You may modify the code for your personal use
- You may customize styling, colors, and branding
- You may add custom perfume data
- **You may NOT distribute modified versions** without explicit written permission

---

## No Warranty

THIS SOFTWARE IS PROVIDED "AS-IS" WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NONINFRINGEMENT.

The creators shall not be liable for any damages (direct, indirect, incidental, special, exemplary, or consequential) arising from the use or inability to use this software.

---

## Intellectual Property

All original code, design, concepts, and database structures are owned by the creators. This includes:
- Source code (React, backend functions)
- UI/UX design and component library
- Branding and visual identity
- Feature architecture and logic
- Data schemas and entity definitions

---

## Third-Party Components

This software uses open-source libraries and frameworks. See [CREDITS.md](./CREDITS.md) for complete attribution and individual licenses.

---

## Data Ownership

### Your Data
- **Personal data** you create (collections, reviews, logs, goals) remains your property
- You own all rights to your exported backups and data
- You can delete your data at any time

### Reference Data
- **Built-in catalog** (perfumes, brands, notes, perfumers) includes data from various public sources
- See [CREDITS.md](./CREDITS.md) for specific data attribution
- This reference data is provided for personal use only

---

## Violation & Enforcement

Unauthorized use, distribution, or modification may result in:
- Legal action for damages
- Injunctive relief
- DMCA complaints against unauthorized distributions

---

## Contact

For licensing inquiries, permissions, or questions:
- Do not redistribute without written consent
- Contact the original creators for commercial use

---

## Changes to License

The creators reserve the right to modify this license for future versions. Continued use constitutes acceptance of changes.

---

**Last Updated:** May 12, 2026  
**Version:** 1.0