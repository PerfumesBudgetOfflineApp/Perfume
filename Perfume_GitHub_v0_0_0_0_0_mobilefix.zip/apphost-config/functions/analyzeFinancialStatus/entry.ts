import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await req.json();
    const { person = 'person1', months = 3 } = payload;

    // Get all financial data
    const [incomes, expenses, obligations, recurring] = await Promise.all([
      base44.entities.BudgetIncome.list('-date', 500),
      base44.entities.BudgetExpense.list('-date', 500),
      base44.entities.BudgetObligation.list('-end_date', 500),
      base44.entities.RecurringExpense.list('-start_date', 500)
    ]);

    const personIncomes = incomes.filter(i => i.person === person);
    const personExpenses = expenses.filter(e => e.person === person);
    const personObligations = obligations.filter(o => o.person === person && o.status === 'active');
    const personRecurring = recurring.filter(r => r.person === person && r.is_active);

    // Calculate current month stats
    const now = new Date();
    const currentMonth = now.toISOString().slice(0, 7);
    
    const currentIncomes = personIncomes.filter(i => i.date.startsWith(currentMonth));
    const currentExpenses = personExpenses.filter(e => e.date.startsWith(currentMonth));

    const totalIncome = currentIncomes.reduce((sum, i) => sum + (i.amount || 0), 0);
    const totalExpenses = currentExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    const totalObligations = personObligations.reduce((sum, o) => sum + (o.monthly_payment || 0), 0);
    const totalRecurring = personRecurring.reduce((sum, r) => sum + (r.amount || 0), 0);
    
    const monthlyFixed = totalObligations + totalRecurring;
    const monthlyVariable = totalExpenses;
    const monthlyNet = totalIncome - monthlyFixed - monthlyVariable;

    // Calculate average income from last 3-6 months
    const pastMonths = [];
    for (let i = 0; i < 6; i++) {
      const date = new Date(now);
      date.setMonth(date.getMonth() - i);
      const monthStr = date.toISOString().slice(0, 7);
      const monthIncomes = personIncomes.filter(inc => inc.date.startsWith(monthStr));
      const monthTotal = monthIncomes.reduce((sum, inc) => sum + (inc.amount || 0), 0);
      if (monthTotal > 0) pastMonths.push(monthTotal);
    }

    const avgIncome = pastMonths.length > 0 ? pastMonths.reduce((a, b) => a + b, 0) / pastMonths.length : totalIncome;

    // Forecast future months
    const forecast = [];
    for (let m = 1; m <= months; m++) {
      const forecastMonth = new Date(now);
      forecastMonth.setMonth(forecastMonth.getMonth() + m);
      const monthStr = forecastMonth.toISOString().slice(0, 7);
      
      // Estimate based on averages and fixed obligations
      const estimatedIncome = avgIncome;
      const estimatedFixed = monthlyFixed;
      const estimatedVariable = monthlyVariable; // Conservative estimate
      const estimatedBalance = estimatedIncome - estimatedFixed - estimatedVariable;

      forecast.push({
        month: monthStr,
        estimatedIncome,
        estimatedFixed,
        estimatedVariable,
        estimatedBalance,
        healthScore: estimatedBalance > 0 ? 'healthy' : 'at-risk'
      });
    }

    // Debt analysis
    const debtAnalysis = personObligations.map(obl => {
      const remaining = obl.total_amount - obl.paid_amount;
      const monthsToPayoff = Math.ceil(remaining / obl.monthly_payment);
      const payoffDate = new Date();
      payoffDate.setMonth(payoffDate.getMonth() + monthsToPayoff);
      
      return {
        title: obl.title,
        totalDebt: obl.total_amount,
        paid: obl.paid_amount,
        remaining,
        monthlyPayment: obl.monthly_payment,
        monthsToPayoff,
        payoffDate: payoffDate.toISOString().slice(0, 10),
        progress: ((obl.paid_amount / obl.total_amount) * 100).toFixed(2)
      };
    });

    // Spending by category
    const spendingByCategory = {};
    personExpenses.forEach(exp => {
      const cat = exp.category || 'other';
      spendingByCategory[cat] = (spendingByCategory[cat] || 0) + (exp.amount || 0);
    });

    // Calculate financial health score (0-100)
    let healthScore = 50; // Base score

    // Income stability bonus
    if (pastMonths.length >= 3) {
      const variance = pastMonths.reduce((sum, m) => sum + Math.abs(m - avgIncome), 0) / pastMonths.length;
      const stability = 1 - (variance / avgIncome);
      healthScore += stability * 20;
    }

    // Balance ratio
    if (monthlyNet > 0) {
      const savingsRatio = Math.min((monthlyNet / totalIncome) * 100, 30);
      healthScore += (savingsRatio / 30) * 20;
    } else {
      healthScore -= 20;
    }

    // Debt ratio
    const totalDebt = personObligations.reduce((sum, o) => sum + (o.total_amount - o.paid_amount), 0);
    if (totalIncome > 0) {
      const debtRatio = totalDebt / totalIncome;
      if (debtRatio < 1) healthScore += 10;
      else if (debtRatio > 3) healthScore -= 10;
    }

    // Fixed expense ratio
    const fixedRatio = (monthlyFixed / totalIncome) * 100;
    if (fixedRatio < 40) healthScore += 5;
    else if (fixedRatio > 60) healthScore -= 10;

    healthScore = Math.max(0, Math.min(100, healthScore));

    // Generate recommendations
    const recommendations = [];
    if (monthlyNet < 0) {
      recommendations.push({
        type: 'critical',
        message: 'Your monthly expenses exceed income. Consider reducing variable expenses or increasing income.'
      });
    }
    if ((monthlyFixed / totalIncome) * 100 > 60) {
      recommendations.push({
        type: 'warning',
        message: 'Fixed obligations are consuming more than 60% of income. Look for ways to reduce fixed costs.'
      });
    }
    if (spendingByCategory.perfume > totalIncome * 0.2) {
      recommendations.push({
        type: 'info',
        message: 'Perfume spending is significant. Consider setting a monthly budget limit.'
      });
    }
    if (debtAnalysis.length > 0) {
      const totalRemaining = debtAnalysis.reduce((sum, d) => sum + d.remaining, 0);
      if (totalRemaining > totalIncome * 3) {
        recommendations.push({
          type: 'warning',
          message: 'Total debt exceeds 3x your monthly income. Focus on paying down high-interest obligations first.'
        });
      }
    }

    return Response.json({
      success: true,
      currentMonth,
      person,
      currentStatus: {
        totalIncome,
        totalExpenses,
        monthlyFixed,
        monthlyNet,
        healthScore: Math.round(healthScore)
      },
      forecast,
      debtAnalysis,
      spendingByCategory,
      recommendations,
      summary: {
        averageIncome: avgIncome.toFixed(2),
        savingsRate: ((monthlyNet / totalIncome) * 100).toFixed(2) + '%',
        fixedExpenseRatio: (((monthlyFixed) / totalIncome) * 100).toFixed(2) + '%',
        totalActiveDebt: debtAnalysis.reduce((sum, d) => sum + d.remaining, 0),
        totalObligations: debtAnalysis.length
      }
    });
  } catch (error) {
    console.error('Error in analyzeFinancialStatus:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
});