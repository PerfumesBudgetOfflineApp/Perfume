import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // جلب جميع الكيانات
    const [brands, perfumes, notes, perfumers, quotes, glossary] = await Promise.all([
      base44.asServiceRole.entities.PerfumeBrand.list('-created_date'),
      base44.asServiceRole.entities.Perfume.list('-created_date'),
      base44.asServiceRole.entities.PerfumeNote.list('-created_date'),
      base44.asServiceRole.entities.Perfumer.list('-created_date'),
      base44.asServiceRole.entities.Quote.list('-created_date'),
      base44.asServiceRole.entities.GlossaryTerm.list('-created_date')
    ]);

    const format = (data) => data.map(item => {
      const formatted = {};
      Object.entries(item).forEach(([key, value]) => {
        if (!['id', 'created_date', 'updated_date', 'created_by'].includes(key)) {
          formatted[key] = value;
        }
      });
      return formatted;
    });

    const allData = {
      brands: format(brands),
      perfumes: format(perfumes),
      notes: format(notes),
      perfumers: format(perfumers),
      quotes: format(quotes),
      glossary: format(glossary),
      exported_at: new Date().toISOString(),
      total_records: {
        brands: brands.length,
        perfumes: perfumes.length,
        notes: notes.length,
        perfumers: perfumers.length,
        quotes: quotes.length,
        glossary: glossary.length
      }
    };

    const jsonString = JSON.stringify(allData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    
    return new Response(blob, {
      status: 200,
      headers: {
        'Content-Type': 'application/json',
        'Content-Disposition': 'attachment; filename=all_builtin_data.json'
      }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});