import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const DEFAULT_MAIN_CATEGORIES = [
  { name_en: "Fashion & Appearance", name_ar: "الموضة والمظهر", icon: "👗", color: "#ec4899" },
  { name_en: "Food & Nutrition", name_ar: "الغذاء والتغذية", icon: "🍽️", color: "#f59e0b" },
  { name_en: "Health & Wellness", name_ar: "الصحة والعافية", icon: "💊", color: "#10b981" },
  { name_en: "Technology & Electronics", name_ar: "التقنية والإلكترونيات", icon: "📱", color: "#6366f1" },
  { name_en: "Home & Living", name_ar: "المنزل والمعيشة", icon: "🏠", color: "#8b5cf6" },
  { name_en: "Beauty & Personal Care", name_ar: "الجمال والعناية الشخصية", icon: "✨", color: "#f43f5e" },
  { name_en: "Fragrances & Oud", name_ar: "العطور والعود", icon: "🌹", color: "#a855f7" },
  { name_en: "Subscriptions & Services", name_ar: "الاشتراكات والخدمات", icon: "📡", color: "#0ea5e9" },
  { name_en: "Education & Books", name_ar: "التعليم والكتب", icon: "📚", color: "#84cc16" },
  { name_en: "Entertainment & Leisure", name_ar: "الترفيه والرياضة", icon: "🎮", color: "#fb923c" },
  { name_en: "Tobacco & Beverages", name_ar: "التبغ والمشروبات", icon: "☕", color: "#a78bfa" },
  { name_en: "Travel & Transport", name_ar: "السفر والتنقل", icon: "✈️", color: "#38bdf8" },
  { name_en: "Kids & Family", name_ar: "الأطفال والعائلة", icon: "👶", color: "#fbbf24" },
  { name_en: "Gifts & Occasions", name_ar: "الهدايا والمناسبات", icon: "🎁", color: "#fb7185" },
  { name_en: "Other", name_ar: "أخرى", icon: "📦", color: "#94a3b8" },
];

const DEFAULT_SUB_CATEGORIES = {
  "Fashion & Appearance": [
    { name_en: "Clothing", name_ar: "الملابس" },
    { name_en: "Footwear", name_ar: "الأحذية" },
    { name_en: "Jewelry & Accessories", name_ar: "المجوهرات والإكسسوارات" },
    { name_en: "Watches", name_ar: "الساعات" },
    { name_en: "Bags & Luggage", name_ar: "الحقائب والأمتعة" },
    { name_en: "Eyewear", name_ar: "النظارات" },
    { name_en: "Sportswear", name_ar: "الملابس الرياضية" },
  ],
  "Food & Nutrition": [
    { name_en: "Groceries", name_ar: "البقالة" },
    { name_en: "Restaurants & Cafes", name_ar: "المطاعم والمقاهي" },
    { name_en: "Bakery & Sweets", name_ar: "المخبوزات والحلويات" },
    { name_en: "Organic & Health Food", name_ar: "الأغذية الصحية والعضوية" },
    { name_en: "Snacks", name_ar: "الوجبات الخفيفة" },
    { name_en: "Meal Delivery", name_ar: "توصيل الوجبات" },
  ],
  "Health & Wellness": [
    { name_en: "Pharmacy & Medicine", name_ar: "الصيدلية والدواء" },
    { name_en: "Supplements & Vitamins", name_ar: "المكملات والفيتامينات" },
    { name_en: "Gym & Fitness", name_ar: "النادي الرياضي واللياقة" },
    { name_en: "Medical Appointments", name_ar: "المواعيد الطبية" },
    { name_en: "Mental Wellness", name_ar: "الصحة النفسية" },
  ],
  "Technology & Electronics": [
    { name_en: "Smartphones & Tablets", name_ar: "الهواتف والأجهزة اللوحية" },
    { name_en: "Computers & Laptops", name_ar: "الحاسوب واللاب توب" },
    { name_en: "Accessories & Peripherals", name_ar: "الملحقات والإضافات" },
    { name_en: "Smart Home", name_ar: "المنزل الذكي" },
    { name_en: "Gaming", name_ar: "الألعاب" },
    { name_en: "Cameras & Photography", name_ar: "الكاميرات والتصوير" },
  ],
  "Home & Living": [
    { name_en: "Furniture", name_ar: "الأثاث" },
    { name_en: "Kitchen & Appliances", name_ar: "المطبخ والأجهزة" },
    { name_en: "Bedding & Linens", name_ar: "الفراش والمفارش" },
    { name_en: "Decor & Art", name_ar: "الديكور والفن" },
    { name_en: "Cleaning & Maintenance", name_ar: "النظافة والصيانة" },
    { name_en: "Garden & Plants", name_ar: "الحديقة والنباتات" },
  ],
  "Beauty & Personal Care": [
    { name_en: "Skincare", name_ar: "العناية بالبشرة" },
    { name_en: "Haircare", name_ar: "العناية بالشعر" },
    { name_en: "Makeup & Cosmetics", name_ar: "المكياج ومستحضرات التجميل" },
    { name_en: "Grooming", name_ar: "العناية الشخصية" },
    { name_en: "Dental Care", name_ar: "العناية بالأسنان" },
    { name_en: "Bath & Body", name_ar: "الاستحمام والجسم" },
  ],
  "Fragrances & Oud": [
    { name_en: "Perfumes (EDP/EDT)", name_ar: "العطور" },
    { name_en: "Oud & Bakhoor", name_ar: "العود والبخور" },
    { name_en: "Samples & Decants", name_ar: "العينات والديكانت" },
    { name_en: "Mukhallat & Oils", name_ar: "المخلطات والزيوت" },
    { name_en: "Ward & Rose Water", name_ar: "ماء الورد" },
  ],
  "Subscriptions & Services": [
    { name_en: "Streaming (Video)", name_ar: "بث الفيديو" },
    { name_en: "Music Streaming", name_ar: "بث الموسيقى" },
    { name_en: "Internet & Mobile", name_ar: "الإنترنت والجوال" },
    { name_en: "Cloud Storage", name_ar: "التخزين السحابي" },
    { name_en: "Productivity Apps", name_ar: "تطبيقات الإنتاجية" },
    { name_en: "News & Magazines", name_ar: "الأخبار والمجلات" },
    { name_en: "Credit Cards (Annual)", name_ar: "بطاقات الائتمان (سنوي)" },
  ],
  "Education & Books": [
    { name_en: "Books & E-Books", name_ar: "الكتب والكتب الإلكترونية" },
    { name_en: "Online Courses", name_ar: "الدورات الإلكترونية" },
    { name_en: "Stationery", name_ar: "القرطاسية" },
    { name_en: "Tutoring", name_ar: "الدروس الخصوصية" },
  ],
  "Entertainment & Leisure": [
    { name_en: "Cinema & Events", name_ar: "السينما والفعاليات" },
    { name_en: "Sports & Recreation", name_ar: "الرياضة والترفيه" },
    { name_en: "Hobbies & Crafts", name_ar: "الهوايات والحرف" },
    { name_en: "Travel & Tourism", name_ar: "السفر والسياحة" },
  ],
  "Tobacco & Beverages": [
    { name_en: "Coffee & Tea", name_ar: "القهوة والشاي" },
    { name_en: "Cigarettes & Shisha", name_ar: "السجائر والشيشة" },
    { name_en: "Soft Drinks & Juices", name_ar: "المشروبات الغازية والعصائر" },
    { name_en: "Energy Drinks", name_ar: "مشروبات الطاقة" },
  ],
  "Travel & Transport": [
    { name_en: "Flights", name_ar: "رحلات الطيران" },
    { name_en: "Hotels & Accommodation", name_ar: "الفنادق والإقامة" },
    { name_en: "Fuel", name_ar: "الوقود" },
    { name_en: "Taxi & Ride Sharing", name_ar: "التاكسي ومشاركة السيارات" },
    { name_en: "Car Maintenance", name_ar: "صيانة السيارة" },
  ],
  "Kids & Family": [
    { name_en: "Toys & Games", name_ar: "الألعاب" },
    { name_en: "Baby Products", name_ar: "منتجات الأطفال" },
    { name_en: "School Supplies", name_ar: "المستلزمات المدرسية" },
    { name_en: "Kids Clothing", name_ar: "ملابس الأطفال" },
  ],
  "Gifts & Occasions": [
    { name_en: "Gift Cards", name_ar: "بطاقات الهدايا" },
    { name_en: "Flowers & Decoration", name_ar: "الزهور والديكور" },
    { name_en: "Special Occasions", name_ar: "المناسبات الخاصة" },
    { name_en: "Charity & Donations", name_ar: "الصدقات والتبرعات" },
  ],
  "Other": [
    { name_en: "Miscellaneous", name_ar: "متفرقات" },
  ],
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Check if categories already exist FOR THIS USER (use user-scoped, not service role)
    const existing = await base44.entities.ShopCategory.filter({ is_default: true });
    
    if (existing.length >= DEFAULT_MAIN_CATEGORIES.length) {
      return Response.json({ 
        success: true, 
        message: 'Categories already seeded',
        count: existing.length 
      });
    }

    // Seed main categories (user-scoped so each user gets their own copy)
    let createdCount = 0;
    for (let i = 0; i < DEFAULT_MAIN_CATEGORIES.length; i++) {
      const main = DEFAULT_MAIN_CATEGORIES[i];
      try {
        const created = await base44.entities.ShopCategory.create({ 
          ...main, 
          is_default: true, 
          sort_order: i 
        });
        createdCount++;
        
        // Seed subcategories
        const subs = DEFAULT_SUB_CATEGORIES[main.name_en] || [];
        for (const sub of subs) {
          await base44.entities.ShopCategory.create({
            ...sub, 
            icon: main.icon, 
            color: main.color,
            parent_id: created.id, 
            parent_name_en: main.name_en, 
            parent_name_ar: main.name_ar, 
            is_default: true,
          });
          createdCount++;
        }
      } catch (e) {
        console.error(`Error creating category ${main.name_en}:`, e);
      }
    }

    return Response.json({ 
      success: true, 
      message: `Seeded ${createdCount} categories`,
      count: createdCount 
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});