import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const categories = await base44.asServiceRole.entities.ShopCategory.list("-created_date", 3000);
    
    const mainCategories = categories.filter(cat => !cat.parent_id);
    const subCategories = categories.filter(cat => cat.parent_id);
    
    return Response.json({
      total: categories.length,
      main_categories: mainCategories.length,
      sub_categories: subCategories.length
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});