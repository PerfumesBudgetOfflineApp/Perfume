import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Known real perfume brands with their IDs from the database
const KNOWN_BRANDS = {
  "Chanel": { country: "France", year: 1910 },
  "Dior": { country: "France", year: 1946 },
  "Guerlain": { country: "France", year: 1828 },
  "Hermès": { country: "France", year: 1837 },
  "Tom Ford": { country: "USA", year: 2006 },
  "Creed": { country: "UK", year: 1760 },
  "YSL": { country: "France", year: 1961 },
  "Prada": { country: "Italy", year: 1913 },
  "Versace": { country: "Italy", year: 1978 },
  "Armani": { country: "Italy", year: 1975 },
  "Kilian": { country: "France", year: 2007 },
  "Maison Francis Kurkdjian": { country: "France", year: 2009 },
  "Le Labo": { country: "USA", year: 2006 },
  "Thierry Mugler": { country: "France", year: 1973 },
  "Paco Rabanne": { country: "France", year: 1966 },
  "Lanvin": { country: "France", year: 1889 },
  "Nina Ricci": { country: "France", year: 1932 },
};

// Comprehensive perfume data per brand
const BRAND_PERFUMES = {
  "Chanel": [
    { name: "Chanel No. 5", type: "Eau de Parfum", gender: "Women", top_notes: "Aldehyde, Neroli, Ylang-ylang", heart_notes: "Rose, Jasmine, Iris", base_notes: "Vetiver, Sandalwood, Vanilla, Musk", release_year: 1921, season: "All Seasons", description: "The world's most iconic fragrance, a floral aldehyde masterpiece.", price_range: "$$$" },
    { name: "Chanel No. 19", type: "Eau de Parfum", gender: "Women", top_notes: "Galbanum, Neroli, Bergamot", heart_notes: "Rose, Iris, Jasmine", base_notes: "Vetiver, Cedarwood, Oakmoss, Musk", release_year: 1970, season: "Spring", description: "A fresh, green floral with a powdery iris heart.", price_range: "$$$" },
    { name: "Coco Mademoiselle", type: "Eau de Parfum", gender: "Women", top_notes: "Orange, Bergamot, Grapefruit", heart_notes: "Rose, Jasmine, Mimosa", base_notes: "Patchouli, Vetiver, Vanilla, White Musk", release_year: 2001, season: "All Seasons", description: "A modern oriental floral with an audacious, feminine character.", price_range: "$$$" },
    { name: "Chance", type: "Eau de Toilette", gender: "Women", top_notes: "Pink Pepper, Pineapple, Grapefruit", heart_notes: "Hyacinth, Jasmine, Iris", base_notes: "Patchouli, White Musk, Amber, Vetiver", release_year: 2002, season: "Spring", description: "A round, floral fragrance full of freshness and femininity.", price_range: "$$$" },
    { name: "Bleu de Chanel", type: "Eau de Parfum", gender: "Men", top_notes: "Grapefruit, Lemon, Mint, Pink Pepper", heart_notes: "Ginger, Nutmeg, Jasmine", base_notes: "Labdanum, Sandalwood, Patchouli, Vetiver", release_year: 2010, season: "All Seasons", description: "A woody aromatic fragrance with a clean, noble intensity.", price_range: "$$$" },
    { name: "Allure Homme Sport", type: "Eau de Toilette", gender: "Men", top_notes: "Aldehyde, Citrus, Sea Notes", heart_notes: "Pepper, Cedar, Elemi", base_notes: "White Musk, Tonka Bean, Vanilla", release_year: 2004, season: "Summer", description: "An energetic, refreshing fragrance for active men.", price_range: "$$$" },
    { name: "Coco Noir", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Grapefruit, Cambodian Oud", heart_notes: "Rose, Jasmine, Geranium", base_notes: "Sandalwood, Patchouli, Vetiver, White Musk", release_year: 2012, season: "Fall", description: "A sensual, opulent oriental floral with mysterious depth.", price_range: "$$$" },
    { name: "Gabrielle", type: "Eau de Parfum", gender: "Women", top_notes: "Blackcurrant, Mandarin, Water Hyacinth", heart_notes: "Jasmine, Ylang-Ylang, Orange Blossom, Grasse Rose", base_notes: "Coconut, Sandalwood, Musk", release_year: 2017, season: "Spring", description: "A rich white floral bouquet celebrating freedom and femininity.", price_range: "$$$" },
    { name: "Chance Eau Tendre", type: "Eau de Toilette", gender: "Women", top_notes: "Grapefruit, Quince", heart_notes: "Jasmine, Iris", base_notes: "Musk, Cedarwood, Amber", release_year: 2010, season: "Spring", description: "A delicate, watery floral expressing lightness and elegance.", price_range: "$$$" },
    { name: "Allure", type: "Eau de Parfum", gender: "Women", top_notes: "Mandarin, Aldehydes, Peach", heart_notes: "Iris, Rose, Jasmine, Lily of the Valley", base_notes: "Vanilla, Vetiver, Amber", release_year: 1996, season: "All Seasons", description: "A timeless classic embodying the allure of Chanel.", price_range: "$$$" },
  ],
  "Dior": [
    { name: "Sauvage", type: "Eau de Parfum", gender: "Men", top_notes: "Bergamot, Pepper", heart_notes: "Sichuan Pepper, Lavender, Pink Pepper, Vetiver, Patchouli", base_notes: "Ambroxan, Cedar, Labdanum", release_year: 2015, season: "All Seasons", description: "A radically fresh composition with a raw and noble character.", price_range: "$$$" },
    { name: "Miss Dior", type: "Eau de Parfum", gender: "Women", top_notes: "Aldehydes, Gardenia, Neroli", heart_notes: "Rose, Jasmine, Lily of the Valley, Iris", base_notes: "Oakmoss, Sandalwood, Vetiver", release_year: 1947, season: "Spring", description: "The quintessential Dior feminine, elegant and timeless.", price_range: "$$$" },
    { name: "J'adore", type: "Eau de Parfum", gender: "Women", top_notes: "Cantaloupe, Pear, Magnolia, Ivy, Peach, Melon, Bergamot", heart_notes: "Orchid, Violet, Rose, Jasmine, Lily of the Valley", base_notes: "Blackberry Musk, Sandalwood, Cedar, Amber, Precious Woods", release_year: 1999, season: "All Seasons", description: "A floral bouquet embodying femininity and radiance.", price_range: "$$$" },
    { name: "Dior Homme", type: "Eau de Toilette", gender: "Men", top_notes: "Lavender, Sage, Bergamot, Pink Pepper, Lemon", heart_notes: "Iris, Vetiver, Cacao", base_notes: "Patchouli, Ambergris, Vanilla", release_year: 2005, season: "Fall", description: "A sophisticated, powdery iris scent redefining masculine elegance.", price_range: "$$$" },
    { name: "Hypnotic Poison", type: "Eau de Toilette", gender: "Women", top_notes: "Bitter Almond, Coconut, Carrot, Plum, Apricot, Jasmine", heart_notes: "Jasmine, Tuberose", base_notes: "Sandalwood, Musk, Vanilla", release_year: 1998, season: "Fall", description: "A sensual, addictive oriental with mysterious allure.", price_range: "$$$" },
    { name: "Fahrenheit", type: "Eau de Toilette", gender: "Men", top_notes: "Hawthorn, Mandarin, Lavender, Chamomile, Cedar Leaf, Violet Leaf", heart_notes: "Violet, Honeysuckle, Lily of the Valley, Carnation, Nutmeg", base_notes: "Leather, Amber, Vetiver, Musk, Sandal", release_year: 1988, season: "Winter", description: "An iconic masculine, bold and revolutionary leather-woody.", price_range: "$$$" },
    { name: "Poison Girl", type: "Eau de Parfum", gender: "Women", top_notes: "Orange, Bitter Orange", heart_notes: "Rose, Grasse Rose, Damask Rose", base_notes: "Vanilla, Almond", release_year: 2016, season: "Winter", description: "A modern, captivating oriental with an addictive sweetness.", price_range: "$$$" },
    { name: "Miss Dior Blooming Bouquet", type: "Eau de Toilette", gender: "Women", top_notes: "Sicilian Mandarin, Pear Blossom, Strawberry Leaf", heart_notes: "Peony, Damascus Rose, Pink Magnolia", base_notes: "White Musk, Patchouli", release_year: 2007, season: "Spring", description: "A light, feminine floral celebrating the joy of spring.", price_range: "$$$" },
    { name: "Diorissimo", type: "Eau de Toilette", gender: "Women", top_notes: "Aldehyde, Gardenia, Rosewood", heart_notes: "Lily of the Valley, Ylang-Ylang, Boronia", base_notes: "Sandalwood, Civet, Musk", release_year: 1956, season: "Spring", description: "A pristine, pure lily of the valley masterpiece.", price_range: "$$$" },
    { name: "Eau Sauvage", type: "Eau de Toilette", gender: "Men", top_notes: "Rosemary, Basil, Lemon, Bergamot, Citron", heart_notes: "Jasmine, Rose, Carnation, Iris", base_notes: "Oakmoss, Vetiver, Musk, Civet, Labdanum", release_year: 1966, season: "Summer", description: "A timeless classic that defined clean masculine elegance.", price_range: "$$$" },
  ],
  "Tom Ford": [
    { name: "Black Orchid", type: "Eau de Parfum", gender: "Unisex", top_notes: "Truffle, Gardenia, Black Currant, Ylang-Ylang, Jasmine, Bergamot, Mandarin", heart_notes: "Orchid, Spices, Gardenia, Fruity Notes, Lotus Wood", base_notes: "Patchouli, Oakmoss, Sandalwood, Dark Chocolate, Incense, Vetiver", release_year: 2006, season: "Winter", description: "A sumptuous, sensual oriental with rare black orchid.", price_range: "$$$$" },
    { name: "Oud Wood", type: "Eau de Parfum", gender: "Unisex", top_notes: "Oud, Rosewood, Cardamom", heart_notes: "Sandalwood, Vetiver, Tonka Bean, Amber", base_notes: "Vanilla, Chinese Pepper", release_year: 2007, season: "Winter", description: "A rare, exotic oud elevated with sensual woods.", price_range: "$$$$" },
    { name: "Tobacco Vanille", type: "Eau de Parfum", gender: "Unisex", top_notes: "Tobacco Leaf, Spices", heart_notes: "Vanilla, Tonka Bean, Tobacco Blossom", base_notes: "Dry Fruit, Woody Notes", release_year: 2007, season: "Winter", description: "A rich, warm tobacco and vanilla oriental.", price_range: "$$$$" },
    { name: "Noir Extreme", type: "Eau de Parfum", gender: "Men", top_notes: "Cardamom, Mandarin, Nutmeg", heart_notes: "Oud, Rose, Jasmine, Amber", base_notes: "Musk, Sandalwood, Tonka Bean, Vanilla", release_year: 2015, season: "Fall", description: "An opulent oriental with a seductive amber character.", price_range: "$$$$" },
    { name: "Lost Cherry", type: "Eau de Parfum", gender: "Unisex", top_notes: "Sour Cherry, Black Cherry", heart_notes: "Turkish Rose, Jasmine Sambac", base_notes: "Tonka Bean, Benzyl Benzoate, Peru Balsam, Sandalwood, Roasted Tonka", release_year: 2019, season: "Fall", description: "An intoxicating gourmand cherry with roasted depth.", price_range: "$$$$" },
    { name: "Neroli Portofino", type: "Eau de Parfum", gender: "Unisex", top_notes: "Sicilian Bergamot, Lemon, Mandarin, Myrtle, Rosemary, Lavender", heart_notes: "Neroli, Orange Blossom, Jasmine, Pitosporum", base_notes: "Amber, Musk, Ambrette Seeds, Oakmoss", release_year: 2011, season: "Summer", description: "A shimmering citrus-floral capturing the Mediterranean coast.", price_range: "$$$$" },
    { name: "Sole di Positano", type: "Eau de Parfum", gender: "Unisex", top_notes: "Lemon, Tangerine, Mandarin", heart_notes: "Neroli, Coconut, Fleur de Sel", base_notes: "Musk, Sandalwood, Cashmeran", release_year: 2016, season: "Summer", description: "A sunny, luminous Mediterranean escape.", price_range: "$$$$" },
    { name: "Tuscan Leather", type: "Eau de Parfum", gender: "Unisex", top_notes: "Saffron, Thyme, Raspberry", heart_notes: "Jasmine, Olibanum", base_notes: "Leather, Suede, Amber, Musk", release_year: 2007, season: "Fall", description: "A bold, luxurious leather for those who command attention.", price_range: "$$$$" },
    { name: "Grey Vetiver", type: "Eau de Toilette", gender: "Men", top_notes: "Grapefruit, Sage, Orange", heart_notes: "Vetiver, Woody Notes, Floral Notes, Geranium", base_notes: "Oakmoss, Musk, Amber", release_year: 2009, season: "Fall", description: "A refined, elegant vetiver with sophisticated woody accents.", price_range: "$$$$" },
    { name: "White Patchouli", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Pink Pepper, Green Iris", heart_notes: "White Patchouli, Flower of Patchouli, Rose", base_notes: "Musk, Amber, Civet", release_year: 2008, season: "Spring", description: "A clean, luminous patchouli reimagined for modern femininity.", price_range: "$$$$" },
  ],
  "Creed": [
    { name: "Aventus", type: "Eau de Parfum", gender: "Men", top_notes: "Pineapple, Bergamot, Black Currant, Apple", heart_notes: "Rose, Dry Birch, Moroccan Jasmine, Patchouli", base_notes: "Oak Moss, Ambergris, Musk, Vanilla", release_year: 2010, season: "All Seasons", description: "The legendary masculine fragrance celebrating power and success.", price_range: "$$$$" },
    { name: "Silver Mountain Water", type: "Eau de Parfum", gender: "Men", top_notes: "Bergamot, Mandarin, Green Tea", heart_notes: "Black Current Bud, Galbanum, Peach", base_notes: "Musk, Sandalwood, Mineral Water", release_year: 1995, season: "Spring", description: "A fresh, aquatic inspired by Swiss mountain streams.", price_range: "$$$$" },
    { name: "Green Irish Tweed", type: "Eau de Parfum", gender: "Men", top_notes: "Lemon Verbena, Violet Leaves, Iris", heart_notes: "French Lavender, Sandalwood", base_notes: "Ambergris, Cashmere", release_year: 1985, season: "Spring", description: "A timeless fresh green masculine evoking the Irish countryside.", price_range: "$$$$" },
    { name: "Love in White", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Neroli, Iris, Magnolia", heart_notes: "Orris, Ylang-Ylang, Bulgarian Rose, Cyclamen, Jasmine", base_notes: "Musk, Rice, Sandalwood, Vanilla, Civet", release_year: 2005, season: "Spring", description: "A romantic white floral with radiant femininity.", price_range: "$$$$" },
    { name: "Bois du Portugal", type: "Eau de Parfum", gender: "Men", top_notes: "Lavender, Bergamot, Rosemary", heart_notes: "Labdanum, Rose, Cedar", base_notes: "Sandalwood, Ambergris, Oakmoss, Musk", release_year: 1987, season: "Winter", description: "A distinguished woody fougere for the refined gentleman.", price_range: "$$$$" },
    { name: "Himalaya", type: "Eau de Parfum", gender: "Men", top_notes: "Grapefruit, Apple, Lemon", heart_notes: "Geranium, Iris, Jasmine", base_notes: "Musk, Sandalwood, Ambergris", release_year: 2002, season: "Spring", description: "A fresh, clean aquatic-woody masculine.", price_range: "$$$$" },
    { name: "Millesime Imperial", type: "Eau de Parfum", gender: "Unisex", top_notes: "Sea Notes, Iris, Citrus", heart_notes: "Musky Notes, Melon", base_notes: "White Musks, Ambergris", release_year: 1995, season: "Summer", description: "A luxurious marine fragrance of imperial elegance.", price_range: "$$$$" },
    { name: "Fleurs de Bulgarie", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Rose", heart_notes: "Rose, Musk", base_notes: "Civet, Musk, Ambergris", release_year: 1845, season: "Spring", description: "The most precious rose fragrance, using rare Bulgarian roses.", price_range: "$$$$" },
    { name: "Royal Oud", type: "Eau de Parfum", gender: "Unisex", top_notes: "Lemon, Galbanum, Pink Pepper, Cardamom, Cypress", heart_notes: "Moroccan Jasmine, Angelica, Oud", base_notes: "Sandalwood, Leather, Musk", release_year: 2011, season: "Winter", description: "A majestic oud composition of regal sophistication.", price_range: "$$$$" },
    { name: "Viking", type: "Eau de Parfum", gender: "Men", top_notes: "Bergamot, Pink Pepper, Elemi", heart_notes: "Lavender, Peppermint, Geranium", base_notes: "Sandalwood, Vetiver, Birch", release_year: 2017, season: "Winter", description: "A bold, powerful fougere celebrating the fearless spirit.", price_range: "$$$$" },
  ],
  "Maison Francis Kurkdjian": [
    { name: "Baccarat Rouge 540", type: "Eau de Parfum", gender: "Unisex", top_notes: "Jasmine, Saffron", heart_notes: "Amberwood, Ambergris", base_notes: "Fir Resin, Cedar", release_year: 2015, season: "All Seasons", description: "An iconic, mineral and luminous amber that became a phenomenon.", price_range: "$$$$" },
    { name: "Grand Soir", type: "Eau de Parfum", gender: "Unisex", top_notes: "Tonka Bean", heart_notes: "Amber, Benzoin", base_notes: "Musk, Vanilla", release_year: 2017, season: "Winter", description: "A warm, sensual amber for memorable evenings.", price_range: "$$$$" },
    { name: "Aqua Universalis", type: "Eau de Toilette", gender: "Unisex", top_notes: "Bergamot, Lemon, Neroli", heart_notes: "White Flowers, Lily of the Valley", base_notes: "White Musk, Sandalwood", release_year: 2009, season: "Summer", description: "A pure, radiant white floral of absolute clarity.", price_range: "$$$$" },
    { name: "Oud Satin Mood", type: "Eau de Parfum", gender: "Unisex", top_notes: "Rose, Violet", heart_notes: "Oud", base_notes: "Vanilla, Musk", release_year: 2016, season: "Winter", description: "A luxurious rose and oud of silky, velvety richness.", price_range: "$$$$" },
    { name: "L'Homme à la Rose", type: "Eau de Parfum", gender: "Men", top_notes: "Grapefruit, Rose, Magnolia", heart_notes: "Rose", base_notes: "Ambrette, White Musk", release_year: 2021, season: "Spring", description: "A masculine rose both fresh and sophisticated.", price_range: "$$$$" },
    { name: "Gentle Fluidity Gold", type: "Eau de Parfum", gender: "Unisex", top_notes: "Bergamot, Coriander, Clary Sage", heart_notes: "Nutmeg, Juniper Berries, Musk", base_notes: "Vanilla, Amber, Sandalwood", release_year: 2019, season: "All Seasons", description: "A golden, warm oriental with gentle spices.", price_range: "$$$$" },
    { name: "APOM pour Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Orange Blossom", heart_notes: "Rose, Jasmine, Magnolia", base_notes: "Patchouli, Musk", release_year: 2009, season: "Spring", description: "A luminous floral celebrating the essence of femininity.", price_range: "$$$$" },
    { name: "724", type: "Eau de Parfum", gender: "Unisex", top_notes: "Bergamot", heart_notes: "Vetiver, Orris", base_notes: "White Musk, Cashmeran", release_year: 2022, season: "All Seasons", description: "A clean, transparent scent for the modern nomad.", price_range: "$$$$" },
    { name: "Amyris Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Grapefruit", heart_notes: "Jasmine, Amyris", base_notes: "Cedar, Musk", release_year: 2012, season: "All Seasons", description: "A fresh, woody floral with a modern femininity.", price_range: "$$$$" },
    { name: "Lumière Noire pour Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Bulgarian Rose, Raspberry", heart_notes: "Patchouli, Labdanum", base_notes: "Musk, Amber", release_year: 2009, season: "Fall", description: "A dark, mysterious rose on a sensual patchouli base.", price_range: "$$$$" },
  ],
  "Le Labo": [
    { name: "Santal 33", type: "Eau de Parfum", gender: "Unisex", top_notes: "Violet Accord, Cardamom, Iris", heart_notes: "Sandalwood, Papyrus, Leather, Ambrette Seeds", base_notes: "Musk, Cedarwood, Sandalwood", release_year: 2011, season: "All Seasons", description: "The cult sandalwood fragrance that became a generation's signature scent.", price_range: "$$$$" },
    { name: "Rose 31", type: "Eau de Parfum", gender: "Unisex", top_notes: "Rose, Cumin, Cedar", heart_notes: "Labdanum, Musk, Oud", base_notes: "Vetiver, Amber, Cistus", release_year: 2006, season: "Fall", description: "A bold, masculine rose pushed into dark, woody territory.", price_range: "$$$$" },
    { name: "Bergamote 22", type: "Eau de Parfum", gender: "Unisex", top_notes: "Bergamot, Neroli, Petitgrain", heart_notes: "Muguet, Ambrette", base_notes: "Musk, Amber", release_year: 2006, season: "Summer", description: "A bright, zesty bergamot with an addictive warmth.", price_range: "$$$$" },
    { name: "Vetiver 46", type: "Eau de Parfum", gender: "Unisex", top_notes: "Vetiver", heart_notes: "Vetiver, Myrrh, Elemi, Olibanum, Virginia Cedar", base_notes: "Vetiver, Amber, Musk", release_year: 2010, season: "Fall", description: "A smoky, earthy vetiver of exceptional complexity.", price_range: "$$$$" },
    { name: "Noir 29", type: "Eau de Parfum", gender: "Unisex", top_notes: "Figs, Guaiac Wood, Black Tea", heart_notes: "Musk, Sandalwood", base_notes: "Amber, Musk", release_year: 2012, season: "Fall", description: "A dark, sophisticated fig with smoky woody depth.", price_range: "$$$$" },
    { name: "Lys 41", type: "Eau de Parfum", gender: "Unisex", top_notes: "Lily, Lily of the Valley", heart_notes: "Musk, Grapefruit, Rose", base_notes: "Musks, Sandalwood", release_year: 2010, season: "Spring", description: "An intoxicating, radiant white lily of hypnotic beauty.", price_range: "$$$$" },
    { name: "Patchouli 24", type: "Eau de Parfum", gender: "Unisex", top_notes: "Birch Tar, Lavender", heart_notes: "Patchouli, Vanilla", base_notes: "Amber, Musk", release_year: 2006, season: "Winter", description: "A smoky, woody patchouli with a campfire warmth.", price_range: "$$$$" },
    { name: "Thé Matcha 26", type: "Eau de Parfum", gender: "Unisex", top_notes: "Matcha, Pepper, Cedar Leaf", heart_notes: "Musk, Wood Accord", base_notes: "Cedar, Amber", release_year: 2018, season: "Spring", description: "A serene, aromatic green tea of meditative calm.", price_range: "$$$$" },
    { name: "Labdanum 18", type: "Eau de Parfum", gender: "Unisex", top_notes: "Labdanum, Grapefruit", heart_notes: "Amber, Tonka Bean", base_notes: "Musk, Sandalwood", release_year: 2006, season: "Winter", description: "A resinous, warm amber of honeyed sensuality.", price_range: "$$$$" },
    { name: "Géranium 30", type: "Eau de Parfum", gender: "Unisex", top_notes: "Geranium, Rose, Mint", heart_notes: "Patchouli, Amber, Olibanum", base_notes: "Musk, Vetiver", release_year: 2006, season: "Summer", description: "A vivid, aromatic geranium with a refreshing green character.", price_range: "$$$$" },
  ],
  "YSL": [
    { name: "Black Opium", type: "Eau de Parfum", gender: "Women", top_notes: "Pink Pepper, Orange Blossom, Pear", heart_notes: "Coffee, Jasmine", base_notes: "Patchouli, Cedar, Cashmere, Vanilla", release_year: 2013, season: "Fall", description: "An addictive, rock-chic feminine with coffee and white flowers.", price_range: "$$$" },
    { name: "Libre", type: "Eau de Parfum", gender: "Women", top_notes: "Lavender, Petitgrain Essence", heart_notes: "Orange Blossom Absolute, Jasmine, Lavender", base_notes: "Vanilla, Ambergris, Musk, Oakmoss", release_year: 2019, season: "All Seasons", description: "A freedom-celebrating floral with a bold lavender-vanilla accord.", price_range: "$$$" },
    { name: "Opium", type: "Eau de Parfum", gender: "Women", top_notes: "Cloves, Aldehydes, Plum, Bergamot, Mandarin, Pepper, Coriander, Orris", heart_notes: "Rose, Carnation, Peach, Lily of the Valley, Jasmine, Balsam, Ylang-Ylang", base_notes: "Labdanum, Benzoin, Sandalwood, Myrrh, Opoponax, Cedarwood, Vetiver", release_year: 1977, season: "Winter", description: "A landmark oriental of intense, sumptuous richness.", price_range: "$$$" },
    { name: "Mon Paris", type: "Eau de Parfum", gender: "Women", top_notes: "Strawberry, Raspberry, Pear, Chypre, White Patchouli", heart_notes: "Datura, Peony, Rose", base_notes: "Patchouli, Musk, Ambrette", release_year: 2016, season: "Spring", description: "A passionate love story captured in a floral chypre.", price_range: "$$$" },
    { name: "Y", type: "Eau de Parfum", gender: "Men", top_notes: "Bergamot, Ginger, Apple", heart_notes: "Geranium, Violet Leaf, Sage", base_notes: "Amberwood, Cedar, Fir Balsam", release_year: 2017, season: "All Seasons", description: "A bold, aromatic woody for the confident modern man.", price_range: "$$$" },
    { name: "Kouros", type: "Eau de Toilette", gender: "Men", top_notes: "Aldehydes, Coriander, Bergamot, Artemisia", heart_notes: "Cyclamen, Geranium, Orris Root, Jasmine, Rose", base_notes: "Leather, Amber, Musk, Oakmoss, Vetiver, Civet, Benzoin, Woody Notes", release_year: 1981, season: "Winter", description: "A legendary masculine of raw, mythological power.", price_range: "$$" },
    { name: "Paris", type: "Eau de Parfum", gender: "Women", top_notes: "Violet, Blackcurrant Bud, Mimosa, Rose", heart_notes: "Rose Centifolia, Violet, Hawthorn Blossom, Lily of the Valley", base_notes: "Musk, Sandalwood, Iris, Ambergris, Civet", release_year: 1983, season: "Spring", description: "An iconic romantic rose ode to the City of Light.", price_range: "$$$" },
    { name: "In Love Again", type: "Eau de Toilette", gender: "Women", top_notes: "Kiwi, Mandarin, Strawberry, Grapefruit", heart_notes: "Rose, Peony, Magnolia, Jasmine", base_notes: "White Musk, Cedar", release_year: 1998, season: "Spring", description: "A joyful, luminous fruity-floral of pure happiness.", price_range: "$$" },
    { name: "Jazz", type: "Eau de Toilette", gender: "Men", top_notes: "Bergamot, Basil, Juniper", heart_notes: "Cloves, Cedar, Rosewood, Lily of the Valley", base_notes: "Musk, Sandalwood, Vetiver, Amber", release_year: 1988, season: "Fall", description: "A smooth, sophisticated aromatic masculine.", price_range: "$$" },
    { name: "Elle", type: "Eau de Parfum", gender: "Women", top_notes: "Rhubarb, Peony, Litchi", heart_notes: "Rose, Patchouli, Magnolia", base_notes: "Vetiver, Sandalwood, White Musk", release_year: 2006, season: "Spring", description: "A confident, contemporary feminine with bold rose at heart.", price_range: "$$$" },
  ],
  "Versace": [
    { name: "Eros", type: "Eau de Toilette", gender: "Men", top_notes: "Mint, Green Apple, Lemon", heart_notes: "Tonka Bean, Ambroxan, Geranium", base_notes: "Oakmoss, Vanilla, Cedarwood, Vetiver", release_year: 2012, season: "Summer", description: "A bold, passionate masculine inspired by the Greek god of love.", price_range: "$$" },
    { name: "Bright Crystal", type: "Eau de Toilette", gender: "Women", top_notes: "Pomegranate, Yuzu, Frosted Accord", heart_notes: "Magnolia, Lotus, Peony", base_notes: "Musk, Amber, Mahogany", release_year: 2006, season: "Spring", description: "A bright, floral gem celebrating feminine radiance.", price_range: "$$" },
    { name: "Dylan Blue", type: "Eau de Toilette", gender: "Men", top_notes: "Fig Leaves, Grapefruit, Aqua Accord", heart_notes: "Patchouli, Papyrus, Saffron, Violet Leaf", base_notes: "Musk, Tonka Bean, Amberwood", release_year: 2016, season: "Summer", description: "A fresh aquatic-woody capturing Mediterranean sensuality.", price_range: "$$" },
    { name: "Crystal Noir", type: "Eau de Parfum", gender: "Women", top_notes: "Ginger, Pepper, Cardamom", heart_notes: "Gardenia, Peony, Coconut", base_notes: "Amber, Musk, Sandalwood", release_year: 2004, season: "Fall", description: "A seductive, mysterious oriental floral.", price_range: "$$" },
    { name: "Pour Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Nectarine, Mandarin, Rose", heart_notes: "Tuberose, Cyclamen, Rose, Coriander", base_notes: "Sandalwood, Musk, Tonka Bean, Oakmoss", release_year: 2002, season: "All Seasons", description: "A timeless feminine of classic luxury.", price_range: "$$" },
    { name: "The Dreamer", type: "Eau de Toilette", gender: "Men", top_notes: "Tarragon, Iris, Flax", heart_notes: "Tobacco, Guaiac Wood, Gaiac, Lily", base_notes: "Vanilla, Amber, Musk", release_year: 1996, season: "Fall", description: "A dreamlike tobacco-floral of poetic, nostalgic warmth.", price_range: "$$" },
    { name: "Yellow Diamond", type: "Eau de Toilette", gender: "Women", top_notes: "Pear, Lemon, Neroli, Freesia", heart_notes: "Water Lily, Amalfi Citrus, Rose, Mimosa", base_notes: "Musk, Amber, Guaiac Wood", release_year: 2011, season: "Spring", description: "A sparkling, luminous floral like a precious gem.", price_range: "$$" },
    { name: "Versace Man Eau Fraîche", type: "Eau de Toilette", gender: "Men", top_notes: "Lemon, Rosewood, Bergamot, Carambola", heart_notes: "Rosewood, Anise, Cedar", base_notes: "Musk, White Musk, Amber, Sycamore", release_year: 2006, season: "Summer", description: "A refreshing, clean aquatic-woody for modern men.", price_range: "$$" },
    { name: "Atelier Versace Éros pour Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Lemon, Pomegranate, Peony", heart_notes: "Jasmine Sambac, Peony", base_notes: "Sandalwood, Musk", release_year: 2014, season: "Spring", description: "A luminous white floral of passionate femininity.", price_range: "$$$" },
    { name: "Medusa Rhapsody", type: "Eau de Parfum", gender: "Women", top_notes: "Lemon Sorbet, Bergamot, Elderflower", heart_notes: "Jasmine, Peony, Iris", base_notes: "Vetiver, Cedarwood, Sandalwood, Musk", release_year: 2023, season: "Spring", description: "A modern feminine floral of timeless Versace glamour.", price_range: "$$$" },
  ],
  "Prada": [
    { name: "Luna Rossa", type: "Eau de Toilette", gender: "Men", top_notes: "Bergamot, Labdanum", heart_notes: "Ambrette, Lavender", base_notes: "Musk", release_year: 2012, season: "Summer", description: "A clean, sporty masculine inspired by sailing and the sea.", price_range: "$$$" },
    { name: "Infusion d'Iris", type: "Eau de Parfum", gender: "Women", top_notes: "Mandarin Orange, Galbanum, Neroli", heart_notes: "Iris, Cedar, Orange Blossom", base_notes: "Vetiver, Benzoin, White Musk", release_year: 2007, season: "Spring", description: "A sheer, powdery iris of refined minimalist elegance.", price_range: "$$$" },
    { name: "Candy", type: "Eau de Parfum", gender: "Women", top_notes: "Caramel", heart_notes: "White Musk, Musks, Benzoin", base_notes: "Labdanum", release_year: 2011, season: "Winter", description: "An addictive, playful gourmand of irresistible sweetness.", price_range: "$$$" },
    { name: "La Femme", type: "Eau de Parfum", gender: "Women", top_notes: "Ylang-Ylang, Frangipani, Tiare", heart_notes: "Iris, Peach, Heliotrope", base_notes: "Vanilla, Sandalwood, Cedarwood", release_year: 2016, season: "Summer", description: "A tropical floral of sophisticated sensuality.", price_range: "$$$" },
    { name: "L'Homme", type: "Eau de Toilette", gender: "Men", top_notes: "Bergamot, Iris, Neroli", heart_notes: "Iris, Amber", base_notes: "Cedar, Vetiver, Musk", release_year: 2008, season: "All Seasons", description: "A refined iris-woody signature of modern masculine elegance.", price_range: "$$$" },
    { name: "Amber Pour Homme", type: "Eau de Toilette", gender: "Men", top_notes: "Neroli, Bitter Orange", heart_notes: "Patchouli, Sandalwood, Rose", base_notes: "Labdanum, Leather, Amber", release_year: 2006, season: "Fall", description: "A sophisticated amber fougere of timeless masculinity.", price_range: "$$$" },
    { name: "Paradoxe", type: "Eau de Parfum", gender: "Women", top_notes: "Neroli, Bergamot", heart_notes: "Iris, Jasmine", base_notes: "Sandalwood, Musk, Amber", release_year: 2022, season: "All Seasons", description: "A luminous, multifaceted floral celebrating contradictions.", price_range: "$$$" },
    { name: "Infusion d'Homme", type: "Eau de Toilette", gender: "Men", top_notes: "Neroli, Orange, Iris", heart_notes: "Iris, Cedar", base_notes: "Vetiver, Incense, Musk", release_year: 2008, season: "Spring", description: "A fresh, clean aromatic of understated luxury.", price_range: "$$$" },
    { name: "Olfactories Valmont", type: "Eau de Parfum", gender: "Unisex", top_notes: "Bergamot, Grapefruit", heart_notes: "Iris, Cedar, Vetiver", base_notes: "Sandalwood, Musk", release_year: 2018, season: "All Seasons", description: "An olfactory journey in the Prada exclusive collection.", price_range: "$$$$" },
    { name: "Candy Kiss", type: "Eau de Parfum", gender: "Women", top_notes: "Orange Blossom, Neroli", heart_notes: "Musks, Rose, Iris", base_notes: "Vanilla, Caramel, Benzoin", release_year: 2016, season: "Winter", description: "A flirtatious, romantic feminine with floral sweetness.", price_range: "$$$" },
  ],
  "Kilian": [
    { name: "Good Girl Gone Bad", type: "Eau de Parfum", gender: "Women", top_notes: "Rose, Tuberose, Iris", heart_notes: "Ylang-Ylang, Narcissus, Osmanthus", base_notes: "Vetiver, Musk", release_year: 2012, season: "Spring", description: "A white floral bouquet of intoxicating heady blossoms.", price_range: "$$$$" },
    { name: "Love", type: "Eau de Parfum", gender: "Unisex", top_notes: "Lemon, Neroli, Rose", heart_notes: "Rose, Jasmine", base_notes: "Musk, Ambergris, Vanilla", release_year: 2007, season: "All Seasons", description: "A timeless love letter captured in an exquisite floral.", price_range: "$$$$" },
    { name: "Black Phantom", type: "Eau de Parfum", gender: "Unisex", top_notes: "Rum, Coffee", heart_notes: "Orris, Jasmine", base_notes: "Sugar Cane, Caramel, Musk, Vetiver", release_year: 2015, season: "Winter", description: "A dangerously seductive gourmand for the bold.", price_range: "$$$$" },
    { name: "Angels' Share", type: "Eau de Parfum", gender: "Unisex", top_notes: "Cognac, Bourbon Vanilla", heart_notes: "Cinnamon, Oak, Tonka Bean", base_notes: "Sandalwood, Musk, Praline", release_year: 2020, season: "Winter", description: "A luxurious cognac-inspired warmth of addictive sophistication.", price_range: "$$$$" },
    { name: "Moonlight in Heaven", type: "Eau de Parfum", gender: "Unisex", top_notes: "Lychee, Yuzu, Grapefruit", heart_notes: "Neroli, Cyclamen, White Rose", base_notes: "Coconut, Violet, Musks", release_year: 2015, season: "Summer", description: "A luminous, tropical moonlit escape of pure bliss.", price_range: "$$$$" },
    { name: "Straight to Heaven", type: "Eau de Parfum", gender: "Men", top_notes: "Armagnac, Rum", heart_notes: "White Musk, Sandalwood, Cedar", base_notes: "Vetiver, Mate, Musk", release_year: 2007, season: "Winter", description: "A boozy, woody masculine of intoxicating appeal.", price_range: "$$$$" },
    { name: "Roses on Ice", type: "Eau de Parfum", gender: "Women", top_notes: "Frosted Rose, Litchi", heart_notes: "Rose, Violet", base_notes: "Musks, Sandalwood", release_year: 2016, season: "Summer", description: "A fresh, icy rose with sparkling luminosity.", price_range: "$$$$" },
    { name: "Voulez-vous Coucher avec Moi", type: "Eau de Parfum", gender: "Women", top_notes: "Rose, Iris", heart_notes: "Jasmine, Tuberose", base_notes: "Musk, Amber, Sandalwood", release_year: 2007, season: "Spring", description: "A provocative floral of bold, confident femininity.", price_range: "$$$$" },
    { name: "Smoking Hot", type: "Eau de Parfum", gender: "Unisex", top_notes: "Cardamom, Black Pepper", heart_notes: "Rose, Oud", base_notes: "Leather, Musk, Tobacco", release_year: 2020, season: "Fall", description: "A smoky, sensual leather rose of magnetic allure.", price_range: "$$$$" },
    { name: "In the City of Sin", type: "Eau de Parfum", gender: "Women", top_notes: "Red Fruits, Peach", heart_notes: "Jasmine, Rose", base_notes: "Musk, Amber, Sandalwood", release_year: 2012, season: "Fall", description: "A seductive fruity-oriental of irresistible temptation.", price_range: "$$$$" },
  ],
  "Paco Rabanne": [
    { name: "1 Million", type: "Eau de Toilette", gender: "Men", top_notes: "Blood Mandarin, Grapefruit, Mint", heart_notes: "Rose, Cinnamon, Spices", base_notes: "Leather, Amber, Patchouli, Blond Wood", release_year: 2008, season: "Fall", description: "A bold, golden masculine of opulent seduction.", price_range: "$$" },
    { name: "Lady Million", type: "Eau de Parfum", gender: "Women", top_notes: "Neroli, Raspberry, Grapefruit", heart_notes: "Arabian Jasmine, Orange Blossom", base_notes: "Honey, Patchouli, White Musk", release_year: 2010, season: "Spring", description: "A sparkling floral of dazzling, diamond-bright femininity.", price_range: "$$" },
    { name: "Olympéa", type: "Eau de Parfum", gender: "Women", top_notes: "Fresh Water, Green Mandarin, Ginger Lily", heart_notes: "Jasmine, Salted Vanilla", base_notes: "Ambergris, Cashmere Wood", release_year: 2015, season: "Summer", description: "An aquatic, sensual feminine of modern goddess power.", price_range: "$$" },
    { name: "Invictus", type: "Eau de Toilette", gender: "Men", top_notes: "Grapefruit, Marine Accord, Bay Laurel", heart_notes: "Hedione, Jasmine, Guaiac Wood", base_notes: "Oakmoss, Ambergris, Patchouli", release_year: 2013, season: "Summer", description: "A fresh, athletic masculine of victorious energy.", price_range: "$$" },
    { name: "Black XS", type: "Eau de Toilette", gender: "Men", top_notes: "Lemon, Pink Pepper, Star Anise", heart_notes: "Heliotrope, Rose, Patchouli", base_notes: "Leather, Labdanum, Amber", release_year: 2005, season: "Fall", description: "A rock-edgy masculine with a rebellious spirit.", price_range: "$$" },
    { name: "Calandre", type: "Eau de Parfum", gender: "Women", top_notes: "Aldehydes, Bergamot, Peach, Hyacinth", heart_notes: "Rose, Lily of the Valley, Iris, Jasmine", base_notes: "Vetiver, Sandalwood, Musk, Oakmoss", release_year: 1969, season: "Spring", description: "A revolutionary metallic floral from the space age.", price_range: "$$" },
    { name: "Fame", type: "Eau de Parfum", gender: "Women", top_notes: "Mango, Plum", heart_notes: "Jasmine", base_notes: "Woody Notes, Musk", release_year: 2022, season: "Summer", description: "A bold, vivid fruity-floral celebrating feminine power.", price_range: "$$" },
    { name: "Phantom", type: "Eau de Toilette", gender: "Men", top_notes: "Lemon, Lavender, Vetiver", heart_notes: "Cashmeran, Mineral Notes", base_notes: "Woody Notes, Musk", release_year: 2021, season: "All Seasons", description: "An electronic, futuristic masculine of bold innovation.", price_range: "$$" },
    { name: "Ultraviolet Man", type: "Eau de Toilette", gender: "Men", top_notes: "Bergamot, Aldehydes, Helional", heart_notes: "Violet, Tonka Bean, Magnetic", base_notes: "Amber, Musk, Sandalwood", release_year: 2001, season: "All Seasons", description: "A futuristic, electric masculine of unique personality.", price_range: "$$" },
    { name: "Pure XS", type: "Eau de Parfum", gender: "Men", top_notes: "Ginger, Vanilla, Blood Orange", heart_notes: "Musk, Oud, Jasmine", base_notes: "Patchouli, Sandalwood, Vetiver", release_year: 2017, season: "Fall", description: "A sensual, amber-oriental of irresistible depth.", price_range: "$$" },
  ],
  "Thierry Mugler": [
    { name: "Angel", type: "Eau de Parfum", gender: "Women", top_notes: "Helional, Bergamot, Melon, Coconut, Mandarin", heart_notes: "Red Berries, Plum, Jasmine, Rose, Lily of the Valley", base_notes: "Patchouli, Vanilla, Musk, Tonka Bean, Dark Chocolate", release_year: 1992, season: "Winter", description: "The legendary celestial oriental that redefined feminine perfumery.", price_range: "$$" },
    { name: "Alien", type: "Eau de Parfum", gender: "Women", top_notes: "Jasmine", heart_notes: "Woodsy Notes", base_notes: "White Amber, Cashmeran", release_year: 2005, season: "All Seasons", description: "A hypnotic solar jasmine of otherworldly magnetism.", price_range: "$$" },
    { name: "A*Men", type: "Eau de Toilette", gender: "Men", top_notes: "Coffee, Mint, Helional, Lavender", heart_notes: "Caramel, Patchouli", base_notes: "Musk, Amber, Vanilla, Tonka Bean, Dark Chocolate", release_year: 1996, season: "Winter", description: "A bold masculine counterpart to Angel with gourmand intensity.", price_range: "$$" },
    { name: "Womanity", type: "Eau de Parfum", gender: "Women", top_notes: "Caviar, Fig", heart_notes: "Woodsy Notes", base_notes: "Musks, Birch", release_year: 2010, season: "Summer", description: "An avant-garde savory-sweet fragrance defying conventions.", price_range: "$$" },
    { name: "Aura", type: "Eau de Parfum", gender: "Women", top_notes: "Rhubarb, Vanilla, Vanilla Orchid", heart_notes: "Tiare Flower", base_notes: "Musk, Sandalwood", release_year: 2017, season: "Spring", description: "A fresh, sensual feminine with a luminous solar quality.", price_range: "$$" },
    { name: "Angel Muse", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Hazelnut", heart_notes: "Vetiver", base_notes: "Patchouli, Vanilla, Caramel", release_year: 2016, season: "Fall", description: "A warm, soft interpretation of the legendary Angel.", price_range: "$$" },
    { name: "Innocent", type: "Eau de Parfum", gender: "Women", top_notes: "Peach, Apricot, Bergamot", heart_notes: "Rose, Jasmine, Freesia", base_notes: "Vanilla, Musk, Amber", release_year: 2000, season: "Spring", description: "A soft, romantic fruity-floral of tender femininity.", price_range: "$$" },
    { name: "Cologne", type: "Eau de Toilette", gender: "Unisex", top_notes: "Bergamot, Mandarin, Lime, Grapefruit", heart_notes: "Jasmine, Rose", base_notes: "Musk, Vanilla", release_year: 2001, season: "Summer", description: "A fresh, bright citrus of radiant simplicity.", price_range: "$$" },
    { name: "Alien Goddess", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Yuzu", heart_notes: "Jasmine, Cashmere Wood", base_notes: "Vanilla, White Amber", release_year: 2021, season: "Summer", description: "A radiant, divine feminine of solar warmth and luminosity.", price_range: "$$" },
    { name: "Bracelet", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Jasmine, Tuberose", heart_notes: "Jasmine, Tuberose, Ylang-Ylang", base_notes: "Sandalwood, Musk, Amber", release_year: 2020, season: "Summer", description: "A warm, sensual floral of sculpted elegance.", price_range: "$$" },
  ],
  "Lanvin": [
    { name: "Eclat d'Arpège", type: "Eau de Parfum", gender: "Women", top_notes: "Ivy, White Flowers, Cherry Blossom, Rose", heart_notes: "Tiare Flower, White Musk, Lychee Blossom", base_notes: "Musk, Sandalwood, Cedar", release_year: 2002, season: "Spring", description: "A luminous, fresh white floral of delicate femininity.", price_range: "$$" },
    { name: "Arpège", type: "Eau de Parfum", gender: "Women", top_notes: "Aldehydes, Bergamot, Neroli, Rosewood, Honeysuckle", heart_notes: "Jasmine, Lily of the Valley, Rose, Iris, Ylang-Ylang", base_notes: "Sandalwood, Vetiver, Musk, Oakmoss, Patchouli", release_year: 1927, season: "All Seasons", description: "A masterpiece of classical perfumery, the first round bottle.", price_range: "$$" },
    { name: "Jeanne Lanvin", type: "Eau de Parfum", gender: "Women", top_notes: "Bergamot, Peach, Mandarin, Violet", heart_notes: "Jasmine, Rose, Peony, Lily of the Valley", base_notes: "Musk, Sandalwood, Cedar, Amber", release_year: 2008, season: "Spring", description: "A modern homage to the iconic founder in a classic bottle.", price_range: "$$" },
    { name: "Oxygene", type: "Eau de Parfum", gender: "Women", top_notes: "Lily of the Valley, Violet, Hyacinth", heart_notes: "Freesia, Peony, Rose, Jasmine", base_notes: "Musk, Cedar, Sandalwood", release_year: 2000, season: "Spring", description: "A pure, airy floral as refreshing as a breath of spring.", price_range: "$$" },
    { name: "Rumeur", type: "Eau de Parfum", gender: "Women", top_notes: "Mandarin, Pear, Bergamot", heart_notes: "Rose, Lily, Peach", base_notes: "Woody Notes, Musk, Amber", release_year: 2006, season: "Spring", description: "A feminine whisper of fruity florals and soft woods.", price_range: "$$" },
    { name: "Marry Me!", type: "Eau de Parfum", gender: "Women", top_notes: "Litchi, Tangerine, Sparkling Notes", heart_notes: "Peony, Rose, Jasmine", base_notes: "Musk, Amber, Cedarwood", release_year: 2010, season: "Spring", description: "A romantic, joyful floral for the most special moment.", price_range: "$$" },
    { name: "Me", type: "Eau de Parfum", gender: "Women", top_notes: "Watermelon, Green Notes, Red Berries, Peach", heart_notes: "Rose, Peony, Jasmine", base_notes: "Musk, Amber, Vetiver, Cedar", release_year: 2013, season: "Spring", description: "A fresh, confident feminine celebrating individuality.", price_range: "$$" },
    { name: "Modern Princess", type: "Eau de Parfum", gender: "Women", top_notes: "Orange, Mandarin, Blackcurrant, Davana", heart_notes: "Peony, White Rose, Magnolia", base_notes: "Vetiver, Musk, Amber, White Cedar", release_year: 2017, season: "Spring", description: "A contemporary fairy tale in a radiant floral.", price_range: "$$" },
  ],
  "Nina Ricci": [
    { name: "L'Air du Temps", type: "Eau de Toilette", gender: "Women", top_notes: "Aldehydes, Bergamot, Gardenia, Rose, Jasmine, Carnation, Spice", heart_notes: "Rose, Iris, Carnation, Jasmine, Orris Root, Ylang-Ylang", base_notes: "Sandalwood, Cedar, Benzyl Benzoate, Musk, Civet, Ambergris", release_year: 1948, season: "Spring", description: "A legendary dove-bottled floral symbol of peace and love.", price_range: "$$" },
    { name: "Nina", type: "Eau de Toilette", gender: "Women", top_notes: "Apple, Bergamot, Caramel", heart_notes: "Jasmine, Peony, Rose", base_notes: "Cedar, Tonka Bean, Musk", release_year: 2006, season: "Fall", description: "A playful, sweet apple floral in an iconic apple-shaped bottle.", price_range: "$$" },
    { name: "Ricci Ricci", type: "Eau de Parfum", gender: "Women", top_notes: "Rhubarb, Yuzu, Galbanum, Violet Leaf", heart_notes: "Tuberose, Rose, Peony, Patchouli Leaf", base_notes: "Black Vanilla, Oakmoss Accord, Vetiver", release_year: 2009, season: "Spring", description: "A lush, feminine tuberose of passionate modernity.", price_range: "$$" },
    { name: "Luna Rossa", type: "Eau de Toilette", gender: "Women", top_notes: "Bergamot, Pink Pepper, Gardenia", heart_notes: "Jasmine, Peony, Freesia", base_notes: "Sandalwood, Musk", release_year: 2014, season: "Spring", description: "A luminous, elegant floral of timeless romance.", price_range: "$$" },
    { name: "Farouche", type: "Eau de Toilette", gender: "Women", top_notes: "Aldehydes, Bergamot, Petitgrain, Violet Leaf", heart_notes: "Lily of the Valley, Rose, Jasmine, Ylang-Ylang, Orris Root", base_notes: "Sandalwood, Oakmoss, Musk, Civet", release_year: 1974, season: "Spring", description: "A classic French chypre of quiet, wild elegance.", price_range: "$$" },
    { name: "Bella", type: "Eau de Toilette", gender: "Women", top_notes: "Bergamot, Fig, Peach", heart_notes: "Peony, Jasmine, Rose", base_notes: "Musk, Cedarwood, Sandalwood", release_year: 2019, season: "Spring", description: "A soft, radiant floral celebrating natural feminine beauty.", price_range: "$$" },
    { name: "L'Extase", type: "Eau de Parfum", gender: "Women", top_notes: "Rose, Pink Pepper, Black Pepper", heart_notes: "Rose, Jasmine, Patchouli", base_notes: "Vanilla, Amber, Musk", release_year: 2011, season: "Fall", description: "An ecstatic rose of sensual, opulent femininity.", price_range: "$$" },
    { name: "Mon Jeu", type: "Eau de Toilette", gender: "Women", top_notes: "Bergamot, Lemon, Blackcurrant", heart_notes: "Rose, Jasmine, Lily", base_notes: "Musk, Vanilla, Cedarwood", release_year: 2015, season: "Spring", description: "A fresh, playful feminine with a sweet, flirtatious charm.", price_range: "$$" },
  ],
};

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (user?.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    const body = await req.json().catch(() => ({}));
    const action = body.action || 'seed_perfumes';

    if (action === 'mark_brands_default') {
      // Mark all existing brands as is_default
      const brands = await base44.asServiceRole.entities.PerfumeBrand.list("-created_date", 500000);
      let updated = 0;
      for (const brand of brands) {
        if (!brand.is_default) {
          await base44.asServiceRole.entities.PerfumeBrand.update(brand.id, { is_default: true });
          updated++;
        }
      }
      return Response.json({ success: true, message: `Marked ${updated} brands as default` });
    }

    if (action === 'seed_perfumes') {
      // Get all brands from DB
      const brands = await base44.asServiceRole.entities.PerfumeBrand.list("-created_date", 500000);
      const brandMap = {};
      for (const b of brands) {
        brandMap[b.name] = b.id;
      }

      // Get existing perfumes to avoid duplicates
      const existingPerfumes = await base44.asServiceRole.entities.Perfume.list('-created_date', 500000);
      const existingNames = new Set(existingPerfumes.map(p => p.name?.toLowerCase()));

      let created = 0;
      let skipped = 0;
      const errors = [];

      for (const [brandName, perfumes] of Object.entries(BRAND_PERFUMES)) {
        const brandId = brandMap[brandName];
        if (!brandId) {
          errors.push(`Brand not found: ${brandName}`);
          continue;
        }

        for (const perfume of perfumes) {
          if (existingNames.has(perfume.name.toLowerCase())) {
            skipped++;
            continue;
          }

          try {
            await base44.asServiceRole.entities.Perfume.create({
              ...perfume,
              brand_id: brandId,
              brand_name: brandName,
              is_default: true,
              list: 'none',
              discontinued: false,
              time_of_day: 'All',
            });
            created++;
            existingNames.add(perfume.name.toLowerCase());
          } catch (e) {
            errors.push(`Failed to create ${perfume.name}: ${e.message}`);
          }
        }
      }

      return Response.json({
        success: true,
        created,
        skipped,
        errors,
        message: `Created ${created} perfumes, skipped ${skipped} existing`
      });
    }

    if (action === 'mark_perfumes_default') {
      // Mark all perfumes created by seeder as is_default
      const perfumes = await base44.asServiceRole.entities.Perfume.list("-created_date", 500000);
      let updated = 0;
      for (const p of perfumes) {
        if (!p.is_default) {
          await base44.asServiceRole.entities.Perfume.update(p.id, { is_default: true });
          updated++;
        }
      }
      return Response.json({ success: true, message: `Marked ${updated} perfumes as default` });
    }

    return Response.json({ error: 'Unknown action' }, { status: 400 });

  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});