import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    
    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Load built-in perfumers data from JSON file (static data)
    const perfumersJson = await Deno.readTextFile('./data/builtin_database/perfumers_builtin.json');
    const perfumersData = JSON.parse(perfumersJson);
    
    let imported = 0;
    let skipped = 0;

    // Import perfumers into this app
    for (const perfumer of perfumersData) {
      try {
        // Check if perfumer already exists
        const existing = await base44.entities.Perfumer.filter({ name: perfumer.name });
        
        if (existing.length === 0) {
          await base44.entities.Perfumer.create({
            name: perfumer.name || '',
            name_ar: perfumer.name_ar || '',
            nationality: perfumer.nationality || '',
            nationality_ar: perfumer.nationality_ar || '',
            gender: perfumer.gender || null,
            birth_year: perfumer.birth_year || null,
            death_year: perfumer.death_year || null,
            bio: perfumer.bio || '',
            website: perfumer.website || '',
            education: perfumer.education || '',
            famous_works: perfumer.famous_works || '',
            favorite_perfumes: perfumer.favorite_perfumes || '',
            favorite_notes: perfumer.favorite_notes || '',
            brand_ids: perfumer.brand_ids || '',
            brand_names: perfumer.brand_names || '',
            perfume_ids: perfumer.perfume_ids || '',
            perfume_names: perfumer.perfume_names || '',
            photo_url: perfumer.photo_url || '',
          });
          imported++;
        } else {
          skipped++;
        }
      } catch (e) {
        console.error(`Error importing perfumer ${perfumer.name}:`, e.message);
      }
    }

    return Response.json({
      message: `✅ تم استيراد ${imported} عطار. تم تخطي ${skipped} موجود بالفعل`,
      imported,
      skipped,
      total: imported + skipped
    });
  } catch (error) {
    return Response.json({ 
      error: error.message,
      message: `❌ ${error.message}`
    }, { status: 500 });
  }
});