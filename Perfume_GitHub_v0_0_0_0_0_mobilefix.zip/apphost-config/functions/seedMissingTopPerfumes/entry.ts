import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user || user.role !== 'admin') {
      return Response.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Top perfumes from timeline (1889-2026)
    const topPerfumes = [
      { name: "Jicky", brand: "Guerlain", year: 1889, notes: "Lavender, coumarin, vanilla", gender: "Unisex" },
      { name: "Peau d'Espagne", brand: "Fragonard", year: 1889, notes: "Rose, musk, civet", gender: "Women" },
      { name: "Violette Mousseuse", brand: "Pinaud", year: 1889, notes: "Violet, aldehydes", gender: "Women" },
      { name: "Eau de Lubin", brand: "Lubin", year: 1889, notes: "Rose, bergamot, musk", gender: "Women" },
      { name: "Chypre", brand: "Coty", year: 1910, notes: "Oakmoss, bergamot, labdanum", gender: "Women" },
      { name: "L'Origan", brand: "Coty", year: 1910, notes: "Florals, citrus", gender: "Women" },
      { name: "Chanel No. 5", brand: "Chanel", year: 1920, notes: "Aldehydes, jasmine, rose, sandalwood", gender: "Women" },
      { name: "Shalimar", brand: "Guerlain", year: 1920, notes: "Bergamot, iris, rose, vanilla", gender: "Women" },
      { name: "Coco", brand: "Chanel", year: 1920, notes: "Florals, amber, musk", gender: "Women" },
      { name: "Joy", brand: "Jean Patou", year: 1930, notes: "Rose, jasmine, ylang-ylang", gender: "Women" },
      { name: "Madame Rochas", brand: "Rochas", year: 1930, notes: "Florals, spice, musk", gender: "Women" },
      { name: "Youth Dew", brand: "Estée Lauder", year: 1940, notes: "Spices, patchouli, rose, amber", gender: "Women" },
      { name: "Miss Dior", brand: "Dior", year: 1940, notes: "Green notes, aldehyde, rose, oakmoss", gender: "Women" },
      { name: "Arpège", brand: "Lanvin", year: 1940, notes: "Aldehydes, rose, jasmine, sandalwood", gender: "Women" },
      { name: "L'Air du Temps", brand: "Nina Ricci", year: 1950, notes: "Carnation, rose, sandalwood", gender: "Women" },
      { name: "No. 19", brand: "Chanel", year: 1950, notes: "Aldehydes, iris, citrus, green", gender: "Women" },
      { name: "Rive Gauche", brand: "YSL", year: 1960, notes: "Aldehydes, rose, jasmine, vetiver", gender: "Women" },
      { name: "Calandre", brand: "Paco Rabanne", year: 1960, notes: "Aldehydes, rose, violet, sandalwood", gender: "Women" },
      { name: "Cristalle", brand: "Chanel", year: 1960, notes: "Aldehydes, citrus, jasmine, vetiver", gender: "Women" },
      { name: "Calèche", brand: "Hermès", year: 1960, notes: "Aldehydes, rose, jasmine, vetiver", gender: "Women" },
      { name: "Charlie", brand: "Revlon", year: 1970, notes: "Green, floral, aldehyde, musk", gender: "Women" },
      { name: "Opium", brand: "YSL", year: 1970, notes: "Spices, patchouli, myrrh, rose", gender: "Women" },
      { name: "Eau Sauvage", brand: "Dior", year: 1970, notes: "Lemon, hedione, jasmine, vetiver", gender: "Men" },
      { name: "Chloé", brand: "Chloé", year: 1970, notes: "Florals, aldehydes, amber", gender: "Women" },
      { name: "Drakkar Noir", brand: "Guy Laroche", year: 1980, notes: "Lavender, fir, sandalwood, musk", gender: "Men" },
      { name: "Giorgio", brand: "Giorgio Beverly Hills", year: 1980, notes: "Florals, peach, tuberose, patchouli", gender: "Women" },
      { name: "Poison", brand: "Dior", year: 1980, notes: "Tuberose, plum, opoponax, musk", gender: "Women" },
      { name: "CK One", brand: "Calvin Klein", year: 1990, notes: "Green tea, bergamot, musk, sandalwood", gender: "Unisex" },
      { name: "Angel", brand: "Thierry Mugler", year: 1990, notes: "Patchouli, caramel, chocolate, musk", gender: "Women" },
      { name: "L'Eau d'Issey", brand: "Miyake", year: 1990, notes: "Water, lotus, peony, cedar", gender: "Women" },
      { name: "Acqua di Giò", brand: "Armani", year: 2000, notes: "Bergamot, jasmine, rosemary, cedar", gender: "Men" },
      { name: "Light Blue", brand: "Dolce & Gabbana", year: 2000, notes: "Sicilian lemon, apple, cedar", gender: "Women" },
      { name: "La Vie Est Belle", brand: "Lancôme", year: 2000, notes: "Iris, praline, patchouli, vanilla", gender: "Women" },
      { name: "Allure", brand: "Chanel", year: 2000, notes: "Florals, amber, musk", gender: "Women" },
      { name: "Santal 33", brand: "Le Labo", year: 2010, notes: "Sandalwood, iris, cardamom, violet", gender: "Unisex" },
      { name: "Baccarat Rouge 540", brand: "Maison Francis Kurkdjian", year: 2010, notes: "Jasmine, saffron, amberwood, fir", gender: "Unisex" },
      { name: "Black Opium", brand: "YSL", year: 2010, notes: "Coffee, vanilla, white flowers", gender: "Women" },
      { name: "Prada L'Homme", brand: "Prada", year: 2010, notes: "Iris, ambroxan, cedar", gender: "Men" },
      { name: "Libre", brand: "YSL", year: 2020, notes: "Lavender, orange blossom, vanilla, musk", gender: "Women" },
      { name: "Good Girl Gone Bad", brand: "Kilian", year: 2020, notes: "Rose, tuberose, iris, vetiver", gender: "Women" },
      { name: "Dylan Blue", brand: "Versace", year: 2020, notes: "Fig, violet, patchouli, musk", gender: "Women" },
      { name: "Bleu de Chanel", brand: "Chanel", year: 2020, notes: "Citrus, ambroxan, sandalwood", gender: "Men" },
    ];

    let created = 0;
    let skipped = 0;

    for (const pf of topPerfumes) {
      // Check if brand exists
      let brand = await base44.asServiceRole.entities.PerfumeBrand.filter(
        { name: pf.brand },
        "name",
        1
      );

      let brandId;
      if (brand && brand.length > 0) {
        brandId = brand[0].id;
      } else {
        // Create brand if missing
        const newBrand = await base44.asServiceRole.entities.PerfumeBrand.create({
          name: pf.brand,
          year_established: pf.year,
          in_business: true,
        });
        brandId = newBrand.id;
      }

      // Check if perfume exists
      const existing = await base44.asServiceRole.entities.Perfume.filter(
        { name: pf.name, brand_id: brandId },
        "name",
        1
      );

      if (existing && existing.length > 0) {
        skipped++;
      } else {
        // Create perfume
        await base44.asServiceRole.entities.Perfume.create({
          name: pf.name,
          brand_id: brandId,
          brand_name: pf.brand,
          release_year: pf.year,
          gender: pf.gender,
          type: "Eau de Parfum",
          top_notes: pf.notes.split(",")[0].trim(),
          heart_notes: pf.notes.includes(",") ? pf.notes.split(",")[1].trim() : "",
          base_notes: pf.notes.split(",").length > 2 ? pf.notes.split(",")[2].trim() : "",
          description: `A classic fragrance from ${pf.year}. ${pf.notes}.`,
        });
        created++;
      }
    }

    return Response.json({
      success: true,
      message: `Seeding complete: ${created} created, ${skipped} already exist`,
      created,
      skipped,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});