/**
 * apply-android-icons.mjs
 * نسخ أيقونات المُطلِق المُعدّة من `android-icons/` إلى مشروع `android/` المولَّد،
 * حتى يحمل الـAPK أيقونتك أنت لا أيقونة Capacitor/Android الافتراضية.
 *
 * Copies prepared launcher icons from android-icons/ into the generated
 * android/ native project so your APK ships YOUR icon, not the default one.
 *
 * شغّليه بعد `npx cap add android` (أو `npx cap sync android`) وقبل بناء الـAPK:
 *   node scripts/apply-android-icons.mjs      (أو: npm run icons:android)
 */
import { cpSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const src = resolve('android-icons/app/src/main/res');
const dest = resolve('android/app/src/main/res');

if (!existsSync(src)) {
  console.error('❌ المصدر غير موجود / source missing:', src);
  process.exit(1);
}
if (!existsSync(dest)) {
  console.error('❌ مشروع android/ غير موجود. شغّلي أولاً: npx cap add android (أو npx cap sync android) ثم أعيدي.');
  console.error('   android/ project not found. Run `npx cap add android` (or `cap sync android`) first.');
  process.exit(1);
}
cpSync(src, dest, { recursive: true });
console.log('✅ نُسخت الأيقونات إلى android/app/src/main/res — أعيدي بناء الـAPK الآن.');
console.log('✅ Launcher icons copied — rebuild the APK now.');
