/**
 * download-perfume-images.mjs
 * Pulls perfume images listed in perfume_images_fragdb.json down to a local
 * folder, so the app can show perfume photos OFFLINE.
 *
 * RUN ON YOUR OWN MACHINE (needs internet — fimgs.net). Node 18+, no install.
 *
 * PowerShell (Windows):
 *   node scripts/download-perfume-images.mjs            # download ALL (~1.2 GB!)
 *   $env:LIMIT=300; node scripts/download-perfume-images.mjs   # first 300 (test)
 *   $env:DRY=1;     node scripts/download-perfume-images.mjs   # plan only
 *   Remove-Item Env:LIMIT,Env:DRY -ErrorAction SilentlyContinue # clear before full run
 *
 * macOS / Linux:
 *   LIMIT=300 node scripts/download-perfume-images.mjs
 *
 * Output:
 *   public/perfume-images/<file>.jpg                       ← the images
 *   src/data/builtin_database/perfume_images_local.json    ← "brand||name" → local path
 *
 * Resumable: re-running skips images already downloaded.
 */
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';

const MAP_FILE    = process.argv[2] || 'perfume_images_fragdb.json';
const OUT_DIR     = process.env.OUT || 'public/perfume-images';
const FOLDER      = OUT_DIR.replace(/^public[\/\\]/, '').replace(/[\/\\]+$/, '').replace(/\\/g, '/');
const URL_PREFIX  = '/' + FOLDER;
const MANIFEST    = process.env.MANIFEST || `src/data/builtin_database/${FOLDER.replace(/[^a-z0-9]+/gi, '_')}_local.json`;
const CONCURRENCY = 8;
const LIMIT = Number(process.env.LIMIT || 0);   // 0 = all
const DRY   = !!process.env.DRY;

function fileFromUrl(u) {
  const base = (u.split('?')[0].split('/').pop() || '').trim();
  return /\.(jpe?g|png|webp|gif|svg)$/i.test(base) ? base : (base || 'img') + '.jpg';
}

if (!existsSync(MAP_FILE)) {
  console.error(`✗ Cannot find "${MAP_FILE}". Put perfume_images_fragdb.json next to this command, or pass its path as an argument.`);
  process.exit(1);
}

const raw = JSON.parse(await readFile(MAP_FILE, 'utf8'));
const byKey = raw.by_key || raw;
let entries = Object.entries(byKey).filter(([, u]) => typeof u === 'string' && u.startsWith('http'));
if (LIMIT) entries = entries.slice(0, LIMIT);

await mkdir(OUT_DIR, { recursive: true });
const manifest = {};
let ok = 0, skip = 0, fail = 0, done = 0;

async function fetchImage(url) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), 20000);   // 20s timeout so a slow/hung server can't freeze a worker
  try {
    return await fetch(url, {
      signal: ctrl.signal,
      headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://www.fragrantica.com/' },
    });
  } finally { clearTimeout(t); }
}

async function downloadOne([key, url]) {
  const file = fileFromUrl(url);
  const dest = path.join(OUT_DIR, file);
  manifest[key] = `${URL_PREFIX}/${file}`;
  if (DRY) { ok++; return; }
  if (existsSync(dest)) { skip++; return; }
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const res = await fetchImage(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const buf = Buffer.from(await res.arrayBuffer());
      if (buf.length < 100) throw new Error('empty');
      await writeFile(dest, buf);
      ok++;
      return;
    } catch {
      if (attempt === 3) { fail++; delete manifest[key]; }
      else await new Promise(r => setTimeout(r, 500 * attempt));   // back off, then retry
    }
  }
}

const queue = [...entries];
async function worker() {
  while (queue.length) {
    const item = queue.shift();
    if (!item) break;
    await downloadOne(item);
    if (++done % 200 === 0 || done === entries.length) {
      process.stdout.write(`\r  ${done}/${entries.length}  ok:${ok} skip:${skip} fail:${fail}   `);
    }
  }
}

console.log(`${DRY ? '[DRY RUN] ' : ''}Pulling ${entries.length} perfume images → ${OUT_DIR}/`);
await Promise.all(Array.from({ length: CONCURRENCY }, worker));
await mkdir(path.dirname(MANIFEST), { recursive: true });
await writeFile(MANIFEST, JSON.stringify(manifest));
console.log(`\n✓ Done. ok:${ok} skip:${skip} fail:${fail}`);
console.log(`✓ Manifest: ${MANIFEST}  (${Object.keys(manifest).length} images mapped)`);
if (DRY) console.log('  (DRY run — nothing downloaded.)');
