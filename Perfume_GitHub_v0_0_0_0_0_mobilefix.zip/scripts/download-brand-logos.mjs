/**
 * download-brand-logos.mjs
 * Pulls every brand logo image listed in brand_logos_fragdb.json down to a
 * local folder, so the app can show logos OFFLINE.
 *
 * RUN THIS ON YOUR OWN MACHINE (it needs internet — fimgs.net):
 *
 *   node scripts/download-brand-logos.mjs
 *
 * Useful options:
 *   LIMIT=300 node scripts/download-brand-logos.mjs   # only first 300 (test)
 *   DRY=1     node scripts/download-brand-logos.mjs   # plan only, no download
 *   node scripts/download-brand-logos.mjs path/to/brand_logos_fragdb.json
 *
 * Output:
 *   public/brand-logos/<brand-slug>.<ext>                 ← the images
 *   src/data/builtin_database/brand_logos_local.json      ← name → local path
 *
 * It is RESUMABLE: re-running skips files already downloaded.
 * Requires Node 18+ (built-in fetch). No npm install needed.
 */
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';

const MAP_FILE   = process.argv[2] || 'brand_logos_fragdb.json';
const OUT_DIR    = 'public/brand-logos';
const MANIFEST   = 'src/data/builtin_database/brand_logos_local.json';
const CONCURRENCY = 8;
const LIMIT = Number(process.env.LIMIT || 0);   // 0 = all
const DRY   = !!process.env.DRY;

function fileFromUrl(u) {
  const base = (u.split('?')[0].split('/').pop() || '').trim();
  return /\.(jpe?g|png|webp|gif|svg)$/i.test(base) ? base : (base || 'logo') + '.jpg';
}

if (!existsSync(MAP_FILE)) {
  console.error(`✗ Cannot find "${MAP_FILE}". Put brand_logos_fragdb.json next to this command, or pass its path as an argument.`);
  process.exit(1);
}

const raw = JSON.parse(await readFile(MAP_FILE, 'utf8'));
const byName = raw.by_name || raw;                 // supports {by_name:{…}} or flat {name:url}
let entries = Object.entries(byName).filter(([, u]) => typeof u === 'string' && u.startsWith('http'));
if (LIMIT) entries = entries.slice(0, LIMIT);

await mkdir(OUT_DIR, { recursive: true });
const manifest = {};
let ok = 0, skip = 0, fail = 0, done = 0;

async function downloadOne([name, url]) {
  const file = fileFromUrl(url);
  const dest = path.join(OUT_DIR, file);
  manifest[name] = `/brand-logos/${file}`;
  if (DRY) { ok++; return; }
  if (existsSync(dest)) { skip++; return; }
  try {
    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0', 'Referer': 'https://www.fragrantica.com/' },
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 100) throw new Error('empty/too small');
    await writeFile(dest, buf);
    ok++;
  } catch {
    fail++;
    delete manifest[name];
  }
}

const queue = [...entries];
async function worker() {
  while (queue.length) {
    await downloadOne(queue.shift());
    if (++done % 100 === 0 || done === entries.length) {
      process.stdout.write(`\r  ${done}/${entries.length}  ok:${ok} skip:${skip} fail:${fail}   `);
    }
  }
}

console.log(`${DRY ? '[DRY RUN] ' : ''}Pulling ${entries.length} brand logos → ${OUT_DIR}/`);
await Promise.all(Array.from({ length: CONCURRENCY }, worker));
await mkdir(path.dirname(MANIFEST), { recursive: true });
await writeFile(MANIFEST, JSON.stringify(manifest));
console.log(`\n✓ Done. ok:${ok} skip:${skip} fail:${fail}`);
console.log(`✓ Manifest: ${MANIFEST}  (${Object.keys(manifest).length} logos mapped)`);
if (DRY) console.log('  (DRY run — nothing was downloaded. Remove DRY=1 to download for real.)');
